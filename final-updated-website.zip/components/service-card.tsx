import Image from "next/image"
import Link from "next/link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock } from "lucide-react"

interface ServiceCardProps {
  title: string
  description: string
  price: string
  duration: string
  imageSrc: string
}

export default function ServiceCard({ title, description, price, duration, imageSrc }: ServiceCardProps) {
  return (
    <Card className="overflow-hidden transition-all hover:shadow-lg">
      <div className="aspect-video relative overflow-hidden">
        <Image
          src={imageSrc || "/placeholder.svg?height=200&width=400"}
          alt={title}
          fill
          className="object-cover transition-transform hover:scale-105"
          unoptimized={imageSrc?.startsWith("blob:")} // אפשר תמונות מקומיות
        />
      </div>
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <div className="flex justify-between items-center">
          <span className="text-lg font-bold text-pink-500">{price}</span>
          <div className="flex items-center text-gray-500">
            <Clock className="h-4 w-4 mr-1" />
            <span className="text-sm">{duration}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-6 pt-0">
        <Link href="/booking" className="w-full">
          <Button className="w-full bg-pink-500 hover:bg-pink-600" onClick={() => console.log("TODO: Add functionality")}>הזמנת תור</Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
