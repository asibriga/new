"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useStore } from "@/lib/store"
import { useToast } from "@/components/ui/use-toast"
import { BadgePercent, X, Check } from "lucide-react"

interface CouponCodeInputProps {
  onApply: (discount: number, type: "percentage" | "fixed", code: string) => void
  onRemove: () => void
}

export default function CouponCodeInput({ onApply, onRemove }: CouponCodeInputProps) {
  const [couponCode, setCouponCode] = useState("")
  const [isApplied, setIsApplied] = useState(false)
  const [isValidating, setIsValidating] = useState(false)
  const [appliedDiscount, setAppliedDiscount] = useState(0)
  const [discountType, setDiscountType] = useState<"percentage" | "fixed">("percentage")
  const [appliedCode, setAppliedCode] = useState("")

  const validateCoupon = useStore((state) => state.validateCoupon)
  const { toast } = useToast()

  const handleApplyCoupon = () => {
    if (!couponCode.trim()) {
      toast({
        title: "שגיאה",
        description: "אנא הכנס קוד קופון",
        variant: "destructive",
      })
      return
    }

    setIsValidating(true)

    // Validate the coupon code
    const result = validateCoupon(couponCode)

    setTimeout(() => {
      setIsValidating(false)

      if (result.valid) {
        setIsApplied(true)
        setAppliedDiscount(result.value)
        setDiscountType(result.type as "percentage" | "fixed")
        setAppliedCode(couponCode)

        // Call the onApply callback
        onApply(result.value, result.type as "percentage" | "fixed", couponCode)

        toast({
          title: "הקופון הופעל בהצלחה",
          description: `קיבלת ${result.type === "percentage" ? `${result.value}%` : `${result.value} ₪`} הנחה`,
        })
      } else {
        toast({
          title: "קוד קופון לא תקין",
          description: "קוד הקופון שהזנת אינו תקף או שפג תוקפו",
          variant: "destructive",
        })
      }
    }, 500)
  }

  const handleRemoveCoupon = () => {
    setIsApplied(false)
    setCouponCode("")
    setAppliedDiscount(0)
    setAppliedCode("")
    onRemove()
  }

  return (
    <div className="space-y-3">
      <Label htmlFor="coupon-code">קוד קופון</Label>

      {!isApplied ? (
        <div className="flex space-x-2 rtl:space-x-reverse">
          <div className="relative flex-1">
            <BadgePercent className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
            <Input
              id="coupon-code"
              value={couponCode}
              onChange={(e) => setCouponCode(e.target.value)}
              placeholder="הכנס קוד קופון"
              className="pl-10"
              disabled={isValidating}
            />
          </div>
          <Button
            onClick={handleApplyCoupon}
            disabled={isValidating || !couponCode.trim()}
            className="bg-pink-500 hover:bg-pink-600"
          >
            {isValidating ? "בודק..." : "הפעל"}
          </Button>
        </div>
      ) : (
        <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-md">
          <div className="flex items-center">
            <Check className="h-5 w-5 text-green-500 mr-2" />
            <div>
              <p className="font-medium text-green-800">{appliedCode}</p>
              <p className="text-sm text-green-600">
                הנחה של {discountType === "percentage" ? `${appliedDiscount}%` : `${appliedDiscount} ₪`}
              </p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={handleRemoveCoupon} className="text-red-500 hover:text-red-700">
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  )
}
