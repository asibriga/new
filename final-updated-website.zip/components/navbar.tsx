"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, X, User, ShoppingCart, LogIn } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useStore } from "@/lib/store"
import { Badge } from "@/components/ui/badge"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()
  const loggedInCustomerId = useStore((state) => state.loggedInCustomerId)
  const loggedInAdminId = useStore((state) => state.loggedInAdminId)
  const cart = useStore((state) => state.cart)
  const addPageView = useStore((state) => state.addPageView)
  const addVisitor = useStore((state) => state.addVisitor)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  useEffect(() => {
    // Track page view
    if (typeof window !== "undefined") {
      try {
        // Add page view
        addPageView(pathname)

        // Check if this is a new visitor
        const hasVisited = sessionStorage.getItem("hasVisited")
        if (!hasVisited) {
          addVisitor()
          sessionStorage.setItem("hasVisited", "true")
        }
      } catch (error) {
        console.warn("Error tracking page view:", error)
        // Continue without tracking
      }
    }
  }, [pathname, addPageView, addVisitor])

  // Check if we're on an admin page
  const isAdminPage = pathname?.startsWith("/admin")

  // Don't show the navbar on admin pages
  if (isAdminPage) {
    return null
  }

  const cartItemCount = cart.reduce((total, item) => total + item.quantity, 0)

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="hidden sm:flex sm:items-center">
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              {loggedInCustomerId ? (
                <Link href="/client/dashboard">
                  <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700" onClick={() => console.log("TODO: Add functionality")}>
                    <User className="h-5 w-5 mr-1" />
                    החשבון שלי
                  </Button>
                </Link>
              ) : (
                <Link href="/login">
                  <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700" onClick={() => console.log("TODO: Add functionality")}>
                    <LogIn className="h-5 w-5 mr-1" />
                    התחברות
                  </Button>
                </Link>
              )}
              <Link href="/shop/cart">
                <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700 relative" onClick={() => console.log("TODO: Add functionality")}>
                  <ShoppingCart className="h-5 w-5" />
                  {cartItemCount > 0 && (
                    <Badge className="absolute -top-2 -right-2 bg-pink-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center p-0">
                      {cartItemCount}
                    </Badge>
                  )}
                </Button>
              </Link>
            </div>
          </div>

          <div className="flex-1 flex justify-center">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/" className="text-2xl font-bold text-pink-600">
                May Beauty
              </Link>
            </div>
          </div>

          <div className="hidden sm:ml-6 sm:flex sm:space-x-8 rtl:space-x-reverse">
            <Link
              href="/"
              className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                pathname === "/"
                  ? "border-pink-500 text-gray-900"
                  : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
              }`}
            >
              בית
            </Link>
            <Link
              href="/services"
              className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                pathname === "/services"
                  ? "border-pink-500 text-gray-900"
                  : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
              }`}
            >
              שירותים
            </Link>
            <Link
              href="/gallery"
              className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                pathname === "/gallery"
                  ? "border-pink-500 text-gray-900"
                  : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
              }`}
            >
              גלריה
            </Link>
            <Link
              href="/booking"
              className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                pathname === "/booking"
                  ? "border-pink-500 text-gray-900"
                  : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
              }`}
            >
              קביעת תור
            </Link>
            <Link
              href="/shop"
              className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                pathname === "/shop"
                  ? "border-pink-500 text-gray-900"
                  : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
              }`}
            >
              חנות
            </Link>
            <Link
              href="/contact"
              className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                pathname === "/contact"
                  ? "border-pink-500 text-gray-900"
                  : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
              }`}
            >
              צור קשר
            </Link>
            <Link
              href="/about"
              className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                pathname === "/about"
                  ? "border-pink-500 text-gray-900"
                  : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
              }`}
            >
              אודות
            </Link>
          </div>

          <div className="-mr-2 flex items-center sm:hidden">
            <button
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-pink-500"
            >
              <span className="sr-only">Open main menu</span>
              {isMenuOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <Link
              href="/"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                pathname === "/"
                  ? "border-pink-500 text-pink-700 bg-pink-50"
                  : "border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700"
              }`}
              onClick={toggleMenu}
            >
              בית
            </Link>
            <Link
              href="/services"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                pathname === "/services"
                  ? "border-pink-500 text-pink-700 bg-pink-50"
                  : "border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700"
              }`}
              onClick={toggleMenu}
            >
              שירותים
            </Link>
            <Link
              href="/gallery"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                pathname === "/gallery"
                  ? "border-pink-500 text-pink-700 bg-pink-50"
                  : "border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700"
              }`}
              onClick={toggleMenu}
            >
              גלריה
            </Link>
            <Link
              href="/booking"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                pathname === "/booking"
                  ? "border-pink-500 text-pink-700 bg-pink-50"
                  : "border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700"
              }`}
              onClick={toggleMenu}
            >
              קביעת תור
            </Link>
            <Link
              href="/shop"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                pathname === "/shop"
                  ? "border-pink-500 text-pink-700 bg-pink-50"
                  : "border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700"
              }`}
              onClick={toggleMenu}
            >
              חנות
            </Link>
            <Link
              href="/contact"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                pathname === "/contact"
                  ? "border-pink-500 text-pink-700 bg-pink-50"
                  : "border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700"
              }`}
              onClick={toggleMenu}
            >
              צור קשר
            </Link>
            <Link
              href="/about"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                pathname === "/about"
                  ? "border-pink-500 text-pink-700 bg-pink-50"
                  : "border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700"
              }`}
              onClick={toggleMenu}
            >
              אודות
            </Link>
          </div>

          <div className="pt-4 pb-3 border-t border-gray-200">
            <div className="flex items-center px-4 space-x-3 rtl:space-x-reverse">
              {loggedInCustomerId ? (
                <Link
                  href="/client/dashboard"
                  className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 w-full"
                  onClick={toggleMenu}
                >
                  <User className="h-5 w-5 inline-block mr-2" />
                  החשבון שלי
                </Link>
              ) : (
                <Link
                  href="/login"
                  className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 w-full"
                  onClick={toggleMenu}
                >
                  <LogIn className="h-5 w-5 inline-block mr-2" />
                  התחברות
                </Link>
              )}
              <Link
                href="/shop/cart"
                className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 w-full"
                onClick={toggleMenu}
              >
                <ShoppingCart className="h-5 w-5 inline-block mr-2" />
                עגלת קניות {cartItemCount > 0 && `(${cartItemCount})`}
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}
