"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useStore } from "@/store/store"
import { Share2, Copy, Check } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function ReferralCodeWidget({ customerId, referralCode: initialReferralCode, referrals = 0 }) {
  const [referralCode, setReferralCode] = useState(initialReferralCode || "")
  const [copied, setCopied] = useState(false)
  const { toast } = useToast()

  const updateCustomer = useStore((state) => state.updateCustomer)
  const addLog = useStore((state) => state.addLog)

  // Local implementation of generateReferralCode
  const generateReferralCode = () => {
    if (!customerId) return ""

    const code = `MAY${customerId.substring(0, 4)}${Math.floor(Math.random() * 1000)
      .toString()
      .padStart(3, "0")}`

    // Update the customer with the new code
    if (typeof updateCustomer === "function") {
      try {
        updateCustomer(customerId, { referralCode: code })
      } catch (error) {
        console.error("Failed to update customer with referral code:", error)
      }
    }

    // Log the action if addLog exists
    if (typeof addLog === "function") {
      try {
        addLog({
          type: "system",
          message: `קוד הפניה ${code} נוצר`,
          user: "system",
        })
      } catch (error) {
        console.error("Failed to log referral code generation:", error)
      }
    }

    return code
  }

  const handleGenerateCode = () => {
    if (!customerId) return

    const code = generateReferralCode()
    setReferralCode(code)

    toast({
      title: "קוד הפניה נוצר",
      description: "קוד ההפניה שלך נוצר בהצלחה. שתפי אותו עם חברים!",
    })
  }

  const handleCopyCode = () => {
    if (!referralCode) return

    navigator.clipboard.writeText(referralCode)
    setCopied(true)

    toast({
      title: "הקוד הועתק",
      description: "קוד ההפניה הועתק ללוח. כעת תוכלי לשתף אותו!",
    })

    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card className="border-pink-200">
      <CardHeader className="pb-3">
        <CardTitle className="text-xl flex items-center">
          <Share2 className="h-5 w-5 text-pink-500 ml-2" />
          הפניית חברים
        </CardTitle>
        <CardDescription>הפני חברות וקבלי נקודות נאמנות</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {referralCode ? (
            <div className="space-y-3">
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <Input value={referralCode} readOnly className="bg-gray-50" />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleCopyCode}
                  className={copied ? "text-green-500" : ""}
                >
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
              <p className="text-sm text-gray-500">
                שתפי את הקוד הזה עם חברות. כאשר הן נרשמות ומזינות את הקוד, תקבלי 50 נקודות נאמנות!
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-sm text-gray-500">
                צרי קוד הפניה אישי ושתפי אותו עם חברות. כאשר הן נרשמות ומזינות את הקוד, תקבלי 50 נקודות נאמנות!
              </p>
              <Button className="w-full bg-pink-500 hover:bg-pink-600" onClick={handleGenerateCode}>
                יצירת קוד הפניה
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
