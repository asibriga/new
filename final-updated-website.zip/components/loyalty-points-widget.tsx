import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Award, Gift } from "lucide-react"

interface LoyaltyPointsWidgetProps {
  points: number
  tier: string
  nextTier: string
  pointsToNextTier: number
}

export default function LoyaltyPointsWidget({
  points = 0,
  tier = "רגיל",
  nextTier = "כסף",
  pointsToNextTier = 100,
}: LoyaltyPointsWidgetProps) {
  // Calculate progress percentage
  const totalPointsNeeded = points + pointsToNextTier
  const progressPercentage = Math.min(Math.round((points / totalPointsNeeded) * 100), 100)

  return (
    <Card className="border-pink-100 shadow-md overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-pink-100 to-rose-100 pb-2">
        <CardTitle className="text-lg text-pink-800 flex items-center">
          <Award className="h-5 w-5 mr-2" />
          נקודות נאמנות
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-gray-600">הרמה שלך: {tier}</span>
          <span className="text-sm text-gray-600">הרמה הבאה: {nextTier}</span>
        </div>

        <Progress
          value={progressPercentage}
          className="h-3 bg-pink-100"
          indicatorClassName="bg-gradient-to-r from-pink-500 to-rose-400"
        />

        <div className="flex justify-between items-center mt-2">
          <div className="flex items-center">
            <Gift className="h-4 w-4 text-pink-600 mr-1" />
            <span className="font-medium text-pink-800">{points} נקודות</span>
          </div>
          <span className="text-sm text-gray-600">{pointsToNextTier} נקודות לרמה הבאה</span>
        </div>

        <div className="mt-4 bg-pink-50 p-3 rounded-lg border border-pink-100">
          <h4 className="font-medium text-pink-800 mb-1">איך צוברים נקודות?</h4>
          <ul className="text-sm text-gray-600 space-y-1 list-disc list-inside">
            <li>קביעת תור - 10 נקודות</li>
            <li>רכישה בחנות - נקודה לכל 10₪</li>
            <li>הפניית חברה - 50 נקודות</li>
            <li>ביקור ביום ההולדת - 100 נקודות</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}
