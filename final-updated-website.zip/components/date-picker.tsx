"use client"

import * as React from "react"
import { format } from "date-fns"
import { he } from "date-fns/locale"
import { CalendarIcon } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface DatePickerProps {
  date: Date | undefined
  setDate: (date: Date | undefined) => void
  className?: string
  showTimeSelect?: boolean
  label?: string
  placeholder?: string
  disabled?: boolean
  disabledDates?: Date[]
  minDate?: Date
  maxDate?: Date
  onTimeChange?: (time: string) => void
  selectedTime?: string
  timeSlots?: string[]
  confirmButtonText?: string
  cancelButtonText?: string
  newTimeButtonText?: string
}

export function DatePicker({
  date,
  setDate,
  className,
  showTimeSelect = false,
  label,
  placeholder = "בחר תאריך",
  disabled = false,
  disabledDates = [],
  minDate,
  maxDate,
  onTimeChange,
  selectedTime,
  timeSlots = [],
  confirmButtonText = "עדכון תור",
  cancelButtonText = "ביטול",
  newTimeButtonText = "שעה חדשה",
}: DatePickerProps) {
  const [open, setOpen] = React.useState(false)
  const [internalDate, setInternalDate] = React.useState<Date | undefined>(date)
  const [internalTime, setInternalTime] = React.useState<string | undefined>(selectedTime)

  // Generate time slots if none provided
  const availableTimeSlots = React.useMemo(() => {
    if (timeSlots.length > 0) return timeSlots

    const slots = []
    for (let hour = 8; hour < 20; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const formattedHour = hour.toString().padStart(2, "0")
        const formattedMinute = minute.toString().padStart(2, "0")
        slots.push(`${formattedHour}:${formattedMinute}`)
      }
    }
    return slots
  }, [timeSlots])

  const handleConfirm = () => {
    if (internalDate) {
      setDate(internalDate)
      if (showTimeSelect && onTimeChange && internalTime) {
        onTimeChange(internalTime)
      }
      setOpen(false)
    }
  }

  const handleCancel = () => {
    setInternalDate(date)
    setInternalTime(selectedTime)
    setOpen(false)
  }

  return (
    <div className={cn("grid gap-2", className)}>
      {label && <label className="text-sm font-medium text-right">{label}</label>}
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn(
              "w-full justify-between text-right font-normal",
              !date && "text-muted-foreground",
              disabled && "cursor-not-allowed opacity-50",
            )}
            disabled={disabled}
           onClick={() => console.log("TODO: Add functionality")}>
            {date ? format(date, "dd/MM/yyyy", { locale: he }) : placeholder}
            <CalendarIcon className="ml-2 h-4 w-4" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <div className="p-3">
            <h3 className="text-lg font-semibold text-right mb-2">{showTimeSelect ? "שינוי תור" : "בחר תאריך חדש"}</h3>
            {showTimeSelect && (
              <p className="text-sm text-muted-foreground text-right mb-4">בחר תאריך ושעה חדשים לתור שלך</p>
            )}
          </div>

          <Calendar
            mode="single"
            selected={internalDate}
            onSelect={setInternalDate}
            disabled={(date) =>
              disabled ||
              disabledDates.some((disabledDate) => disabledDate.toDateString() === date.toDateString()) ||
              (minDate ? date < minDate : false) ||
              (maxDate ? date > maxDate : false)
            }
            initialFocus
            className="rtl-calendar"
            locale={he}
          />

          {showTimeSelect && (
            <div className="p-3 border-t">
              <div className="mb-4">
                <label className="text-sm font-medium block mb-2 text-right">{newTimeButtonText}</label>
                <Select value={internalTime} onValueChange={setInternalTime} disabled={!internalDate}>
                  <SelectTrigger className="w-full text-right">
                    <SelectValue placeholder="בחר שעה" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableTimeSlots.map((time) => (
                      <SelectItem key={time} value={time} className="text-right">
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between p-3 border-t">
            <Button variant="outline" onClick={handleCancel} className="w-[45%]">
              {cancelButtonText}
            </Button>
            <Button
              onClick={handleConfirm}
              disabled={!internalDate || (showTimeSelect && !internalTime)}
              className="w-[45%] bg-pink-500 hover:bg-pink-600"
            >
              {confirmButtonText}
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
