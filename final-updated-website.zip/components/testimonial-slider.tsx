"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"
import Image from "next/image"

const testimonials = [
  {
    id: 1,
    name: "מיכל כהן",
    text: "אני מגיעה לסטודיו כבר שנתיים ותמיד יוצאת מרוצה. השירות מקצועי והתוצאות מדהימות!",
    rating: 5,
    image: "/images/testimonial-1.jpg",
  },
  {
    id: 2,
    name: "שירה לוי",
    text: "הציפורניים שלי נשארות יפות ושלמות לאורך זמן. ממליצה בחום על הסטודיו!",
    rating: 5,
    image: "/images/testimonial-2.jpg",
  },
  {
    id: 3,
    name: "רונית אברהם",
    text: "הסטודיו נקי ומטופח, והצוות מקצועי ונעים. אני תמיד מקבלת מחמאות על הציפורניים.",
    rating: 4,
    image: "/images/testimonial-3.jpg",
  },
]

export default function TestimonialSlider() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1))
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1))
  }

  return (
    <div className="relative max-w-4xl mx-auto">
      <Card className="border-pink-100 shadow-md">
        <CardContent className="p-8">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="w-24 h-24 md:w-32 md:h-32 relative rounded-full overflow-hidden flex-shrink-0">
              <Image
                src={testimonials[currentIndex].image || "/placeholder.svg"}
                alt={testimonials[currentIndex].name}
                fill
                className="object-cover"
              />
            </div>
            <div className="flex-1 text-center md:text-right">
              <div className="flex justify-center md:justify-end mb-2">
                {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                ))}
                {[...Array(5 - testimonials[currentIndex].rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-gray-300" />
                ))}
              </div>
              <p className="text-gray-700 mb-4 text-lg italic">"{testimonials[currentIndex].text}"</p>
              <h4 className="font-semibold text-lg">{testimonials[currentIndex].name}</h4>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-center mt-6 gap-2">
        <Button
          variant="outline"
          size="icon"
          onClick={prevSlide}
          className="rounded-full border-pink-200 text-pink-600 hover:bg-pink-50"
        >
          <ChevronRight className="h-5 w-5" />
          <span className="sr-only">Previous</span>
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={nextSlide}
          className="rounded-full border-pink-200 text-pink-600 hover:bg-pink-50"
        >
          <ChevronLeft className="h-5 w-5" />
          <span className="sr-only">Next</span>
        </Button>
      </div>
    </div>
  )
}
