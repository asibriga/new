"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { useStore } from "@/lib/store"
import { useEffect, useState } from "react"

export default function GallerySection() {
  const siteContent = useStore((state) => state.siteContent)
  const [galleryImages, setGalleryImages] = useState<string[]>([])

  // Update gallery images when store changes
  useEffect(() => {
    // Default empty array if siteContent or images or gallery is undefined
    const defaultGallery = Array(6).fill("/placeholder.svg?height=300&width=300")

    // Safely access gallery images with fallback to default
    const storeGallery = siteContent?.images?.gallery || defaultGallery

    setGalleryImages(storeGallery)
  }, [siteContent])

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">הגלריה שלנו</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">צפי בעבודות האחרונות שלנו והתרשמי מהסגנון והאיכות</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {galleryImages.length > 0
            ? galleryImages.slice(0, 6).map((image, index) => (
                <Card key={index} className="overflow-hidden group cursor-pointer">
                  <CardContent className="p-0">
                    <div className="aspect-square relative overflow-hidden">
                      <Image
                        src={image || "/placeholder.svg?height=300&width=300"}
                        alt={`Gallery image ${index + 1}`}
                        fill
                        className="object-cover transition-transform group-hover:scale-105"
                        unoptimized={image.startsWith("blob:")}
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                    </div>
                  </CardContent>
                </Card>
              ))
            : // Fallback to placeholder images if no gallery images
              Array(6)
                .fill(0)
                .map((_, index) => (
                  <Card key={index} className="overflow-hidden group cursor-pointer">
                    <CardContent className="p-0">
                      <div className="aspect-square relative overflow-hidden">
                        <Image
                          src={`/placeholder.svg?height=300&width=300`}
                          alt={`Gallery image ${index + 1}`}
                          fill
                          className="object-cover transition-transform group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/gallery">
            <Button variant="outline" className="border-pink-300 text-pink-600 hover:bg-pink-50" onClick={() => console.log("TODO: Add functionality")}>
              לגלריה המלאה
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
