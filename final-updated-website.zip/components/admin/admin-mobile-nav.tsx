"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  Calendar,
  CreditCard,
  Home,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  Settings,
  ShoppingBag,
  Users,
  Bell,
  ShoppingCart,
  LineChart,
  FileText,
  Database,
  Ticket,
  Award,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useStore } from "@/lib/store"
import { Badge } from "@/components/ui/badge"

export default function AdminMobileNav() {
  const pathname = usePathname()
  const router = useRouter()
  const [open, setOpen] = useState(false)

  // Get unread notifications
  const notifications = useStore((state) => state.notifications)
  const unreadNotifications = notifications.filter((notification) => !notification.isRead)

  // Get pending appointments
  const appointments = useStore((state) => state.appointments)
  const pendingAppointments = appointments.filter((appointment) => appointment.status === "pending")

  // Get pending orders
  const orders = useStore((state) => state.orders)
  const pendingOrders = orders.filter((order) => order.status === "pending")

  const handleLogout = () => {
    localStorage.removeItem("adminAuthenticated")
    router.push("/admin/login")
  }

  return (
    <>
      {/* Top navigation bar */}
      <div className="sticky top-0 z-40 flex h-16 items-center justify-between bg-white px-4 shadow-sm">
        <div className="flex items-center">
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button type="button" variant="ghost" size="icon" onClick={() => setOpen(true)}>
                <Menu className="h-6 w-6" />
                <span className="sr-only">פתח תפריט</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[250px] sm:w-[300px]">
              <div className="flex flex-col h-full">
                <div className="px-2 py-4 border-b">
                  <h2 className="text-lg font-bold text-pink-500">May Beauty</h2>
                  <p className="text-sm text-muted-foreground">פאנל ניהול</p>
                </div>

                <div className="flex-1 overflow-auto py-2">
                  <nav className="grid items-start px-4 text-sm font-medium">
                    <Link
                      href="/admin"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <LayoutDashboard className="h-4 w-4" />
                      דף הבית
                      {unreadNotifications.length > 0 && (
                        <Badge className="ml-auto flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-pink-500">
                          {unreadNotifications.length}
                        </Badge>
                      )}
                    </Link>
                    <Link
                      href="/admin/appointments"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/appointments" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <Calendar className="h-4 w-4" />
                      ניהול תורים
                      {pendingAppointments.length > 0 && (
                        <Badge className="ml-auto flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-pink-500">
                          {pendingAppointments.length}
                        </Badge>
                      )}
                    </Link>
                    <Link
                      href="/admin/orders"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/orders" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <ShoppingCart className="h-4 w-4" />
                      הזמנות
                      {pendingOrders.length > 0 && (
                        <Badge className="ml-auto flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-pink-500">
                          {pendingOrders.length}
                        </Badge>
                      )}
                    </Link>
                    <Link
                      href="/admin/customers"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/customers" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <Users className="h-4 w-4" />
                      לקוחות
                    </Link>
                    <Link
                      href="/admin/services"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/services" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <Package className="h-4 w-4" />
                      שירותים
                    </Link>
                    <Link
                      href="/admin/shop"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/shop" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <ShoppingBag className="h-4 w-4" />
                      חנות
                    </Link>
                    <Link
                      href="/admin/finances"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/finances" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <CreditCard className="h-4 w-4" />
                      פיננסים
                    </Link>
                    <Link
                      href="/admin/analytics"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/analytics" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <LineChart className="h-4 w-4" />
                      אנליטיקה
                    </Link>
                    <Link
                      href="/admin/logs"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/logs" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <FileText className="h-4 w-4" />
                      לוגים
                    </Link>
                    <Link
                      href="/admin/data-management"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/data-management" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <Database className="h-4 w-4" />
                      ניהול נתונים
                    </Link>
                    <Link
                      href="/admin/coupons"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/coupons" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <Ticket className="h-4 w-4" />
                      קופונים
                    </Link>
                    <Link
                      href="/admin/loyalty"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/loyalty" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <Award className="h-4 w-4" />
                      תוכנית נאמנות
                    </Link>
                    <Link
                      href="/admin/settings"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                        pathname === "/admin/settings" && "bg-pink-50 text-pink-600",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <Settings className="h-4 w-4" />
                      הגדרות
                    </Link>
                  </nav>
                </div>

                <div className="border-t p-2">
                  <Link href="/" onClick={() => setOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start" onClick={() => console.log("TODO: Add functionality")}>
                      <Home className="h-5 w-5 mr-2" />
                      <span>לאתר הראשי</span>
                    </Button>
                  </Link>
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50"
                    onClick={() => {
                      handleLogout()
                      setOpen(false)
                    }}
                  >
                    <LogOut className="h-5 w-5 mr-2" />
                    <span>התנתקות</span>
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>

          <div className="mr-4">
            <h1 className="text-lg font-bold text-pink-500">May Beauty</h1>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {unreadNotifications.length > 0 && (
            <Link href="/admin">
              <Button variant="ghost" size="icon" className="relative" onClick={() => console.log("TODO: Add functionality")}>
                <Bell className="h-5 w-5" />
                <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-pink-500">
                  {unreadNotifications.length}
                </Badge>
              </Button>
            </Link>
          )}
          {pendingOrders.length > 0 && (
            <Link href="/admin/orders">
              <Button variant="ghost" size="icon" className="relative" onClick={() => console.log("TODO: Add functionality")}>
                <ShoppingCart className="h-5 w-5" />
                <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-pink-500">
                  {pendingOrders.length}
                </Badge>
              </Button>
            </Link>
          )}
          <Link href="/">
            <Button variant="ghost" size="icon" onClick={() => console.log("TODO: Add functionality")}>
              <Home className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>

      {/* Bottom navigation bar for mobile */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t md:hidden">
        <div className="flex justify-around">
          <Link href="/admin">
            <Button
              variant="ghost"
              className={cn("flex flex-col py-2 h-auto", pathname === "/admin" && "text-pink-600")}
             onClick={() => console.log("TODO: Add functionality")}>
              <LayoutDashboard className="h-5 w-5" />
              <span className="text-xs mt-1">דף הבית</span>
              {unreadNotifications.length > 0 && (
                <Badge className="absolute -top-1 right-0 h-5 w-5 p-0 flex items-center justify-center bg-pink-500">
                  {unreadNotifications.length}
                </Badge>
              )}
            </Button>
          </Link>
          <Link href="/admin/appointments">
            <Button
              variant="ghost"
              className={cn(
                "flex flex-col py-2 h-auto relative",
                pathname === "/admin/appointments" && "text-pink-600",
              )}
             onClick={() => console.log("TODO: Add functionality")}>
              <Calendar className="h-5 w-5" />
              <span className="text-xs mt-1">תורים</span>
              {pendingAppointments.length > 0 && (
                <Badge className="absolute -top-1 right-0 h-5 w-5 p-0 flex items-center justify-center bg-pink-500">
                  {pendingAppointments.length}
                </Badge>
              )}
            </Button>
          </Link>
          <Link href="/admin/orders">
            <Button
              variant="ghost"
              className={cn("flex flex-col py-2 h-auto relative", pathname === "/admin/orders" && "text-pink-600")}
             onClick={() => console.log("TODO: Add functionality")}>
              <ShoppingCart className="h-5 w-5" />
              <span className="text-xs mt-1">הזמנות</span>
              {pendingOrders.length > 0 && (
                <Badge className="absolute -top-1 right-0 h-5 w-5 p-0 flex items-center justify-center bg-pink-500">
                  {pendingOrders.length}
                </Badge>
              )}
            </Button>
          </Link>
          <Link href="/admin/customers">
            <Button
              variant="ghost"
              className={cn("flex flex-col py-2 h-auto", pathname === "/admin/customers" && "text-pink-600")}
             onClick={() => console.log("TODO: Add functionality")}>
              <Users className="h-5 w-5" />
              <span className="text-xs mt-1">לקוחות</span>
            </Button>
          </Link>
        </div>
      </div>
    </>
  )
}
