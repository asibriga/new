"use client"

import { useState, useEffect } from "react"

interface DateRangePickerProps {
  dateRange: { from: Date | null; to: Date | null }
  onDateRangeChange: (dateRange: { from: Date; to: Date }) => void
  className?: string
}

export function DateRangePicker({ dateRange, onDateRangeChange, className }: DateRangePickerProps) {
  // Initialize with default dates if null values are provided
  const [selectedRange, setSelectedRange] = useState<{ from: Date; to: Date }>({
    from: dateRange.from || new Date(),
    to: dateRange.to || new Date(),
  })
  const [isOpen, setIsOpen] = useState(false)

  // Update selected range when props change
  useEffect(() => {
    if (dateRange.from && dateRange.to) {
      setSelectedRange({
        from: dateRange.from,
        to: dateRange.to,
      })
    }
  }, [dateRange])

  const handleSelect = (date: Date | undefined) => {
    if (!date) return

    const newRange = { ...selectedRange }

    if (!newRange.from || (newRange.from && newRange.to)) {
      newRange.from = date
      newRange.to = date
    } else if (date < newRange.from) {
      newRange.to = newRange.from
      newRange.from = date
    } else {
      newRange.to = date
    }

    setSelectedRange(newRange)
  }

  const handleApply = () => {
    onDateRangeChange(selectedRange)
    setIsOpen(false)
  }

  const handleCancel = () => {
    setSelectedRange({
      from: dateRange.from || new Date(),
      to: dateRange.to || new Date(),
    })
    setIsOpen(false)
  }

  const predefinedRanges = [
    {
      label: "היום",
      getRange: () => {
        const today = new Date()
        return { from: today, to: today }
      },
    },
    {
      label: "אתמול",
      getRange: () => {
        const yesterday = new Date()
        yesterday.setDate(yesterday.getDate() - 1)
        return { from: yesterday, to: yesterday }
      },
    },
    {
      label: "השבוע",
      getRange: () => {
        const today = new Date()
        const startOfWeek = new Date(today)
        startOfWeek.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1)) // Monday
        return { from: startOfWeek, to: today }
      },
    },
    {
      label: "החודש",
      getRange: () => {
        const today = new Date()
        const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)
        return { from: startOfMonth, to: today }
      },
    },
    {
      label: "החודש הקודם",
      getRange: () => {
        const today = new Date()
        const startOfLastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1)
        const endOfLastMonth = new Date(today.getFullYear(), today.getMonth(), 0)
        return { from: startOfLastMonth, to: endOfLastMonth }
      },
    },
    {
      label: "הרבעון",
      getRange: () => {
        const today = new Date()
        const quarter = Math.floor(today.getMonth() / 3)
        const startOfQuarter = new Date(today.getFullYear(), quarter * 3, 1)
        return { from: startOfQuarter, to: today }
      },
    },
    {
      label: "השנה",
      getRange: () => {
        const today = new Date()
        const startOfYear = new Date(today.getFullYear(), 0, 1)
        return { from: startOfYear, to: today }
      },
    },
  ]

  const handlePredefinedRange = (getRange: () => { from: Date; to: Date }) => {
    const newRange = getRange()
    setSelectedRange(newRange)
    onDateRangeChange(newRange)
    setIsOpen(false)
  }

  // Format dates safely
  const formatDate = (date: Date | null) => {
    if (!date) return "N/A"
    try {
      return date.toLocaleDateString()
    } catch (e) {
      console.error("Error formatting date:", e)
      return "Invalid date"
    }
  }

  return (
    <div className={className}>
      <div className="relative">
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center justify-between w-full px-3 py-2 text-sm border rounded-md shadow-sm bg-background hover:bg-accent"
        >
          <span>
            {formatDate(selectedRange.from)} - {formatDate(selectedRange.to)}
          </span>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-4 h-4 ml-2"
          >
            <rect width="18" height="18" x="3" y="4" rx="2" ry="2"></rect>
            <line x1="16" x2="16" y1="2" y2="6"></line>
            <line x1="8" x2="8" y1="2" y2="6"></line>
            <line x1="3" x2="21" y1="10" y2="10"></line>
          </svg>
        </button>

        {isOpen && (
          <div className="absolute z-50 mt-1 bg-background border rounded-md shadow-lg p-4 w-80">
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-2">
                {predefinedRanges.map((range) => (
                  <button
                    key={range.label}
                    type="button"
                    onClick={() => handlePredefinedRange(range.getRange)}
                    className="px-3 py-1 text-sm border rounded hover:bg-accent"
                  >
                    {range.label}
                  </button>
                ))}
              </div>

              <div className="pt-4 border-t">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-sm mb-1">מתאריך</label>
                    <input
                      type="date"
                      value={selectedRange.from.toISOString().split("T")[0]}
                      onChange={(e) => {
                        const date = new Date(e.target.value)
                        if (!isNaN(date.getTime())) {
                          setSelectedRange({ ...selectedRange, from: date })
                        }
                      }}
                      className="w-full px-2 py-1 border rounded text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-1">עד תאריך</label>
                    <input
                      type="date"
                      value={selectedRange.to.toISOString().split("T")[0]}
                      onChange={(e) => {
                        const date = new Date(e.target.value)
                        if (!isNaN(date.getTime())) {
                          setSelectedRange({ ...selectedRange, to: date })
                        }
                      }}
                      className="w-full px-2 py-1 border rounded text-sm"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2 space-x-reverse pt-4">
                <button
                  type="button"
                  onClick={handleCancel}
                  className="px-3 py-1 text-sm border rounded hover:bg-accent"
                >
                  ביטול
                </button>
                <button
                  type="button"
                  onClick={handleApply}
                  className="px-3 py-1 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90"
                >
                  החל
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
