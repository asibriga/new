"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useStore } from "@/lib/store"
import { useToast } from "@/components/ui/use-toast"
import { format } from "date-fns"
import { Calendar } from "@/components/ui/calendar"
import { he } from "date-fns/locale"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"

export default function AddEventForm() {
  const { toast } = useToast()
  const addHoliday = useStore((state) => state.addHoliday)
  const addClosedDay = useStore((state) => state.addClosedDay)

  const [eventName, setEventName] = useState("")
  const [eventDate, setEventDate] = useState<Date | undefined>(new Date())
  const [eventType, setEventType] = useState<"holiday" | "closed" | "specific-hours">("holiday")
  const [startTime, setStartTime] = useState("09:00")
  const [endTime, setEndTime] = useState("10:00")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [activeTab, setActiveTab] = useState<"holiday" | "closed" | "specific-hours">("holiday")

  // Generate time options from 7:00 to 22:00
  const timeOptions = Array.from({ length: 31 }, (_, i) => {
    const hour = Math.floor(i / 2) + 7
    const minute = (i % 2) * 30
    return `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`
  })

  const handleAddEvent = () => {
    if (!eventName || !eventDate) {
      toast({
        title: "שגיאה",
        description: "אנא מלא את כל השדות הנדרשים",
        variant: "destructive",
      })
      return
    }

    try {
      const formattedDate = format(eventDate, "yyyy-MM-dd")

      if (eventType === "holiday") {
        addHoliday({
          name: eventName,
          date: formattedDate,
        })
        toast({
          title: "החג נוסף בהצלחה",
          description: `${eventName} נוסף ללוח השנה בתאריך ${format(eventDate, "dd/MM/yyyy")}`,
        })
      } else if (eventType === "closed") {
        addClosedDay({
          name: eventName,
          date: formattedDate,
          isSpecificHours: false,
        })
        toast({
          title: "היום הסגור נוסף בהצלחה",
          description: `${eventName} נוסף ללוח השנה בתאריך ${format(eventDate, "dd/MM/yyyy")}`,
        })
      } else if (eventType === "specific-hours") {
        addClosedDay({
          name: eventName,
          date: formattedDate,
          isSpecificHours: true,
          startTime: startTime,
          endTime: endTime,
        })
        toast({
          title: "השעות הסגורות נוספו בהצלחה",
          description: `${eventName} (${startTime}-${endTime}) נוסף ללוח השנה בתאריך ${format(eventDate, "dd/MM/yyyy")}`,
        })
      }

      // Reset form and close dialog
      setEventName("")
      setEventDate(new Date())
      setStartTime("09:00")
      setEndTime("10:00")
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Error adding event:", error)
      toast({
        title: "שגיאה בהוספת האירוע",
        description: "אירעה שגיאה בהוספת האירוע. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>הוספת אירוע חדש</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs
            value={activeTab}
            onValueChange={(value: "holiday" | "closed" | "specific-hours") => {
              setActiveTab(value)
              setEventType(value)
            }}
          >
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="holiday">חג</TabsTrigger>
              <TabsTrigger value="closed">יום סגור</TabsTrigger>
              <TabsTrigger value="specific-hours">שעות סגורות</TabsTrigger>
            </TabsList>

            <div className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="event-name">שם האירוע</Label>
                <Input
                  id="event-name"
                  value={eventName}
                  onChange={(e) => setEventName(e.target.value)}
                  placeholder="הזן את שם האירוע"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="event-date">תאריך</Label>
                <div className="relative">
                  <Calendar
                    mode="single"
                    selected={eventDate}
                    onSelect={(date) => {
                      if (date) {
                        setEventDate(date)
                      }
                    }}
                    locale={he}
                    initialFocus
                    className="border rounded-md p-3 rtl"
                  />
                </div>
              </div>

              {activeTab === "specific-hours" && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="start-time">שעת התחלה</Label>
                    <Select value={startTime} onValueChange={setStartTime}>
                      <SelectTrigger id="start-time">
                        <SelectValue placeholder="בחר שעת התחלה" />
                      </SelectTrigger>
                      <SelectContent>
                        {timeOptions.map((time) => (
                          <SelectItem key={`start-${time}`} value={time}>
                            {time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end-time">שעת סיום</Label>
                    <Select value={endTime} onValueChange={setEndTime}>
                      <SelectTrigger id="end-time">
                        <SelectValue placeholder="בחר שעת סיום" />
                      </SelectTrigger>
                      <SelectContent>
                        {timeOptions.map((time) => (
                          <SelectItem key={`end-${time}`} value={time}>
                            {time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}

              <Button className="bg-pink-500 hover:bg-pink-600 w-full" onClick={() => setIsDialogOpen(true)}>
                הוספת אירוע
              </Button>
            </div>
          </Tabs>
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>אישור הוספת אירוע</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p>האם אתה בטוח שברצונך להוסיף את האירוע הבא?</p>
            <div className="mt-4 space-y-2 bg-gray-50 p-3 rounded-md">
              <p>
                <strong>שם:</strong> {eventName}
              </p>
              <p>
                <strong>תאריך:</strong> {eventDate ? format(eventDate, "dd/MM/yyyy") : ""}
              </p>
              <p>
                <strong>סוג:</strong>{" "}
                {eventType === "holiday" ? "חג" : eventType === "closed" ? "יום סגור" : "שעות סגורות"}
              </p>
              {eventType === "specific-hours" && (
                <p>
                  <strong>שעות:</strong> {startTime} - {endTime}
                </p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              ביטול
            </Button>
            <Button className="bg-pink-500 hover:bg-pink-600" onClick={handleAddEvent}>
              אישור
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
