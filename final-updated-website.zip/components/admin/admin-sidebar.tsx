"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  BarChart3,
  Calendar,
  CreditCard,
  Settings,
  ShoppingBag,
  Users,
  FileText,
  Home,
  LogOut,
  Database,
  Star,
  UserCog,
} from "lucide-react"

export default function AdminSidebar() {
  const pathname = usePathname()
  const [isCollapsed, setIsCollapsed] = useState(false)

  const routes = [
    {
      label: "דף הבית",
      icon: Home,
      href: "/admin",
      active: pathname === "/admin",
    },
    {
      label: "תורים",
      icon: Calendar,
      href: "/admin/appointments",
      active: pathname?.startsWith("/admin/appointments"),
    },
    {
      label: "לקוחות",
      icon: Users,
      href: "/admin/customers",
      active: pathname?.startsWith("/admin/customers"),
    },
    {
      label: "ניהול משתמשים",
      icon: UserCog,
      href: "/admin/users",
      active: pathname?.startsWith("/admin/users"),
    },
    {
      label: "שירותים",
      icon: FileText,
      href: "/admin/services",
      active: pathname?.startsWith("/admin/services"),
    },
    {
      label: "חנות",
      icon: ShoppingBag,
      href: "/admin/shop",
      active: pathname?.startsWith("/admin/shop"),
    },
    {
      label: "הזמנות",
      icon: CreditCard,
      href: "/admin/orders",
      active: pathname?.startsWith("/admin/orders"),
    },
    {
      label: "פיננסים",
      icon: CreditCard,
      href: "/admin/finances",
      active: pathname?.startsWith("/admin/finances"),
    },
    {
      label: "אנליטיקס",
      icon: BarChart3,
      href: "/admin/analytics",
      active: pathname?.startsWith("/admin/analytics"),
    },
    {
      label: "לוגים",
      icon: FileText,
      href: "/admin/logs",
      active: pathname?.startsWith("/admin/logs"),
    },
    {
      label: "ניהול נתונים",
      icon: Database,
      href: "/admin/data-management",
      active: pathname?.startsWith("/admin/data-management"),
    },
    {
      label: "המלצות",
      icon: Star,
      href: "/admin/recommendations",
      active: pathname?.startsWith("/admin/recommendations"),
    },
    {
      label: "הגדרות",
      icon: Settings,
      href: "/admin/settings",
      active: pathname?.startsWith("/admin/settings"),
    },
  ]

  return (
    <div className={cn("h-full border-r bg-gray-100/40 flex flex-col", isCollapsed ? "w-[70px]" : "w-60")}>
      <div className="p-3 flex flex-col h-full">
        <div className="space-y-2 py-4 flex flex-col flex-1">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={cn(
                "text-sm group flex p-3 w-full justify-start font-medium cursor-pointer hover:text-pink-700 hover:bg-pink-100/50 rounded-lg transition",
                route.active ? "text-pink-700 bg-pink-100" : "text-gray-500",
              )}
            >
              <div className="flex items-center flex-1">
                <route.icon className={cn("h-5 w-5 mr-3", route.active ? "text-pink-700" : "text-gray-500")} />
                {!isCollapsed && <span>{route.label}</span>}
              </div>
            </Link>
          ))}
        </div>
        <Link
          href="/"
          className="text-sm group flex p-3 w-full justify-start font-medium cursor-pointer hover:text-pink-700 hover:bg-pink-100/50 rounded-lg transition text-gray-500"
        >
          <div className="flex items-center flex-1">
            <LogOut className="h-5 w-5 mr-3 text-gray-500" />
            {!isCollapsed && <span>חזרה לאתר</span>}
          </div>
        </Link>
      </div>
    </div>
  )
}
