"use client"

import { useState, useEffect } from "react"
import { format, getDay, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday } from "date-fns"
import { he } from "date-fns/locale"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useStore } from "@/lib/store"
import { isIsraeliHoliday, getHolidayName } from "@/lib/israeli-holidays"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Check } from "lucide-react"
import "../admin/calendar-rtl.css"
import { useToast } from "@/components/ui/use-toast"

export default function AdminCalendar() {
  const [date, setDate] = useState<Date>(new Date())
  const [holidayName, setHolidayName] = useState<string | null>(null)
  const [isMobile, setIsMobile] = useState(false)
  const { toast } = useToast()

  const appointments = useStore((state) => state.appointments)
  const holidays = useStore((state) => state.holidays)
  const closedDays = useStore((state) => state.closedDays)
  const closedHours = useStore((state) => state.closedHours)
  const updateAppointment = useStore((state) => state.updateAppointment)

  // Check if mobile
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)

    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  // Update holiday name when date changes
  useEffect(() => {
    if (date) {
      setHolidayName(getHolidayName(date))
    } else {
      setHolidayName(null)
    }
  }, [date])

  // Function to get appointments for the selected date
  const getAppointmentsForDate = (selectedDate: Date | undefined) => {
    if (!selectedDate) return []

    const formattedDate = selectedDate.toISOString().split("T")[0]

    return appointments.filter((appointment) => appointment.date === formattedDate)
  }

  // Function to check if a day has appointments
  const hasAppointments = (day: Date) => {
    const formattedDate = day.toISOString().split("T")[0]
    return appointments.some((appointment) => appointment.date === formattedDate)
  }

  // Function to check if a day is a holiday
  const isHoliday = (day: Date) => {
    const formattedDate = day.toISOString().split("T")[0]
    return holidays?.some((holiday) => holiday.date === formattedDate) || isIsraeliHoliday(day)
  }

  // Function to check if a day is closed
  const isClosed = (day: Date) => {
    const formattedDate = day.toISOString().split("T")[0]
    return closedDays?.some((closedDay) => closedDay.date === formattedDate)
  }

  // Function to check if a day has closed hours
  const hasClosedHours = (day: Date) => {
    const formattedDate = day.toISOString().split("T")[0]
    return closedHours?.some((ch) => ch.date === formattedDate)
  }

  const selectedDateAppointments = getAppointmentsForDate(date)

  // Group appointments by customer and time
  const groupedAppointments = selectedDateAppointments.reduce((groups, appointment) => {
    const key = `${appointment.customerPhone}-${appointment.time}`
    if (!groups[key]) {
      groups[key] = {
        id: appointment.id,
        customerId: appointment.customerId,
        customerName: appointment.customerName,
        customerPhone: appointment.customerPhone,
        time: appointment.time,
        status: appointment.status,
        notes: appointment.notes,
        services: [],
        totalPrice: 0,
      }
    }

    groups[key].services.push({
      name: appointment.serviceName,
      price: appointment.price || 0,
    })

    groups[key].totalPrice += appointment.price || 0

    return groups
  }, {})

  // Function to render calendar
  const renderCalendar = () => {
    // Hebrew days of week (Sunday is first)
    const daysOfWeek = ["א'", "ב'", "ג'", "ד'", "ה'", "ו'", "ש'"]

    // Get the current month and year
    const currentMonth = date.getMonth()
    const currentYear = date.getFullYear()

    // Get the first day of the month
    const monthStart = startOfMonth(date)

    // Get the last day of the month
    const monthEnd = endOfMonth(date)

    // Get all days in the month
    const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd })

    // Get the day of the week for the first day (0 = Sunday, 1 = Monday, etc.)
    const startDay = getDay(monthStart)

    // Create an array to hold all calendar cells
    const calendarCells = []

    // Add empty cells for days before the start of the month
    for (let i = 0; i < startDay; i++) {
      calendarCells.push(null)
    }

    // Add cells for each day in the month
    daysInMonth.forEach((day) => {
      calendarCells.push(day)
    })

    // Calculate total cells needed (7 days * up to 6 rows)
    const totalCells = 7 * Math.ceil((startDay + daysInMonth.length) / 7)

    // Add empty cells at the end to complete the grid
    const emptyCellsAtEnd = totalCells - calendarCells.length
    for (let i = 0; i < emptyCellsAtEnd; i++) {
      calendarCells.push(null)
    }

    // Group cells into rows
    const rows = []
    for (let i = 0; i < calendarCells.length; i += 7) {
      rows.push(calendarCells.slice(i, i + 7))
    }

    return (
      <div className="calendar-container rtl" dir="rtl">
        <div className="text-center mb-6">
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                const newDate = new Date(date)
                newDate.setMonth(newDate.getMonth() - 1)
                setDate(newDate)
              }}
              className="rounded-full hover:bg-pink-50 hover:text-pink-600 transition-colors"
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
            <h2 className="text-xl font-bold text-pink-600">{format(date, "MMMM yyyy", { locale: he })}</h2>
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                const newDate = new Date(date)
                newDate.setMonth(newDate.getMonth() + 1)
                setDate(newDate)
              }}
              className="rounded-full hover:bg-pink-50 hover:text-pink-600 transition-colors"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Days of week header */}
        <div className="grid grid-cols-7 gap-1 mb-2">
          {daysOfWeek.map((day, index) => (
            <div key={index} className="text-center font-medium text-gray-600 py-1">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar grid */}
        <div className="space-y-1">
          {rows.map((row, rowIndex) => (
            <div key={rowIndex} className="grid grid-cols-7 gap-1">
              {row.map((day, dayIndex) => {
                if (!day) {
                  // Empty cell
                  return <div key={`empty-${rowIndex}-${dayIndex}`} className="h-10 md:h-12 p-1"></div>
                }

                const isCurrentMonth = day.getMonth() === currentMonth
                const isSelectedDay = date && isSameDay(day, date)
                const hasAppointmentsToday = hasAppointments(day)
                const isHolidayToday = isHoliday(day)
                const isClosedToday = isClosed(day)
                const hasClosedHoursToday = hasClosedHours(day)

                return (
                  <div
                    key={day.toString()}
                    onClick={() => setDate(day)}
                    className={`
                      h-10 md:h-12 p-1 rounded-md flex flex-col items-center justify-center relative cursor-pointer
                      ${!isCurrentMonth ? "text-gray-300" : ""}
                      ${isToday(day) ? "bg-pink-100 text-pink-800 font-bold" : ""}
                      ${isSelectedDay ? "bg-pink-500 text-white font-bold" : ""}
                      ${!isSelectedDay && !isToday(day) ? "hover:bg-pink-50" : ""}
                      ${isHolidayToday && !isSelectedDay ? "bg-red-100 text-red-800" : ""}
                      ${isClosedToday && !isSelectedDay ? "bg-orange-100 text-orange-800" : ""}
                      ${hasClosedHoursToday && !isSelectedDay && !isClosedToday ? "bg-yellow-50 text-yellow-800" : ""}
                    `}
                  >
                    <span className="text-sm md:text-base font-medium">{day.getDate()}</span>
                    <div className="flex gap-0.5 mt-1">
                      {hasAppointmentsToday && <span className="w-1.5 h-1.5 bg-pink-500 rounded-full"></span>}
                      {hasClosedHoursToday && <span className="w-1.5 h-1.5 bg-yellow-500 rounded-full"></span>}
                      {isClosedToday && <span className="w-1.5 h-1.5 bg-orange-500 rounded-full"></span>}
                      {isHolidayToday && <span className="w-1.5 h-1.5 bg-red-500 rounded-full"></span>}
                    </div>
                  </div>
                )
              })}
            </div>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap gap-2 justify-center text-xs">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-pink-100 ml-1 rounded-sm"></div>
            <span>היום</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-pink-500 ml-1 rounded-sm"></div>
            <span>נבחר</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-100 ml-1 rounded-sm"></div>
            <span>חג</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-orange-100 ml-1 rounded-sm"></div>
            <span>יום סגור</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-yellow-50 ml-1 rounded-sm"></div>
            <span>שעות סגורות</span>
          </div>
        </div>
      </div>
    )
  }

  function calculateEndTime(startTime, notes) {
    try {
      if (!startTime) return "לא זמין"

      let totalDurationMinutes = 0

      try {
        if (notes) {
          const parsedNotes = JSON.parse(notes)
          if (parsedNotes.totalDuration) {
            totalDurationMinutes = Number.parseInt(parsedNotes.totalDuration)
          } else if (parsedNotes.services && Array.isArray(parsedNotes.services)) {
            totalDurationMinutes = parsedNotes.services.reduce((total, service) => {
              return total + (service.duration || 0)
            }, 0)
          }
        }
      } catch (e) {
        console.error("Error parsing appointment notes:", e)
        totalDurationMinutes = 60 // Default duration
      }

      // If we couldn't extract a duration, use a default
      if (totalDurationMinutes <= 0) {
        totalDurationMinutes = 60 // Default duration
      }

      const [hours, minutes] = startTime.split(":").map(Number)
      if (isNaN(hours) || isNaN(minutes)) return "לא זמין"

      const startDate = new Date()
      startDate.setHours(hours, minutes, 0, 0)

      const endDate = new Date(startDate.getTime() + totalDurationMinutes * 60000)
      const endHours = endDate.getHours().toString().padStart(2, "0")
      const endMinutes = endDate.getMinutes().toString().padStart(2, "0")

      return `${endHours}:${endMinutes}`
    } catch (error) {
      console.error("Error calculating end time:", error)
      return "לא זמין"
    }
  }

  return (
    <div className={`flex ${isMobile ? "flex-col" : "flex-row"} gap-6`} dir="rtl">
      <div className={isMobile ? "w-full mb-4" : "md:w-1/2"}>{renderCalendar()}</div>

      <div className={isMobile ? "w-full" : "md:w-1/2"}>
        <h3 className="text-lg font-medium mb-4 text-right">
          {date ? `תורים ליום ${date.toLocaleDateString("he-IL")}` : "בחרי תאריך"}
        </h3>

        {holidayName && <Badge className="mb-4 bg-red-500">{holidayName}</Badge>}

        {Object.values(groupedAppointments).length > 0 ? (
          <div className="space-y-3">
            {Object.values(groupedAppointments).map((appointment, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="text-right">
                      <p className="font-medium">
                        {appointment.time} - {calculateEndTime(appointment.time, appointment.notes)}
                      </p>
                      <div className="text-sm text-muted-foreground">
                        {appointment.services.map((service, idx) => (
                          <div key={idx}>
                            {service.name} {service.price ? `- ₪${service.price}` : ""}
                          </div>
                        ))}
                        {appointment.totalPrice > 0 && (
                          <div className="font-medium mt-1">סה"כ: ₪{appointment.totalPrice}</div>
                        )}
                      </div>
                    </div>
                    <div className="text-left">
                      <p className="font-medium">{appointment.customerName}</p>
                      <p className="text-sm text-muted-foreground">
                        {appointment.status === "confirmed"
                          ? "מאושר"
                          : appointment.status === "completed"
                            ? "הושלם"
                            : appointment.status === "cancelled"
                              ? "בוטל"
                              : "ממתין לאישור"}
                      </p>
                      <p className="text-sm text-muted-foreground">{appointment.customerPhone}</p>
                      {appointment.status === "pending" && (
                        <Button
                          size="sm"
                          className="mt-2 bg-green-500 hover:bg-green-600"
                          onClick={() => {
                            // Approve the appointment
                            updateAppointment(appointment.id, { status: "confirmed" })
                            toast({
                              title: "התור אושר",
                              description: `התור של ${appointment.customerName} אושר בהצלחה`,
                            })
                          }}
                        >
                          <Check className="h-4 w-4 mr-1" />
                          אישור
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground">אין תורים לתאריך זה</p>
        )}
      </div>
    </div>
  )
}
