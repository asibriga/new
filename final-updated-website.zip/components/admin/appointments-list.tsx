"use client"

import { useState, useEffect } from "react"
import { useStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { he } from "date-fns/locale"
import { Calendar, Clock, Search, Filter, Edit, Trash, Check } from "lucide-react"
import { DateRangePicker } from "@/components/admin/date-range-picker"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Card, CardContent } from "@/components/ui/card"

interface AppointmentsListProps {
  dateFilter?: string
  calculateEndTime?: (startTime: string, notes: string) => string
}

export default function AppointmentsList({ calculateEndTime }) {
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateRange, setDateRange] = useState({ from: null, to: null })
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedAppointment, setSelectedAppointment] = useState(null)
  const [editFormData, setEditFormData] = useState({
    status: "",
    time: "",
    notes: "",
  })
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [appointmentToDelete, setAppointmentToDelete] = useState(null)
  const [isMobile, setIsMobile] = useState(false)

  // Get appointments from store
  const appointments = useStore((state) => state.appointments)
  const updateAppointment = useStore((state) => state.updateAppointment)
  const deleteAppointment = useStore((state) => state.deleteAppointment)
  const services = useStore((state) => state.services)
  const [selectedDate, setSelectedDate] = useState(new Date())

  // Check if mobile
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)

    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  // Filter appointments based on search and filters
  const filteredAppointments = appointments.filter((appointment) => {
    // Search filter
    if (
      searchQuery &&
      !appointment.customerName.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !appointment.serviceName.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false
    }

    // Status filter
    if (statusFilter && statusFilter !== "all" && appointment.status !== statusFilter) {
      return false
    }

    // Date range filter
    if (dateRange.from && dateRange.to) {
      const appointmentDate = new Date(appointment.date)
      if (appointmentDate < dateRange.from || appointmentDate > dateRange.to) {
        return false
      }
    }

    return true
  })

  // Sort appointments by date and time
  const sortedAppointments = [...filteredAppointments].sort((a, b) => {
    const dateA = new Date(`${a.date}T${a.time}`)
    const dateB = new Date(`${b.date}T${b.time}`)
    return dateB - dateA
  })

  const handleEditClick = (appointment) => {
    setSelectedAppointment(appointment)
    setEditFormData({
      status: appointment.status,
      time: appointment.time,
      notes: appointment.notes,
    })
    setIsEditDialogOpen(true)
  }

  const handleSaveEdit = () => {
    if (!selectedAppointment) return

    updateAppointment(selectedAppointment.id, {
      status: editFormData.status,
      time: editFormData.time,
      notes: editFormData.notes,
    })

    setIsEditDialogOpen(false)
    setSelectedAppointment(null)

    toast({
      title: "התור עודכן",
      description: "פרטי התור עודכנו בהצלחה",
    })
  }

  const handleDeleteClick = (appointment) => {
    setAppointmentToDelete(appointment)
    setIsDeleteDialogOpen(true)
  }

  const handleConfirmDelete = () => {
    if (!appointmentToDelete) return

    deleteAppointment(appointmentToDelete.id)
    setIsDeleteDialogOpen(false)
    setAppointmentToDelete(null)

    toast({
      title: "התור נמחק",
      description: "התור נמחק בהצלחה",
    })
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "confirmed":
        return <Badge className="bg-green-500">מאושר</Badge>
      case "pending":
        return (
          <Badge variant="outline" className="text-orange-500 border-orange-500">
            ממתין
          </Badge>
        )
      case "cancelled":
        return <Badge variant="destructive">בוטל</Badge>
      case "completed":
        return <Badge className="bg-blue-500">הושלם</Badge>
      default:
        return null
    }
  }

  const renderAppointments = () => {
    const dayStr = format(selectedDate, "yyyy-MM-dd")
    const dayAppointments = appointments.filter((a) => a.date === dayStr)

    if (dayAppointments.length === 0) {
      return <div className="text-center py-8 text-gray-500">אין תורים לתאריך זה</div>
    }

    // Sort appointments by time
    const sortedAppointments = [...dayAppointments].sort((a, b) => {
      return a.time.localeCompare(b.time)
    })

    return (
      <div className="space-y-3">
        {sortedAppointments.map((appointment) => {
          // Calculate end time
          let endTime = "לא זמין"
          try {
            if (appointment.time) {
              const [hours, minutes] = appointment.time.split(":").map(Number)

              // Get total duration from service or notes
              let duration = 60 // Default duration

              try {
                if (appointment.notes && appointment.notes.includes("multipleServices")) {
                  const notes = JSON.parse(appointment.notes)
                  duration = notes.totalDuration || 60
                }
              } catch (e) {
                console.error("Error parsing notes:", e)
              }

              const startDate = new Date()
              startDate.setHours(hours, minutes, 0, 0)
              const endDate = new Date(startDate.getTime() + duration * 60000)
              endTime = `${endDate.getHours().toString().padStart(2, "0")}:${endDate.getMinutes().toString().padStart(2, "0")}`
            }
          } catch (error) {
            console.error("Error calculating end time:", error)
          }

          return (
            <Card key={appointment.id}>
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-medium">
                      {appointment.time}
                      {endTime !== "לא זמין" ? ` - ${endTime}` : ""}
                    </p>
                    <div className="text-sm text-muted-foreground">{appointment.serviceName}</div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{appointment.customerName}</p>
                    <p className="text-sm text-muted-foreground">
                      {appointment.status === "confirmed"
                        ? "מאושר"
                        : appointment.status === "completed"
                          ? "הושלם"
                          : appointment.status === "cancelled"
                            ? "בוטל"
                            : "ממתין לאישור"}
                    </p>
                    <p className="text-sm text-muted-foreground">{appointment.customerPhone}</p>
                    <p className="text-sm font-medium text-pink-600">₪{appointment.price || 0}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-4 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="חיפוש לפי שם לקוח או שירות"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="סטטוס" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">הכל</SelectItem>
              <SelectItem value="confirmed">מאושר</SelectItem>
              <SelectItem value="pending">ממתין</SelectItem>
              <SelectItem value="cancelled">בוטל</SelectItem>
              <SelectItem value="completed">הושלם</SelectItem>
            </SelectContent>
          </Select>
          <DateRangePicker dateRange={dateRange} onDateRangeChange={setDateRange} />
        </div>
      </div>

      {isMobile ? (
        <div className="space-y-4">
          {sortedAppointments.length > 0 ? (
            sortedAppointments.map((appointment) => (
              <Card key={appointment.id} className="overflow-hidden border-l-4 border-l-pink-500">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium text-lg">{appointment.customerName}</h3>
                    {getStatusBadge(appointment.status)}
                  </div>
                  <p className="text-md font-medium text-pink-600">{appointment.serviceName}</p>
                  <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 text-sm text-muted-foreground mt-2">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>{format(new Date(appointment.date), "EEEE, d בMMMM yyyy", { locale: he })}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>
                        {appointment.time} - {calculateEndTime(appointment.time, appointment.notes)}
                      </span>
                    </div>
                  </div>
                  <div className="mt-2 text-sm">
                    <span className="font-medium">טלפון: </span>
                    <span dir="ltr">{appointment.customerPhone}</span>
                  </div>
                  <div className="mt-1 text-sm">
                    <span className="font-medium">סכום לתשלום: </span>
                    <span className="font-bold text-pink-600">₪{appointment.price || 0}</span>
                  </div>
                  <div className="flex justify-end mt-3 gap-2">
                    {appointment.status === "pending" && (
                      <Button
                        size="sm"
                        className="bg-green-500 hover:bg-green-600"
                        onClick={() => {
                          // Call the parent component's approve function
                          const updateAppointment = useStore.getState().updateAppointment
                          updateAppointment(appointment.id, { status: "confirmed" })
                          toast({
                            title: "התור אושר",
                            description: `התור של ${appointment.customerName} אושר בהצלחה`,
                          })
                        }}
                      >
                        <Check className="h-4 w-4 mr-1" />
                        אישור
                      </Button>
                    )}
                    <Button variant="outline" size="sm" onClick={() => handleEditClick(appointment)}>
                      <Edit className="h-4 w-4 mr-1" />
                      עריכה
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-red-500"
                      onClick={() => handleDeleteClick(appointment)}
                    >
                      <Trash className="h-4 w-4 mr-1" />
                      מחיקה
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center py-8 text-gray-500">לא נמצאו תורים התואמים את החיפוש</div>
          )}
        </div>
      ) : (
        <div className="rounded-md border overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>לקוח</TableHead>
                <TableHead>שירות</TableHead>
                <TableHead>תאריך</TableHead>
                <TableHead>שעה</TableHead>
                <TableHead>סכום</TableHead>
                <TableHead>סטטוס</TableHead>
                <TableHead className="text-left">פעולות</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedAppointments.length > 0 ? (
                sortedAppointments.map((appointment) => (
                  <TableRow key={appointment.id}>
                    <TableCell className="font-medium">{appointment.customerName}</TableCell>
                    <TableCell>{appointment.serviceName}</TableCell>
                    <TableCell>{format(new Date(appointment.date), "dd/MM/yyyy")}</TableCell>
                    <TableCell>
                      {appointment.time} - {calculateEndTime(appointment.time, appointment.notes)}
                    </TableCell>
                    <TableCell className="font-bold text-pink-600">₪{appointment.price || 0}</TableCell>
                    <TableCell>{getStatusBadge(appointment.status)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        {appointment.status === "pending" && (
                          <Button
                            size="sm"
                            className="bg-green-500 hover:bg-green-600"
                            onClick={() => {
                              // Call the parent component's approve function
                              const updateAppointment = useStore.getState().updateAppointment
                              updateAppointment(appointment.id, { status: "confirmed" })
                              toast({
                                title: "התור אושר",
                                description: `התור של ${appointment.customerName} אושר בהצלחה`,
                              })
                            }}
                          >
                            <Check className="h-4 w-4 mr-1" />
                            אישור
                          </Button>
                        )}
                        <Button variant="outline" size="sm" onClick={() => handleEditClick(appointment)}>
                          <Edit className="h-4 w-4 mr-1" />
                          עריכה
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-500"
                          onClick={() => handleDeleteClick(appointment)}
                        >
                          <Trash className="h-4 w-4 mr-1" />
                          מחיקה
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                    לא נמצאו תורים התואמים את החיפוש
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>עריכת תור</DialogTitle>
            <DialogDescription>
              עריכת פרטי התור של {selectedAppointment?.customerName} ל{selectedAppointment?.serviceName}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="bg-gray-50 p-3 rounded-md mb-4">
              <div className="grid grid-cols-2 gap-2 mb-3">
                <div>
                  <p className="text-sm font-medium text-gray-500">לקוח:</p>
                  <p>{selectedAppointment?.customerName}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">טלפון:</p>
                  <p dir="ltr">{selectedAppointment?.customerPhone}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">תאריך:</p>
                  <p>{selectedAppointment?.date}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">שירות:</p>
                  <p>{selectedAppointment?.serviceName}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-sm font-medium text-gray-500">סכום לתשלום:</p>
                  <p className="font-bold text-pink-600">₪{selectedAppointment?.price || 0}</p>
                </div>
              </div>
            </div>

            <div className="grid gap-2">
              <label htmlFor="status">סטטוס</label>
              <Select
                value={editFormData.status}
                onValueChange={(value) => setEditFormData({ ...editFormData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="בחר סטטוס" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="confirmed">מאושר</SelectItem>
                  <SelectItem value="pending">ממתין</SelectItem>
                  <SelectItem value="cancelled">בוטל</SelectItem>
                  <SelectItem value="completed">הושלם</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <label htmlFor="time">שעה</label>
              <Input
                id="time"
                type="time"
                value={editFormData.time}
                onChange={(e) => setEditFormData({ ...editFormData, time: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <label htmlFor="notes">הערות</label>
              <Input
                id="notes"
                value={editFormData.notes}
                onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              ביטול
            </Button>
            <Button onClick={handleSaveEdit} className="bg-pink-500 hover:bg-pink-600">
              שמירה
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>האם אתה בטוח?</AlertDialogTitle>
            <AlertDialogDescription>
              פעולה זו תמחק את התור של {appointmentToDelete?.customerName} ל{appointmentToDelete?.serviceName} בתאריך{" "}
              {appointmentToDelete?.date}. פעולה זו לא ניתנת לביטול.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ביטול</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDelete} className="bg-red-500 hover:bg-red-600">
              מחיקה
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
