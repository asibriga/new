import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"
import { format } from "date-fns"
import { he } from "date-fns/locale"

interface AppointmentDetailProps {
  isOpen: boolean
  onClose: () => void
  appointment: {
    id: string
    name?: string
    service?: string
    date?: Date
    startTime?: string
    endTime?: string
    status?: string
    price?: number
    duration?: number
    notes?: string
    multipleServices?: boolean
    services?: Array<{ id: string; name: string; price: number; duration: number }>
  }
}

export function AppointmentDetailDialog({ isOpen, onClose, appointment }: AppointmentDetailProps) {
  if (!appointment) return null

  const formatDate = (date?: Date) => {
    if (!date) return ""
    return format(date, "EEEE, d בMMMM yyyy", { locale: he })
  }

  const formatTime = (startTime?: string, endTime?: string) => {
    if (!startTime) return ""
    if (!endTime) return startTime
    return `${startTime} - ${endTime}`
  }

  const formatServices = () => {
    if (appointment.multipleServices && appointment.services && appointment.services.length > 0) {
      return appointment.services.map((service) => (
        <div key={service.id} className="flex justify-between mb-1">
          <span>{service.name}</span>
          <span>₪{service.price}</span>
        </div>
      ))
    } else if (appointment.service) {
      return (
        <div className="flex justify-between mb-1">
          <span>{appointment.service}</span>
          <span>₪{appointment.price}</span>
        </div>
      )
    }
    return null
  }

  const calculateTotal = () => {
    if (appointment.multipleServices && appointment.services && appointment.services.length > 0) {
      return appointment.services.reduce((total, service) => total + (service.price || 0), 0)
    }
    return appointment.price || 0
  }

  return (
    <Dialog open={isOpen} onOpenChange={() => onClose()}>
      <DialogContent className="sm:max-w-md max-w-[95vw] rounded-lg p-0 overflow-hidden">
        <DialogHeader className="bg-pink-500 text-white p-4">
          <div className="flex justify-between items-center">
            <DialogClose asChild>
              <Button variant="ghost" size="icon" className="text-white hover:bg-pink-600 hover:text-white" onClick={() => console.log("TODO: Add functionality")}>
                <X className="h-5 w-5" />
              </Button>
            </DialogClose>
            <DialogTitle className="text-xl font-bold">פרטי השירות</DialogTitle>
          </div>
        </DialogHeader>

        <div className="p-4 space-y-4 text-right">
          {appointment.service && (
            <div className="mb-4">
              <h3 className="font-semibold text-lg mb-1">שירות:</h3>
              <p>{appointment.service}</p>
            </div>
          )}

          {appointment.date && (
            <div className="mb-4">
              <h3 className="font-semibold text-lg mb-1">תאריך:</h3>
              <p dir="rtl">{formatDate(appointment.date)}</p>
            </div>
          )}

          {appointment.startTime && (
            <div className="mb-4">
              <h3 className="font-semibold text-lg mb-1">שעה:</h3>
              <p>{formatTime(appointment.startTime, appointment.endTime)}</p>
            </div>
          )}

          {appointment.status && (
            <div className="mb-4">
              <h3 className="font-semibold text-lg mb-1">סטטוס:</h3>
              <p>{appointment.status}</p>
            </div>
          )}

          <div className="mb-4">
            <h3 className="font-semibold text-lg mb-1">מחיר:</h3>
            <div className="border rounded-md p-3 bg-gray-50">
              {formatServices()}

              <div className="border-t mt-2 pt-2 font-bold flex justify-between">
                <span>סה"כ:</span>
                <span>₪{calculateTotal()}</span>
              </div>
            </div>
          </div>

          {appointment.notes && (
            <div className="mb-4">
              <h3 className="font-semibold text-lg mb-1">הערות:</h3>
              <p className="whitespace-pre-wrap break-words">{appointment.notes}</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
