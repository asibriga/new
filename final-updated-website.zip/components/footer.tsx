"use client"

import type React from "react"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Instagram, MapPin, Phone } from "lucide-react"
import { useState, useEffect } from "react"
import { useStore } from "@/lib/store"
import { useToast } from "@/components/ui/use-toast"
import { ToastAction } from "@/components/ui/toast"
import { Label } from "@/components/ui/label"

// Custom TikTok icon since it's not in Lucide
function TikTokIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" />
    </svg>
  )
}

export default function Footer() {
  const [name, setName] = useState("")
  const [phone, setPhone] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [footerText, setFooterText] = useState("© 2024 May Beauty. כל הזכויות שמורות.")
  const subscribeToNewsletter = useStore((state) => state.subscribeToNewsletter)
  const siteContent = useStore((state) => state.siteContent)
  const { toast } = useToast()

  useEffect(() => {
    if (siteContent?.footerText) {
      setFooterText(siteContent.footerText)
    }
  }, [siteContent])

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate inputs
    if (!name || !phone) {
      toast({
        title: "שגיאה",
        description: "אנא מלא/י את כל השדות הנדרשים",
        variant: "destructive",
      })
      return
    }

    // Validate phone number format (Israeli format)
    const phoneRegex = /^0(5[0-9]|[23489])[0-9]{7}$/
    if (!phoneRegex.test(phone)) {
      toast({
        title: "שגיאה",
        description: "אנא הזיני מספר טלפון תקין",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Call store function to subscribe
      await subscribeToNewsletter(phone, name)

      // Reset form
      setName("")
      setPhone("")

      // Show success message
      toast({
        title: "נרשמת בהצלחה!",
        description: "תודה שנרשמת לניוזלטר שלנו",
        action: <ToastAction altText="סגירה">סגירה</ToastAction>,
      })
    } catch (error) {
      console.error("Error subscribing to newsletter:", error)
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה בעת ההרשמה. אנא נסה שוב מאוחר יותר.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">May Beauty</h3>
            <p className="text-gray-400 mb-6">סטודיו מקצועי לבניית ציפורניים וטיפולי יופי</p>
            <div className="flex space-x-4">
              <a
                href="https://www.instagram.com/may_beauty__cosmetics?igsh=MWFzZXMzOHprY3JlaA%3D%3D&utm_source=qr"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="ghost" size="icon" className="text-pink-400 hover:text-pink-300 hover:bg-gray-800" onClick={() => console.log("TODO: Add functionality")}>
                  <Instagram className="h-5 w-5" />
                  <span className="sr-only">Instagram</span>
                </Button>
              </a>
              <a
                href="https://www.tiktok.com/@may.beauty_studio?_t=ZS-8vNDqUTogky&_r=1"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="ghost" size="icon" className="text-pink-400 hover:text-pink-300 hover:bg-gray-800" onClick={() => console.log("TODO: Add functionality")}>
                  <TikTokIcon className="h-5 w-5" />
                  <span className="sr-only">TikTok</span>
                </Button>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">קישורים מהירים</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-400 hover:text-pink-400 transition-colors">
                  דף הבית
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-gray-400 hover:text-pink-400 transition-colors">
                  שירותים
                </Link>
              </li>
              <li>
                <Link href="/gallery" className="text-gray-400 hover:text-pink-400 transition-colors">
                  גלריה
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-400 hover:text-pink-400 transition-colors">
                  אודות
                </Link>
              </li>
              <li>
                <Link href="/shop" className="text-gray-400 hover:text-pink-400 transition-colors">
                  חנות
                </Link>
              </li>
              <li>
                <Link href="/booking" className="text-gray-400 hover:text-pink-400 transition-colors">
                  קביעת תור
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-pink-400 transition-colors">
                  צור קשר
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">צור קשר</h3>
            <ul className="space-y-4">
              <li className="flex items-center">
                <MapPin className="h-5 w-5 text-pink-400 mr-2" />
                <span className="text-gray-400">שדרות חן 7, הרצליה</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-pink-400 mr-2" />
                <span className="text-gray-400">052-8588876</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">הרשמה לעדכונים</h3>
            <p className="text-gray-400 mb-4">הירשמי לניוזלטר שלנו וקבלי עדכונים ומבצעים</p>
            <form onSubmit={handleSubscribe} className="flex flex-col space-y-2">
              <div className="space-y-2">
                <Label htmlFor="newsletter-name" className="text-gray-300">
                  שם מלא
                </Label>
                <Input
                  id="newsletter-name"
                  type="text"
                  placeholder="השם שלך"
                  className="bg-gray-800 border-gray-700 text-white"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="newsletter-phone" className="text-gray-300">
                  מספר טלפון
                </Label>
                <Input
                  id="newsletter-phone"
                  type="tel"
                  placeholder="הטלפון שלך"
                  className="bg-gray-800 border-gray-700 text-white"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  inputMode="numeric"
                  pattern="[0-9]*"
                />
              </div>
              <Button type="submit" className="bg-pink-500 hover:bg-pink-600 text-white" disabled={isSubmitting}>
                {isSubmitting ? "מעבד..." : "הרשמה"}
              </Button>
            </form>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-500">
          <p>{footerText}</p>
        </div>
      </div>
    </footer>
  )
}
