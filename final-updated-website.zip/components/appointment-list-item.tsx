"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Clock, Calendar, DollarSign, MoreVertical } from "lucide-react"
import { format } from "date-fns"
import { he } from "date-fns/locale"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface AppointmentListItemProps {
  appointment: {
    id: string
    clientName: string
    service: string
    date: Date
    startTime: string
    endTime: string
    status: string
    price: number
  }
  onViewDetails: (id: string) => void
  onEdit: (id: string) => void
  onCancel: (id: string) => void
  onComplete: (id: string) => void
  isAdmin?: boolean
}

export function AppointmentListItem({
  appointment,
  onViewDetails,
  onEdit,
  onCancel,
  onComplete,
  isAdmin = false,
}: AppointmentListItemProps) {
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "confirmed":
      case "מאושר":
        return "bg-green-100 text-green-800"
      case "pending":
      case "ממתין":
        return "bg-yellow-100 text-yellow-800"
      case "cancelled":
      case "בוטל":
        return "bg-red-100 text-red-800"
      case "completed":
      case "הושלם":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const formatDate = (date: Date) => {
    return format(date, "EEEE, d בMMMM", { locale: he })
  }

  return (
    <Card className="mb-3 overflow-hidden border-r-4 border-r-pink-500">
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row justify-between">
          <div className="flex-1 mb-3 md:mb-0">
            <div className="flex justify-between items-start">
              <div className="text-right">
                <h3 className="font-bold text-lg">{appointment.service}</h3>
                {isAdmin && <p className="text-gray-600 text-sm mb-2">{appointment.clientName}</p>}
                <div className="flex flex-col space-y-1 mt-2">
                  <div className="flex items-center justify-end text-gray-600 text-sm">
                    <span className="ml-1">{formatDate(appointment.date)}</span>
                    <Calendar className="h-4 w-4 mr-1" />
                  </div>
                  <div className="flex items-center justify-end text-gray-600 text-sm">
                    <span className="ml-1">
                      {appointment.startTime} - {appointment.endTime}
                    </span>
                    <Clock className="h-4 w-4 mr-1" />
                  </div>
                  <div className="flex items-center justify-end text-gray-600 text-sm">
                    <span className="ml-1">₪{appointment.price}</span>
                    <DollarSign className="h-4 w-4 mr-1" />
                  </div>
                </div>
              </div>
              <div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(appointment.status)}`}>
                  {appointment.status}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end space-x-2 rtl:space-x-reverse">
            <Button variant="outline" size="sm" onClick={() => onViewDetails(appointment.id)} className="text-xs h-8">
              פרטים
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => console.log("TODO: Add functionality")}>
                  <MoreVertical className="h-4 w-4" />
                  <span className="sr-only">פעולות</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                <DropdownMenuItem onClick={() => onEdit(appointment.id)}>עריכה</DropdownMenuItem>
                {appointment.status !== "בוטל" && appointment.status !== "cancelled" && (
                  <DropdownMenuItem onClick={() => onCancel(appointment.id)} className="text-red-600">
                    ביטול תור
                  </DropdownMenuItem>
                )}
                {isAdmin && appointment.status !== "הושלם" && appointment.status !== "completed" && (
                  <DropdownMenuItem onClick={() => onComplete(appointment.id)}>סמן כהושלם</DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
