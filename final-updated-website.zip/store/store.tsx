"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

// Define types
export type Service = {
  id: string
  name: string
  description: string
  duration: number
  price: number
  image?: string
}

export type Appointment = {
  id: string
  customerId: string
  customerName: string
  customerPhone: string
  customerEmail?: string
  serviceId: string
  serviceName: string
  date: string
  time: string
  notes?: string
  status: "pending" | "confirmed" | "cancelled"
  price: number
}

export type Customer = {
  id: string
  name: string
  phone: string
  email?: string
  notes?: string
  visits: number
  lastVisit?: string
  status: "active" | "inactive" | "new" | "needs_followup"
  isSubscribedToNewsletter?: boolean
  loyaltyPoints?: number
  rewardHistory?: {
    id: string
    rewardId: string
    rewardName: string
    pointsCost: number
    date: string
  }[]
  referralCode?: string
}

export type TimeSlot = {
  time: string
  isAvailable: boolean
}

export type TwilioSettings = {
  accountSid: string
  authToken: string
  phoneNumber: string
  isEnabled: boolean
}

export type Product = {
  id: string
  name: string
  description: string
  category: string
  price: number
  stock: number
  status: "active" | "inactive" | "out_of_stock"
  image?: string
}

export type CartItem = {
  productId: string
  quantity: number
}

export type Order = {
  id: string
  customerId: string
  customerName: string
  customerPhone: string
  customerEmail?: string
  items: {
    productId: string
    productName: string
    quantity: number
    price: number
  }[]
  total: number
  status: "pending" | "paid" | "completed" | "cancelled"
  paymentMethod: "bit" | "cash" | "credit_card"
  pickupMethod: "pickup" | "delivery"
  date: string
}

export type Transaction = {
  id: string
  date: string
  description: string
  amount: number
  type: "income" | "expense"
  category: string
  relatedId?: string // appointment ID or order ID
}

export type NewsletterSubscriber = {
  id: string
  name: string
  phone: string
  date: string
  isActive: boolean
}

export type SiteContent = {
  heroTitle: string
  heroSubtitle: string
  aboutText: string
  contactText: string
  footerText: string
  images: {
    hero: string
    about: string
    services: string[]
    gallery: string[]
  }
}

// הוספת טיפים לאחר קביעת תור
export type AppointmentTips = {
  title: string
  content: string[]
}

export type LoyaltyTier = {
  id: string
  name: string
  pointsRequired: number
  benefits: string[]
}

export type LoyaltyReward = {
  id: string
  name: string
  description: string
  pointsCost: number
  isReward?: boolean
}

export type LoyaltySettings = {
  pointsPerPurchase: number
  pointsMultiplier: number
  referralPoints: number
}

export type Coupon = {
  id: string
  code: string
  discount: number
  expirationDate: string
  isActive: boolean
  isReward?: boolean
  maxUses?: number
  usedCount?: number
  type?: "percentage" | "fixed"
  customerId?: string
  redemptionId?: string
  isReferral?: boolean
}

// Define store
type StoreState = {
  services: Service[]
  appointments: Appointment[]
  customers: Customer[]
  twilioSettings: TwilioSettings
  products: Product[]
  cart: CartItem[]
  orders: Order[]
  transactions: Transaction[]
  newsletterSubscribers: NewsletterSubscriber[]
  siteContent: SiteContent
  notifications: {
    id: string
    type: "newsletter" | "appointment" | "order" | "system" | "contact" | "reward" | "points" | "coupon"
    message: string
    date: string
    isRead: boolean
    userId?: string | null
    isCustomerNotification?: boolean
  }[]
  analytics: {
    pageViews: any[]
    referrers: any[]
  }

  // הוספת טיפים לאחר קביעת תור
  appointmentTips: AppointmentTips
  holidays: { date: string; name: string }[]
  closedDays: {
    id: string
    date: string
    reason: string
    specificHours?: boolean
    startTime?: string
    endTime?: string
  }[]
  loyaltyTiers: LoyaltyTier[]
  loyaltyRewards: LoyaltyReward[]
  loyaltySettings: LoyaltySettings
  coupons: Coupon[]
  logs: {
    id: string
    timestamp: string
    type: "appointment" | "order" | "system"
    message: string
    user: string
    details: any
  }[]
  loggedInCustomerId: string | null
  closedHours: {
    id: string
    date: string
    startTime: string
    endTime: string
    reason: string
  }[]

  // Actions
  addService: (service: Omit<Service, "id">) => void
  updateService: (id: string, service: Partial<Service>) => void
  deleteService: (id: string) => void

  addAppointment: (appointment: Omit<Appointment, "id" | "status">) => void
  updateAppointment: (id: string, appointment: Partial<Appointment>) => void
  deleteAppointment: (id: string) => void

  addCustomer: (customer: Omit<Customer, "id" | "visits" | "status"> & { status?: string }) => void
  updateCustomer: (id: string, customer: Partial<Customer>) => void
  deleteCustomer: (id: string) => void

  updateTwilioSettings: (settings: Partial<TwilioSettings>) => void

  addProduct: (product: Omit<Product, "id">) => void
  updateProduct: (id: string, product: Partial<Product>) => void
  deleteProduct: (id: string) => void

  addToCart: (productId: string, quantity: number) => void
  updateCartItem: (productId: string, quantity: number) => void
  removeFromCart: (productId: string) => void
  clearCart: () => void

  createOrder: (order: Omit<Order, "id">) => void
  updateOrder: (id: string, order: Partial<Order>) => void

  addTransaction: (transaction: Omit<Transaction, "id">) => void
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void
  deleteTransaction: (id: string) => void

  subscribeToNewsletter: (phone: string, name: string) => void
  unsubscribeFromNewsletter: (id: string) => void

  updateSiteContent: (content: Partial<SiteContent>) => void
  addGalleryImage: (image: string) => void
  removeGalleryImage: (imageUrl: string) => void
  resetFinancialData: () => void

  markNotificationAsRead: (id: string) => void
  clearNotifications: () => void

  getAvailableTimeSlots: (date: string, serviceId: string) => TimeSlot[]
  isTimeSlotAvailable: (date: string, time: string) => boolean

  getFinancialSummary: (
    startDate: string,
    endDate: string,
  ) => {
    totalIncome: number
    totalExpenses: number
    netProfit: number
    serviceIncome: number
    productIncome: number
    expensesByCategory: Record<string, number>
  }
  addManualTransaction: (transaction: Partial<Transaction>) => void

  addNotification: (notification: { type: string; message: string; userId?: string }) => void

  addClosedDay: (date: string, reason: string, specificHours?: boolean, startTime?: string, endTime?: string) => string
  removeClosedDay: (date: string) => void
  updateAppointmentTips: (tips: Partial<AppointmentTips>) => void

  verifyReferralCode: (code: string) => boolean
  applyCoupon: (code: string, orderId?: string) => boolean
  validateCoupon: (code: string) => {
    valid: boolean
    discount: number
    message: string
    value: number
    type: string
    isReferral?: boolean
  }
  redeemReward: (customerId: string, rewardId: string) => boolean
  processReferralBonus: (customerId: string) => void
  addClosedHours: (date: string, startTime: string, endTime: string, reason: string) => string
  removeClosedHours: (id: string) => void
}

// Initial site content
const initialSiteContent: SiteContent = {
  heroTitle: "May Beauty",
  heroSubtitle: "עיצוב ציפורניים מקצועי ואיכותי בסטנדרטים הגבוהים ביותר",
  aboutText:
    "May Beauty נוסד בשנת 2018 מתוך אהבה גדולה לאמנות הציפורניים וטיפוח היופי. הסטודיו שלנו מציע מגוון רחב של טיפולי ציפורניים וטיפולי יופי ברמה הגבוהה ביותר.",
  contactText: "יש לך שאלות? אנחנו כאן בשבילך. צרי איתנו קשר ונחזור אלייך בהקדם.",
  footerText: "© 2025 May Beauty. כל הזכויות שמורות.",
  images: {
    hero: "/images/hero-bg.jpg",
    about: "/placeholder.svg?height=400&width=600",
    services: [
      "/placeholder.svg?height=200&width=300",
      "/placeholder.svg?height=200&width=300",
      "/placeholder.svg?height=200&width=300",
    ],
    gallery: [
      "/placeholder.svg?height=300&width=300",
      "/placeholder.svg?height=300&width=300",
      "/placeholder.svg?height=300&width=300",
      "/placeholder.svg?height=300&width=300",
      "/placeholder.svg?height=300&width=300",
      "/placeholder.svg?height=300&width=300",
    ],
  },
}

// Create store with persistence
export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      // הסרת נתוני דמו מהמערכת
      // בתוך הפונקציה create, שנה את הערכים ההתחלתיים:
      customers: [],
      services: [
      ],
      appointments: [],
      products: [
      ],
      cart: [],
      orders: [],
      transactions: [],
      newsletterSubscribers: [],
      siteContent: initialSiteContent,
      notifications: [],
      analytics: {
        pageViews: [],
        referrers: [],
      },
      // הוספה לערכים ההתחלתיים
      appointmentTips: {
        title: "טיפים חשובים לקראת התור שלך",
        content: [
          "נא להגיע 10 דקות לפני התור שנקבע",
          "במקרה של איחור, התור עלול להתקצר או להתבטל",
          "אנא הודיעי מראש על ביטול (לפחות 24 שעות מראש)",
          "אנו מקבלים תשלום במזומן, העברה בנקאית או ביט",
        ],
      },
      holidays: [
        { date: "2025-04-15", name: "פסח" },
        { date: "2025-04-21", name: "שביעי של פסח" },
        { date: "2025-05-04", name: "יום העצמאות" },
        { date: "2025-05-24", name: "שבועות" },
        { date: "2025-09-25", name: "ראש השנה" },
        { date: "2025-10-04", name: "יום כיפור" },
        { date: "2025-10-09", name: "סוכות" },
        { date: "2025-10-16", name: "שמחת תורה" },
      ],
      closedDays: [],
      loyaltyTiers: [
        {
          id: "lt1",
          name: "חבר",
          pointsRequired: 0,
          benefits: ["צבירת נקודות על כל רכישה", "הטבת יום הולדת"],
        },
        {
          id: "lt2",
          name: "כסף",
          pointsRequired: 100,
          benefits: ["צבירת נקודות על כל רכישה", "הטבת יום הולדת", "10% הנחה על מוצרים"],
        },
        {
          id: "lt3",
          name: "זהב",
          pointsRequired: 300,
          benefits: ["צבירת נקודות על כל רכישה", "הטבת יום הולדת", "15% הנחה על מוצרים", "תור מועדף"],
        },
      ],
      loyaltyRewards: [
      ],
      loyaltySettings: {
        pointsPerPurchase: 1,
        pointsMultiplier: 1,
        referralPoints: 50,
      },
      coupons: [],
      logs: [],
      loggedInCustomerId: null,

      // Service actions
      addService: (service) =>
        set((state) => ({
          services: [...state.services, { ...service, id: Date.now().toString() }],
        })),

      updateService: (id, updatedService) =>
        set((state) => ({
          services: state.services.map((service) => (service.id === id ? { ...service, ...updatedService } : service)),
        })),

      deleteService: (id) =>
        set((state) => ({
          services: state.services.filter((service) => service.id !== id),
        })),

      // Appointment actions
      addAppointment: (appointment) =>
        set((state) => {
          const service = state.services.find((s) => s.id === appointment.serviceId)
          const price = service ? service.price : 0

          const newAppointment = {
            ...appointment,
            id: Date.now().toString(),
            status: "pending" as const, // Always set as pending
          }

          return {
            appointments: [...state.appointments, newAppointment],
          }
        }),

      // תיקון לבעיית עיבוד תורים והזמנות שהושלמו
      // עדכון פונקציית updateAppointment
      updateAppointment: (id, appointment) =>
        set((state) => {
          const currentAppointment = state.appointments.find((a) => a.id === id)
          if (!currentAppointment) return state

          // Calculate the total price if this is a multi-service appointment
          let updatedPrice = currentAppointment.price
          if (appointment.notes && appointment.notes.includes("multipleServices")) {
            try {
              const notesData = JSON.parse(appointment.notes)
              if (notesData.services && Array.isArray(notesData.services)) {
                updatedPrice = notesData.services.reduce((total, service) => {
                  return total + (service.price || 0)
                }, 0)
              }
            } catch (error) {
              console.error("Error parsing updated appointment notes:", error)
            }
          }

          // Check if status is changing to completed and points haven't been awarded yet
          if (
            (appointment.status === "completed" || appointment.status === "confirmed") &&
            currentAppointment.status !== "completed" &&
            currentAppointment.status !== "confirmed" &&
            !currentAppointment.pointsAwarded
          ) {
            // Find the customer
            const customerId = currentAppointment.customerId
            const customer = state.customers.find((c) => c.id === customerId)

            if (customer) {
              // Calculate points to add (1 point per 10 shekels)
              const totalPrice = updatedPrice || currentAppointment.price
              const pointsToAdd = Math.floor(totalPrice / 10)

              // Update customer with points
              const updatedCustomers = state.customers.map((c) =>
                c.id === customerId
                  ? {
                      ...c,
                      loyaltyPoints: (c.loyaltyPoints || 0) + pointsToAdd,
                    }
                  : c,
              )

              // Add notification about points
              const newNotification = {
                id: Date.now().toString(),
                type: "points",
                message: `קיבלת ${pointsToAdd} נקודות נאמנות עבור התור שלך`,
                date: new Date().toISOString(),
                isRead: false,
                userId: customerId,
                isCustomerNotification: true,
              }

              // Add transaction for completed appointment - AUTOMATICALLY
              const updatedTransactions = [...state.transactions]
              if (appointment.status === "completed" && currentAppointment.status !== "completed") {
                updatedTransactions.push({
                  id: `tr-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                  date: new Date().toISOString().split("T")[0],
                  description: `תשלום עבור ${currentAppointment.serviceName} - ${currentAppointment.customerName}`,
                  amount: totalPrice,
                  type: "income",
                  category: "service",
                  relatedId: currentAppointment.id,
                })
              }

              // Add log for appointment completion
              const logEntry = {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "appointment" as const,
                message: `תור הושלם: ${currentAppointment.customerName} - ${currentAppointment.serviceName} בתאריך ${currentAppointment.date}`,
                user: "system",
                details: { appointmentId: id, customerId, pointsAwarded: pointsToAdd },
              }

              // Update appointment with pointsAwarded flag and updated price
              return {
                appointments: state.appointments.map((a) =>
                  a.id === id
                    ? {
                        ...a,
                        ...appointment,
                        price: updatedPrice,
                        pointsAwarded: true,
                      }
                    : a,
                ),
                customers: updatedCustomers,
                notifications: [...state.notifications, newNotification],
                transactions: updatedTransactions,
                logs: [...state.logs, logEntry],
              }
            }
          }

          // If status is changing to cancelled and points were awarded, remove the points
          if (appointment.status === "cancelled" && currentAppointment.pointsAwarded) {
            // Find the customer
            const customerId = currentAppointment.customerId
            const customer = state.customers.find((c) => c.id === customerId)

            if (customer) {
              // Calculate points to remove (1 point per 10 shekels)
              const pointsToRemove = Math.floor(currentAppointment.price / 10)

              // Update customer with reduced points
              const updatedCustomers = state.customers.map((c) =>
                c.id === customerId
                  ? {
                      ...c,
                      loyaltyPoints: Math.max(0, (c.loyaltyPoints || 0) - pointsToRemove),
                    }
                  : c,
              )

              // Add notification about points removal
              const newNotification = {
                id: Date.now().toString(),
                type: "points",
                message: `${pointsToRemove} נקודות נאמנות הוסרו בעקבות ביטול התור`,
                date: new Date().toISOString(),
                isRead: false,
                userId: customerId,
                isCustomerNotification: true,
              }

              // Add log for appointment cancellation
              const logEntry = {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "appointment" as const,
                message: `תור בוטל: ${currentAppointment.customerName} - ${currentAppointment.serviceName} בתאריך ${currentAppointment.date}`,
                user: "system",
                details: { appointmentId: id, customerId, pointsRemoved: pointsToRemove },
              }

              // Update appointment with pointsAwarded flag set to false
              return {
                appointments: state.appointments.map((a) =>
                  a.id === id
                    ? {
                        ...a,
                        ...appointment,
                        price: updatedPrice,
                        pointsAwarded: false,
                      }
                    : a,
                ),
                customers: updatedCustomers,
                notifications: [...state.notifications, newNotification],
                logs: [...state.logs, logEntry],
              }
            }
          }

          // Add log for appointment update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "appointment" as const,
            message: `תור עודכן: ${currentAppointment.customerName} - ${currentAppointment.serviceName} בתאריך ${currentAppointment.date}`,
            user: "system",
            details: { appointmentId: id, customerId: currentAppointment.customerId, changes: appointment },
          }

          // Default case - just update the appointment with the updated price
          return {
            appointments: state.appointments.map((a) =>
              a.id === id
                ? {
                    ...a,
                    ...appointment,
                    price: updatedPrice,
                  }
                : a,
            ),
            logs: [...state.logs, logEntry],
          }
        }),

      deleteAppointment: (id) =>
        set((state) => ({
          appointments: state.appointments.filter((appointment) => appointment.id !== id),
        })),

      // Customer actions
      addCustomer: (customer) =>
        set((state) => ({
          customers: [...state.customers, { ...customer, id: Date.now().toString(), visits: 0, status: "new" }],
        })),

      updateCustomer: (id, updatedCustomer) =>
        set((state) => ({
          customers: state.customers.map((customer) =>
            customer.id === id ? { ...customer, ...updatedCustomer } : customer,
          ),
        })),

      deleteCustomer: (id) =>
        set((state) => ({
          customers: state.customers.filter((customer) => customer.id !== id),
        })),

      // Twilio settings
      updateTwilioSettings: (settings) =>
        set((state) => ({
          twilioSettings: { ...state.twilioSettings, ...settings },
        })),

      // Product actions
      addProduct: (product) =>
        set((state) => ({
          products: [...state.products, { ...product, id: Date.now().toString() }],
        })),

      updateProduct: (id, updatedProduct) =>
        set((state) => ({
          products: state.products.map((product) => (product.id === id ? { ...product, ...updatedProduct } : product)),
        })),

      deleteProduct: (id) =>
        set((state) => ({
          products: state.products.filter((product) => product.id !== id),
        })),

      // Cart actions
      addToCart: (productId, quantity) =>
        set((state) => {
          const existingItem = state.cart.find((item) => item.productId === productId)

          if (existingItem) {
            return {
              cart: state.cart.map((item) =>
                item.productId === productId ? { ...item, quantity: item.quantity + quantity } : item,
              ),
            }
          } else {
            return {
              cart: [...state.cart, { productId, quantity }],
            }
          }
        }),

      updateCartItem: (productId, quantity) =>
        set((state) => ({
          cart: state.cart.map((item) => (item.productId === productId ? { ...item, quantity } : item)),
        })),

      removeFromCart: (productId) =>
        set((state) => ({
          cart: state.cart.filter((item) => item.productId !== productId),
        })),

      clearCart: () => set({ cart: [] }),

      // Order actions
      createOrder: (order) =>
        set((state) => ({
          orders: [...state.orders, { ...order, id: Date.now().toString() }],
          cart: [], // Clear cart after order
        })),

      // תיקון לבעיית עיבוד הזמנות שהושלמו
      // עדכון פונקציית updateOrder
      updateOrder: (id, updatedOrder) =>
        set((state) => {
          const currentOrder = state.orders.find((o) => o.id === id)
          if (!currentOrder) return state

          // Check if status is changing to paid/completed and points haven't been awarded yet
          if (
            (updatedOrder.status === "paid" || updatedOrder.status === "completed") &&
            currentOrder.status !== "paid" &&
            currentOrder.status !== "completed" &&
            !currentOrder.pointsAwarded
          ) {
            // Find the customer
            const customerId = currentOrder.customerId
            const customer = state.customers.find((c) => c.id === customerId)

            if (customer) {
              // Calculate points to add (1 point per 10 shekels)
              const pointsToAdd = Math.floor(currentOrder.total / 10)

              // Update customer with points
              const updatedCustomers = state.customers.map((c) =>
                c.id === customerId
                  ? {
                      ...c,
                      loyaltyPoints: (c.loyaltyPoints || 0) + pointsToAdd,
                    }
                  : c,
              )

              // Add notification about points
              const newNotification = {
                id: Date.now().toString(),
                type: "points",
                message: `קיבלת ${pointsToAdd} נקודות נאמנות עבור ההזמנה שלך`,
                date: new Date().toISOString(),
                isRead: false,
                userId: customerId,
                isCustomerNotification: true,
              }

              // Add transaction for completed order - AUTOMATICALLY
              const updatedTransactions = [...state.transactions]
              if (
                (updatedOrder.status === "paid" || updatedOrder.status === "completed") &&
                currentOrder.status !== "paid" &&
                currentOrder.status !== "completed"
              ) {
                updatedTransactions.push({
                  id: `tr-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                  date: new Date().toISOString().split("T")[0],
                  description: `תשלום עבור הזמנה #${currentOrder.id.slice(-6)} - ${currentOrder.customerName}`,
                  amount: currentOrder.total,
                  type: "income",
                  category: "product",
                  relatedId: currentOrder.id,
                })
              }

              // Add log for order completion
              const logEntry = {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "order" as const,
                message: `הזמנה הושלמה: ${currentOrder.customerName} - סה"כ ${currentOrder.total}₪`,
                user: "system",
                details: { orderId: id, customerId, pointsAwarded: pointsToAdd },
              }

              // Update order with pointsAwarded flag
              return {
                orders: state.orders.map((o) =>
                  o.id === id
                    ? {
                        ...o,
                        ...updatedOrder,
                        pointsAwarded: true,
                      }
                    : o,
                ),
                customers: updatedCustomers,
                notifications: [...state.notifications, newNotification],
                transactions: updatedTransactions,
                logs: [...state.logs, logEntry],
              }
            }
          }

          // If status is changing to cancelled and points were awarded, remove the points
          if (updatedOrder.status === "cancelled" && currentOrder.pointsAwarded) {
            // Find the customer
            const customerId = currentOrder.customerId
            const customer = state.customers.find((c) => c.id === customerId)

            if (customer) {
              // Calculate points to remove (1 point per 10 shekels)
              const pointsToRemove = Math.floor(currentOrder.total / 10)

              // Update customer with reduced points
              const updatedCustomers = state.customers.map((c) =>
                c.id === customerId
                  ? {
                      ...c,
                      loyaltyPoints: Math.max(0, (c.loyaltyPoints || 0) - pointsToRemove),
                    }
                  : c,
              )

              // Add notification about points removal
              const newNotification = {
                id: Date.now().toString(),
                type: "points",
                message: `${pointsToRemove} נקודות נאמנות הוסרו בעקבות ביטול ההזמנה`,
                date: new Date().toISOString(),
                isRead: false,
                userId: customerId,
                isCustomerNotification: true,
              }

              // Add log for order cancellation
              const logEntry = {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "order" as const,
                message: `הזמנה בוטלה: ${currentOrder.customerName} - סה"כ ${currentOrder.total}₪`,
                user: "system",
                details: { orderId: id, customerId, pointsRemoved: pointsToRemove },
              }

              // Update order with pointsAwarded flag set to false
              return {
                orders: state.orders.map((o) =>
                  o.id === id
                    ? {
                        ...o,
                        ...updatedOrder,
                        pointsAwarded: false,
                      }
                    : o,
                ),
                customers: updatedCustomers,
                notifications: [...state.notifications, newNotification],
                logs: [...state.logs, logEntry],
              }
            }
          }

          // Add log for order update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "order" as const,
            message: `הזמנה עודכנה: ${currentOrder.customerName} - סה"כ ${currentOrder.total}₪`,
            user: "system",
            details: { orderId: id, customerId: currentOrder.customerId, changes: updatedOrder },
          }

          // Default case - just update the order
          return {
            orders: state.orders.map((o) => (o.id === id ? { ...o, ...updatedOrder } : o)),
            logs: [...state.logs, logEntry],
          }
        }),

      // Transaction actions
      addTransaction: (transaction) =>
        set((state) => ({
          transactions: [...state.transactions, { ...transaction, id: Date.now().toString() }],
        })),

      updateTransaction: (id, updatedTransaction) =>
        set((state) => ({
          transactions: state.transactions.map((transaction) =>
            transaction.id === id ? { ...transaction, ...updatedTransaction } : transaction,
          ),
        })),

      deleteTransaction: (id) =>
        set((state) => ({
          transactions: state.transactions.filter((transaction) => transaction.id !== id),
        })),
      addManualTransaction: (transaction) =>
        set((state) => ({
          transactions: [
            ...state.transactions,
            {
              ...transaction,
              id: Date.now().toString(),
              date: transaction.date || new Date().toISOString().split("T")[0],
            },
          ],
        })),

      // Newsletter actions
      subscribeToNewsletter: (phone, name) =>
        set((state) => {
          const newSubscriber = {
            id: Date.now().toString(),
            phone,
            name,
            date: new Date().toISOString(),
            isActive: true,
          }
          return { newsletterSubscribers: [...state.newsletterSubscribers, newSubscriber] }
        }),

      unsubscribeFromNewsletter: (id) =>
        set((state) => ({
          newsletterSubscribers: state.newsletterSubscribers.map((sub) =>
            sub.id === id ? { ...sub, isActive: false } : sub,
          ),
        })),

      // Site content actions
      updateSiteContent: (content) =>
        set((state) => ({
          siteContent: {
            ...state.siteContent,
            ...content,
            images: {
              ...state.siteContent.images,
              ...content.images,
            },
          },
        })),

      addGalleryImage: (image) =>
        set((state) => ({
          siteContent: {
            ...state.siteContent,
            images: {
              ...state.siteContent.images,
              gallery: [...state.siteContent.images.gallery, image],
            },
          },
        })),

      removeGalleryImage: (imageUrl) =>
        set((state) => ({
          siteContent: {
            ...state.siteContent,
            images: {
              ...state.siteContent.images,
              gallery: state.siteContent.images.gallery.filter((img) => img !== imageUrl),
            },
          },
        })),

      // עדכון פונקציית resetFinancialData
      resetFinancialData: () =>
        set((state) => ({
          transactions: [],
        })),

      // Notification actions
      markNotificationAsRead: (id) =>
        set((state) => ({
          notifications: state.notifications.map((notification) =>
            notification.id === id ? { ...notification, isRead: true } : notification,
          ),
        })),

      clearNotifications: () =>
        set((state) => ({
          notifications: [],
        })),

      // Исправление функции addNotification для правильной маршрутизации уведомлений
      addNotification: (notification) =>
        set((state) => ({
          notifications: [
            ...state.notifications,
            {
              id: Date.now().toString(),
              type: notification.type,
              message: notification.message,
              date: new Date().toISOString(),
              isRead: false,
              userId: notification.userId || null, // Убедимся, что userId правильно установлен
            },
          ],
        })),

      // Time slot utilities
      getAvailableTimeSlots: (date, serviceId) => {
        const state = get()
        const service = state.services.find((s) => s.id === serviceId)
        if (!service) return []

        const timeSlots = ["11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"]
        const bookedAppointments = state.appointments.filter((a) => a.date === date && a.serviceId === serviceId)

        return timeSlots.map((time) => ({
          time,
          isAvailable: !bookedAppointments.some((a) => a.time === time),
        }))
      },

      isTimeSlotAvailable: (date, time) => {
        const state = get()
        const bookedAppointments = state.appointments.filter(
          (a) => a.date === date && a.time === time && a.status !== "cancelled",
        )
        return bookedAppointments.length === 0
      },

      // Исправление функции getFinancialSummary для учета всех финансовых транзакций
      getFinancialSummary: (startDate, endDate) => {
        const state = get()

        // Фильтровать транзакции в пределах диапазона дат
        const filteredTransactions = state.transactions.filter((transaction) => {
          return transaction.date >= startDate && transaction.date <= endDate
        })

        // Получить все заказы в пределах диапазона дат
        const filteredOrders = state.orders.filter((order) => {
          return (
            order.date >= startDate &&
            order.date <= endDate &&
            (order.status === "paid" || order.status === "completed")
          )
        })

        // Получить все подтвержденные встречи в пределах диапазона дат
        const filteredAppointments = state.appointments.filter((appointment) => {
          return (
            appointment.date >= startDate &&
            appointment.date <= endDate &&
            (appointment.status === "confirmed" || appointment.status === "completed")
          )
        })

        // Рассчитать общий доход от транзакций
        const transactionIncome = filteredTransactions
          .filter((t) => t.type === "income")
          .reduce((sum, t) => sum + t.amount, 0)

        // Рассчитать общий доход от заказов
        const orderIncome = filteredOrders.reduce((sum, order) => sum + order.total, 0)

        // Рассчитать общий доход от встреч
        const appointmentIncome = filteredAppointments.reduce((sum, appointment) => sum + appointment.price, 0)

        // Общий доход
        const totalIncome = transactionIncome + orderIncome + appointmentIncome

        // Общие расходы
        const totalExpenses = filteredTransactions
          .filter((t) => t.type === "expense")
          .reduce((sum, t) => sum + t.amount, 0)

        // Чистая прибыль
        const netProfit = totalIncome - totalExpenses

        // Рассчитать доход по категориям
        const serviceIncome =
          filteredTransactions
            .filter((t) => t.type === "income" && t.category === "service")
            .reduce((sum, t) => sum + t.amount, 0) + appointmentIncome

        const productIncome =
          filteredTransactions
            .filter((t) => t.type === "income" && t.category === "product")
            .reduce((sum, t) => sum + t.amount, 0) + orderIncome

        // Рассчитать расходы по категориям
        const expensesByCategory: Record<string, number> = {}

        filteredTransactions
          .filter((t) => t.type === "expense")
          .forEach((t) => {
            if (!expensesByCategory[t.category]) {
              expensesByCategory[t.category] = 0
            }
            expensesByCategory[t.category] += t.amount
          })

        return {
          totalIncome,
          totalExpenses,
          netProfit,
          serviceIncome,
          productIncome,
          expensesByCategory,
        }
      },
      // פונקציות לניהול ימים סגורים
      // Исправление функции addClosedDay для сохранения закрытых дней
      addClosedDay: (date, reason, specificHours = false, startTime, endTime) => {
        const id = `closed-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

        set((state) => ({
          closedDays: [
            ...state.closedDays,
            {
              id,
              date,
              reason,
              specificHours,
              startTime,
              endTime,
            },
          ],
        }))

        return id
      },

      removeClosedDay: (date) =>
        set((state) => ({
          closedDays: state.closedDays.filter((day) => day.date !== date),
        })),
      updateAppointmentTips: (tips) =>
        set((state) => ({
          appointmentTips: { ...state.appointmentTips, ...tips },
        })),

      // Исправление функции verifyReferralCode для правильной проверки кода направления
      verifyReferralCode: (code) => {
        if (!code || code.trim() === "") return false

        const customers = get().customers
        const matchingCustomer = customers.find((c) => c && c.referralCode === code.trim())
        return matchingCustomer !== undefined
      },

      // תיקון לבעיית קופונים חד פעמיים וקופונים עם מגבלת שימושים
      // עדכון פונקציית applyCoupon
      applyCoupon: (code, orderId) => {
        const state = get()
        const result = state.validateCoupon(code)

        if (result.valid) {
          // Update coupon usage count
          set((state) => {
            const coupon = state.coupons.find((c) => c.code.toLowerCase() === code.toLowerCase())

            if (!coupon) return state

            // Add log for coupon application
            const logEntry = {
              id: Date.now().toString(),
              timestamp: new Date().toISOString(),
              type: "system" as const,
              message: `קופון הופעל: ${code}`,
              user: "system",
              details: { couponCode: code, customerId: state.loggedInCustomerId, orderId },
            }

            // If this is a reward coupon or has maxUses of 1, mark it as inactive after use
            if (coupon.isReward || coupon.maxUses === 1) {
              // Add notification about coupon usage
              const newNotification = {
                id: Date.now().toString(),
                type: "coupon",
                message: `ניצלת קוד קופון "${coupon.code}" על סך ${coupon.type === "percentage" ? `${coupon.discount}%` : `${coupon.discount} ₪`}`,
                date: new Date().toISOString(),
                isRead: false,
                userId: coupon.customerId || state.loggedInCustomerId,
                isCustomerNotification: true,
              }

              // If this is a reward coupon, mark the redemption as used
              let updatedCustomers = [...state.customers]
              if (coupon.redemptionId && coupon.customerId) {
                const customer = state.customers.find((c) => c.id === coupon.customerId)
                if (customer && customer.rewardHistory) {
                  updatedCustomers = state.customers.map((c) => {
                    if (c.id === coupon.customerId) {
                      return {
                        ...c,
                        rewardHistory: (c.rewardHistory || []).map((r) =>
                          r.id === coupon.redemptionId ? { ...r, isUsed: true } : r,
                        ),
                      }
                    }
                    return c
                  })
                }
              }

              return {
                coupons: state.coupons.map((c) =>
                  c.code.toLowerCase() === code.toLowerCase()
                    ? {
                        ...c,
                        isActive: false, // Deactivate the coupon after use
                        usedCount: (c.usedCount || 0) + 1,
                      }
                    : c,
                ),
                notifications: [...state.notifications, newNotification],
                customers: updatedCustomers,
                logs: [...state.logs, logEntry],
              }
            } else {
              // Otherwise just increment the used count
              const updatedUsedCount = (coupon.usedCount || 0) + 1
              const reachedMaxUses = coupon.maxUses && updatedUsedCount >= coupon.maxUses

              return {
                coupons: state.coupons.map((c) =>
                  c.code.toLowerCase() === code.toLowerCase()
                    ? {
                        ...c,
                        usedCount: updatedUsedCount,
                        isActive: reachedMaxUses ? false : c.isActive, // Deactivate if max uses reached
                      }
                    : c,
                ),
                logs: [...state.logs, logEntry],
              }
            }
          })

          return true
        }

        return false
      },

      // תיקון לבעיית אימות קופונים
      validateCoupon: (code) => {
        const state = get()
        const coupon = state.coupons.find((c) => c.code.toLowerCase() === code.toLowerCase())

        if (!coupon) {
          return { valid: false, value: 0, type: "percentage", message: "קוד קופון לא קיים" }
        }

        if (!coupon.isActive) {
          return { valid: false, value: 0, type: "percentage", message: "קוד קופון לא פעיל" }
        }

        // Check expiration date
        if (coupon.expirationDate) {
          const today = new Date().toISOString().split("T")[0]
          if (coupon.expirationDate < today) {
            return { valid: false, value: 0, type: "percentage", message: "קוד קופון פג תוקף" }
          }
        }

        // Check max uses
        if (coupon.maxUses && coupon.usedCount && coupon.usedCount >= coupon.maxUses) {
          return { valid: false, value: 0, type: "percentage", message: "קוד קופון הגיע למקסימום שימושים" }
        }

        // Check if it's a reward coupon that belongs to a specific customer
        if (coupon.isReward && coupon.customerId) {
          const loggedInCustomerId = state.loggedInCustomerId
          if (coupon.customerId !== loggedInCustomerId) {
            return { valid: false, value: 0, type: "percentage", message: "קוד קופון לא שייך ללקוח זה" }
          }
        }

        // Add log for coupon validation
        const logEntry = {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          type: "system" as const,
          message: `קופון אומת: ${code}`,
          user: "system",
          details: { couponCode: code, customerId: state.loggedInCustomerId },
        }

        set((state) => ({
          logs: [...state.logs, logEntry],
        }))

        return {
          valid: true,
          value: coupon.discount,
          type: coupon.type || "percentage",
          isReferral: coupon.isReferral,
          message: "קוד קופון תקף",
        }
      },

      // תיקון לבעיית קוד הפניה
      verifyReferralCode: (code) => {
        if (!code || code.trim() === "") {
          console.log("Referral code is empty")
          return false
        }

        const state = get()
        const trimmedCode = code.trim()
        console.log("Verifying referral code:", trimmedCode)

        // Check if the code belongs to the currently logged in customer
        const loggedInCustomerId = state.loggedInCustomerId
        if (loggedInCustomerId) {
          const loggedInCustomer = state.customers.find((c) => c.id === loggedInCustomerId)
          if (loggedInCustomer && loggedInCustomer.referralCode === trimmedCode) {
            console.log("Self-referral attempt detected")

            // Add log for self-referral attempt
            const logEntry = {
              id: Date.now().toString(),
              timestamp: new Date().toISOString(),
              type: "system" as const,
              message: `ניסיון הפניה עצמית: ${loggedInCustomer.name} ניסה להשתמש בקוד ההפניה שלו`,
              user: "system",
              details: { customerId: loggedInCustomerId, referralCode: trimmedCode },
            }

            set((state) => ({
              logs: [...state.logs, logEntry],
            }))

            return false // Prevent self-referral
          }
        }

        const customers = state.customers
        const matchingCustomer = customers.find((c) => c && c.referralCode === trimmedCode)

        console.log("Found matching customer:", matchingCustomer ? matchingCustomer.name : "No")

        if (matchingCustomer) {
          // Don't award points immediately - store the pending bonus
          // Points will be awarded when the new customer logs in for the first time
          if (loggedInCustomerId) {
            const referralPoints = state.loyaltySettings.referralPoints || 50

            // Add log for valid referral code
            const logEntry = {
              id: Date.now().toString(),
              timestamp: new Date().toISOString(),
              type: "system" as const,
              message: `קוד הפניה תקף: ${trimmedCode} (${matchingCustomer.name})`,
              user: "system",
              details: {
                referrerId: matchingCustomer.id,
                newCustomerId: loggedInCustomerId,
                referralCode: trimmedCode,
              },
            }

            set((state) => {
              // Store the pending referral bonus in the new customer's record
              const updatedCustomers = state.customers.map((c) => {
                if (c.id === loggedInCustomerId) {
                  return {
                    ...c,
                    referredBy: matchingCustomer.id,
                    pendingReferralBonus: {
                      fromCustomerId: matchingCustomer.id,
                      points: referralPoints,
                    },
                  }
                }
                return c
              })

              return {
                customers: updatedCustomers,
                logs: [...state.logs, logEntry],
              }
            })
          }

          return true
        }

        return false
      },

      // תיקון לבעיית עיבוד בונוס הפניה
      processReferralBonus: (customerId) => {
        const state = get()
        const customer = state.customers.find((c) => c.id === customerId)

        if (!customer || !customer.pendingReferralBonus) {
          console.log("No pending bonus found for customer:", customerId)
          return // No pending bonus
        }

        if (customer.hasLoggedIn) {
          console.log("Customer already logged in before, not processing bonus:", customerId)
          return // Already logged in before
        }

        const { fromCustomerId, points } = customer.pendingReferralBonus
        const referrer = state.customers.find((c) => c.id === fromCustomerId)

        if (!referrer) {
          console.log("Referrer not found:", fromCustomerId)
          return // Referrer not found
        }

        console.log("Processing referral bonus:", {
          referrer: referrer.name,
          newCustomer: customer.name,
          points: points,
        })

        // Add log for referral bonus processing
        const logEntry = {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          type: "system" as const,
          message: `בונוס הפניה הוענק: ${referrer.name} קיבל ${points} נקודות עבור הפניית ${customer.name}`,
          user: "system",
          details: { referrerId: fromCustomerId, newCustomerId: customerId, points },
        }

        // Update the referrer with points and referral count
        set((state) => {
          const updatedCustomers = state.customers.map((c) => {
            if (c.id === fromCustomerId) {
              return {
                ...c,
                loyaltyPoints: (c.loyaltyPoints || 0) + points,
                referrals: (c.referrals || 0) + 1,
              }
            } else if (c.id === customerId) {
              // Mark the customer as logged in and clear the pending bonus
              return {
                ...c,
                hasLoggedIn: true,
                pendingReferralBonus: undefined,
              }
            }
            return c
          })

          // Add notification for the referrer
          const newNotification = {
            id: Date.now().toString(),
            type: "points",
            message: `קיבלת ${points} נקודות נאמנות עבור הפניית ${customer.name}!`,
            date: new Date().toISOString(),
            isRead: false,
            userId: fromCustomerId,
            isCustomerNotification: true,
          }

          // Add notification for the new customer
          const newCustomerNotification = {
            id: Date.now().toString() + "-1",
            type: "points",
            message: `קיבלת ${customer.loyaltyPoints || 0} נקודות נאמנות כבונוס על הרשמה עם קוד הפניה!`,
            date: new Date().toISOString(),
            isRead: false,
            userId: customerId,
            isCustomerNotification: true,
          }

          return {
            customers: updatedCustomers,
            notifications: [...state.notifications, newNotification, newCustomerNotification],
            logs: [...state.logs, logEntry],
          }
        })
      },
      addClosedHours: (date, startTime, endTime, reason) => {
        const id = `closed-hours-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

        set((state) => {
          const closedHours = state.closedHours || []
          return {
            closedHours: [
              ...closedHours,
              {
                id,
                date,
                startTime,
                endTime,
                reason: reason || `סגור בין ${startTime} ל-${endTime}`,
              },
            ],
          }
        })

        return id
      },

      removeClosedHours: (id) => {
        set((state) => {
          const closedHours = state.closedHours || []
          return {
            closedHours: closedHours.filter((hours) => hours.id !== id),
          }
        })
      },
    }),
    {
      name: "may-beauty-storage",
    },
  ),
)
