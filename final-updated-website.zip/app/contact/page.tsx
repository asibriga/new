export default function ContactPage() {
  return null
}
