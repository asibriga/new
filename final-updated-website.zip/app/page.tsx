"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Calendar, ShoppingBag, BookOpen } from "lucide-react"
import ServiceCard from "@/components/service-card"
import GallerySection from "@/components/gallery-section"
import { useStore } from "@/lib/store"

export default function Home() {
  const siteContent = useStore((state) => state.siteContent)
  const [content, setContent] = useState({
    businessName: "May Beauty",
    businessPhone: "052-8588876",
    businessAddress: "שדרות חן 7, הרצליה",
    heroTitle: "May Beauty",
    heroSubtitle: "עיצוב ציפורניים מקצועי ואיכותי בסטנדרטים הגבוהים ביותר",
    images: {
      hero: "/placeholder.svg?height=800&width=1200",
      about: "/placeholder.svg?height=400&width=600",
      gallery: [],
      services: [],
    },
  })

  // Update content when store changes
  useEffect(() => {
    const defaultContent = {
      businessName: "May Beauty",
      businessPhone: "052-8588876",
      businessAddress: "שדרות חן 7, הרצליה",
      heroTitle: "May Beauty",
      heroSubtitle: "עיצוב ציפורניים מקצועי ואיכותי בסטנדרטים הגבוהים ביותר",
      images: {
        hero: "/placeholder.svg?height=800&width=1200",
        about: "/placeholder.svg?height=400&width=600",
        gallery: [],
        services: [],
      },
    }

    setContent({
      ...defaultContent,
      ...siteContent,
      businessName: siteContent?.businessName || defaultContent.businessName,
      businessPhone: siteContent?.businessPhone || defaultContent.businessPhone,
      businessAddress: siteContent?.businessAddress || defaultContent.businessAddress,
      heroTitle: siteContent?.heroTitle || defaultContent.heroTitle,
      heroSubtitle: siteContent?.heroSubtitle || defaultContent.heroSubtitle,
      images: {
        hero: siteContent?.images?.hero || defaultContent.images.hero,
        about: siteContent?.images?.about || defaultContent.images.about,
        gallery: siteContent?.images?.gallery || defaultContent.images.gallery,
        services: siteContent?.images?.services || defaultContent.images.services,
      },
    })
  }, [siteContent])

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          {content.images.heroVideo ? (
            <video autoPlay muted loop className="w-full h-full object-cover">
              <source src={content.images.heroVideo} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          ) : (
            <div
              className="w-full h-full bg-cover bg-center"
              style={{
                backgroundImage: `url('${content.images.hero}')`,
                backgroundPosition: "center",
              }}
            ></div>
          )}
          <div className="absolute inset-0 bg-black/30" />
        </div>

        <div className="relative z-10 container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">{content.heroTitle}</h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto">{content.heroSubtitle}</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/booking">
              <Button size="lg" className="bg-pink-500 hover:bg-pink-600 text-white px-8 py-6 text-lg" onClick={() => console.log("TODO: Add functionality")}>
                <Calendar className="mr-2 h-5 w-5" /> קביעת תור
              </Button>
            </Link>
            <Link href="/shop">
              <Button
                size="lg"
                variant="outline"
                className="bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white border-white/30 px-8 py-6 text-lg"
               onClick={() => console.log("TODO: Add functionality")}>
                <ShoppingBag className="mr-2 h-5 w-5" /> לחנות שלנו
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-gradient-to-b from-pink-50 to-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">השירותים שלנו</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              אנו מציעים מגוון רחב של טיפולי ציפורניים וטיפולי יופי ברמה הגבוהה ביותר
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ServiceCard
              title="מניקור קלאסי"
              description="טיפול מניקור מקצועי לציפורניים טבעיות"
              price="120 ₪"
              duration="45 דקות"
              imageSrc="/images/service-1.jpg"
            />
            <ServiceCard
              title="בניית ציפורניים ג'ל"
              description="בניית ציפורניים מקצועית בג'ל עם חומרים איכותיים"
              price="250 ₪"
              duration="90 דקות"
              imageSrc="/images/service-2.jpg"
            />
            <ServiceCard
              title="פדיקור ספא"
              description="טיפול פדיקור מפנק כולל עיסוי כפות רגליים"
              price="180 ₪"
              duration="60 דקות"
              imageSrc="/images/service-3.jpg"
            />
          </div>

          <div className="text-center mt-12">
            <Link href="/services">
              <Button variant="outline" className="border-pink-300 text-pink-600 hover:bg-pink-50" onClick={() => console.log("TODO: Add functionality")}>
                <BookOpen className="mr-2 h-4 w-4" /> לכל השירותים
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <GallerySection />

      {/* CTA Section - UPDATED: Removed phone button */}
      <section className="py-16 bg-pink-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">מוכנה לציפורניים מושלמות?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">קבעי תור עכשיו וקבלי 10% הנחה בביקור הראשון שלך</p>
          <div className="flex justify-center mb-8">
            <Link href="/booking">
              <Button size="lg" className="bg-white text-pink-600 hover:bg-pink-100 px-8 py-6 text-lg w-full sm:w-auto" onClick={() => console.log("TODO: Add functionality")}>
                <Calendar className="mr-2 h-5 w-5" /> קביעת תור עכשיו
              </Button>
            </Link>
          </div>
          <div className="text-white/80 text-sm">
            <p>{content.businessAddress}</p>
            <p>{content.businessEmail}</p>
          </div>
        </div>
      </section>
    </div>
  )
}
