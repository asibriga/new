"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Trash, Plus, Minus, CreditCard, Banknote, ShoppingBag, ArrowRight, CheckCircle } from "lucide-react"
import Image from "next/image"
import { useStore } from "@/lib/store"
import { useToast } from "@/components/ui/use-toast"
import Link from "next/link"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import CouponCodeInput from "@/components/coupon-code-input"

export default function CartPage() {
  const { toast } = useToast()
  const [paymentMethod, setPaymentMethod] = useState<"bit" | "cash">("bit")
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    phone: "",
    email: "",
    notes: "",
  })
  const [isCheckingOut, setIsCheckingOut] = useState(false)
  const [isOrderComplete, setIsOrderComplete] = useState(false)
  const [orderNumber, setOrderNumber] = useState("")

  // Add this state to the component
  const [couponDiscount, setCouponDiscount] = useState(0)
  const [couponType, setCouponType] = useState<"percentage" | "fixed">("fixed")
  const [appliedCouponCode, setAppliedCouponCode] = useState("")

  // Get cart and products from store
  const cart = useStore((state) => state.cart)
  const products = useStore((state) => state.products)
  const updateCartItem = useStore((state) => state.updateCartItem)
  const removeFromCart = useStore((state) => state.removeFromCart)
  const clearCart = useStore((state) => state.clearCart)
  const createOrder = useStore((state) => state.createOrder)
  const loggedInCustomerId = useStore((state) => state.loggedInCustomerId)

  // Calculate cart items and total
  const cartItems = cart.map((item) => {
    const product = products.find((p) => p.id === item.productId)
    return {
      ...item,
      product: product || {
        id: item.productId,
        name: "מוצר לא קיים",
        price: 0,
        image: "/placeholder.svg",
      },
    }
  })

  const cartTotal = cartItems.reduce((total, item) => {
    return total + item.product.price * item.quantity
  }, 0)

  const handleQuantityChange = (productId: string, newQuantity: number) => {
    if (newQuantity < 1) return
    updateCartItem(productId, newQuantity)
  }

  const handleRemoveItem = (productId: string) => {
    removeFromCart(productId)
    toast({
      title: "הפריט הוסר",
      description: "הפריט הוסר מסל הקניות שלך",
    })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setCustomerInfo((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Add this function to handle coupon application
  const handleApplyCoupon = (discount: number, type: "percentage" | "fixed", code: string) => {
    setCouponDiscount(discount)
    setCouponType(type)
    setAppliedCouponCode(code)
  }

  const handleRemoveCoupon = () => {
    setCouponDiscount(0)
    setCouponType("fixed")
    setAppliedCouponCode("")
  }

  // Calculate the final price with coupon discount
  const calculateFinalPrice = () => {
    if (couponDiscount <= 0) return cartTotal

    if (couponType === "percentage") {
      return cartTotal - cartTotal * (couponDiscount / 100)
    } else {
      return Math.max(0, cartTotal - couponDiscount)
    }
  }

  const handleCheckout = () => {
    if (!customerInfo.name || !customerInfo.phone) {
      toast({
        title: "שגיאה",
        description: "אנא מלאי את כל השדות הנדרשים",
        variant: "destructive",
      })
      return
    }

    // Generate order number
    const newOrderNumber = Date.now().toString().slice(-6)
    setOrderNumber(newOrderNumber)

    // Create order
    const newOrder = {
      id: `order-${Date.now()}`,
      customerId: loggedInCustomerId || "",
      customerName: customerInfo.name,
      customerPhone: customerInfo.phone,
      customerEmail: customerInfo.email,
      items: cartItems.map((item) => ({
        productId: item.productId,
        productName: item.product.name,
        quantity: item.quantity,
        price: item.product.price,
      })),
      total: calculateFinalPrice(),
      status: "pending",
      paymentMethod: paymentMethod,
      pickupMethod: "pickup",
      date: new Date().toISOString().split("T")[0],
      notes: customerInfo.notes,
      couponCode: appliedCouponCode,
      couponDiscount: couponDiscount,
      couponType: couponType,
    }

    createOrder(newOrder)

    // Clear cart
    clearCart()

    // Show success message
    setIsOrderComplete(true)

    // Simulate SMS sending
    toast({
      title: "הודעת SMS נשלחה",
      description: `הודעת אישור נשלחה למספר ${customerInfo.phone}`,
    })
  }

  // Add useEffect to auto-fill customer info from logged-in user
  useEffect(() => {
    // Check if user is logged in
    if (loggedInCustomerId) {
      const customers = useStore.getState().customers
      const loggedInCustomer = customers.find((c) => c.id === loggedInCustomerId)

      if (loggedInCustomer) {
        setCustomerInfo({
          name: loggedInCustomer.name || "",
          phone: loggedInCustomer.phone || "",
          email: loggedInCustomer.email || "",
          notes: "",
        })
      }
    }
  }, [loggedInCustomerId])

  if (isOrderComplete) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-3xl mx-auto text-center">
          <Card>
            <CardContent className="pt-6 pb-6">
              <div className="text-center py-8">
                <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-green-100">
                  <CheckCircle className="h-10 w-10 text-green-600" />
                </div>
                <h2 className="text-2xl font-bold mb-4">ההזמנה התקבלה בהצלחה!</h2>
                <p className="text-gray-600 mb-6">
                  תודה על הזמנתך! מספר ההזמנה שלך הוא: <span className="font-bold">#{orderNumber}</span>
                </p>
                <Alert className="bg-blue-50 border-blue-200 mb-6 max-w-md mx-auto">
                  <AlertTitle className="text-blue-800">הודעת SMS נשלחה אליך</AlertTitle>
                  <AlertDescription className="text-blue-700">
                    שלחנו לך הודעת SMS עם פרטי ההזמנה. ניצור איתך קשר בהקדם לתיאום איסוף.
                  </AlertDescription>
                </Alert>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link href="/">
                    <Button className="w-full bg-pink-500 hover:bg-pink-600" onClick={() => console.log("TODO: Add functionality")}>חזרה לדף הבית</Button>
                  </Link>
                  <Link href="/shop">
                    <Button variant="outline" onClick={() => console.log("TODO: Add functionality")}>המשך בקניות</Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-3xl font-bold mb-6">סל הקניות שלך</h1>
          <Card>
            <CardContent className="pt-6 pb-6">
              <div className="text-center py-12">
                <ShoppingBag className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500 mb-6">סל הקניות שלך ריק</p>
                <Link href="/shop">
                  <Button className="bg-pink-500 hover:bg-pink-600" onClick={() => console.log("TODO: Add functionality")}>
                    <ArrowRight className="ml-2 h-4 w-4" /> המשך בקניות
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center mb-6">
          <Link href="/shop" className="text-gray-500 hover:text-pink-500 flex items-center">
            <ArrowRight className="ml-1 h-4 w-4" /> חזרה לחנות
          </Link>
          <h1 className="text-3xl font-bold mr-auto">סל הקניות שלך</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <Card>
              <CardHeader className="p-4">
                <CardTitle className="text-lg">פריטים בסל</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>מוצר</TableHead>
                      <TableHead>מחיר</TableHead>
                      <TableHead>כמות</TableHead>
                      <TableHead>סה"כ</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cartItems.map((item) => (
                      <TableRow key={item.productId}>
                        <TableCell>
                          <div className="flex items-center">
                            <div className="w-12 h-12 relative rounded overflow-hidden mr-3">
                              <Image
                                src={item.product.image || "/placeholder.svg"}
                                alt={item.product.name}
                                fill
                                className="object-cover"
                                unoptimized={item.product.image?.startsWith?.("blob:") || false}
                              />
                            </div>
                            <span>{item.product.name}</span>
                          </div>
                        </TableCell>
                        <TableCell>₪{item.product.price}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => handleQuantityChange(item.productId, item.quantity - 1)}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span className="mx-2">{item.quantity}</span>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => handleQuantityChange(item.productId, item.quantity + 1)}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                        <TableCell>₪{item.product.price * item.quantity}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" onClick={() => handleRemoveItem(item.productId)}>
                            <Trash className="h-4 w-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader className="p-4">
                <CardTitle className="text-lg">סיכום הזמנה</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>סה"כ</span>
                    <span className="font-bold">₪{cartTotal}</span>
                  </div>

                  <CouponCodeInput onApply={handleApplyCoupon} onRemove={handleRemoveCoupon} />

                  {couponDiscount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>הנחת קופון:</span>
                      <span>{couponType === "percentage" ? `${couponDiscount}%` : `₪${couponDiscount}`}</span>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <span>משלוח</span>
                    <span>איסוף עצמי</span>
                  </div>
                  <Separator />
                  <div className="pt-2 flex justify-between">
                    <span className="font-bold">סה"כ לתשלום</span>
                    <span className="font-bold text-pink-500">₪{calculateFinalPrice()}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="p-4 pt-0">
                <Button className="w-full bg-pink-500 hover:bg-pink-600" onClick={() => setIsCheckingOut(true)}>
                  המשך לתשלום
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>

        {isCheckingOut && (
          <Card className="mt-6">
            <CardHeader className="p-4">
              <CardTitle className="text-lg">פרטי הזמנה</CardTitle>
              <CardDescription>אנא מלאי את הפרטים הבאים להשלמת ההזמנה</CardDescription>
            </CardHeader>
            <CardContent className="p-4 pt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="space-y-2">
                  <Label htmlFor="name">שם מלא *</Label>
                  <Input id="name" name="name" value={customerInfo.name} onChange={handleInputChange} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">טלפון *</Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={customerInfo.phone}
                    onChange={handleInputChange}
                    required
                    type="tel"
                    inputMode="numeric"
                    pattern="[0-9]*"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">אימייל</Label>
                  <Input id="email" name="email" type="email" value={customerInfo.email} onChange={handleInputChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">הערות</Label>
                  <Textarea id="notes" name="notes" value={customerInfo.notes} onChange={handleInputChange} />
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="font-medium mb-2">אמצעי תשלום</h3>
                  <RadioGroup
                    value={paymentMethod}
                    onValueChange={(value) => setPaymentMethod(value as "bit" | "cash")}
                    className="space-y-2"
                  >
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value="bit" id="bit" />
                      <Label htmlFor="bit" className="flex items-center">
                        <CreditCard className="mr-2 h-4 w-4" />
                        תשלום בביט
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value="cash" id="cash" />
                      <Label htmlFor="cash" className="flex items-center">
                        <Banknote className="mr-2 h-4 w-4" />
                        תשלום במזומן בעת האיסוף
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                {paymentMethod === "bit" && (
                  <div className="bg-blue-50 p-4 rounded-md">
                    <p className="text-blue-700 mb-2 font-medium">פרטי תשלום בביט:</p>
                    <p className="text-blue-600">מספר טלפון לביט: 052-8588876</p>
                    <p className="text-blue-600 text-sm mt-2">לאחר ביצוע התשלום, ניצור איתך קשר לתיאום איסוף</p>
                  </div>
                )}

                {paymentMethod === "cash" && (
                  <div className="bg-green-50 p-4 rounded-md">
                    <p className="text-green-700">ניצור איתך קשר לתיאום איסוף והתשלום יתבצע במזומן בעת האיסוף</p>
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="p-4 pt-0 flex flex-col sm:flex-row gap-2">
              <Button className="bg-pink-500 hover:bg-pink-600 w-full sm:w-auto" onClick={handleCheckout}>
                אישור והשלמת הזמנה
              </Button>
              <Button variant="outline" className="w-full sm:w-auto" onClick={() => setIsCheckingOut(false)}>
                חזרה לסל הקניות
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  )
}
