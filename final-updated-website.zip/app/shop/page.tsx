"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Search } from "lucide-react"
import Image from "next/image"
import { useStore } from "@/lib/store"
import { useToast } from "@/components/ui/use-toast"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ShopPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState<"name" | "price-low" | "price-high" | "newest">("name")
  const { toast } = useToast()

  // Get products and cart functions from store
  const products = useStore((state) => state.products)
  const addToCart = useStore((state) => state.addToCart)
  const cart = useStore((state) => state.cart)

  // Filter products based on search query
  const filteredProducts = products.filter((product) => {
    return (
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })

  // Sort products based on selected sort option
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "name":
        return a.name.localeCompare(b.name)
      case "price-low":
        return a.price - b.price
      case "price-high":
        return b.price - a.price
      case "newest":
        // Assuming newer products have higher IDs
        return Number.parseInt(b.id) - Number.parseInt(a.id)
      default:
        return 0
    }
  })

  const handleAddToCart = (productId: string) => {
    addToCart(productId, 1)

    const product = products.find((p) => p.id === productId)

    toast({
      title: "נוסף לסל הקניות",
      description: `${product?.name} נוסף לסל הקניות שלך`,
    })
  }

  const cartItemsCount = cart.reduce((total, item) => total + item.quantity, 0)

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2">החנות שלנו</h1>
          <p className="text-gray-600">מגוון מוצרים איכותיים לטיפוח הציפורניים והידיים</p>
        </div>

        {cartItemsCount > 0 && (
          <Link href="/shop/cart">
            <Button className="bg-pink-500 hover:bg-pink-600" onClick={() => console.log("TODO: Add functionality")}>
              <ShoppingCart className="mr-2 h-4 w-4" />
              צפייה בסל ({cartItemsCount})
            </Button>
          </Link>
        )}
      </div>

      <div className="bg-gray-50 p-4 rounded-lg mb-8">
        <div className="flex flex-col md:flex-row gap-4 justify-between">
          <div className="flex flex-col sm:flex-row gap-4 flex-1">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="חיפוש מוצרים..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="w-full sm:w-48">
              <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                <SelectTrigger>
                  <SelectValue placeholder="מיון לפי" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">שם (א-ת)</SelectItem>
                  <SelectItem value="price-low">מחיר (מהנמוך לגבוה)</SelectItem>
                  <SelectItem value="price-high">מחיר (מהגבוה לנמוך)</SelectItem>
                  <SelectItem value="newest">החדשים ביותר</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {sortedProducts.length > 0 ? (
          sortedProducts.map((product) => (
            <Card key={product.id} className="overflow-hidden h-full flex flex-col">
              <div className="aspect-square relative">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-cover"
                  unoptimized={product.image?.startsWith("blob:")}
                />
                {product.status === "new" && <Badge className="absolute top-2 right-2 bg-blue-500">חדש</Badge>}
                {product.status === "out_of_stock" && (
                  <Badge className="absolute top-2 right-2 bg-red-500">אזל מהמלאי</Badge>
                )}
              </div>
              <CardContent className="p-3 flex-grow">
                <h3 className="font-medium text-sm mb-1 line-clamp-1">{product.name}</h3>
                <p className="text-xs text-gray-500 mb-2 line-clamp-2">{product.description}</p>
                <div className="flex justify-between items-center mt-auto">
                  <div className="text-sm font-bold text-pink-500">₪{product.price}</div>
                  <Button
                    className="bg-pink-500 hover:bg-pink-600"
                    onClick={() => handleAddToCart(product.id)}
                    disabled={product.status === "out_of_stock"}
                    size="sm"
                  >
                    <ShoppingCart className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="col-span-full text-center py-12 bg-gray-50 rounded-lg">
            <p className="text-gray-500">לא נמצאו מוצרים התואמים את החיפוש</p>
          </div>
        )}
      </div>
    </div>
  )
}
