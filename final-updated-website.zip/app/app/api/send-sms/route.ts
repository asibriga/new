
// app/api/send-sms/route.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export async function POST(req: NextRequest) {
  const body = await req.json();

  const { apiKey, to, message } = body;

  if (!apiKey || !to || !message) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  try {
    const response = await fetch("https://d7networks.com/api/verifier/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        to,
        content: message,
        from: "SMSInfo", // You can change this sender ID if you have a custom one
        channel: "sms"
      })
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result?.error || 'Failed to send SMS');
    }

    return NextResponse.json({ success: true, result }, { status: 200 });
  } catch (error: any) {
    console.error('D7 Error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
