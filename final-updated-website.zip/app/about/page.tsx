"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"
import { useStore } from "@/store/store"

export default function AboutPage() {
  const siteContent = useStore((state) => state.siteContent)
  const [content, setContent] = useState(siteContent)

  // Update content when store changes
  useEffect(() => {
    setContent(siteContent)
  }, [siteContent])

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">אודות May Beauty</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">הסטודיו המקצועי לבניית ציפורניים וטיפולי יופי</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
        <div>
          <h2 className="text-2xl font-bold mb-4">הסיפור שלנו</h2>
          <div className="text-gray-700 space-y-4">
            {content.aboutText.split("\n").map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
        </div>
        <div className="relative h-80 rounded-lg overflow-hidden">
          <Image src="/placeholder.svg?height=400&width=600" alt="סטודיו May Beauty" fill className="object-cover" />
        </div>
      </div>

      <div className="bg-pink-50 rounded-lg p-8 mb-16">
        <h2 className="text-2xl font-bold mb-6 text-center">למה לבחור בנו?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-pink-500 mt-1 ml-2 flex-shrink-0" />
                <div>
                  <h3 className="font-bold mb-2">מקצועיות</h3>
                  <p className="text-gray-600">צוות מקצועי ומנוסה שעובר הכשרות והשתלמויות באופן קבוע</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-pink-500 mt-1 ml-2 flex-shrink-0" />
                <div>
                  <h3 className="font-bold mb-2">חומרים איכותיים</h3>
                  <p className="text-gray-600">שימוש בחומרים האיכותיים והמתקדמים ביותר בשוק</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-pink-500 mt-1 ml-2 flex-shrink-0" />
                <div>
                  <h3 className="font-bold mb-2">היגיינה</h3>
                  <p className="text-gray-600">הקפדה על סטרליזציה והיגיינה ברמה הגבוהה ביותר</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-pink-500 mt-1 ml-2 flex-shrink-0" />
                <div>
                  <h3 className="font-bold mb-2">אווירה נעימה</h3>
                  <p className="text-gray-600">סטודיו מעוצב ונעים עם אווירה רגועה ומפנקת</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-pink-500 mt-1 ml-2 flex-shrink-0" />
                <div>
                  <h3 className="font-bold mb-2">מחירים הוגנים</h3>
                  <p className="text-gray-600">מחירים הוגנים ביחס לאיכות הגבוהה של השירותים שלנו</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-pink-500 mt-1 ml-2 flex-shrink-0" />
                <div>
                  <h3 className="font-bold mb-2">שירות אישי</h3>
                  <p className="text-gray-600">יחס אישי ומותאם לכל לקוחה, תוך הקשבה לצרכים ולרצונות שלה</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6 text-center">מאי - בעלת הסטודיו</h2>
        <div className="flex flex-col md:flex-row items-center justify-center gap-8">
          <div className="relative h-64 w-64 rounded-lg overflow-hidden">
            <Image
              src="https://media-hosting.imagekit.io/ef15b461fda74496/WhatsApp Image 2025-05-11 at 23.09.10.jpeg?Expires=1841602732&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=RTr6SJcnKjoG9C9BXLyzbYXT0v85qG4Lf2Rpj3HirhYgNfnRW1HatpgrM8l0cxunMqe8hSTY5wPYMwjERRDVkFl4eZckTTcuQkbqyT3AZUQj5WRYKgsY7U4-YptFYHEvW0GS08hzgnNA~TDW7MBXp42j1YnPWtYK0eK~DsbPUjN7OSwrjHKClf2KT~oivKOgPNZARV9qBtJSGZcO33BDfhGfh~OV~924IoLLQB73uQKdbrCI2xYTCWxYRxw0tEmupe2O5OqBaD3wgb2TxL63l-7NLTSind5DCll2sQ1jYmdcRhBXhVlaEQpqnI1kYJs91b5o73ZJzjN8h9oLXvc7bw__"
              alt="מאי - בעלת הסטודיו"
              fill
              className="object-cover"
            />
          </div>
          <div className="max-w-md text-center md:text-right">
            <h3 className="font-bold text-lg mb-2">מאי</h3>
            <p className="text-gray-600">
              מאי היא בעלת הסטודיו ומניקוריסטית מקצועית עם ניסיון של מעל 5 שנים בתחום. היא בוגרת קורסים מתקדמים בבניית
              ציפורניים ועיצוב ציפורניים, ומתמחה בטכניקות חדשניות ועיצובים ייחודיים. מאי מקפידה על עבודה מקצועית,
              סטרילית ואיכותית, ומעניקה יחס אישי לכל לקוחה.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
