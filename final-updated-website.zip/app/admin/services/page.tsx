"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Edit, Plus, Trash, Upload, Link } from "lucide-react"
import { useStore } from "@/lib/store"
import { useToast } from "@/components/ui/use-toast"
import Image from "next/image"

export default function ServicesPage() {
  const { toast } = useToast()
  const services = useStore((state) => state.services)
  const addService = useStore((state) => state.addService)
  const updateService = useStore((state) => state.updateService)
  const deleteService = useStore((state) => state.deleteService)

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [currentService, setCurrentService] = useState<any>(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    duration: "",
    price: "",
    image: "",
  })

  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Create a URL for the selected image
    const imageUrl = URL.createObjectURL(file)
    setFormData((prev) => ({ ...prev, image: imageUrl }))

    // Log for debugging
    console.log("Image URL created for service:", imageUrl)
  }

  const handleAddService = () => {
    // Validate data
    if (!formData.name || !formData.description || !formData.duration || !formData.price) {
      toast({
        title: "שגיאה",
        description: "אנא מלאי את כל השדות הנדרשים",
        variant: "destructive",
      })
      return
    }

    // Parse numeric values
    const duration = Number.parseInt(formData.duration, 10)
    const price = Number.parseInt(formData.price, 10)

    if (isNaN(duration) || isNaN(price)) {
      toast({
        title: "שגיאה",
        description: "משך זמן ומחיר חייבים להיות מספרים",
        variant: "destructive",
      })
      return
    }

    const newService = {
      id: Date.now().toString(),
      name: formData.name,
      description: formData.description,
      duration: duration,
      price: price,
      image: formData.image || "/placeholder.svg?height=200&width=300",
    }

    // Add service to store
    addService(newService)

    // Reset form
    setFormData({ name: "", description: "", duration: "", price: "", image: "" })
    setIsAddDialogOpen(false)

    toast({
      title: "השירות נוסף בהצלחה",
      description: `השירות ${newService.name} נוסף בהצלחה`,
    })

    // Log for debugging
    console.log("Service added:", newService)
  }

  const handleEditService = () => {
    if (!currentService) return

    // Validate data
    if (!formData.name || !formData.description || !formData.duration || !formData.price) {
      toast({
        title: "שגיאה",
        description: "אנא מלאי את כל השדות הנדרשים",
        variant: "destructive",
      })
      return
    }

    // Parse numeric values
    const duration = Number.parseInt(formData.duration, 10)
    const price = Number.parseInt(formData.price, 10)

    if (isNaN(duration) || isNaN(price)) {
      toast({
        title: "שגיאה",
        description: "משך זמן ומחיר חייבים להיות מספרים",
        variant: "destructive",
      })
      return
    }

    const updatedService = {
      name: formData.name,
      description: formData.description,
      duration: duration,
      price: price,
      image: formData.image,
    }

    updateService(currentService.id, updatedService)
    setIsEditDialogOpen(false)

    toast({
      title: "השירות עודכן בהצלחה",
      description: `השירות ${updatedService.name} עודכן בהצלחה`,
    })
  }

  const handleDeleteService = (id: string) => {
    deleteService(id)

    toast({
      title: "השירות נמחק בהצלחה",
      description: "השירות נמחק מהמערכת",
    })
  }

  const openEditDialog = (service: any) => {
    setCurrentService(service)
    setFormData({
      name: service.name,
      description: service.description,
      duration: service.duration.toString(),
      price: service.price.toString(),
      image: service.image || "",
    })
    setIsEditDialogOpen(true)
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
        <h1 className="text-2xl font-bold">ניהול שירותים</h1>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-pink-500 hover:bg-pink-600 w-full sm:w-auto" onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" /> הוספת שירות חדש
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>הוספת שירות חדש</DialogTitle>
              <DialogDescription>הזיני את פרטי השירות החדש</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">שם השירות</Label>
                <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">תיאור</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="duration">משך זמן (דקות)</Label>
                  <Input
                    id="duration"
                    name="duration"
                    type="number"
                    value={formData.duration}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="price">מחיר (₪)</Label>
                  <Input
                    id="price"
                    name="price"
                    type="number"
                    value={formData.price}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="image">תמונה</Label>
                <div className="flex flex-wrap items-center gap-2">
                  <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="mr-2 h-4 w-4" /> העלאת תמונה
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      const imageUrl = prompt("הזן כתובת URL לתמונה:")
                      if (imageUrl && imageUrl.trim() !== "") {
                        setFormData((prev) => ({ ...prev, image: imageUrl }))
                      }
                    }}
                  >
                    <Link className="mr-2 h-4 w-4" /> הוספת URL
                  </Button>
                  <Input
                    ref={fileInputRef}
                    id="image"
                    name="image"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileChange}
                  />
                  {formData.image && (
                    <div className="relative w-12 h-12 rounded overflow-hidden">
                      <Image
                        src={formData.image || "/placeholder.svg"}
                        alt="תמונת שירות"
                        fill
                        className="object-cover"
                        unoptimized={formData.image?.startsWith?.("blob:") || false}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                ביטול
              </Button>
              <Button type="button" onClick={handleAddService} className="bg-pink-500 hover:bg-pink-600">
                הוספה
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader className="p-4">
          <CardTitle className="text-lg">רשימת השירותים</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>תמונה</TableHead>
                <TableHead>שם השירות</TableHead>
                <TableHead>תיאור</TableHead>
                <TableHead>משך זמן</TableHead>
                <TableHead>מחיר</TableHead>
                <TableHead className="text-left">פעולות</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {services.map((service) => (
                <TableRow key={service.id}>
                  <TableCell>
                    <div className="relative w-12 h-12 rounded overflow-hidden">
                      <Image
                        src={service.image || "/placeholder.svg?height=50&width=50"}
                        alt={service.name}
                        fill
                        className="object-cover"
                        unoptimized={service.image?.startsWith("blob:")}
                      />
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{service.name}</TableCell>
                  <TableCell>{service.description}</TableCell>
                  <TableCell>{service.duration} דקות</TableCell>
                  <TableCell>₪{service.price}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-blue-600 hover:bg-blue-50"
                        onClick={(e) => {
                          e.preventDefault()
                          e.stopPropagation()
                          setCurrentService(service)
                          setFormData({
                            name: service.name,
                            description: service.description,
                            duration: service.duration.toString(),
                            price: service.price.toString(),
                            image: service.image || "",
                          })
                          setIsEditDialogOpen(true)
                        }}
                        type="button"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-red-600 hover:bg-red-50"
                        onClick={(e) => {
                          e.preventDefault()
                          e.stopPropagation()
                          if (confirm(`האם אתה בטוח שברצונך למחוק את השירות "${service.name}"?`)) {
                            handleDeleteService(service.id)
                            toast({
                              title: "השירות נמחק",
                              description: `השירות ${service.name} נמחק בהצלחה`,
                            })
                          }
                        }}
                        type="button"
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>עריכת שירות</DialogTitle>
            <DialogDescription>ערכי את פרטי השירות</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">שם השירות</Label>
              <Input id="edit-name" name="name" value={formData.name} onChange={handleChange} required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-description">תיאור</Label>
              <Textarea
                id="edit-description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-duration">משך זמן (דקות)</Label>
                <Input
                  id="edit-duration"
                  name="duration"
                  type="number"
                  value={formData.duration}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-price">מחיר (₪)</Label>
                <Input
                  id="edit-price"
                  name="price"
                  type="number"
                  value={formData.price}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-image">תמונה</Label>
              <div className="flex flex-wrap items-center gap-2">
                <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()}>
                  <Upload className="mr-2 h-4 w-4" /> החלפת תמונה
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    const imageUrl = prompt("הזן כתובת URL לתמונה:")
                    if (imageUrl && imageUrl.trim() !== "") {
                      setFormData((prev) => ({ ...prev, image: imageUrl }))
                    }
                  }}
                >
                  <Link className="mr-2 h-4 w-4" /> הוספת URL
                </Button>
                <Input
                  ref={fileInputRef}
                  id="edit-image"
                  name="image"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
                {formData.image && (
                  <div className="relative w-12 h-12 rounded overflow-hidden">
                    <Image
                      src={formData.image || "/placeholder.svg"}
                      alt="תמונת שירות"
                      fill
                      className="object-cover"
                      unoptimized={formData.image?.startsWith?.("blob:") || false}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              ביטול
            </Button>
            <Button type="button" onClick={handleEditService} className="bg-pink-500 hover:bg-pink-600">
              שמירה
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
