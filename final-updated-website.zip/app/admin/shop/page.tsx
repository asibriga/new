"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Edit, Plus, Trash, Upload, Link } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useStore } from "@/lib/store"
import Image from "next/image"
import { useToast } from "@/components/ui/use-toast"

export default function ShopPage() {
  const { toast } = useToast()
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [currentProduct, setCurrentProduct] = useState<any>(null)

  // Get products from store
  const products = useStore((state) => state.products)
  const addProduct = useStore((state) => state.addProduct)
  const updateProduct = useStore((state) => state.updateProduct)
  const deleteProduct = useStore((state) => state.deleteProduct)

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    category: "",
    price: "",
    stock: "",
    status: "active",
    image: "",
  })

  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // יצירת URL לתמונה שנבחרה
    const imageUrl = URL.createObjectURL(file)
    setFormData((prev) => ({ ...prev, image: imageUrl }))

    // הוספת לוג לבדיקה
    console.log("Product image URL created:", imageUrl)
  }

  const handleAddProduct = () => {
    if (!formData.name || !formData.category || !formData.price || !formData.stock) {
      toast({
        title: "שגיאה",
        description: "אנא מלא את כל השדות הנדרשים",
        variant: "destructive",
      })
      return
    }

    try {
      const newProduct = {
        name: formData.name,
        description: formData.description,
        category: formData.category,
        price: Number(formData.price),
        stock: Number(formData.stock),
        status: formData.status,
        image: formData.image || "/placeholder.svg?height=200&width=300",
      }

      addProduct(newProduct)

      setFormData({
        name: "",
        description: "",
        category: "",
        price: "",
        stock: "",
        status: "active",
        image: "",
      })

      setIsAddDialogOpen(false)

      toast({
        title: "המוצר נוסף בהצלחה",
        description: `המוצר ${newProduct.name} נוסף בהצלחה`,
      })
    } catch (error) {
      console.error("Error adding product:", error)
      toast({
        title: "שגיאה בהוספת המוצר",
        description: "אירעה שגיאה בהוספת המוצר. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  const handleEditProduct = () => {
    if (!currentProduct) return

    try {
      const updatedProduct = {
        name: formData.name,
        description: formData.description,
        category: formData.category,
        price: Number(formData.price),
        stock: Number(formData.stock),
        status: formData.status,
        image: formData.image,
      }

      updateProduct(currentProduct.id, updatedProduct)
      setIsEditDialogOpen(false)

      toast({
        title: "המוצר עודכן בהצלחה",
        description: `המוצר ${updatedProduct.name} עודכן בהצלחה`,
      })
    } catch (error) {
      console.error("Error updating product:", error)
      toast({
        title: "שגיאה בעדכון המוצר",
        description: "אירעה שגיאה בעדכון המוצר. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteProduct = (id: string) => {
    try {
      deleteProduct(id)

      toast({
        title: "המוצר נמחק בהצלחה",
        description: "המוצר נמחק מהמערכת",
      })
    } catch (error) {
      console.error("Error deleting product:", error)
      toast({
        title: "שגיאה במחיקת המוצר",
        description: "אירעה שגיאה במחיקת המוצר. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  const openEditDialog = (product: any) => {
    setCurrentProduct(product)
    setFormData({
      name: product.name,
      description: product.description,
      category: product.category,
      price: product.price.toString(),
      stock: product.stock.toString(),
      status: product.status,
      image: product.image || "",
    })
    setIsEditDialogOpen(true)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">פעיל</Badge>
      case "inactive":
        return (
          <Badge variant="outline" className="text-gray-500 border-gray-500">
            לא פעיל
          </Badge>
        )
      case "out_of_stock":
        return <Badge variant="destructive">אזל מהמלאי</Badge>
      default:
        return null
    }
  }

  const getCategoryName = (categoryId: string) => {
    const categories = [
      { id: "drees", name: "שמלות" },
      { id: "polish", name: "לקים" },
      { id: "care", name: "טיפוח" },
      { id: "tools", name: "כלים וציוד" },
      { id: "kits", name: "ערכות" },
    ]
    const category = categories.find((c) => c.id === categoryId)
    return category ? category.name : categoryId
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
        <h1 className="text-2xl font-bold">ניהול חנות</h1>
        <Button className="bg-pink-500 hover:bg-pink-600 w-full sm:w-auto" onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> הוספת מוצר חדש
        </Button>
      </div>

      <Card>
        <CardHeader className="p-4">
          <CardTitle className="text-lg">רשימת המוצרים</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>תמונה</TableHead>
                <TableHead>שם המוצר</TableHead>
                <TableHead>קטגוריה</TableHead>
                <TableHead>מחיר</TableHead>
                <TableHead>מלאי</TableHead>
                <TableHead>סטטוס</TableHead>
                <TableHead className="text-left">פעולות</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((product) => (
                <TableRow key={product.id}>
                  <TableCell>
                    <div className="relative w-12 h-12 rounded overflow-hidden">
                      <Image
                        src={product.image || "/placeholder.svg?height=50&width=50"}
                        alt={product.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{product.name}</TableCell>
                  <TableCell>{getCategoryName(product.category)}</TableCell>
                  <TableCell>₪{product.price}</TableCell>
                  <TableCell>{product.stock}</TableCell>
                  <TableCell>{getStatusBadge(product.status)}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-blue-600 hover:bg-blue-50"
                        onClick={() => {
                          setCurrentProduct(product)
                          setFormData({
                            name: product.name,
                            description: product.description,
                            category: product.category,
                            price: product.price.toString(),
                            stock: product.stock.toString(),
                            status: product.status,
                            image: product.image || "",
                          })
                          setIsEditDialogOpen(true)
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-red-600 hover:bg-red-50"
                        onClick={() => {
                          if (confirm(`האם אתה בטוח שברצונך למחוק את המוצר "${product.name}"?`)) {
                            handleDeleteProduct(product.id)
                            toast({
                              title: "המוצר נמחק",
                              description: `המוצר ${product.name} נמחק בהצלחה`,
                            })
                          }
                        }}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Add Product Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>הוספת מוצר חדש</DialogTitle>
            <DialogDescription>הזיני את פרטי המוצר החדש</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">שם המוצר</Label>
              <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">תיאור</Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="category">קטגוריה</Label>
              <Select value={formData.category} onValueChange={(value) => handleSelectChange("category", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="בחרי קטגוריה" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="polish">לקים</SelectItem>
                  <SelectItem value="care">טיפוח</SelectItem>
                  <SelectItem value="tools">כלים וציוד</SelectItem>
                  <SelectItem value="kits">ערכות</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="price">מחיר (₪)</Label>
                <Input id="price" name="price" type="number" value={formData.price} onChange={handleChange} required />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="stock">מלאי</Label>
                <Input id="stock" name="stock" type="number" value={formData.stock} onChange={handleChange} required />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="status">סטטוס</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="בחרי סטטוס" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">פעיל</SelectItem>
                  <SelectItem value="inactive">לא פעיל</SelectItem>
                  <SelectItem value="out_of_stock">אזל מהמלאי</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="image">תמונה</Label>
              <div className="flex flex-wrap items-center gap-2">
                <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()}>
                  <Upload className="mr-2 h-4 w-4" /> העלאת תמונה
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    const imageUrl = prompt("הזן כתובת URL לתמונה:")
                    if (imageUrl && imageUrl.trim() !== "") {
                      setFormData((prev) => ({ ...prev, image: imageUrl }))
                      console.log("Product image URL added:", imageUrl)
                    }
                  }}
                >
                  <Link className="mr-2 h-4 w-4" /> הוספת URL
                </Button>
                <Input
                  ref={fileInputRef}
                  id="image"
                  name="image"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
                {formData.image && (
                  <div className="relative w-12 h-12 rounded overflow-hidden">
                    <Image
                      src={formData.image || "/placeholder.svg"}
                      alt="תמונת מוצר"
                      fill
                      className="object-cover"
                      unoptimized={formData.image?.startsWith?.("blob:") || false}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              ביטול
            </Button>
            <Button type="button" onClick={handleAddProduct} className="bg-pink-500 hover:bg-pink-600">
              הוספה
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Product Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>עריכת מוצר</DialogTitle>
            <DialogDescription>ערכי את פרטי המוצר</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">שם המוצר</Label>
              <Input id="edit-name" name="name" value={formData.name} onChange={handleChange} required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-description">תיאור</Label>
              <Textarea
                id="edit-description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-category">קטגוריה</Label>
              <Select value={formData.category} onValueChange={(value) => handleSelectChange("category", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="בחרי קטגוריה" />
                </SelectTrigger>
                <SelectContent>
                 <SelectItem value="drees">שמלות</SelectItem>
                  <SelectItem value="polish">לקים</SelectItem>
                  <SelectItem value="care">טיפוח</SelectItem>
                  <SelectItem value="tools">כלים וציוד</SelectItem>
                  <SelectItem value="kits">ערכות</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-price">מחיר (₪)</Label>
                <Input
                  id="edit-price"
                  name="price"
                  type="number"
                  value={formData.price}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-stock">מלאי</Label>
                <Input
                  id="edit-stock"
                  name="stock"
                  type="number"
                  value={formData.stock}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-status">סטטוס</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="בחרי סטטוס" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">פעיל</SelectItem>
                  <SelectItem value="inactive">לא פעיל</SelectItem>
                  <SelectItem value="out_of_stock">אזל מהמלאי</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-image">תמונה</Label>
              <div className="flex flex-wrap items-center gap-2">
                <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()}>
                  <Upload className="mr-2 h-4 w-4" /> החלפת תמונה
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    const imageUrl = prompt("הזן כתובת URL לתמונה:")
                    if (imageUrl && imageUrl.trim() !== "") {
                      setFormData((prev) => ({ ...prev, image: imageUrl }))
                      console.log("Product image URL added:", imageUrl)
                    }
                  }}
                >
                  <Link className="mr-2 h-4 w-4" /> הוספת URL
                </Button>
                <Input
                  ref={fileInputRef}
                  id="edit-image"
                  name="image"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
                {formData.image && (
                  <div className="relative w-12 h-12 rounded overflow-hidden">
                    <Image
                      src={formData.image || "/placeholder.svg"}
                      alt="תמונת מוצר"
                      fill
                      className="object-cover"
                      unoptimized={formData.image?.startsWith?.("blob:") || false}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              ביטול
            </Button>
            <Button type="button" onClick={handleEditProduct} className="bg-pink-500 hover:bg-pink-600">
              שמירה
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
