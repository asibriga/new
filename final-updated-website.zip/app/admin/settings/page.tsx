"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import GeneralSettings from "./general"
import SmsTemplates from "./sms-templates"
import HolidaysSettings from "./holidays"
import TwilioIntegration from "./twilio-integration"

export default function SettingsPage() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">הגדרות</h1>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">כללי</TabsTrigger>
          <TabsTrigger value="sms">תבניות SMS</TabsTrigger>
          <TabsTrigger value="twilio">Twilio</TabsTrigger>
          <TabsTrigger value="holidays">חגים וימים סגורים</TabsTrigger>
        </TabsList>
        <TabsContent value="general" className="mt-6">
          <GeneralSettings />
        </TabsContent>
        <TabsContent value="sms" className="mt-6">
          <SmsTemplates />
        </TabsContent>
        <TabsContent value="twilio" className="mt-6">
          <TwilioIntegration />
        </TabsContent>
        <TabsContent value="holidays" className="mt-6">
          <HolidaysSettings />
        </TabsContent>
      </Tabs>
    </div>
  )
}
