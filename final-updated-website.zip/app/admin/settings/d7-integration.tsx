
"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { useStore } from "@/lib/store"
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert"
import { Check, AlertCircle } from "lucide-react"

export default function D7Integration() {
  const { toast } = useToast()
  const d7Settings = useStore((state) => state.d7Settings)
  const setD7Settings = useStore((state) => state.setD7Settings)

  const [apiKey, setApiKey] = useState(d7Settings?.apiKey || "")
  const [testing, setTesting] = useState(false)

  const saveSettings = () => {
    setD7Settings({ apiKey })
    toast({ title: "ההגדרות נשמרו בהצלחה", variant: "default" })
  }

  const sendTestSMS = async () => {
    setTesting(true)
    try {
      const res = await fetch("/api/send-sms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          apiKey,
          to: "+972501234567",
          message: "הודעת בדיקה מ-D7"
        })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || "שליחה נכשלה")
      toast({ title: "ההודעה נשלחה בהצלחה!", variant: "success" })
    } catch (error) {
      toast({ title: "שגיאה בשליחת הודעה", description: error.message, variant: "destructive" })
    } finally {
      setTesting(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>הגדרות D7 SMS</CardTitle>
        <Alert variant="default" className="mt-4">
          <AlertTitle>💡 מידע:</AlertTitle>
          <AlertDescription>
            הזן את ה-API Key שלך מ-D7 לשליחת הודעות טקסט. ניתן לבדוק באמצעות הודעת בדיקה.
          </AlertDescription>
        </Alert>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>API Key</Label>
          <Input
            placeholder="הכנס API Key"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
          />
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button onClick={saveSettings}>שמירה</Button>
        <Button variant="secondary" onClick={sendTestSMS} disabled={testing}>
          {testing ? "שולח..." : "שלח הודעת בדיקה"}
        </Button>
      </CardFooter>
    </Card>
  )
}
