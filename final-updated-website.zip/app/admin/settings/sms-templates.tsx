"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Save } from "lucide-react"
import { useStore } from "@/lib/store"

export default function SmsTemplates() {
  const { toast } = useToast()
  const twilioSettings = useStore((state) => state.twilioSettings)
  const updateTwilioSettings = useStore((state) => state.updateTwilioSettings)

  const [templates, setTemplates] = useState(() => {
    const defaultTemplates = {
      appointmentConfirmation: "שלום {name}, התור שלך ל{service} ב-May Beauty נקבע לתאריך {date} בשעה {time}. להתראות!",
      appointmentReminder: "שלום {name}, תזכורת: התור שלך ל{service} ב-May Beauty מחר בשעה {time}. להתראות!",
      appointmentCancellation:
        "שלום {name}, התור שלך ל{service} בתאריך {date} בשעה {time} בוטל. לקביעת תור חדש צרי קשר.",
      waitlistConfirmation: "שלום {name}, תודה שנכנסת לרשימת ההמתנה לתאריך {date}. במידה ויתפנה מקום תעודכני.",
      orderConfirmation:
        "שלום {name}, הזמנתך מ-May Beauty התקבלה בהצלחה! מספר הזמנה: {order_id}. סכום לתשלום: {total}₪. ניצור איתך קשר בהקדם לתיאום איסוף.",
      orderShipped: "שלום {name}, הזמנתך מס' {order_id} נשלחה ותגיע אליך בקרוב. תודה שקנית ב-May Beauty!",
      orderReady: "שלום {name}, הזמנתך מס' {order_id} מוכנה לאיסוף. ניתן לאסוף אותה בשעות הפעילות שלנו.",
      birthdayWish:
        "שלום {name}, צוות May Beauty מאחל לך יום הולדת שמח! קיבלת קופון הנחה של 10% לרגל יום הולדתך: {coupon_code}",
      loyaltyPointsUpdate: 'שלום {name}, צברת {points} נקודות נאמנות חדשות! סה"כ יש לך כעת {total_points} נקודות.',
      loyaltyTierUpgrade:
        "שלום {name}, ברכות! עלית לרמת {tier_name} במועדון הלקוחות שלנו. כעת תוכלי ליהנות מהטבות נוספות!",
      couponIssued:
        "שלום {name}, הונפק לך קופון חדש: {coupon_code}. הקופון מקנה {discount} הנחה ותקף עד {expiry_date}.",
      passwordReset: "שלום {name}, הסיסמה שלך אופסה בהצלחה. הסיסמה החדשה שלך היא: {password}. אנא שני אותה בהקדם.",
      specialPromotion:
        "שלום {name}, מבצע מיוחד ללקוחות May Beauty! {promotion_details}. המבצע בתוקף עד {expiry_date}.",
    }

    // Use templates from twilioSettings if available
    if (twilioSettings && twilioSettings.templates) {
      return {
        ...defaultTemplates,
        ...twilioSettings.templates,
      }
    }

    return defaultTemplates
  })

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setTemplates((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Replace the saveSmsTemplates function with:
  const saveSmsTemplates = () => {
    try {
      // Initialize twilioSettings if it doesn't exist
      const currentSettings = twilioSettings || {
        accountSid: "",
        authToken: "",
        phoneNumber: "",
        isEnabled: true,
        templates: {},
      }

      // Update the Twilio settings with the new templates
      updateTwilioSettings({
        ...currentSettings,
        templates: {
          appointmentConfirmation: templates.appointmentConfirmation,
          appointmentReminder: templates.appointmentReminder,
          appointmentCancellation: templates.appointmentCancellation,
          waitlistConfirmation: templates.waitlistConfirmation,
          orderConfirmation: templates.orderConfirmation,
          orderShipped: templates.orderShipped,
          orderReady: templates.orderReady,
          birthdayWish: templates.birthdayWish,
          loyaltyPointsUpdate: templates.loyaltyPointsUpdate,
          loyaltyTierUpgrade: templates.loyaltyTierUpgrade,
          couponIssued: templates.couponIssued,
          passwordReset: templates.passwordReset,
          specialPromotion: templates.specialPromotion,
        },
      })

      toast({
        title: "תבניות ה-SMS נשמרו בהצלחה",
        description: "כל השינויים נשמרו במערכת",
      })
    } catch (error) {
      console.error("Error saving SMS templates:", error)
      toast({
        title: "שגיאה בשמירת התבניות",
        description: "אירעה שגיאה בשמירת תבניות ה-SMS, נסה שנית",
        variant: "destructive",
      })
    }
  }

  // Update the handleSave function to call saveSmsTemplates:
  const handleSave = () => {
    saveSmsTemplates()
  }

  const handleTestSms = (templateName: string) => {
    if (
      !twilioSettings ||
      !twilioSettings.isEnabled ||
      !twilioSettings.accountSid ||
      !twilioSettings.authToken ||
      !twilioSettings.phoneNumber
    ) {
      toast({
        title: "שגיאה",
        description: "יש להגדיר את פרטי Twilio לפני שליחת הודעת בדיקה",
        variant: "destructive",
      })
      return
    }

    // In a real app, this would send a test SMS
    toast({
      title: "הודעת בדיקה נשלחה",
      description: `הודעת בדיקה נשלחה בהצלחה עם תבנית ${templateName}`,
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>תבניות הודעות SMS</CardTitle>
        <CardDescription>הגדרת תבניות להודעות אוטומטיות</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="appointmentConfirmation">אישור תור</Label>
          <Textarea
            id="appointmentConfirmation"
            name="appointmentConfirmation"
            value={templates.appointmentConfirmation}
            onChange={handleChange}
            rows={3}
          />
          <p className="text-sm text-muted-foreground">
            ניתן להשתמש בתגיות: {"{name}"}, {"{service}"}, {"{date}"}, {"{time}"}
          </p>
          <Button variant="outline" size="sm" onClick={() => handleTestSms("אישור תור")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="appointmentReminder">תזכורת לתור</Label>
          <Textarea
            id="appointmentReminder"
            name="appointmentReminder"
            value={templates.appointmentReminder}
            onChange={handleChange}
            rows={3}
          />
          <Button variant="outline" size="sm" onClick={() => handleTestSms("תזכורת לתור")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="appointmentCancellation">ביטול תור</Label>
          <Textarea
            id="appointmentCancellation"
            name="appointmentCancellation"
            value={templates.appointmentCancellation}
            onChange={handleChange}
            rows={3}
          />
          <Button variant="outline" size="sm" onClick={() => handleTestSms("ביטול תור")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="waitlistConfirmation">אישור רשימת המתנה</Label>
          <Textarea
            id="waitlistConfirmation"
            name="waitlistConfirmation"
            value={templates.waitlistConfirmation}
            onChange={handleChange}
            rows={3}
          />
          <Button variant="outline" size="sm" onClick={() => handleTestSms("אישור רשימת המתנה")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="orderConfirmation">אישור הזמנה מהחנות</Label>
          <Textarea
            id="orderConfirmation"
            name="orderConfirmation"
            value={templates.orderConfirmation}
            onChange={handleChange}
            rows={3}
          />
          <p className="text-sm text-muted-foreground">
            ניתן להשתמש בתגיות: {"{name}"}, {"{order_id}"}, {"{total}"}
          </p>
          <Button variant="outline" size="sm" onClick={() => handleTestSms("אישור הזמנה")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="orderShipped">משלוח הזמנה</Label>
          <Textarea
            id="orderShipped"
            name="orderShipped"
            value={templates.orderShipped}
            onChange={handleChange}
            rows={3}
          />
          <p className="text-sm text-muted-foreground">
            ניתן להשתמש בתגיות: {"{name}"}, {"{order_id}"}
          </p>
          <Button variant="outline" size="sm" onClick={() => handleTestSms("משלוח הזמנה")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="orderReady">הזמנה מוכנה לאיסוף</Label>
          <Textarea id="orderReady" name="orderReady" value={templates.orderReady} onChange={handleChange} rows={3} />
          <p className="text-sm text-muted-foreground">
            ניתן להשתמש בתגיות: {"{name}"}, {"{order_id}"}
          </p>
          <Button variant="outline" size="sm" onClick={() => handleTestSms("הזמנה מוכנה")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="birthdayWish">ברכת יום הולדת</Label>
          <Textarea
            id="birthdayWish"
            name="birthdayWish"
            value={templates.birthdayWish}
            onChange={handleChange}
            rows={3}
          />
          <p className="text-sm text-muted-foreground">
            ניתן להשתמש בתגיות: {"{name}"}, {"{coupon_code}"}
          </p>
          <Button variant="outline" size="sm" onClick={() => handleTestSms("ברכת יום הולדת")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="loyaltyPointsUpdate">עדכון נקודות נאמנות</Label>
          <Textarea
            id="loyaltyPointsUpdate"
            name="loyaltyPointsUpdate"
            value={templates.loyaltyPointsUpdate}
            onChange={handleChange}
            rows={3}
          />
          <p className="text-sm text-muted-foreground">
            ניתן להשתמש בתגיות: {"{name}"}, {"{points}"}, {"{total_points}"}
          </p>
          <Button variant="outline" size="sm" onClick={() => handleTestSms("עדכון נקודות")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="loyaltyTierUpgrade">שדרוג רמת נאמנות</Label>
          <Textarea
            id="loyaltyTierUpgrade"
            name="loyaltyTierUpgrade"
            value={templates.loyaltyTierUpgrade}
            onChange={handleChange}
            rows={3}
          />
          <p className="text-sm text-muted-foreground">
            ניתן להשתמש בתגיות: {"{name}"}, {"{tier_name}"}
          </p>
          <Button variant="outline" size="sm" onClick={() => handleTestSms("שדרוג רמת נאמנות")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="couponIssued">הנפקת קופון</Label>
          <Textarea
            id="couponIssued"
            name="couponIssued"
            value={templates.couponIssued}
            onChange={handleChange}
            rows={3}
          />
          <p className="text-sm text-muted-foreground">
            ניתן להשתמש בתגיות: {"{name}"}, {"{coupon_code}"}, {"{discount}"}, {"{expiry_date}"}
          </p>
          <Button variant="outline" size="sm" onClick={() => handleTestSms("הנפקת קופון")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="passwordReset">איפוס סיסמה</Label>
          <Textarea
            id="passwordReset"
            name="passwordReset"
            value={templates.passwordReset}
            onChange={handleChange}
            rows={3}
          />
          <p className="text-sm text-muted-foreground">
            ניתן להשתמש בתגיות: {"{name}"}, {"{password}"}
          </p>
          <Button variant="outline" size="sm" onClick={() => handleTestSms("איפוס סיסמה")}>
            שליחת הודעת בדיקה
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="specialPromotion">מבצע מיוחד</Label>
          <Textarea
            id="specialPromotion"
            name="specialPromotion"
            value={templates.specialPromotion}
            onChange={handleChange}
            rows={3}
          />
          <p className="text-sm text-muted-foreground">
            ניתן להשתמש בתגיות: {"{name}"}, {"{promotion_details}"}, {"{expiry_date}"}
          </p>
          <Button variant="outline" size="sm" onClick={() => handleTestSms("מבצע מיוחד")}>
            שליחת הודעת בדיקה
          </Button>
        </div>
      </CardContent>
      <CardFooter>
        <Button className="bg-pink-500 hover:bg-pink-600" onClick={saveSmsTemplates}>
          <Save className="mr-2 h-4 w-4" /> שמירת תבניות
        </Button>
      </CardFooter>
    </Card>
  )
}
