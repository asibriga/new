"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { format, isValid, parseISO, addMonths, subMonths } from "date-fns"
import { he } from "date-fns/locale"
import { useStore } from "@/lib/store"
import { useToast } from "@/components/ui/use-toast"
import { isIsraeliHoliday, getHolidayName } from "@/lib/israeli-holidays"
import { Trash, Plus, Clock, ChevronLeft, ChevronRight } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

// Define types for our data
type Holiday = {
  id?: string
  date: string
  name: string
}

type ClosedDay = {
  id?: string
  date: string
  reason: string
  specificHours?: boolean
  startTime?: string
  endTime?: string
}

export default function HolidaysSettings() {
  // Local state for form
  const [date, setDate] = useState<Date | null>(new Date())
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [holidayName, setHolidayName] = useState("")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [calendarOpen, setCalendarOpen] = useState(false)
  const [isSpecificHours, setIsSpecificHours] = useState(false)
  const [startTime, setStartTime] = useState<string | undefined>(undefined)
  const [endTime, setEndTime] = useState<string | undefined>(undefined)
  const [formType, setFormType] = useState<"holiday" | "closedDay">("closedDay")
  const [isHoursDialogOpen, setIsHoursDialogOpen] = useState(false)

  // Local state for data
  const [localHolidays, setLocalHolidays] = useState<Holiday[]>([])
  const [localClosedDays, setLocalClosedDays] = useState<ClosedDay[]>([])

  const { toast } = useToast()

  // Get data from store
  const storeHolidays = useStore((state) => state.holidays || [])
  const storeClosedDays = useStore((state) => state.closedDays || [])
  const addClosedDay = useStore((state) => state.addClosedDay)
  const removeClosedDay = useStore((state) => state.removeClosedDay)
  const [state, setState] = useState(useStore.getState())

  // Sync store data to local state on mount and when store changes
  useEffect(() => {
    // Add IDs to holidays if they don't have them
    const holidaysWithIds = storeHolidays.map((holiday) => {
      if (!holiday.id) {
        return { ...holiday, id: `holiday-${Date.now()}-${Math.random().toString(36).substr(2, 9)}` }
      }
      return holiday
    })
    setLocalHolidays(holidaysWithIds)
  }, [storeHolidays])

  useEffect(() => {
    // Add IDs to closed days if they don't have them
    const closedDaysWithIds = storeClosedDays.map((day) => {
      if (!day.id) {
        return { ...day, id: `closed-${Date.now()}-${Math.random().toString(36).substr(2, 9)}` }
      }
      return day
    })
    setLocalClosedDays(closedDaysWithIds)
  }, [storeClosedDays])

  // Reset form fields when dialog opens
  useEffect(() => {
    if (dialogOpen) {
      setDate(new Date())
      setCurrentMonth(new Date())
      setHolidayName("")
      setIsSpecificHours(false)
      setStartTime(undefined)
      setEndTime(undefined)
    }
  }, [dialogOpen])

  // Handle adding a holiday
  const handleAddHoliday = () => {
    if (!date || !holidayName.trim()) {
      toast({
        title: "שגיאה",
        description: "יש למלא את כל השדות",
        variant: "destructive",
      })
      return
    }

    try {
      const formattedDate = format(date, "yyyy-MM-dd")

      // Check if holiday already exists
      const exists = localHolidays.some((h) => h.date === formattedDate)
      if (exists) {
        toast({
          title: "שגיאה",
          description: "חג זה כבר קיים ברשימה",
          variant: "destructive",
        })
        return
      }

      // Create new holiday with ID
      const newHoliday: Holiday = {
        id: `holiday-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        date: formattedDate,
        name: holidayName,
      }

      // Update local state
      const updatedHolidays = [...localHolidays, newHoliday]
      setLocalHolidays(updatedHolidays)

      // Update store safely outside of render
      setTimeout(() => {
        useStore.setState({ holidays: updatedHolidays })
      }, 0)

      toast({
        title: "החג נוסף בהצלחה",
        description: `${holidayName} נוסף לרשימת החגים`,
      })

      setDate(new Date())
      setHolidayName("")
      setDialogOpen(false)
      setIsSpecificHours(false)
      setStartTime(undefined)
      setEndTime(undefined)
    } catch (error) {
      console.error("Error adding holiday:", error)
      toast({
        title: "שגיאה בהוספת החג",
        description: "אירעה שגיאה בהוספת החג. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  // Handle adding a closed day
  const handleAddClosedDay = () => {
    if (!date) {
      toast({
        title: "שגיאה",
        description: "יש לבחור תאריך",
        variant: "destructive",
      })
      return
    }

    const formattedDate = format(date, "yyyy-MM-dd")

    // If specific hours, validate time inputs
    if (isSpecificHours) {
      if (!startTime || !endTime) {
        toast({
          title: "שגיאה",
          description: "יש לבחור שעת התחלה ושעת סיום",
          variant: "destructive",
        })
        return
      }

      // Check if the start time is before the end time
      const [startHour, startMinute] = startTime.split(":").map(Number)
      const [endHour, endMinute] = endTime.split(":").map(Number)
      const startMinutes = startHour * 60 + startMinute
      const endMinutes = endHour * 60 + endMinute

      if (startMinutes >= endMinutes) {
        toast({
          title: "שגיאה",
          description: "שעת ההתחלה חייבת להיות לפני שעת הסיום",
          variant: "destructive",
        })
        return
      }

      // Add closed hours instead of closed day
      const closedHoursId = useStore
        .getState()
        .addClosedHours(formattedDate, startTime, endTime, holidayName || `סגור בין ${startTime} ל-${endTime}`)

      toast({
        title: "שעות סגורות נוספו בהצלחה",
        description: `נוספו שעות סגורות ב-${format(date, "dd/MM/yyyy")} בין ${startTime} ל-${endTime}`,
      })

      setDate(new Date())
      setHolidayName("")
      setDialogOpen(false)
      setIsSpecificHours(false)
      setStartTime(undefined)
      setEndTime(undefined)
      return
    }

    // Check if closed day already exists
    const exists = localClosedDays.some((d) => d.date === formattedDate && !d.specificHours)
    if (exists) {
      toast({
        title: "שגיאה",
        description: "יום סגור זה כבר קיים ברשימה",
        variant: "destructive",
      })
      return
    }

    // Add reason if none provided
    const reason = holidayName || "יום סגור"

    // Create new closed day with ID
    const newClosedDay = {
      id: `closed-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      date: formattedDate,
      reason: reason,
      specificHours: false,
    }

    // Update local state
    const updatedClosedDays = [...localClosedDays, newClosedDay]
    setLocalClosedDays(updatedClosedDays)

    // Update store safely outside of render
    setTimeout(() => {
      useStore.setState({ closedDays: updatedClosedDays })
    }, 0)

    toast({
      title: "היום הסגור נוסף בהצלחה",
      description: `${format(date, "dd/MM/yyyy")} נוסף לרשימת הימים הסגורים`,
    })

    setDate(new Date())
    setHolidayName("")
    setDialogOpen(false)
    setIsSpecificHours(false)
    setStartTime(undefined)
    setEndTime(undefined)
  }

  // Handle removing a holiday
  const handleRemoveHoliday = (holidayId: string) => {
    // Update local state
    const updatedHolidays = localHolidays.filter((h) => h.id !== holidayId)
    setLocalHolidays(updatedHolidays)

    // Update store safely outside of render
    setTimeout(() => {
      useStore.setState({ holidays: updatedHolidays })
    }, 0)

    toast({
      title: "החג הוסר בהצלחה",
      description: "החג הוסר מרשימת החגים",
    })
  }

  // Handle removing a closed day
  const handleRemoveClosedDay = (closedDayId: string) => {
    // Find the closed day to get its date
    const closedDay = localClosedDays.find((day) => day.id === closedDayId)

    // Update local state
    const updatedClosedDays = localClosedDays.filter((d) => d.id !== closedDayId)
    setLocalClosedDays(updatedClosedDays)

    // Update store safely outside of render
    setTimeout(() => {
      useStore.setState({ closedDays: updatedClosedDays })

      // Also use the removeClosedDay function if available
      if (removeClosedDay && closedDay) {
        removeClosedDay(closedDay.date)
      }
    }, 0)

    toast({
      title: "היום הסגור הוסר בהצלחה",
      description: "היום הוסר מרשימת הימים הסגורים",
    })
  }

  // Function to check if a date is a holiday or closed day
  const isDateDisabled = (date: Date) => {
    const formattedDate = format(date, "yyyy-MM-dd")
    const isHoliday = localHolidays.some((h) => h.date === formattedDate)
    const isClosed = localClosedDays.some((d) => d.date === formattedDate)
    return isHoliday || isClosed
  }

  // Function to get class name for date cell
  const getDateClassName = (date: Date) => {
    const formattedDate = format(date, "yyyy-MM-dd")
    const isHoliday = localHolidays.some((h) => h.date === formattedDate)
    const isClosed = localClosedDays.some((d) => d.date === formattedDate)
    const isSelectedDate = date && date.toDateString() === (date?.toDateString() || "")

    if (isHoliday) return "bg-red-100 text-red-800 hover:bg-red-200"
    if (isClosed) return "bg-orange-100 text-orange-800 hover:bg-orange-200"
    if (isSelectedDate) return "bg-pink-500 text-white hover:bg-pink-600"
    return "hover:bg-gray-100"
  }

  // Function to navigate to previous month
  const goToPreviousMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1))
  }

  // Function to navigate to next month
  const goToNextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1))
  }

  // Function to render calendar
  const renderCalendar = () => {
    const year = currentMonth.getFullYear()
    const month = currentMonth.getMonth()

    // First day of month
    const firstDay = new Date(year, month, 1)

    // Last day of month
    const lastDay = new Date(year, month + 1, 0)

    // Get day of week for first day (0 = Sunday, 6 = Saturday)
    const firstDayOfWeek = firstDay.getDay() // 0 for Sunday, 1 for Monday, etc.
    const emptyCellsAtStart = firstDayOfWeek // For RTL Hebrew calendar, Sunday is rightmost

    // Array to hold all calendar cells
    const days = []

    // Add empty cells for days before first day of month
    for (let i = 0; i < emptyCellsAtStart; i++) {
      days.push(<div key={`empty-start-${i}`} className="h-10"></div>)
    }

    // Add days of month
    for (let i = 1; i <= lastDay.getDate(); i++) {
      const date = new Date(year, month, i)
      const isToday = new Date().toDateString() === date.toDateString()
      const isSelected = date && date.toDateString() === (date?.toDateString() || "")
      const customClass = getDateClassName(date)

      days.push(
        <Button
          key={`day-${i}`}
          variant="ghost"
          className={`h-10 w-full rounded-md flex items-center justify-center p-0 ${
            isSelected ? "bg-pink-500 text-white hover:bg-pink-600" : ""
          } ${isToday && !isSelected ? "bg-pink-100 text-pink-900" : ""} 
          ${customClass}`}
          onClick={() => setDate(date)}
        >
          {i}
        </Button>,
      )
    }

    // Calculate total cells needed (7 days * up to 6 rows)
    const totalCells = 7 * Math.ceil((emptyCellsAtStart + lastDay.getDate()) / 7)

    // Add empty cells at the end to complete the grid
    const emptyCellsAtEnd = totalCells - days.length
    for (let i = 0; i < emptyCellsAtEnd; i++) {
      days.push(<div key={`empty-end-${i}`} className="h-10"></div>)
    }

    return days
  }

  // תיקון פונקציית addClosedDay כך שתטפל נכון בשעות סגורות

  const handleAddEvent = () => {
    if (!holidayName || !date) {
      toast({
        title: "שגיאה",
        description: "אנא מלא את כל השדות הנדרשים",
        variant: "destructive",
      })
      return
    }

    try {
      const formattedDate = format(date, "yyyy-MM-dd")

      if (formType === "holiday") {
        // Add holiday
        const newHoliday = {
          id: `holiday-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          date: formattedDate,
          name: holidayName,
        }

        // Update local state
        const updatedHolidays = [...localHolidays, newHoliday]
        setLocalHolidays(updatedHolidays)

        // Update store
        setTimeout(() => {
          useStore.setState({ holidays: updatedHolidays })
        }, 0)

        toast({
          title: "החג נוסף בהצלחה",
          description: `${holidayName} נוסף לרשימת החגים`,
        })
      } else {
        // Add closed day or specific hours
        const newClosedDay = {
          id: `closed-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          date: formattedDate,
          reason: holidayName,
          specificHours: isSpecificHours,
          startTime: isSpecificHours ? startTime : undefined,
          endTime: isSpecificHours ? endTime : undefined,
        }

        // Update local state
        const updatedClosedDays = [...localClosedDays, newClosedDay]
        setLocalClosedDays(updatedClosedDays)

        // Update store
        setTimeout(() => {
          useStore.setState({ closedDays: updatedClosedDays })
        }, 0)

        toast({
          title: isSpecificHours ? "שעות סגורות נוספו בהצלחה" : "היום הסגור נוסף בהצלחה",
          description: isSpecificHours
            ? `נוספו שעות סגורות ב-${format(date, "dd/MM/yyyy")} בין ${startTime} ל-${endTime}`
            : `${format(date, "dd/MM/yyyy")} נוסף לרשימת הימים הסגורים`,
        })
      }

      // Reset form and close dialog
      setHolidayName("")
      setDate(new Date())
      setIsSpecificHours(false)
      setStartTime("09:00")
      setEndTime("10:00")
      setDialogOpen(false)
    } catch (error) {
      console.error("Error adding event:", error)
      toast({
        title: "שגיאה בהוספת האירוע",
        description: "אירעה שגיאה בהוספת האירוע. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  // Fix the closed hours display issue by updating the useEffect hook
  useEffect(() => {
    const unsubscribe = useStore.subscribe(
      (state) => state.closedHours,
      (closedHours) => {
        setState((prevState) => ({
          ...prevState,
          closedHours: closedHours || [],
        }))
      },
    )

    // Initial load
    setState((prevState) => ({
      ...prevState,
      closedHours: useStore.getState().closedHours || [],
    }))

    return () => unsubscribe()
  }, [])

  // Fix the addClosedHours function to properly update the state
  const handleAddClosedHours = () => {
    if (!date || !startTime || !endTime) {
      toast({
        title: "שגיאה",
        description: "יש לבחור תאריך ושעות",
        variant: "destructive",
      })
      return
    }

    const formattedDate = format(date, "yyyy-MM-dd")

    // Check if the start time is before the end time
    const [startHour, startMinute] = startTime.split(":").map(Number)
    const [endHour, endMinute] = endTime.split(":").map(Number)
    const startMinutes = startHour * 60 + startMinute
    const endMinutes = endHour * 60 + endMinute

    if (startMinutes >= endMinutes) {
      toast({
        title: "שגיאה",
        description: "שעת ההתחלה חייבת להיות לפני שעת הסיום",
        variant: "destructive",
      })
      return
    }

    // Add closed hours
    try {
      const closedHoursId = useStore
        .getState()
        .addClosedHours(formattedDate, startTime, endTime, holidayName || `סגור בין ${startTime} ל-${endTime}`)

      // Force update the local state
      setState((prevState) => ({
        ...prevState,
        closedHours: useStore.getState().closedHours || [],
      }))

      toast({
        title: "שעות סגורות נוספו בהצלחה",
        description: `נוספו שעות סגורות ב-${format(date, "dd/MM/yyyy")} בין ${startTime} ל-${endTime}`,
      })

      setDate(new Date())
      setHolidayName("")
      setIsHoursDialogOpen(false)
      setStartTime(undefined)
      setEndTime(undefined)
    } catch (error) {
      console.error("Error adding closed hours:", error)
      toast({
        title: "שגיאה בהוספת שעות סגורות",
        description: "אירעה שגיאה בהוספת שעות סגורות. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  const handleRemoveClosedHours = (id) => {
    try {
      useStore.getState().removeClosedHours(id)

      toast({
        title: "השעות הסגורות הוסרו בהצלחה",
        description: "השעות הסגורות הוסרו מהמערכת בהצלחה",
      })

      // Обновить локальное состояние
      setState(useStore.getState())
    } catch (error) {
      console.error("Error removing closed hours:", error)
      toast({
        title: "שגיאה בהסרת השעות הסגורות",
        description: "אירעה שגיאה בהסרת השעות הסגורות. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">חגים וימים סגורים</CardTitle>

          <div className="flex gap-2">
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button
                  className="bg-pink-500 hover:bg-pink-600"
                  onClick={() => {
                    setFormType("closedDay")
                    setIsSpecificHours(false)
                    setDialogOpen(true)
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  הוספת יום סגור
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{formType === "holiday" ? "הוספת חג" : "הוספת יום סגור"}</DialogTitle>
                  <DialogDescription>
                    {formType === "holiday" ? "בחרי תאריך והוסיפי שם החג" : "בחרי תאריך והוסיפי סיבה ליום הסגור"}
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="date">תאריך</Label>

                    {/* Calendar component */}
                    <div className="border rounded-lg p-4">
                      <div className="text-center mb-4">
                        <div className="flex items-center justify-between">
                          <Button variant="ghost" size="sm" onClick={goToNextMonth}>
                            <ChevronLeft className="h-5 w-5" />
                          </Button>
                          <h3 className="text-lg font-medium">{format(currentMonth, "MMMM yyyy", { locale: he })}</h3>
                          <Button variant="ghost" size="sm" onClick={goToPreviousMonth}>
                            <ChevronRight className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>

                      <div className="calendar-container rtl">
                        {/* Days of week - right to left */}
                        <div className="grid grid-cols-7 gap-1 mb-2 text-center">
                          <div className="text-sm font-medium">א'</div>
                          <div className="text-sm font-medium">ב'</div>
                          <div className="text-sm font-medium">ג'</div>
                          <div className="text-sm font-medium">ד'</div>
                          <div className="text-sm font-medium">ה'</div>
                          <div className="text-sm font-medium">ו'</div>
                          <div className="text-sm font-medium">ש'</div>
                        </div>

                        {/* Calendar grid */}
                        <div className="grid grid-cols-7 gap-1">{renderCalendar()}</div>
                      </div>

                      <div className="mt-4 flex flex-wrap gap-2">
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-red-100 ml-1 rounded-sm"></div>
                          <span className="text-xs">חג</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-orange-100 ml-1 rounded-sm"></div>
                          <span className="text-xs">יום סגור</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-pink-100 ml-1 rounded-sm"></div>
                          <span className="text-xs">היום</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-pink-500 ml-1 rounded-sm"></div>
                          <span className="text-xs">נבחר</span>
                        </div>
                      </div>
                    </div>

                    {date && (
                      <div className="mt-2 text-sm text-gray-500">
                        תאריך נבחר: {format(date, "dd/MM/yyyy", { locale: he })}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="name">סיבה / שם החג</Label>
                    <Input
                      id="name"
                      value={holidayName}
                      onChange={(e) => setHolidayName(e.target.value)}
                      placeholder="הכניסי סיבה ליום הסגור או שם החג"
                    />
                  </div>

                  {date && isIsraeliHoliday(date) && (
                    <div className="bg-blue-50 p-3 rounded-md">
                      <p className="text-sm text-blue-700">
                        <span className="font-medium">שים לב:</span> התאריך שנבחר הוא {getHolidayName(date)}
                      </p>
                    </div>
                  )}
                </div>
                <DialogFooter className="flex flex-col sm:flex-row gap-2">
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    ביטול
                  </Button>
                  {formType === "holiday" ? (
                    <Button className="bg-pink-500 hover:bg-pink-600" onClick={handleAddHoliday}>
                      הוספת חג
                    </Button>
                  ) : (
                    <Button className="bg-pink-500 hover:bg-pink-600" onClick={handleAddClosedDay}>
                      הוספת יום סגור
                    </Button>
                  )}
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Dialog open={isHoursDialogOpen} onOpenChange={setIsHoursDialogOpen}>
              <DialogTrigger asChild>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsHoursDialogOpen(true)
                  }}
                >
                  <Clock className="mr-2 h-4 w-4" />
                  הוספת שעות סגורות
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>הוספת שעות סגורות</DialogTitle>
                  <DialogDescription>בחרי תאריך ושעות שבהן הסטודיו יהיה סגור</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="date">תאריך</Label>

                    {/* Calendar component */}
                    <div className="border rounded-lg p-4">
                      <div className="text-center mb-4">
                        <div className="flex items-center justify-between">
                          <Button variant="ghost" size="sm" onClick={goToNextMonth}>
                            <ChevronLeft className="h-5 w-5" />
                          </Button>
                          <h3 className="text-lg font-medium">{format(currentMonth, "MMMM yyyy", { locale: he })}</h3>
                          <Button variant="ghost" size="sm" onClick={goToPreviousMonth}>
                            <ChevronRight className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>

                      <div className="calendar-container rtl">
                        {/* Days of week - right to left */}
                        <div className="grid grid-cols-7 gap-1 mb-2 text-center">
                          <div className="text-sm font-medium">א'</div>
                          <div className="text-sm font-medium">ב'</div>
                          <div className="text-sm font-medium">ג'</div>
                          <div className="text-sm font-medium">ד'</div>
                          <div className="text-sm font-medium">ה'</div>
                          <div className="text-sm font-medium">ו'</div>
                          <div className="text-sm font-medium">ש'</div>
                        </div>

                        {/* Calendar grid */}
                        <div className="grid grid-cols-7 gap-1">{renderCalendar()}</div>
                      </div>

                      {date && (
                        <div className="mt-2 text-sm text-gray-500">
                          תאריך נבחר: {format(date, "dd/MM/yyyy", { locale: he })}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reason">סיבה</Label>
                    <Input
                      id="reason"
                      value={holidayName}
                      onChange={(e) => setHolidayName(e.target.value)}
                      placeholder="הכניסי סיבה לשעות הסגורות"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label htmlFor="start-time">שעת התחלה</Label>
                      <Select value={startTime} onValueChange={setStartTime}>
                        <SelectTrigger id="start-time">
                          <SelectValue placeholder="בחר שעה" />
                        </SelectTrigger>
                        <SelectContent>
                          {["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"].map(
                            (time) => (
                              <SelectItem key={`start-${time}`} value={time}>
                                {time}
                              </SelectItem>
                            ),
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="end-time">שעת סיום</Label>
                      <Select value={endTime} onValueChange={setEndTime}>
                        <SelectTrigger id="end-time">
                          <SelectValue placeholder="בחר שעה" />
                        </SelectTrigger>
                        <SelectContent>
                          {["10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"].map(
                            (time) => (
                              <SelectItem key={`end-${time}`} value={time}>
                                {time}
                              </SelectItem>
                            ),
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsHoursDialogOpen(false)}>
                    ביטול
                  </Button>
                  <Button
                    className="bg-pink-500 hover:bg-pink-600"
                    onClick={handleAddClosedHours}
                    disabled={!date || !startTime || !endTime}
                  >
                    הוספת שעות סגורות
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Button variant="outline" onClick={() => setFormType("holiday")}>
              <Plus className="mr-2 h-4 w-4" />
              הוספת חג
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>חגים</CardTitle>
          </CardHeader>
          <CardContent>
            {localHolidays.length > 0 ? (
              <div className="space-y-2">
                {localHolidays.map((holiday) => (
                  <div key={holiday.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                    <div>
                      <p className="font-medium">{holiday.name}</p>
                      <p className="text-sm text-gray-500">
                        {isValid(parseISO(holiday.date)) ? format(parseISO(holiday.date), "dd/MM/yyyy") : holiday.date}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => handleRemoveHoliday(holiday.id || holiday.date)}>
                      <Trash className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500 py-4">אין חגים ברשימה</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>ימים וזמנים סגורים</CardTitle>
          </CardHeader>
          <CardContent>
            {localClosedDays.length > 0 ? (
              <div className="space-y-2">
                {localClosedDays.map((day) => (
                  <div key={day.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{day.reason}</p>
                        {day.specificHours && (
                          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                            שעות מוגבלות
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-500">
                        {isValid(parseISO(day.date)) ? format(parseISO(day.date), "dd/MM/yyyy") : day.date}
                        {day.specificHours && day.startTime && day.endTime && (
                          <span className="flex items-center mt-1">
                            <Clock className="h-3 w-3 mr-1" />
                            {day.startTime} - {day.endTime}
                          </span>
                        )}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => handleRemoveClosedDay(day.id || day.date)}>
                      <Trash className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500 py-4">אין ימים סגורים ברשימה</p>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>שעות סגורות</CardTitle>
          </CardHeader>
          <CardContent>
            {state.closedHours && state.closedHours.length > 0 ? (
              <div className="space-y-2">
                {state.closedHours.map((hours) => (
                  <div key={hours.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{hours.reason}</p>
                        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                          שעות מוגבלות
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500">
                        {isValid(parseISO(hours.date)) ? format(parseISO(hours.date), "dd/MM/yyyy") : hours.date}
                        <span className="flex items-center mt-1">
                          <Clock className="h-3 w-3 mr-1" />
                          {hours.startTime} - {hours.endTime}
                        </span>
                      </p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => handleRemoveClosedHours(hours.id)}>
                      <Trash className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500 py-4">אין שעות סגורות ברשימה</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
