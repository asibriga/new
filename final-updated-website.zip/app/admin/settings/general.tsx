"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useStore } from "@/lib/store"
import { useToast } from "@/components/ui/use-toast"
import { X, Upload, Link } from "lucide-react"
import { format } from "date-fns"
import Image from "next/image"

export default function GeneralSettings() {
  const { toast } = useToast()
  const siteContent = useStore((state) => state.siteContent)
  const updateSiteContent = useStore((state) => state.updateSiteContent)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [businessName, setBusinessName] = useState("")
  const [businessAddress, setBusinessAddress] = useState("")
  const [businessPhone, setBusinessPhone] = useState("")
  const [businessEmail, setBusinessEmail] = useState("")
  const [heroTitle, setHeroTitle] = useState("")
  const [heroSubtitle, setHeroSubtitle] = useState("")
  const [aboutText, setAboutText] = useState("")
  const [contactText, setContactText] = useState("")
  const [footerText, setFooterText] = useState("")
  const [businessHours, setBusinessHours] = useState("")
  const [appointmentTips, setAppointmentTips] = useState("")
  const [holidays, setHolidays] = useState<{ name: string; date: string }[]>([])
  const [heroImage, setHeroImage] = useState("")
  const [aboutImage, setAboutImage] = useState("")
  const [galleryImages, setGalleryImages] = useState<string[]>([])
  const [serviceImages, setServiceImages] = useState<string[]>([])
  const [currentImageType, setCurrentImageType] = useState<"hero" | "about" | "gallery" | "service" | null>(null)

  // Load initial values
  useEffect(() => {
    if (siteContent) {
      setBusinessName(siteContent.businessName || "May Beauty")
      setBusinessAddress(siteContent.businessAddress || "שדרות חן 7, הרצליה")
      setBusinessPhone(siteContent.businessPhone || "052-8588876")
      setHeroTitle(siteContent.heroTitle || "")
      setHeroSubtitle(siteContent.heroSubtitle || "")
      setAboutText(siteContent.aboutText || "")
      setContactText(siteContent.contactText || "")
      setFooterText(siteContent.footerText || "")
      setBusinessHours(siteContent.businessHours || "")
      setAppointmentTips(siteContent.appointmentTips || "")
      setHolidays(siteContent.holidays || [])

      // Set images
      if (siteContent.images) {
        setHeroImage(siteContent.images.hero || "")
        setAboutImage(siteContent.images.about || "")
        setGalleryImages(siteContent.images.gallery || [])
        setServiceImages(siteContent.images.services || [])
      }
    }
  }, [siteContent])

  // Handle file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !currentImageType) return

    // Create URL for the selected image
    const imageUrl = URL.createObjectURL(file)

    // Update the appropriate image state
    switch (currentImageType) {
      case "hero":
        setHeroImage(imageUrl)
        break
      case "about":
        setAboutImage(imageUrl)
        break
      case "gallery":
        setGalleryImages([...galleryImages, imageUrl])
        break
      case "service":
        setServiceImages([...serviceImages, imageUrl])
        break
    }

    // Reset the file input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  // Handle URL input
  const handleUrlInput = (type: "hero" | "about" | "gallery" | "service") => {
    const imageUrl = prompt("הזן כתובת URL לתמונה:")
    if (imageUrl && imageUrl.trim() !== "") {
      // Update the appropriate image state
      switch (type) {
        case "hero":
          setHeroImage(imageUrl)
          break
        case "about":
          setAboutImage(imageUrl)
          break
        case "gallery":
          setGalleryImages([...galleryImages, imageUrl])
          break
        case "service":
          setServiceImages([...serviceImages, imageUrl])
          break
      }
    }
  }

  // Remove image
  const removeImage = (type: "hero" | "about", index?: number) => {
    if (type === "hero") {
      setHeroImage("")
    } else if (type === "about") {
      setAboutImage("")
    } else if (type === "gallery" && index !== undefined) {
      const newGalleryImages = [...galleryImages]
      newGalleryImages.splice(index, 1)
      setGalleryImages(newGalleryImages)
    } else if (type === "service" && index !== undefined) {
      const newServiceImages = [...serviceImages]
      newServiceImages.splice(index, 1)
      setServiceImages(newServiceImages)
    }
  }

  // הוספת פונקציית שמירה
  const saveGeneralSettings = async () => {
    try {
      // Update site content with all values including images
      updateSiteContent({
        businessName,
        businessAddress,
        businessPhone,
        businessEmail,
        businessHours,
        appointmentTips,
        heroTitle,
        heroSubtitle,
        aboutText,
        contactText,
        footerText,
        holidays,
        images: {
          hero: heroImage,
          about: aboutImage,
          gallery: galleryImages,
          services: serviceImages,
        },
      })

      toast({
        title: "ההגדרות נשמרו בהצלחה",
        description: "כל השינויים נשמרו במערכת",
      })
    } catch (error) {
      console.error("Error saving settings:", error)
      toast({
        title: "שגיאה בשמירת ההגדרות",
        description: "אירעה שגיאה בשמירת ההגדרות, נסה שנית",
        variant: "destructive",
      })
    }
  }

  // הוספת פונקציה למחיקת חג
  const handleDeleteHoliday = (holidayDate: string) => {
    try {
      const success = useStore.getState().deleteHoliday(holidayDate)

      if (success) {
        toast({
          title: "החג נמחק בהצלחה",
          description: "החג הוסר מרשימת החגים הקבועים",
        })

        // עדכון הרשימה המקומית
        setHolidays(holidays.filter((h) => h.date !== holidayDate))
      } else {
        toast({
          title: "שגיאה במחיקת החג",
          description: "אירעה שגיאה במחיקת החג, נסה שנית",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error deleting holiday:", error)
      toast({
        title: "שגיאה במחיקת החג",
        description: "אירעה שגיאה במחיקת החג, נסה שנית",
        variant: "destructive",
      })
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>הגדרות כלליות</CardTitle>
        <CardDescription>הגדרות בסיסיות של האתר והעסק</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium">פרטי העסק</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="business-name">שם העסק</Label>
              <Input
                id="business-name"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="הזן את שם העסק"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="business-phone">טלפון</Label>
              <Input
                id="business-phone"
                value={businessPhone}
                onChange={(e) => setBusinessPhone(e.target.value)}
                placeholder="הזן את מספר הטלפון של העסק"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="business-email">אימייל</Label>
              <Input
                id="business-email"
                value={businessEmail}
                onChange={(e) => setBusinessEmail(e.target.value)}
                placeholder="הזן את כתובת האימייל של העסק"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="business-address">כתובת</Label>
              <Input
                id="business-address"
                value={businessAddress}
                onChange={(e) => setBusinessAddress(e.target.value)}
                placeholder="הזן את כתובת העסק"
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium">תוכן דף הבית</h3>
          <div className="space-y-2">
            <Label htmlFor="hero-title">כותרת ראשית</Label>
            <Input
              id="hero-title"
              value={heroTitle}
              onChange={(e) => setHeroTitle(e.target.value)}
              placeholder="הזן את הכותרת הראשית של דף הבית"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="hero-subtitle">כותרת משנה</Label>
            <Input
              id="hero-subtitle"
              value={heroSubtitle}
              onChange={(e) => setHeroSubtitle(e.target.value)}
              placeholder="הזן את כותרת המשנה של דף הבית"
            />
          </div>

          {/* Hero Image */}
          <div className="space-y-2">
            <Label>תמונת רקע ראשית</Label>
            <div className="flex flex-wrap items-center gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setCurrentImageType("hero")
                  fileInputRef.current?.click()
                }}
              >
                <Upload className="mr-2 h-4 w-4" /> העלאת תמונה
              </Button>
              <Button type="button" variant="outline" onClick={() => handleUrlInput("hero")}>
                <Link className="mr-2 h-4 w-4" /> הוספת URL
              </Button>
              {heroImage && (
                <div className="relative w-full h-32 mt-2 rounded overflow-hidden">
                  <Image
                    src={heroImage || "/placeholder.svg"}
                    alt="תמונת רקע ראשית"
                    fill
                    className="object-cover"
                    unoptimized={heroImage?.startsWith?.("blob:") || false}
                  />
                  <Button
                    variant="destructive"
                    size="icon"
                    className="absolute top-2 right-2 h-6 w-6"
                    onClick={() => removeImage("hero")}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium">תוכן דפים נוספים</h3>
          <div className="space-y-2">
            <Label htmlFor="about-text">טקסט אודות</Label>
            <Textarea
              id="about-text"
              value={aboutText}
              onChange={(e) => setAboutText(e.target.value)}
              placeholder="הזן את הטקסט לדף אודות"
              rows={4}
            />
          </div>

          {/* About Image */}
          <div className="space-y-2">
            <Label>תמונת אודות</Label>
            <div className="flex flex-wrap items-center gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setCurrentImageType("about")
                  fileInputRef.current?.click()
                }}
              >
                <Upload className="mr-2 h-4 w-4" /> העלאת תמונה
              </Button>
              <Button type="button" variant="outline" onClick={() => handleUrlInput("about")}>
                <Link className="mr-2 h-4 w-4" /> הוספת URL
              </Button>
              {aboutImage && (
                <div className="relative w-full h-32 mt-2 rounded overflow-hidden">
                  <Image
                    src={aboutImage || "/placeholder.svg"}
                    alt="תמונת אודות"
                    fill
                    className="object-cover"
                    unoptimized={aboutImage?.startsWith?.("blob:") || false}
                  />
                  <Button
                    variant="destructive"
                    size="icon"
                    className="absolute top-2 right-2 h-6 w-6"
                    onClick={() => removeImage("about")}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="contact-text">טקסט צור קשר</Label>
            <Textarea
              id="contact-text"
              value={contactText}
              onChange={(e) => setContactText(e.target.value)}
              placeholder="הזן את הטקסט לדף צור קשר"
              rows={4}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="footer-text">טקסט פוטר</Label>
            <Input
              id="footer-text"
              value={footerText}
              onChange={(e) => setFooterText(e.target.value)}
              placeholder="הזן את הטקסט לפוטר"
            />
          </div>
        </div>

        {/* Gallery Images */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium">תמונות גלריה</h3>
          <div className="flex flex-wrap items-center gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setCurrentImageType("gallery")
                fileInputRef.current?.click()
              }}
            >
              <Upload className="mr-2 h-4 w-4" /> העלאת תמונה
            </Button>
            <Button type="button" variant="outline" onClick={() => handleUrlInput("gallery")}>
              <Link className="mr-2 h-4 w-4" /> הוספת URL
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
            {galleryImages.map((image, index) => (
              <div key={index} className="relative h-32 rounded overflow-hidden">
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`תמונת גלריה ${index + 1}`}
                  fill
                  className="object-cover"
                  unoptimized={image?.startsWith("blob:")}
                />
                <Button
                  variant="destructive"
                  size="icon"
                  className="absolute top-2 right-2 h-6 w-6"
                  onClick={() => removeImage("gallery", index)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Service Images */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium">תמונות שירותים</h3>
          <div className="flex flex-wrap items-center gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setCurrentImageType("service")
                fileInputRef.current?.click()
              }}
            >
              <Upload className="mr-2 h-4 w-4" /> העלאת תמונה
            </Button>
            <Button type="button" variant="outline" onClick={() => handleUrlInput("service")}>
              <Link className="mr-2 h-4 w-4" /> הוספת URL
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
            {serviceImages.map((image, index) => (
              <div key={index} className="relative h-32 rounded overflow-hidden">
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`תמונת שירות ${index + 1}`}
                  fill
                  className="object-cover"
                  unoptimized={image?.startsWith("blob:")}
                />
                <Button
                  variant="destructive"
                  size="icon"
                  className="absolute top-2 right-2 h-6 w-6"
                  onClick={() => removeImage("service", index)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium">חגים קבועים</h3>
          {holidays.map((holiday, index) => (
            <div key={index} className="flex items-center justify-between p-2 border-b">
              <div>
                <p className="font-medium">{holiday.name}</p>
                <p className="text-sm text-gray-500">{format(new Date(holiday.date), "dd/MM/yyyy")}</p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-red-600 hover:bg-red-50"
                onClick={() => handleDeleteHoliday(holiday.date)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter>
        <Button className="bg-pink-500 hover:bg-pink-600" onClick={saveGeneralSettings}>
          שמירת הגדרות
        </Button>
      </CardFooter>

      {/* Hidden file input */}
      <Input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
    </Card>
  )
}
