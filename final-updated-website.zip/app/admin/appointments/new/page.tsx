"use client"
import { useRouter, useSearchParams } from "next/navigation"
import { useEffect, useState, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { format, addMonths, subMonths } from "date-fns"
import { he } from "date-fns/locale"
import { checkAppointmentOverlap } from "@/lib/utils"
import { useStore } from "@/lib/store"
import { useToast } from "@/components/ui/use-toast"
import { Checkbox } from "@/components/ui/checkbox"
import { ChevronLeft, ChevronRight } from "lucide-react"

const formSchema = z.object({
  name: z.string().min(2, {
    message: "שם חייב להכיל לפחות 2 תווים",
  }),
  phone: z.string().min(9, {
    message: "מספר טלפון לא תקין",
  }),
  services: z.array(z.string()).min(1, {
    message: "אנא בחרי לפחות שירות אחד",
  }),
  date: z.date({
    required_error: "אנא בחרי תאריך",
  }),
  time: z.string({
    required_error: "אנא בחרי שעה",
  }),
  notes: z.string().optional(),
})

export default function NewAppointmentPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const [calendarOpen, setCalendarOpen] = useState(false)
  const [selectedServices, setSelectedServices] = useState<string[]>([])
  const [totalDuration, setTotalDuration] = useState(0)
  const [totalPrice, setTotalPrice] = useState(0)
  const [endTime, setEndTime] = useState("")
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState<Date | null>(new Date())

  // Ref for calendar trigger
  const calendarTriggerRef = useRef<HTMLButtonElement>(null)

  // Get store data
  const services = useStore((state) => state.services)
  const customers = useStore((state) => state.customers)
  const addAppointment = useStore((state) => state.addAppointment)
  const getAvailableTimeSlots = useStore((state) => state.getAvailableTimeSlots)
  const appointments = useStore((state) => state.appointments)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      phone: "",
      services: [],
      notes: "",
      date: new Date(),
    },
  })

  // Get available time slots for selected date and service
  const selectedTime = form.watch("time")

  // Calculate available times based on all selected services
  const [availableTimes, setAvailableTimes] = useState<string[]>([])

  // Update available times when date or services change
  useEffect(() => {
    if (selectedDate && selectedServices.length > 0) {
      // Get the first service for initial time slots
      const primaryServiceId = selectedServices[0]
      const formattedDate = format(selectedDate, "yyyy-MM-dd")

      // Get all time slots for the primary service
      const timeSlots = getAvailableTimeSlots(formattedDate, primaryServiceId)
        .filter((slot) => slot.isAvailable)
        .map((slot) => slot.time)

      // Filter out slots that would cause overlap with other services
      const validTimeSlots = timeSlots.filter((time) => {
        // Check if this time works for all selected services
        return !selectedServices.some((serviceId) => {
          const service = services.find((s) => s.id === serviceId)
          if (!service) return false

          return checkAppointmentOverlap(time, service.duration, formattedDate, appointments)
        })
      })

      setAvailableTimes(validTimeSlots)
    } else {
      setAvailableTimes([])
    }
  }, [selectedDate, selectedServices, services, appointments, getAvailableTimeSlots])

  // Calculate total duration and price when services change
  useEffect(() => {
    let duration = 0
    let price = 0

    selectedServices.forEach((serviceId) => {
      const service = services.find((s) => s.id === serviceId)
      if (service) {
        duration += service.duration
        price += service.price
      }
    })

    setTotalDuration(duration)
    setTotalPrice(price)
  }, [selectedServices, services])

  // Calculate end time whenever selected time or total duration changes
  useEffect(() => {
    if (selectedTime && totalDuration > 0) {
      const [hours, minutes] = selectedTime.split(":").map(Number)
      if (!isNaN(hours) && !isNaN(minutes)) {
        const startDate = new Date()
        startDate.setHours(hours, minutes, 0, 0)
        const endDate = new Date(startDate.getTime() + totalDuration * 60000)
        const calculatedEndTime = `${endDate.getHours().toString().padStart(2, "0")}:${endDate.getMinutes().toString().padStart(2, "0")}`
        setEndTime(calculatedEndTime)
      }
    } else {
      setEndTime("")
    }
  }, [selectedTime, totalDuration])

  // Check for customer ID in URL params and pre-fill form
  useEffect(() => {
    const customerId = searchParams.get("customer")
    if (customerId) {
      const customer = customers.find((c) => c.id === customerId)
      if (customer) {
        form.setValue("name", customer.name)
        form.setValue("phone", customer.phone)
        // If customer has notes, add them to the appointment notes
        if (customer.notes) {
          form.setValue("notes", customer.notes)
        }
      }
    }
  }, [searchParams, customers, form])

  // Update currentMonth when selectedDate changes
  useEffect(() => {
    if (selectedDate) {
      setCurrentMonth(selectedDate)
    }
  }, [selectedDate])

  // Memoize the service toggle handler to prevent infinite loops
  const handleServiceToggle = useCallback(
    (serviceId: string) => {
      setSelectedServices((prev) => {
        const newServices = prev.includes(serviceId) ? prev.filter((id) => id !== serviceId) : [...prev, serviceId]

        // Update form value outside of the state setter
        setTimeout(() => {
          form.setValue("services", newServices)
        }, 0)

        return newServices
      })
    },
    [form],
  )

  // Function to navigate to previous month
  const goToPreviousMonth = () => {
    const newDate = subMonths(currentMonth, 1)
    setCurrentMonth(newDate)
  }

  // Function to navigate to next month
  const goToNextMonth = () => {
    const newDate = addMonths(currentMonth, 1)
    setCurrentMonth(newDate)
  }

  function onSubmit(values: z.infer<typeof formSchema>) {
    if (selectedServices.length === 0) {
      toast({
        title: "שגיאה",
        description: "אנא בחר לפחות שירות אחד",
        variant: "destructive",
      })
      return
    }

    // Format date
    const formattedDate = format(values.date, "yyyy-MM-dd")

    // Create appointment with combined services
    const serviceNames = selectedServices
      .map((serviceId) => {
        const service = services.find((s) => s.id === serviceId)
        return service?.name || ""
      })
      .join(", ")

    // Get all selected service details
    const servicesDetails = selectedServices.map((serviceId) => {
      const service = services.find((s) => s.id === serviceId)
      return {
        id: serviceId,
        name: service?.name || "",
        price: service?.price || 0,
        duration: service?.duration || 0,
      }
    })

    // Find customer ID if exists
    const existingCustomer = customers.find((c) => c.phone === values.phone)
    const customerId = existingCustomer ? existingCustomer.id : ""

    // Add appointment to store
    addAppointment({
      customerId: customerId,
      customerName: values.name,
      customerPhone: values.phone,
      serviceId: selectedServices[0], // Use first service ID as primary
      serviceName: serviceNames, // Combined service names
      date: formattedDate,
      time: values.time,
      notes: JSON.stringify({
        multipleServices: true,
        services: servicesDetails,
        totalDuration: totalDuration,
        endTime: endTime,
      }),
      price: totalPrice,
    })

    toast({
      title: "התור נקבע בהצלחה",
      description: `תור חדש נקבע: ${values.name} - ${serviceNames}`,
    })

    // Redirect back to appointments page
    router.push("/admin/appointments")
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">הוספת תור חדש</h1>
      </div>

      <Card>
        <CardHeader className="p-4">
          <CardTitle className="text-lg">פרטי התור</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>שם לקוח/ה</FormLabel>
                    <FormControl>
                      <Input placeholder="הכניסי את שם הלקוח/ה" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>מספר טלפון</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="הכניסי את מספר הטלפון"
                        {...field}
                        type="tel"
                        inputMode="numeric"
                        pattern="[0-9]*"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div>
                <FormLabel>בחירת שירותים</FormLabel>
                <div className="space-y-2 mt-2">
                  {services.map((service) => (
                    <div
                      key={service.id}
                      className={`border rounded-lg p-3 cursor-pointer transition-all ${
                        selectedServices.includes(service.id) ? "border-pink-500 bg-pink-50" : "hover:border-pink-200"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center">
                            <div className="mr-2">
                              <Checkbox
                                id={`service-${service.id}`}
                                checked={selectedServices.includes(service.id)}
                                onCheckedChange={() => handleServiceToggle(service.id)}
                              />
                            </div>
                            <label
                              htmlFor={`service-${service.id}`}
                              className="text-md font-medium cursor-pointer"
                              onClick={(e) => {
                                e.preventDefault()
                                handleServiceToggle(service.id)
                              }}
                            >
                              {service.name}
                            </label>
                          </div>
                          <div className="flex items-center mt-1 space-x-3 rtl:space-x-reverse text-sm text-gray-500">
                            <span>₪{service.price}</span>
                            <span>{service.duration} דקות</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                {selectedServices.length > 0 && (
                  <div className="mt-3 p-3 bg-gray-50 rounded-md">
                    <div className="flex justify-between">
                      <span>סה"כ זמן:</span>
                      <span>{totalDuration} דקות</span>
                    </div>
                    <div className="flex justify-between font-medium">
                      <span>סה"כ מחיר:</span>
                      <span>₪{totalPrice}</span>
                    </div>
                  </div>
                )}
                {form.formState.errors.services && (
                  <p className="text-sm font-medium text-destructive mt-2">{form.formState.errors.services.message}</p>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>תאריך</FormLabel>
                      <div className="relative">
                        <div className="border rounded-lg p-4">
                          <div className="text-center mb-4">
                            <div className="flex items-center justify-between">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  if (selectedDate) {
                                    const nextMonth = new Date(selectedDate)
                                    nextMonth.setMonth(nextMonth.getMonth() + 1)
                                    setSelectedDate(nextMonth)
                                  }
                                }}
                              >
                                <ChevronLeft className="h-5 w-5" />
                              </Button>
                              <h3 className="text-lg font-medium">
                                {selectedDate ? format(selectedDate, "MMMM yyyy", { locale: he }) : ""}
                              </h3>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  if (selectedDate) {
                                    const prevMonth = new Date(selectedDate)
                                    prevMonth.setMonth(prevMonth.getMonth() - 1)
                                    setSelectedDate(prevMonth)
                                  }
                                }}
                              >
                                <ChevronRight className="h-5 w-5" />
                              </Button>
                            </div>
                          </div>

                          <div className="calendar-container rtl">
                            {/* Days of week - right to left */}
                            <div className="grid grid-cols-7 gap-1 mb-2 text-center">
                              <div className="text-sm font-medium">א'</div>
                              <div className="text-sm font-medium">ב'</div>
                              <div className="text-sm font-medium">ג'</div>
                              <div className="text-sm font-medium">ד'</div>
                              <div className="text-sm font-medium">ה'</div>
                              <div className="text-sm font-medium">ו'</div>
                              <div className="text-sm font-medium">ש'</div>
                            </div>

                            <Calendar
                              mode="single"
                              selected={selectedDate}
                              onSelect={(date) => {
                                if (date) {
                                  setSelectedDate(date)
                                  form.setValue("date", date)
                                }
                              }}
                              month={selectedDate}
                              onMonthChange={setSelectedDate}
                              locale={he}
                              disabled={(date) => date < new Date() || date.getDay() === 6}
                              initialFocus
                              className="rtl"
                            />
                          </div>
                        </div>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="time"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>שעה</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="בחרי שעה" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {availableTimes.length > 0 ? (
                            availableTimes.map((time) => (
                              <SelectItem key={time} value={time}>
                                {time}
                              </SelectItem>
                            ))
                          ) : (
                            <SelectItem value="no-times-available" disabled>
                              בחרי תאריך ושירות תחילה
                            </SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {selectedTime && totalDuration > 0 && (
                <div className="p-3 bg-blue-50 rounded-md">
                  <p className="text-sm text-blue-700">
                    <span className="font-medium">זמן סיום משוער:</span> {endTime}
                  </p>
                </div>
              )}

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>הערות</FormLabel>
                    <FormControl>
                      <Textarea placeholder="הוסיפי הערות או בקשות מיוחדות" className="resize-none" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex flex-col sm:flex-row gap-2 pt-2">
                <Button type="submit" className="bg-pink-500 hover:bg-pink-600">
                  שמירה
                </Button>
                <Button type="button" variant="outline" onClick={() => router.push("/admin/appointments")}>
                  ביטול
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  )
}
