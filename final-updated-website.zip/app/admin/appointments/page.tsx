"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Check, X, AlertCircle, Bell } from "lucide-react"
import Link from "next/link"
import AppointmentsList from "@/components/admin/appointments-list"
import MonthlyCalendar from "@/components/admin/monthly-calendar"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { useStore } from "@/lib/store"
import { useSearchParams } from "next/navigation"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { format } from "date-fns"

export default function AppointmentsPage() {
  const searchParams = useSearchParams()
  const dateParam = searchParams?.get("date")

  const [view, setView] = useState("list")
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateRange, setDateRange] = useState({ from: null, to: null })
  const [isScheduleDialogOpen, setIsScheduleDialogOpen] = useState(false)
  const [selectedAppointment, setSelectedAppointment] = useState(null)
  const [scheduleTime, setScheduleTime] = useState("")
  const [isMobile, setIsMobile] = useState(false)
  const [pendingAppointments, setPendingAppointments] = useState([])
  const [isApprovalDialogOpen, setIsApprovalDialogOpen] = useState(false)
  const [appointmentToApprove, setAppointmentToApprove] = useState(null)
  const [notificationSent, setNotificationSent] = useState(false)

  // Get appointments from store
  const appointments = useStore((state) => state.appointments)
  const updateAppointment = useStore((state) => state.updateAppointment)
  const deleteAppointment = useStore((state) => state.deleteAppointment)
  const addSystemLog = useStore((state) => state.addSystemLog)
  const { toast } = useToast()

  // Check if mobile
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)

    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  // Filter pending appointments
  useEffect(() => {
    const pending = appointments.filter((appointment) => appointment.status === "pending" && !appointment.isWaitlist)
    setPendingAppointments(pending)
  }, [appointments])

  // Filter appointments based on search and filters
  const filteredAppointments = appointments.filter((appointment) => {
    // Exclude waitlist appointments
    if (appointment.isWaitlist) {
      return false
    }

    // Search filter
    if (
      searchQuery &&
      !appointment.customerName.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !appointment.serviceName.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false
    }

    // Status filter
    if (statusFilter && statusFilter !== "all" && appointment.status !== statusFilter) {
      return false
    }

    // Date range filter
    if (dateRange.from && dateRange.to) {
      const appointmentDate = new Date(appointment.date)
      if (appointmentDate < dateRange.from || appointmentDate > dateRange.to) {
        return false
      }
    }

    return true
  })

  // Filter waitlist appointments separately
  const filteredWaitlistAppointments = appointments.filter((appointment) => {
    if (!appointment.isWaitlist) {
      return false
    }

    // Search filter
    if (
      searchQuery &&
      !appointment.customerName.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !appointment.serviceName.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false
    }

    // Date range filter
    if (dateRange.from && dateRange.to) {
      const appointmentDate = new Date(appointment.date)
      if (appointmentDate < dateRange.from || appointmentDate > dateRange.to) {
        return false
      }
    }

    return true
  })

  // Fixed function for calculating actual end time for all services
  const calculateEndTime = (startTime, notes) => {
    try {
      if (!startTime) return "לא זמין"

      // Extract total duration from notes if available
      let totalDurationMinutes = 0

      try {
        if (notes) {
          const parsedNotes = JSON.parse(notes)
          if (parsedNotes.totalDuration) {
            totalDurationMinutes = Number.parseInt(parsedNotes.totalDuration)
          } else if (parsedNotes.services && Array.isArray(parsedNotes.services)) {
            // Sum up durations of all services
            totalDurationMinutes = parsedNotes.services.reduce((total, service) => {
              return total + (service.duration || 0)
            }, 0)
          }
        }
      } catch (e) {
        console.error("Error parsing appointment notes:", e)
        return "לא זמין"
      }

      // If we couldn't extract a duration, use a default
      if (totalDurationMinutes <= 0) {
        totalDurationMinutes = 60 // Default duration
      }

      const [hours, minutes] = startTime.split(":").map(Number)
      if (isNaN(hours) || isNaN(minutes)) return "לא זמין"

      const startDate = new Date()
      startDate.setHours(hours, minutes, 0, 0)

      const endDate = new Date(startDate.getTime() + totalDurationMinutes * 60000)
      const endHours = endDate.getHours().toString().padStart(2, "0")
      const endMinutes = endDate.getMinutes().toString().padStart(2, "0")

      return `${endHours}:${endMinutes}`
    } catch (error) {
      console.error("Error calculating end time:", error)
      return "לא זמין"
    }
  }

  const handleApproveAppointment = (appointment) => {
    setAppointmentToApprove(appointment)
    setIsApprovalDialogOpen(true)
    setNotificationSent(false)
  }

  const handleRejectAppointment = (appointment) => {
    try {
      updateAppointment(appointment.id, {
        status: "cancelled",
      })

      // Add system log
      if (addSystemLog) {
        addSystemLog({
          action: "appointment_rejected",
          details: `דחיית תור: ${appointment.customerName} - ${appointment.serviceName} בתאריך ${appointment.date}`,
          userId: "admin",
          userType: "admin",
        })
      }

      // Update pending appointments list
      setPendingAppointments((prev) => prev.filter((app) => app.id !== appointment.id))

      toast({
        title: "התור נדחה",
        description: `התור של ${appointment.customerName} נדחה`,
        variant: "destructive",
      })

      // Send notification to customer
      setTimeout(() => {
        toast({
          title: "הודעה נשלחה ללקוח",
          description: `הודעת דחייה נשלחה ל${appointment.customerName}`,
        })
      }, 1000)
    } catch (error) {
      console.error("Error rejecting appointment:", error)
      toast({
        title: "שגיאה בדחיית התור",
        description: "אירעה שגיאה בעת דחיית התור. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  const confirmApproval = () => {
    if (!appointmentToApprove) return

    try {
      // Update the appointment status to confirmed
      updateAppointment(appointmentToApprove.id, {
        status: "confirmed",
      })

      // Add system log
      if (addSystemLog) {
        addSystemLog({
          action: "appointment_approved",
          details: `אישור תור: ${appointmentToApprove.customerName} - ${appointmentToApprove.serviceName} בתאריך ${appointmentToApprove.date}`,
          userId: "admin",
          userType: "admin",
        })
      }

      // Show success notification
      toast({
        title: "התור אושר",
        description: `התור של ${appointmentToApprove.customerName} אושר בהצלחה`,
      })

      // Update pending appointments list
      setPendingAppointments((prev) => prev.filter((app) => app.id !== appointmentToApprove.id))

      // Send notification to customer
      setNotificationSent(true)
      setTimeout(() => {
        toast({
          title: "הודעה נשלחה ללקוח",
          description: `הודעת אישור נשלחה ל${appointmentToApprove.customerName}`,
        })
        setIsApprovalDialogOpen(false)
        setAppointmentToApprove(null)
      }, 1500)
    } catch (error) {
      console.error("Error approving appointment:", error)
      toast({
        title: "שגיאה באישור התור",
        description: "אירעה שגיאה בעת אישור התור. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <h1 className="text-3xl font-bold">ניהול תורים</h1>
        <Link href="/admin/appointments/new">
          <Button className="bg-pink-500 hover:bg-pink-600 w-full sm:w-auto" onClick={() => console.log("TODO: Add functionality")}>
            <Plus className="mr-2 h-4 w-4" /> תור חדש
          </Button>
        </Link>
      </div>

      {pendingAppointments.length > 0 && (
        <Alert className="mb-6 border-amber-300 bg-amber-50">
          <AlertCircle className="h-4 w-4 text-amber-600" />
          <AlertDescription className="flex justify-between items-center">
            <span>יש {pendingAppointments.length} תורים ממתינים לאישור</span>
            <Button
              variant="outline"
              size="sm"
              className="border-amber-300 text-amber-700 hover:bg-amber-100"
              onClick={() => setStatusFilter("pending")}
            >
              צפייה בתורים ממתינים
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <Tabs value={view} onValueChange={setView}>
        <TabsList className="grid w-full grid-cols-2 gap-2 mb-6">
          <TabsTrigger value="list">רשימת תורים</TabsTrigger>
          <TabsTrigger value="monthly">יומן</TabsTrigger>
        </TabsList>

        <TabsContent value="list">
          <Card>
            <CardHeader>
              <CardTitle>רשימת תורים</CardTitle>
              <CardDescription>צפייה וניהול של כל התורים במערכת</CardDescription>
            </CardHeader>
            <CardContent>
              {pendingAppointments.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-lg font-medium mb-3">תורים ממתינים לאישור</h3>
                  <div className="space-y-3">
                    {pendingAppointments.map((appointment) => (
                      <Card key={appointment.id} className="overflow-hidden border-amber-200">
                        <CardContent className="p-4">
                          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                            <div>
                              <div className="font-medium">{appointment.customerName}</div>
                              <div className="text-sm text-muted-foreground">{appointment.serviceName}</div>
                              <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 text-sm text-muted-foreground mt-1">
                                <div className="flex items-center">
                                  <span className="ml-1">תאריך:</span>{" "}
                                  {format(new Date(appointment.date), "dd/MM/yyyy")}
                                </div>
                                <div className="flex items-center">
                                  <span className="ml-1">שעה:</span> {appointment.time} -{" "}
                                  {calculateEndTime(appointment.time, appointment.notes)}
                                </div>
                                <div className="flex items-center">
                                  <span className="ml-1">סכום:</span>{" "}
                                  <span className="font-medium text-pink-600">₪{appointment.price || 0}</span>
                                </div>
                              </div>
                            </div>
                            <div className="flex gap-2 w-full sm:w-auto">
                              <Button
                                className="bg-green-500 hover:bg-green-600 flex-1 sm:flex-auto"
                                onClick={() => {
                                  setAppointmentToApprove(appointment)
                                  setIsApprovalDialogOpen(true)
                                  setNotificationSent(false)
                                }}
                              >
                                <Check className="h-4 w-4 mr-1" />
                                אישור
                              </Button>
                              <Button
                                variant="outline"
                                className="text-red-500 border-red-200 hover:bg-red-50 flex-1 sm:flex-auto"
                                onClick={() => {
                                  if (confirm(`האם אתה בטוח שברצונך לדחות את התור של ${appointment.customerName}?`)) {
                                    handleRejectAppointment(appointment)
                                  }
                                }}
                              >
                                <X className="h-4 w-4 mr-1" />
                                דחייה
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
              <AppointmentsList calculateEndTime={calculateEndTime} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monthly">
          <Card>
            <CardHeader>
              <CardTitle>יומן תורים</CardTitle>
              <CardDescription>צפייה בתורים לפי תאריך</CardDescription>
            </CardHeader>
            <CardContent className={isMobile ? "px-2 py-2" : "px-4"}>
              <MonthlyCalendar />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={isScheduleDialogOpen} onOpenChange={setIsScheduleDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>קביעת תור מרשימת המתנה</DialogTitle>
            <DialogDescription>
              בחר שעה לתור של {selectedAppointment?.customerName} בתאריך {selectedAppointment?.date}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="time">שעה</Label>
              <Select value={scheduleTime} onValueChange={setScheduleTime}>
                <SelectTrigger>
                  <SelectValue placeholder="בחר שעה" />
                </SelectTrigger>
                <SelectContent>
                  {["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"].map((time) => (
                    <SelectItem key={time} value={time}>
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsScheduleDialogOpen(false)}>
              ביטול
            </Button>
            <Button
              className="bg-pink-500 hover:bg-pink-600"
              onClick={() => {
                if (!scheduleTime) {
                  toast({
                    title: "שגיאה",
                    description: "אנא בחר שעה לתור",
                    variant: "destructive",
                  })
                  return
                }

                updateAppointment(selectedAppointment.id, {
                  time: scheduleTime,
                  isWaitlist: false,
                  status: "confirmed",
                })

                setIsScheduleDialogOpen(false)
                setScheduleTime("")

                toast({
                  title: "התור נקבע בהצלחה",
                  description: `התור נקבע ל${selectedAppointment.date} בשעה ${scheduleTime}`,
                })
              }}
              disabled={!scheduleTime}
            >
              קביעת תור
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isApprovalDialogOpen} onOpenChange={setIsApprovalDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>אישור תור</DialogTitle>
            <DialogDescription>
              האם אתה בטוח שברצונך לאשר את התור של {appointmentToApprove?.customerName} בתאריך{" "}
              {appointmentToApprove?.date}?
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="bg-gray-50 p-3 rounded-md">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <p className="text-sm font-medium text-gray-500">לקוח:</p>
                  <p>{appointmentToApprove?.customerName}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">שירות:</p>
                  <p>{appointmentToApprove?.serviceName}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">תאריך:</p>
                  <p>{appointmentToApprove?.date}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">שעה:</p>
                  <p>{appointmentToApprove?.time}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-sm font-medium text-gray-500">סכום לתשלום:</p>
                  <p className="font-bold text-pink-600">₪{appointmentToApprove?.price || 0}</p>
                </div>
              </div>
            </div>

            {notificationSent && (
              <div className="mt-4 bg-green-50 p-3 rounded-md flex items-center">
                <Bell className="h-4 w-4 text-green-500 mr-2" />
                <p className="text-sm text-green-700">הודעה נשלחה ללקוח בהצלחה</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsApprovalDialogOpen(false)}>
              ביטול
            </Button>
            <Button className="bg-green-500 hover:bg-green-600" onClick={confirmApproval} disabled={notificationSent}>
              {notificationSent ? "התור אושר" : "אישור התור"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
