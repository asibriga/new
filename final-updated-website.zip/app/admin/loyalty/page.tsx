"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { useStore } from "@/lib/store"
// הוספת ייבוא של Settings
import { Award, Edit, Plus, Trash, Gift, Settings } from "lucide-react"

// הוספת כפתור הגדרות תוכנית נאמנות
export default function LoyaltyPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("tiers")
  const [isCreateTierDialogOpen, setIsCreateTierDialogOpen] = useState(false)
  const [isEditTierDialogOpen, setIsEditTierDialogOpen] = useState(false)
  const [isCreateRewardDialogOpen, setIsCreateRewardDialogOpen] = useState(false)
  const [isEditRewardDialogOpen, setIsEditRewardDialogOpen] = useState(false)
  const [isSettingsDialogOpen, setIsSettingsDialogOpen] = useState(false)
  const [selectedTier, setSelectedTier] = useState(null)
  const [selectedReward, setSelectedReward] = useState(null)
  const [pendingAction, setPendingAction] = useState(null)

  // הגדרות תוכנית נאמנות
  const [loyaltySettings, setLoyaltySettings] = useState({
    pointsPerPurchase: 1,
    pointsMultiplier: 1,
    referralPoints: 50,
  })

  // קבלת הגדרות מהמאגר
  const storeLoyaltySettings = useStore(
    (state) =>
      state.loyaltySettings || {
        pointsPerPurchase: 1,
        pointsMultiplier: 1,
        referralPoints: 50,
      },
  )

  // עדכון הגדרות מהמאגר בעת טעינה
  useEffect(() => {
    setLoyaltySettings(storeLoyaltySettings)
  }, [storeLoyaltySettings])

  // שמירת הגדרות תוכנית נאמנות
  const handleSaveSettings = () => {
    try {
      useStore.setState({ loyaltySettings })
      toast({
        title: "הגדרות נשמרו",
        description: "הגדרות תוכנית הנאמנות נשמרו בהצלחה",
      })
      setIsSettingsDialogOpen(false)
    } catch (error) {
      console.error("Error saving loyalty settings:", error)
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה בשמירת ההגדרות",
        variant: "destructive",
      })
    }
  }

  // טופס ליצירת/עריכת דרגת נאמנות
  const [tierForm, setTierForm] = useState({
    name: "",
    pointsRequired: 0,
    discount: 0,
    description: "",
    isActive: true,
    color: "#ff4d8c", // ורוד כברירת מחדל
  })

  // טופס ליצירת/עריכת הטבה
  const [rewardForm, setRewardForm] = useState({
    name: "",
    pointsCost: 0,
    description: "",
    isActive: true,
    expirationDays: 30,
    limitPerCustomer: 0,
  })

  // קבלת נתונים מהמאגר
  const loyaltyTiers = useStore((state) => state.loyaltyTiers || [])
  const loyaltyRewards = useStore((state) => state.loyaltyRewards || [])
  const addLoyaltyTier = useStore((state) => state.addLoyaltyTier)
  const updateLoyaltyTier = useStore((state) => state.updateLoyaltyTier)
  const deleteLoyaltyTier = useStore((state) => state.deleteLoyaltyTier)
  const addLoyaltyReward = useStore((state) => state.addLoyaltyReward)
  const updateLoyaltyReward = useStore((state) => state.updateLoyaltyReward)
  const deleteLoyaltyReward = useStore((state) => state.deleteLoyaltyReward)

  // איפוס טפסים בעת פתיחת דיאלוג
  useEffect(() => {
    if (isCreateTierDialogOpen) {
      setTierForm({
        name: "",
        pointsRequired: 0,
        discount: 0,
        description: "",
        isActive: true,
        color: "#ff4d8c",
      })
    }
  }, [isCreateTierDialogOpen])

  useEffect(() => {
    if (isCreateRewardDialogOpen) {
      setRewardForm({
        name: "",
        pointsCost: 0,
        description: "",
        isActive: true,
        expirationDays: 30,
        limitPerCustomer: 0,
      })
    }
  }, [isCreateRewardDialogOpen])

  // מילוי טופס בעת עריכה
  useEffect(() => {
    if (selectedTier && isEditTierDialogOpen) {
      setTierForm({
        name: selectedTier.name || "",
        pointsRequired: selectedTier.pointsRequired || 0,
        discount: selectedTier.discount || 0,
        description: selectedTier.description || "",
        isActive: selectedTier.isActive !== false,
        color: selectedTier.color || "#ff4d8c",
      })
    }
  }, [selectedTier, isEditTierDialogOpen])

  useEffect(() => {
    if (selectedReward && isEditRewardDialogOpen) {
      setRewardForm({
        name: selectedReward.name || "",
        pointsCost: selectedReward.pointsCost || 0,
        description: selectedReward.description || "",
        isActive: selectedReward.isActive !== false,
        expirationDays: selectedReward.expirationDays || 30,
        limitPerCustomer: selectedReward.limitPerCustomer || 0,
      })
    }
  }, [selectedReward, isEditRewardDialogOpen])

  // טיפול בפעולות ממתינות
  useEffect(() => {
    if (pendingAction) {
      switch (pendingAction.type) {
        case "createTier":
          handleCreateTier()
          break
        case "updateTier":
          handleUpdateTier()
          break
        case "createReward":
          handleCreateReward()
          break
        case "updateReward":
          handleUpdateReward()
          break
        default:
          break
      }
      setPendingAction(null)
    }
  }, [pendingAction])

  // יצירת דרגת נאמנות חדשה
  const handleCreateTier = () => {
    if (!tierForm.name) {
      toast({
        title: "שגיאה",
        description: "יש להזין שם לדרגת הנאמנות",
        variant: "destructive",
      })
      return
    }

    try {
      const newTier = {
        id: `tier_${Date.now()}`,
        ...tierForm,
        pointsRequired: Number(tierForm.pointsRequired),
        discount: Number(tierForm.discount),
      }

      addLoyaltyTier(newTier)
      setIsCreateTierDialogOpen(false)

      toast({
        title: "דרגת נאמנות נוצרה",
        description: `דרגת הנאמנות "${tierForm.name}" נוצרה בהצלחה`,
      })
    } catch (error) {
      console.error("Error creating loyalty tier:", error)
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה ביצירת דרגת הנאמנות",
        variant: "destructive",
      })
    }
  }

  // עדכון דרגת נאמנות
  const handleUpdateTier = () => {
    if (!selectedTier || !tierForm.name) {
      toast({
        title: "שגיאה",
        description: "יש להזין שם לדרגת הנאמנות",
        variant: "destructive",
      })
      return
    }

    try {
      const updatedTier = {
        ...selectedTier,
        ...tierForm,
        pointsRequired: Number(tierForm.pointsRequired),
        discount: Number(tierForm.discount),
      }

      updateLoyaltyTier(selectedTier.id, updatedTier)
      setIsEditTierDialogOpen(false)
      setSelectedTier(null)

      toast({
        title: "דרגת נאמנות עודכנה",
        description: `דרגת הנאמנות "${tierForm.name}" עודכנה בהצלחה`,
      })
    } catch (error) {
      console.error("Error updating loyalty tier:", error)
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה בעדכון דרגת הנאמנות",
        variant: "destructive",
      })
    }
  }

  // מחיקת דרגת נאמנות
  const handleDeleteTier = (tierId) => {
    try {
      deleteLoyaltyTier(tierId)

      toast({
        title: "דרגת נאמנות נמחקה",
        description: "דרגת הנאמנות נמחקה בהצלחה",
      })
    } catch (error) {
      console.error("Error deleting loyalty tier:", error)
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה במחיקת דרגת הנאמנות",
        variant: "destructive",
      })
    }
  }

  // יצירת הטבה חדשה
  const handleCreateReward = () => {
    if (!rewardForm.name) {
      toast({
        title: "שגיאה",
        description: "יש להזין שם להטבה",
        variant: "destructive",
      })
      return
    }

    try {
      const newReward = {
        id: `reward_${Date.now()}`,
        ...rewardForm,
        pointsCost: Number(rewardForm.pointsCost),
        expirationDays: Number(rewardForm.expirationDays),
        limitPerCustomer: Number(rewardForm.limitPerCustomer),
      }

      addLoyaltyReward(newReward)
      setIsCreateRewardDialogOpen(false)

      toast({
        title: "הטבה נוצרה",
        description: `ההטבה "${rewardForm.name}" נוצרה בהצלחה`,
      })
    } catch (error) {
      console.error("Error creating loyalty reward:", error)
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה ביצירת ההטבה",
        variant: "destructive",
      })
    }
  }

  // עדכון הטבה
  const handleUpdateReward = () => {
    if (!selectedReward || !rewardForm.name) {
      toast({
        title: "שגיאה",
        description: "יש להזין שם להטבה",
        variant: "destructive",
      })
      return
    }

    try {
      const updatedReward = {
        ...selectedReward,
        ...rewardForm,
        pointsCost: Number(rewardForm.pointsCost),
        expirationDays: Number(rewardForm.expirationDays),
        limitPerCustomer: Number(rewardForm.limitPerCustomer),
      }

      updateLoyaltyReward(selectedReward.id, updatedReward)
      setIsEditRewardDialogOpen(false)
      setSelectedReward(null)

      toast({
        title: "הטבה עודכנה",
        description: `ההטבה "${rewardForm.name}" עודכנה בהצלחה`,
      })
    } catch (error) {
      console.error("Error updating loyalty reward:", error)
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה בעדכון ההטבה",
        variant: "destructive",
      })
    }
  }

  // מחיקת הטבה
  const handleDeleteReward = (rewardId) => {
    try {
      deleteLoyaltyReward(rewardId)

      toast({
        title: "הטבה נמחקה",
        description: "ההטבה נמחקה בהצלחה",
      })
    } catch (error) {
      console.error("Error deleting loyalty reward:", error)
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה במחיקת ההטבה",
        variant: "destructive",
      })
    }
  }

  // הוספת כפתור הגדרות לחלק העליון של הדף
  return (
    <div className="container mx-auto p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h1 className="text-2xl font-bold">ניהול תוכנית נאמנות</h1>
          <p className="text-muted-foreground">ניהול דרגות נאמנות והטבות ללקוחות</p>
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <Button variant="outline" onClick={() => setIsSettingsDialogOpen(true)} className="w-full md:w-auto">
            <Settings className="mr-2 h-4 w-4" />
            הגדרות
          </Button>
          {activeTab === "tiers" ? (
            <Button
              className="bg-pink-500 hover:bg-pink-600 w-full md:w-auto"
              onClick={() => setIsCreateTierDialogOpen(true)}
            >
              <Plus className="mr-2 h-4 w-4" />
              דרגת נאמנות חדשה
            </Button>
          ) : (
            <Button
              className="bg-pink-500 hover:bg-pink-600 w-full md:w-auto"
              onClick={() => setIsCreateRewardDialogOpen(true)}
            >
              <Plus className="mr-2 h-4 w-4" />
              הטבה חדשה
            </Button>
          )}
        </div>
      </div>

      {/* הוספת דיאלוג הגדרות */}
      <Dialog open={isSettingsDialogOpen} onOpenChange={setIsSettingsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>הגדרות תוכנית נאמנות</DialogTitle>
            <DialogDescription>הגדר את הפרמטרים של תוכנית הנאמנות</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="points-per-purchase">נקודות לכל 10 ש"ח</Label>
              <Input
                id="points-per-purchase"
                type="number"
                min="0"
                step="0.1"
                value={loyaltySettings.pointsPerPurchase}
                onChange={(e) =>
                  setLoyaltySettings({ ...loyaltySettings, pointsPerPurchase: Number.parseFloat(e.target.value) || 0 })
                }
              />
              <p className="text-sm text-muted-foreground">מספר הנקודות שיתווספו עבור כל 10 ש"ח רכישה</p>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="points-multiplier">מכפיל נקודות</Label>
              <Input
                id="points-multiplier"
                type="number"
                min="1"
                step="0.1"
                value={loyaltySettings.pointsMultiplier}
                onChange={(e) =>
                  setLoyaltySettings({ ...loyaltySettings, pointsMultiplier: Number.parseFloat(e.target.value) || 1 })
                }
              />
              <p className="text-sm text-muted-foreground">מכפיל לכל הנקודות הנצברות (למבצעים מיוחדים)</p>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="referral-points">נקודות עבור הפניה</Label>
              <Input
                id="referral-points"
                type="number"
                min="0"
                value={loyaltySettings.referralPoints}
                onChange={(e) =>
                  setLoyaltySettings({ ...loyaltySettings, referralPoints: Number.parseInt(e.target.value) || 0 })
                }
              />
              <p className="text-sm text-muted-foreground">מספר הנקודות שיתווספו עבור הפניית חבר</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSettingsDialogOpen(false)}>
              ביטול
            </Button>
            <Button className="bg-pink-500 hover:bg-pink-600" onClick={handleSaveSettings}>
              שמירה
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="tiers" className="flex items-center gap-2">
            <Award className="h-4 w-4" />
            דרגות נאמנות
          </TabsTrigger>
          <TabsTrigger value="rewards" className="flex items-center gap-2">
            <Gift className="h-4 w-4" />
            הטבות
          </TabsTrigger>
        </TabsList>

        <TabsContent value="tiers">
          <Card>
            <CardHeader>
              <CardTitle>דרגות נאמנות</CardTitle>
              <CardDescription>ניהול דרגות הנאמנות במערכת</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>שם</TableHead>
                    <TableHead>נקודות נדרשות</TableHead>
                    <TableHead>הנחה</TableHead>
                    <TableHead>סטטוס</TableHead>
                    <TableHead>פעולות</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loyaltyTiers.length > 0 ? (
                    loyaltyTiers.map((tier) => (
                      <TableRow key={tier.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: tier.color || "#ff4d8c" }}
                            ></div>
                            <span className="font-medium">{tier.name}</span>
                          </div>
                        </TableCell>
                        <TableCell>{tier.pointsRequired}</TableCell>
                        <TableCell>{tier.discount}%</TableCell>
                        <TableCell>
                          {tier.isActive !== false ? (
                            <Badge className="bg-green-500">פעיל</Badge>
                          ) : (
                            <Badge variant="outline" className="text-gray-500">
                              לא פעיל
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedTier(tier)
                                setIsEditTierDialogOpen(true)
                              }}
                            >
                              <Edit className="h-4 w-4 text-blue-500" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                if (confirm(`האם אתה בטוח שברצונך למחוק את דרגת הנאמנות "${tier.name}"?`)) {
                                  handleDeleteTier(tier.id)
                                }
                              }}
                            >
                              <Trash className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-4">
                        לא נמצאו דרגות נאמנות. לחץ על "דרגת נאמנות חדשה" כדי להוסיף.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rewards">
          <Card>
            <CardHeader>
              <CardTitle>הטבות</CardTitle>
              <CardDescription>ניהול ההטבות שלקוחות יכולים לממש עם נקודות נאמנות</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>שם</TableHead>
                    <TableHead>עלות בנקודות</TableHead>
                    <TableHead>תוקף (ימים)</TableHead>
                    <TableHead>סטטוס</TableHead>
                    <TableHead>פעולות</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loyaltyRewards.length > 0 ? (
                    loyaltyRewards.map((reward) => (
                      <TableRow key={reward.id}>
                        <TableCell className="font-medium">{reward.name}</TableCell>
                        <TableCell>{reward.pointsCost}</TableCell>
                        <TableCell>{reward.expirationDays}</TableCell>
                        <TableCell>
                          {reward.isActive !== false ? (
                            <Badge className="bg-green-500">פעיל</Badge>
                          ) : (
                            <Badge variant="outline" className="text-gray-500">
                              לא פעיל
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedReward(reward)
                                setIsEditRewardDialogOpen(true)
                              }}
                            >
                              <Edit className="h-4 w-4 text-blue-500" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                if (confirm(`האם אתה בטוח שברצונך למחוק את ההטבה "${reward.name}"?`)) {
                                  handleDeleteReward(reward.id)
                                }
                              }}
                            >
                              <Trash className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-4">
                        לא נמצאו הטבות. לחץ על "הטבה חדשה" כדי להוסיף.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* דיאלוג יצירת דרגת נאמנות */}
      <Dialog open={isCreateTierDialogOpen} onOpenChange={setIsCreateTierDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>יצירת דרגת נאמנות חדשה</DialogTitle>
            <DialogDescription>הגדר את פרטי דרגת הנאמנות החדשה</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="tier-name">שם הדרגה</Label>
              <Input
                id="tier-name"
                value={tierForm.name}
                onChange={(e) => setTierForm({ ...tierForm, name: e.target.value })}
                placeholder="לדוגמה: זהב, פלטינום, VIP"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="tier-points">נקודות נדרשות</Label>
              <Input
                id="tier-points"
                type="number"
                min="0"
                value={tierForm.pointsRequired}
                onChange={(e) => setTierForm({ ...tierForm, pointsRequired: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="tier-discount">הנחה (%)</Label>
              <Input
                id="tier-discount"
                type="number"
                min="0"
                max="100"
                value={tierForm.discount}
                onChange={(e) => setTierForm({ ...tierForm, discount: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="tier-color">צבע</Label>
              <div className="flex gap-2">
                <Input
                  id="tier-color"
                  type="color"
                  value={tierForm.color}
                  onChange={(e) => setTierForm({ ...tierForm, color: e.target.value })}
                  className="w-12 h-10 p-1"
                />
                <Input
                  value={tierForm.color}
                  onChange={(e) => setTierForm({ ...tierForm, color: e.target.value })}
                  placeholder="#ff4d8c"
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="tier-description">תיאור</Label>
              <Textarea
                id="tier-description"
                value={tierForm.description}
                onChange={(e) => setTierForm({ ...tierForm, description: e.target.value })}
                placeholder="תיאור קצר של הדרגה והטבותיה"
              />
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Switch
                id="tier-active"
                checked={tierForm.isActive}
                onCheckedChange={(checked) => setTierForm({ ...tierForm, isActive: checked })}
              />
              <Label htmlFor="tier-active">דרגה פעילה</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateTierDialogOpen(false)}>
              ביטול
            </Button>
            <Button className="bg-pink-500 hover:bg-pink-600" onClick={() => setPendingAction({ type: "createTier" })}>
              יצירה
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* דיאלוג עריכת דרגת נאמנות */}
      <Dialog open={isEditTierDialogOpen} onOpenChange={setIsEditTierDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>עריכת דרגת נאמנות</DialogTitle>
            <DialogDescription>עדכן את פרטי דרגת הנאמנות</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-tier-name">שם הדרגה</Label>
              <Input
                id="edit-tier-name"
                value={tierForm.name}
                onChange={(e) => setTierForm({ ...tierForm, name: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-tier-points">נקודות נדרשות</Label>
              <Input
                id="edit-tier-points"
                type="number"
                min="0"
                value={tierForm.pointsRequired}
                onChange={(e) => setTierForm({ ...tierForm, pointsRequired: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-tier-discount">הנחה (%)</Label>
              <Input
                id="edit-tier-discount"
                type="number"
                min="0"
                max="100"
                value={tierForm.discount}
                onChange={(e) => setTierForm({ ...tierForm, discount: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-tier-color">צבע</Label>
              <div className="flex gap-2">
                <Input
                  id="edit-tier-color"
                  type="color"
                  value={tierForm.color}
                  onChange={(e) => setTierForm({ ...tierForm, color: e.target.value })}
                  className="w-12 h-10 p-1"
                />
                <Input value={tierForm.color} onChange={(e) => setTierForm({ ...tierForm, color: e.target.value })} />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-tier-description">תיאור</Label>
              <Textarea
                id="edit-tier-description"
                value={tierForm.description}
                onChange={(e) => setTierForm({ ...tierForm, description: e.target.value })}
              />
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Switch
                id="edit-tier-active"
                checked={tierForm.isActive}
                onCheckedChange={(checked) => setTierForm({ ...tierForm, isActive: checked })}
              />
              <Label htmlFor="edit-tier-active">דרגה פעילה</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditTierDialogOpen(false)}>
              ביטול
            </Button>
            <Button className="bg-pink-500 hover:bg-pink-600" onClick={() => setPendingAction({ type: "updateTier" })}>
              עדכון
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* דיאלוג יצירת הטבה */}
      <Dialog open={isCreateRewardDialogOpen} onOpenChange={setIsCreateRewardDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>יצירת הטבה חדשה</DialogTitle>
            <DialogDescription>הגדר את פרטי ההטבה החדשה</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="reward-name">שם ההטבה</Label>
              <Input
                id="reward-name"
                value={rewardForm.name}
                onChange={(e) => setRewardForm({ ...rewardForm, name: e.target.value })}
                placeholder="לדוגמה: טיפול חינם, הנחה מיוחדת"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="reward-points">עלות בנקודות</Label>
              <Input
                id="reward-points"
                type="number"
                min="0"
                value={rewardForm.pointsCost}
                onChange={(e) => setRewardForm({ ...rewardForm, pointsCost: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="reward-expiration">תוקף (ימים)</Label>
              <Input
                id="reward-expiration"
                type="number"
                min="0"
                value={rewardForm.expirationDays}
                onChange={(e) => setRewardForm({ ...rewardForm, expirationDays: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="reward-limit">הגבלה ללקוח (0 = ללא הגבלה)</Label>
              <Input
                id="reward-limit"
                type="number"
                min="0"
                value={rewardForm.limitPerCustomer}
                onChange={(e) => setRewardForm({ ...rewardForm, limitPerCustomer: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="reward-description">תיאור</Label>
              <Textarea
                id="reward-description"
                value={rewardForm.description}
                onChange={(e) => setRewardForm({ ...rewardForm, description: e.target.value })}
                placeholder="תיאור מפורט של ההטבה ותנאי השימוש"
              />
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Switch
                id="reward-active"
                checked={rewardForm.isActive}
                onCheckedChange={(checked) => setRewardForm({ ...rewardForm, isActive: checked })}
              />
              <Label htmlFor="reward-active">הטבה פעילה</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateRewardDialogOpen(false)}>
              ביטול
            </Button>
            <Button
              className="bg-pink-500 hover:bg-pink-600"
              onClick={() => setPendingAction({ type: "createReward" })}
            >
              יצירה
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* דיאלוג עריכת הטבה */}
      <Dialog open={isEditRewardDialogOpen} onOpenChange={setIsEditRewardDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>עריכת הטבה</DialogTitle>
            <DialogDescription>עדכן את פרטי ההטבה</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-reward-name">שם ההטבה</Label>
              <Input
                id="edit-reward-name"
                value={rewardForm.name}
                onChange={(e) => setRewardForm({ ...rewardForm, name: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-reward-points">עלות בנקודות</Label>
              <Input
                id="edit-reward-points"
                type="number"
                min="0"
                value={rewardForm.pointsCost}
                onChange={(e) => setRewardForm({ ...rewardForm, pointsCost: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-reward-expiration">תוקף (ימים)</Label>
              <Input
                id="edit-reward-expiration"
                type="number"
                min="0"
                value={rewardForm.expirationDays}
                onChange={(e) => setRewardForm({ ...rewardForm, expirationDays: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-reward-limit">הגבלה ללקוח (0 = ללא הגבלה)</Label>
              <Input
                id="edit-reward-limit"
                type="number"
                min="0"
                value={rewardForm.limitPerCustomer}
                onChange={(e) => setRewardForm({ ...rewardForm, limitPerCustomer: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-reward-description">תיאור</Label>
              <Textarea
                id="edit-reward-description"
                value={rewardForm.description}
                onChange={(e) => setRewardForm({ ...rewardForm, description: e.target.value })}
              />
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Switch
                id="edit-reward-active"
                checked={rewardForm.isActive}
                onCheckedChange={(checked) => setRewardForm({ ...rewardForm, isActive: checked })}
              />
              <Label htmlFor="edit-reward-active">הטבה פעילה</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditRewardDialogOpen(false)}>
              ביטול
            </Button>
            <Button
              className="bg-pink-500 hover:bg-pink-600"
              onClick={() => setPendingAction({ type: "updateReward" })}
            >
              עדכון
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
