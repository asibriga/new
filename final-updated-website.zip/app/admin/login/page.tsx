"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Lock } from "lucide-react"

export default function AdminLoginPage() {
  const router = useRouter()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()

    // Simple authentication - in a real app, this would be handled securely
    if (username === "may" && password === "may2703") {
      // Set a session token or cookie here in a real app
      localStorage.setItem("adminAuthenticated", "true")
      router.push("/admin")
    } else {
      setError("שם משתמש או סיסמה שגויים")
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-pink-100">
            <Lock className="h-8 w-8 text-pink-600" />
          </div>
          <CardTitle className="text-2xl">כניסה לפאנל ניהול</CardTitle>
          <CardDescription>May Beauty</CardDescription>
        </CardHeader>
        <form onSubmit={handleLogin}>
          <CardContent className="space-y-4">
            {error && <div className="bg-red-50 text-red-600 p-3 rounded-md text-center text-sm">{error}</div>}
            <div className="space-y-2">
              <Label htmlFor="username">שם משתמש</Label>
              <Input id="username" value={username} onChange={(e) => setUsername(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">סיסמה</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full bg-pink-500 hover:bg-pink-600">
              כניסה
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
