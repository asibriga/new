"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Search, Download, RefreshCw, Trash } from "lucide-react"
import { useStore } from "@/lib/store"
import { format } from "date-fns"
import { useToast } from "@/components/ui/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

export default function LogsPage() {
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [logType, setLogType] = useState("all")
  const [filteredLogs, setFilteredLogs] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)

  const logs = useStore((state) => state.logs || []) // Add fallback empty array
  const clearLogs = useStore((state) => state.clearLogs)
  const addLog = useStore((state) => state.addLog)

  // Add some sample logs if none exist
  useEffect(() => {
    // Add sample logs if none exist
    if (logs.length === 0) {
      addLog({
        type: "system",
        message: "המערכת הופעלה בהצלחה",
      })
      addLog({
        type: "user",
        message: "משתמש התחבר למערכת",
        user: "admin",
      })
      addLog({
        type: "appointment",
        message: "נקבע תור חדש",
        user: "לקוח: רונית כהן",
      })
      addLog({
        type: "error",
        message: "שגיאה בעיבוד התשלום",
      })
    }
  }, [logs.length, addLog])

  // Filter logs when search term or log type changes
  useEffect(() => {
    setIsLoading(true)

    setTimeout(() => {
      let filtered = [...logs]

      if (logType !== "all") {
        filtered = filtered.filter((log) => log.type === logType)
      }

      if (searchTerm) {
        filtered = filtered.filter(
          (log) =>
            log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.user?.toLowerCase().includes(searchTerm.toLowerCase()),
        )
      }

      // Sort by timestamp (newest first)
      filtered.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

      setFilteredLogs(filtered)
      setIsLoading(false)
    }, 300)
  }, [logs, searchTerm, logType])

  const handleClearLogs = () => {
    clearLogs()
    setIsDeleteDialogOpen(false)
    toast({
      title: "הלוגים נמחקו בהצלחה",
      description: "כל הלוגים נמחקו מהמערכת",
    })
  }

  const handleExportLogs = () => {
    try {
      // Create CSV content
      const headers = ["תאריך", "סוג", "הודעה", "משתמש"]
      const csvContent = [
        headers.join(","),
        ...filteredLogs.map((log) =>
          [
            format(new Date(log.timestamp), "yyyy-MM-dd HH:mm:ss"),
            getLogTypeText(log.type),
            `"${log.message.replace(/"/g, '""')}"`,
            log.user || "",
          ].join(","),
        ),
      ].join("\n")

      // Create blob and download link
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.setAttribute("href", url)
      link.setAttribute("download", `logs_${format(new Date(), "yyyy-MM-dd")}.csv`)
      link.style.visibility = "hidden"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toast({
        title: "הלוגים יוצאו בהצלחה",
        description: "קובץ CSV עם הלוגים הורד למחשב שלך",
      })
    } catch (error) {
      console.error("Error exporting logs:", error)
      toast({
        title: "שגיאה בייצוא הלוגים",
        description: "אירעה שגיאה בייצוא הלוגים. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
        <h1 className="text-2xl font-bold">לוגים ופעילות מערכת</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setFilteredLogs([...logs])}>
            <RefreshCw className="mr-2 h-4 w-4" /> רענון
          </Button>
          <Button variant="outline" onClick={handleExportLogs}>
            <Download className="mr-2 h-4 w-4" /> ייצוא לוגים
          </Button>
          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogTrigger asChild>
              <Button variant="outline" className="text-red-500 border-red-200 hover:bg-red-50" onClick={() => console.log("TODO: Add functionality")}>
                <Trash className="mr-2 h-4 w-4" /> ניקוי לוגים
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>ניקוי לוגים</AlertDialogTitle>
                <AlertDialogDescription>
                  האם את בטוחה שברצונך למחוק את כל הלוגים? פעולה זו אינה ניתנת לביטול.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>ביטול</AlertDialogCancel>
                <AlertDialogAction onClick={handleClearLogs} className="bg-red-500 hover:bg-red-600">
                  מחיקת לוגים
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>סינון לוגים</CardTitle>
          <CardDescription>סנן את הלוגים לפי סוג או חיפוש טקסט חופשי</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="חיפוש בלוגים..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="w-full sm:w-48">
              <Select value={logType} onValueChange={setLogType}>
                <SelectTrigger>
                  <SelectValue placeholder="סוג לוג" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">הכל</SelectItem>
                  <SelectItem value="system">מערכת</SelectItem>
                  <SelectItem value="user">משתמש</SelectItem>
                  <SelectItem value="appointment">תורים</SelectItem>
                  <SelectItem value="order">הזמנות</SelectItem>
                  <SelectItem value="error">שגיאות</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>לוגים אחרונים</CardTitle>
          <CardDescription>
            {filteredLogs.length} לוגים מוצגים מתוך {logs.length} סה"כ
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-solid border-pink-500 border-r-transparent"></div>
              <p className="mt-2 text-gray-500">טוען לוגים...</p>
            </div>
          ) : filteredLogs.length > 0 ? (
            <div className="space-y-2">
              {filteredLogs.map((log, index) => (
                <div key={index} className={`p-3 rounded-md ${getLogTypeStyle(log.type)}`}>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">
                      {format(new Date(log.timestamp), "dd/MM/yyyy HH:mm:ss")}
                    </span>
                    <span className={`text-xs px-2 py-1 rounded-full ${getLogTypeBadgeStyle(log.type)}`}>
                      {getLogTypeText(log.type)}
                    </span>
                  </div>
                  <p className="mt-1">{log.message}</p>
                  {log.user && <p className="text-xs text-gray-500 mt-1">משתמש: {log.user}</p>}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">לא נמצאו לוגים התואמים את החיפוש</div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// פונקציות עזר לעיצוב הלוגים
function getLogTypeStyle(type) {
  switch (type) {
    case "error":
      return "bg-red-50"
    case "system":
      return "bg-blue-50"
    case "user":
      return "bg-green-50"
    case "appointment":
      return "bg-purple-50"
    case "order":
      return "bg-yellow-50"
    default:
      return "bg-gray-50"
  }
}

function getLogTypeBadgeStyle(type) {
  switch (type) {
    case "error":
      return "bg-red-100 text-red-800"
    case "system":
      return "bg-blue-100 text-blue-800"
    case "user":
      return "bg-green-100 text-green-800"
    case "appointment":
      return "bg-purple-100 text-purple-800"
    case "order":
      return "bg-yellow-100 text-yellow-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

function getLogTypeText(type) {
  switch (type) {
    case "error":
      return "שגיאה"
    case "system":
      return "מערכת"
    case "user":
      return "משתמש"
    case "appointment":
      return "תור"
    case "order":
      return "הזמנה"
    default:
      return type
  }
}
