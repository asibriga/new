"use client"

import { useState } from "react"
import { useStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { Search, UserPlus, Edit, Trash2, Filter, Download, CheckCircle, XCircle } from "lucide-react"

export default function UsersPage() {
  const { toast } = useToast()
  const customers = useStore((state) => state.customers)
  const addCustomer = useStore((state) => state.addCustomer)
  const updateCustomer = useStore((state) => state.updateCustomer)
  const deleteCustomer = useStore((state) => state.deleteCustomer)
  const appointments = useStore((state) => state.appointments)
  const orders = useStore((state) => state.orders)

  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null)
  const [newCustomer, setNewCustomer] = useState({
    name: "",
    phone: "",
    email: "",
    status: "new",
    isRegistered: false,
    password: "",
    loyaltyPoints: 0,
  })

  // Filter customers based on search term and status filter
  const filteredCustomers = customers.filter((customer) => {
    const matchesSearch =
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.phone.includes(searchTerm) ||
      (customer.email && customer.email.toLowerCase().includes(searchTerm.toLowerCase()))

    if (statusFilter === "all") return matchesSearch
    return matchesSearch && customer.status === statusFilter
  })

  // Handle adding a new customer
  const handleAddCustomer = () => {
    if (!newCustomer.name || !newCustomer.phone) {
      toast({
        title: "שגיאה",
        description: "שם וטלפון הם שדות חובה",
        variant: "destructive",
      })
      return
    }

    // Check if phone number already exists
    const phoneExists = customers.some((c) => c.phone === newCustomer.phone)
    if (phoneExists) {
      toast({
        title: "שגיאה",
        description: "מספר טלפון זה כבר קיים במערכת",
        variant: "destructive",
      })
      return
    }

    // Add customer
    const customerId = addCustomer(newCustomer)

    toast({
      title: "לקוח נוסף בהצלחה",
      description: `${newCustomer.name} נוסף למערכת`,
    })

    // Reset form and close dialog
    setNewCustomer({
      name: "",
      phone: "",
      email: "",
      status: "new",
      isRegistered: false,
      password: "",
      loyaltyPoints: 0,
    })
    setIsAddDialogOpen(false)
  }

  // Handle updating a customer
  const handleUpdateCustomer = () => {
    if (!selectedCustomer || !selectedCustomer.name || !selectedCustomer.phone) {
      toast({
        title: "שגיאה",
        description: "שם וטלפון הם שדות חובה",
        variant: "destructive",
      })
      return
    }

    // Check if phone number already exists (excluding the current customer)
    const phoneExists = customers.some((c) => c.phone === selectedCustomer.phone && c.id !== selectedCustomer.id)
    if (phoneExists) {
      toast({
        title: "שגיאה",
        description: "מספר טלפון זה כבר קיים במערכת",
        variant: "destructive",
      })
      return
    }

    // Update customer
    updateCustomer(selectedCustomer.id, selectedCustomer)

    toast({
      title: "לקוח עודכן בהצלחה",
      description: `${selectedCustomer.name} עודכן במערכת`,
    })

    // Close dialog
    setIsEditDialogOpen(false)
  }

  // Handle deleting a customer
  const handleDeleteCustomer = () => {
    if (!selectedCustomer) return

    // Check if customer has appointments or orders
    const hasAppointments = appointments.some((a) => a.customerId === selectedCustomer.id)
    const hasOrders = orders.some((o) => o.customerId === selectedCustomer.id)

    if (hasAppointments || hasOrders) {
      toast({
        title: "לא ניתן למחוק",
        description: "לא ניתן למחוק לקוח עם תורים או הזמנות. יש לבטל אותם תחילה.",
        variant: "destructive",
      })
      setIsDeleteDialogOpen(false)
      return
    }

    // Delete customer
    deleteCustomer(selectedCustomer.id)

    toast({
      title: "לקוח נמחק בהצלחה",
      description: `${selectedCustomer.name} נמחק מהמערכת`,
    })

    // Close dialog
    setIsDeleteDialogOpen(false)
  }

  // Get customer status badge
  const getStatusBadge = (status) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">פעיל</Badge>
      case "inactive":
        return <Badge className="bg-gray-500">לא פעיל</Badge>
      case "new":
        return <Badge className="bg-blue-500">חדש</Badge>
      case "needs_followup":
        return <Badge className="bg-yellow-500">דורש מעקב</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  // Export customers to CSV
  const exportCustomersToCSV = () => {
    const headers = ["שם", "טלפון", "אימייל", "סטטוס", "נקודות נאמנות", "ביקורים", "רשום"]
    const csvContent = [
      headers.join(","),
      ...filteredCustomers.map((customer) =>
        [
          customer.name,
          customer.phone,
          customer.email || "",
          customer.status,
          customer.loyaltyPoints || 0,
          customer.visits || 0,
          customer.isRegistered ? "כן" : "לא",
        ].join(","),
      ),
    ].join("\n")

    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "customers.csv"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "ייצוא הושלם",
      description: "רשימת הלקוחות יוצאה בהצלחה",
    })
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">ניהול משתמשים</h1>
        <Button className="bg-pink-500 hover:bg-pink-600" onClick={() => setIsAddDialogOpen(true)}>
          <UserPlus className="mr-2 h-4 w-4" />
          הוספת לקוח חדש
        </Button>
      </div>

      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
              <Input
                placeholder="חיפוש לפי שם, טלפון או אימייל"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="w-full md:w-64">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <div className="flex items-center">
                    <Filter className="mr-2 h-4 w-4" />
                    <span>סינון לפי סטטוס</span>
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">כל הלקוחות</SelectItem>
                  <SelectItem value="active">פעילים</SelectItem>
                  <SelectItem value="inactive">לא פעילים</SelectItem>
                  <SelectItem value="new">חדשים</SelectItem>
                  <SelectItem value="needs_followup">דורשים מעקב</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button variant="outline" onClick={exportCustomersToCSV}>
              <Download className="mr-2 h-4 w-4" />
              ייצוא לקוחות
            </Button>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>שם</TableHead>
                  <TableHead>טלפון</TableHead>
                  <TableHead>אימייל</TableHead>
                  <TableHead>סטטוס</TableHead>
                  <TableHead>נקודות נאמנות</TableHead>
                  <TableHead>ביקורים</TableHead>
                  <TableHead>רשום</TableHead>
                  <TableHead>פעולות</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCustomers.length > 0 ? (
                  filteredCustomers.map((customer) => (
                    <TableRow key={customer.id}>
                      <TableCell className="font-medium">{customer.name}</TableCell>
                      <TableCell>{customer.phone}</TableCell>
                      <TableCell>{customer.email || "-"}</TableCell>
                      <TableCell>{getStatusBadge(customer.status)}</TableCell>
                      <TableCell>{customer.loyaltyPoints || 0}</TableCell>
                      <TableCell>{customer.visits || 0}</TableCell>
                      <TableCell>
                        {customer.isRegistered ? (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        ) : (
                          <XCircle className="h-5 w-5 text-gray-300" />
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2 rtl:space-x-reverse">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedCustomer(customer)
                              setIsEditDialogOpen(true)
                            }}
                          >
                            <Edit className="h-4 w-4 text-blue-500" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedCustomer(customer)
                              setIsDeleteDialogOpen(true)
                            }}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-4">
                      לא נמצאו לקוחות
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Add Customer Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>הוספת לקוח חדש</DialogTitle>
            <DialogDescription>הזן את פרטי הלקוח החדש</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">שם מלא</Label>
              <Input
                id="name"
                value={newCustomer.name}
                onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                placeholder="הכנס שם מלא"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">טלפון</Label>
              <Input
                id="phone"
                value={newCustomer.phone}
                onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                placeholder="הכנס מספר טלפון"
                type="tel"
                inputMode="numeric"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">אימייל (אופציונלי)</Label>
              <Input
                id="email"
                value={newCustomer.email}
                onChange={(e) => setNewCustomer({ ...newCustomer, email: e.target.value })}
                placeholder="הכנס כתובת אימייל"
                type="email"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">סטטוס</Label>
              <Select
                value={newCustomer.status}
                onValueChange={(value) => setNewCustomer({ ...newCustomer, status: value })}
              >
                <SelectTrigger id="status">
                  <SelectValue placeholder="בחר סטטוס" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">פעיל</SelectItem>
                  <SelectItem value="inactive">לא פעיל</SelectItem>
                  <SelectItem value="new">חדש</SelectItem>
                  <SelectItem value="needs_followup">דורש מעקב</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="loyaltyPoints">נקודות נאמנות</Label>
              <Input
                id="loyaltyPoints"
                value={newCustomer.loyaltyPoints}
                onChange={(e) =>
                  setNewCustomer({ ...newCustomer, loyaltyPoints: Number.parseInt(e.target.value) || 0 })
                }
                placeholder="הכנס נקודות נאמנות"
                type="number"
                min="0"
              />
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <input
                type="checkbox"
                id="isRegistered"
                checked={newCustomer.isRegistered}
                onChange={(e) => setNewCustomer({ ...newCustomer, isRegistered: e.target.checked })}
                className="mr-2"
              />
              <Label htmlFor="isRegistered">משתמש רשום</Label>
            </div>
            {newCustomer.isRegistered && (
              <div className="space-y-2">
                <Label htmlFor="password">סיסמה</Label>
                <Input
                  id="password"
                  value={newCustomer.password}
                  onChange={(e) => setNewCustomer({ ...newCustomer, password: e.target.value })}
                  placeholder="הכנס סיסמה"
                  type="password"
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              ביטול
            </Button>
            <Button className="bg-pink-500 hover:bg-pink-600" onClick={handleAddCustomer}>
              הוספת לקוח
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Customer Dialog */}
      {selectedCustomer && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>עריכת לקוח</DialogTitle>
              <DialogDescription>ערוך את פרטי הלקוח</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">שם מלא</Label>
                <Input
                  id="edit-name"
                  value={selectedCustomer.name}
                  onChange={(e) => setSelectedCustomer({ ...selectedCustomer, name: e.target.value })}
                  placeholder="הכנס שם מלא"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-phone">טלפון</Label>
                <Input
                  id="edit-phone"
                  value={selectedCustomer.phone}
                  onChange={(e) => setSelectedCustomer({ ...selectedCustomer, phone: e.target.value })}
                  placeholder="הכנס מספר טלפון"
                  type="tel"
                  inputMode="numeric"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-email">אימייל (אופציונלי)</Label>
                <Input
                  id="edit-email"
                  value={selectedCustomer.email || ""}
                  onChange={(e) => setSelectedCustomer({ ...selectedCustomer, email: e.target.value })}
                  placeholder="הכנס כתובת אימייל"
                  type="email"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-status">סטטוס</Label>
                <Select
                  value={selectedCustomer.status}
                  onValueChange={(value) => setSelectedCustomer({ ...selectedCustomer, status: value })}
                >
                  <SelectTrigger id="edit-status">
                    <SelectValue placeholder="בחר סטטוס" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">פעיל</SelectItem>
                    <SelectItem value="inactive">לא פעיל</SelectItem>
                    <SelectItem value="new">חדש</SelectItem>
                    <SelectItem value="needs_followup">דורש מעקב</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-loyaltyPoints">נקודות נאמנות</Label>
                <Input
                  id="edit-loyaltyPoints"
                  value={selectedCustomer.loyaltyPoints || 0}
                  onChange={(e) =>
                    setSelectedCustomer({ ...selectedCustomer, loyaltyPoints: Number.parseInt(e.target.value) || 0 })
                  }
                  placeholder="הכנס נקודות נאמנות"
                  type="number"
                  min="0"
                />
              </div>
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <input
                  type="checkbox"
                  id="edit-isRegistered"
                  checked={selectedCustomer.isRegistered || false}
                  onChange={(e) => setSelectedCustomer({ ...selectedCustomer, isRegistered: e.target.checked })}
                  className="mr-2"
                />
                <Label htmlFor="edit-isRegistered">משתמש רשום</Label>
              </div>
              {selectedCustomer.isRegistered && (
                <div className="space-y-2">
                  <Label htmlFor="edit-password">סיסמה (השאר ריק לשמירת הסיסמה הקיימת)</Label>
                  <Input
                    id="edit-password"
                    value={selectedCustomer.newPassword || ""}
                    onChange={(e) => setSelectedCustomer({ ...selectedCustomer, newPassword: e.target.value })}
                    placeholder="הכנס סיסמה חדשה"
                    type="password"
                  />
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                ביטול
              </Button>
              <Button className="bg-pink-500 hover:bg-pink-600" onClick={handleUpdateCustomer}>
                עדכון לקוח
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Delete Customer Dialog */}
      {selectedCustomer && (
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>מחיקת לקוח</DialogTitle>
              <DialogDescription>האם אתה בטוח שברצונך למחוק את הלקוח {selectedCustomer.name}?</DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <p className="text-red-500">
                פעולה זו אינה ניתנת לביטול. לא ניתן למחוק לקוחות עם תורים או הזמנות פעילים.
              </p>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                ביטול
              </Button>
              <Button variant="destructive" onClick={handleDeleteCustomer}>
                מחיקת לקוח
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
