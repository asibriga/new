"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DateRangePicker } from "@/components/admin/date-range-picker"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts"
import { useStore } from "@/lib/store"
import { subDays, parseISO, isWithinInterval } from "date-fns"
import { Award } from "lucide-react"

export default function AnalyticsPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date }>({
    from: subDays(new Date(), 30),
    to: new Date(),
  })

  const appointments = useStore((state) => state.appointments)
  const customers = useStore((state) => state.customers)
  const analytics = useStore((state) => state.analytics)
  const services = useStore((state) => state.services)
  const transactions = useStore((state) => state.transactions)

  // Get loyalty data
  const loyaltySettings = useStore((state) => state.loyaltySettings)
  const loyaltyTiers = useStore((state) => state.loyaltyTiers)
  const loyaltyRewards = useStore((state) => state.loyaltyRewards)
  const coupons = useStore((state) => state.coupons || [])

  // Calculate coupon usage
  const couponUsage = coupons.reduce((acc, coupon) => {
    if (coupon.usageCount > 0) {
      acc.push({
        name: coupon.code,
        value: coupon.usageCount,
      })
    }
    return acc
  }, [])

  // Calculate loyalty points distribution
  const loyaltyPointsDistribution = customers.reduce((acc, customer) => {
    const points = customer.loyaltyPoints || 0
    const tier = loyaltyTiers
      .sort((a, b) => a.pointsRequired - b.pointsRequired)
      .find((tier) => points >= tier.pointsRequired)

    if (tier) {
      const existingTier = acc.find((t) => t.name === tier.name)
      if (existingTier) {
        existingTier.value += 1
      } else {
        acc.push({ name: tier.name, value: 1 })
      }
    }

    return acc
  }, [])

  // Calculate reward redemptions
  const rewardRedemptions = loyaltyRewards.map((reward) => {
    // This is a placeholder - in a real app, you'd track redemptions
    const randomRedemptions = Math.floor(Math.random() * 10)
    return {
      name: reward.name,
      value: randomRedemptions,
    }
  })

  // Generate data for charts
  const pageViewsData = Object.entries(analytics.pageViews || {}).map(([page, views]) => {
    const pageName = page === "/" ? "דף הבית" : page.replace("/", "")
    return { name: pageName, views }
  })

  const referrersData = Object.entries(analytics.referrers || {}).map(([source, count]) => {
    return { name: source, value: count }
  })

  // Filter data by date range
  const filteredAppointments = appointments.filter((appointment) => {
    const appointmentDate = parseISO(appointment.date)
    return isWithinInterval(appointmentDate, { start: dateRange.from, end: dateRange.to })
  })

  const filteredCustomers = customers.filter((customer) => {
    if (!customer.createdAt) return false
    const createdDate = parseISO(customer.createdAt)
    return isWithinInterval(createdDate, { start: dateRange.from, end: dateRange.to })
  })

  const filteredTransactions = transactions.filter((transaction) => {
    const transactionDate = parseISO(transaction.date)
    return isWithinInterval(transactionDate, { start: dateRange.from, end: dateRange.to })
  })

  // Calculate service popularity
  const servicePopularity = filteredAppointments.reduce((acc, appointment) => {
    const service = services.find((s) => s.id === appointment.serviceId)
    if (service) {
      const existingItem = acc.find((i) => i.name === service.name)
      if (existingItem) {
        existingItem.count += 1
      } else {
        acc.push({ name: service.name, count: 1 })
      }
    }
    return acc
  }, [])

  // Calculate monthly activity
  const monthlyActivity = (() => {
    const months = [
      "ינואר",
      "פברואר",
      "מרץ",
      "אפריל",
      "מאי",
      "יוני",
      "יולי",
      "אוגוסט",
      "ספטמבר",
      "אוקטובר",
      "נובמבר",
      "דצמבר",
    ]

    const data = months.map((month) => ({ name: month, תורים: 0, "לקוחות חדשים": 0, הכנסות: 0 }))

    // Add appointments data
    filteredAppointments.forEach((appointment) => {
      if (!appointment.date) return
      const date = parseISO(appointment.date)
      if (!date || isNaN(date.getTime())) return
      const monthIndex = date.getMonth()
      data[monthIndex].תורים += 1

      // Add appointment revenue if it's confirmed or completed
      if (appointment.status === "confirmed" || appointment.status === "completed") {
        data[monthIndex].הכנסות += appointment.price || 0
      }
    })

    // Add customers data
    filteredCustomers.forEach((customer) => {
      if (!customer.createdAt) return
      const date = parseISO(customer.createdAt)
      if (!date || isNaN(date.getTime())) return
      const monthIndex = date.getMonth()
      data[monthIndex]["לקוחות חדשים"] += 1
    })

    // Add income data from transactions
    filteredTransactions.forEach((transaction) => {
      if (transaction.type !== "income") return
      if (!transaction.date) return
      const date = parseISO(transaction.date)
      if (!date || isNaN(date.getTime())) return
      const monthIndex = date.getMonth()
      data[monthIndex].הכנסות += transaction.amount || 0
    })

    // Add order data
    const orders = useStore.getState().orders
    const filteredOrders = orders.filter((order) => {
      const orderDate = parseISO(order.date)
      return isWithinInterval(orderDate, { start: dateRange.from, end: dateRange.to })
    })

    filteredOrders.forEach((order) => {
      if (order.status === "paid" || order.status === "completed") {
        if (!order.date) return
        const date = parseISO(order.date)
        if (!date || isNaN(date.getTime())) return
        const monthIndex = date.getMonth()
        data[monthIndex].הכנסות += order.total || 0
      }
    })

    return data
  })()

  // Colors for charts
  const COLORS = ["#ec4899", "#8b5cf6", "#3b82f6", "#10b981", "#f59e0b", "#ef4444"]

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
        <h1 className="text-2xl font-bold">אנליטיקה וסטטיסטיקות</h1>
        <DateRangePicker dateRange={dateRange} onDateRangeChange={setDateRange} />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="overview">סקירה כללית</TabsTrigger>
          <TabsTrigger value="customers">לקוחות</TabsTrigger>
          <TabsTrigger value="services">שירותים</TabsTrigger>
          <TabsTrigger value="loyalty" className="flex items-center">
            <Award className="h-4 w-4 ml-2" />
            נאמנות וקופונים
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>צפיות בדפים</CardTitle>
                <CardDescription>מספר הצפיות בכל דף באתר</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={pageViewsData.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="views" fill="#ec4899" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>פעילות חודשית</CardTitle>
                <CardDescription>תורים, לקוחות חדשים והכנסות לפי חודש</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={monthlyActivity}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis yAxisId="left" />
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Line yAxisId="left" type="monotone" dataKey="תורים" stroke="#ec4899" activeDot={{ r: 8 }} />
                      <Line yAxisId="left" type="monotone" dataKey="לקוחות חדשים" stroke="#3b82f6" />
                      <Line yAxisId="right" type="monotone" dataKey="הכנסות" stroke="#10b981" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>סיכום נתונים</CardTitle>
              <CardDescription>נתונים מרכזיים לתקופה הנבחרת</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-pink-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-pink-800">סה"כ תורים</h3>
                  <p className="text-2xl font-bold text-pink-600">{filteredAppointments.length || 0}</p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-blue-800">לקוחות חדשים</h3>
                  <p className="text-2xl font-bold text-blue-600">{filteredCustomers.length || 0}</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-green-800">הכנסות</h3>
                  <p className="text-2xl font-bold text-green-600">
                    ₪
                    {filteredTransactions
                      .filter((t) => t.type === "income")
                      .reduce((sum, t) => sum + (t.amount || 0), 0) || 0}
                  </p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-purple-800">שירות פופולרי</h3>
                  <p className="text-2xl font-bold text-purple-600">
                    {servicePopularity.sort((a, b) => b.count - a.count)[0]?.name || "אין נתונים"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customers" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>לקוחות חדשים לאורך זמן</CardTitle>
                <CardDescription>מספר הלקוחות החדשים לפי חודש</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyActivity}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="לקוחות חדשים" fill="#3b82f6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>סטטוס לקוחות</CardTitle>
                <CardDescription>התפלגות הלקוחות לפי סטטוס</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: "פעילים", value: customers.filter((c) => c.status === "active").length },
                          { name: "לא פעילים", value: customers.filter((c) => c.status === "inactive").length },
                          { name: "חדשים", value: customers.filter((c) => c.status === "new").length },
                          { name: "דורשים מענה", value: customers.filter((c) => c.status === "needs_followup").length },
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {[
                          { name: "פעילים", value: customers.filter((c) => c.status === "active").length },
                          { name: "לא פעילים", value: customers.filter((c) => c.status === "inactive").length },
                          { name: "חדשים", value: customers.filter((c) => c.status === "new").length },
                          { name: "דורשים מענה", value: customers.filter((c) => c.status === "needs_followup").length },
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>נתוני לקוחות</CardTitle>
              <CardDescription>סיכום נתוני לקוחות</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-blue-800">סה"כ לקוחות</h3>
                  <p className="text-2xl font-bold text-blue-600">{customers.length}</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-green-800">לקוחות פעילים</h3>
                  <p className="text-2xl font-bold text-green-600">
                    {customers.filter((c) => c.status === "active").length}
                  </p>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-yellow-800">רשומים לניוזלטר</h3>
                  <p className="text-2xl font-bold text-yellow-600">
                    {customers.filter((c) => c.isSubscribedToNewsletter).length}
                  </p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-red-800">דורשים מענה</h3>
                  <p className="text-2xl font-bold text-red-600">
                    {customers.filter((c) => c.status === "needs_followup").length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="services" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>פופולריות שירותים</CardTitle>
                <CardDescription>מספר התורים לפי שירות</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={servicePopularity}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count" fill="#ec4899" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>הכנסות לפי שירות</CardTitle>
                <CardDescription>סך ההכנסות מכל שירות</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={services
                          .map((service) => {
                            const serviceAppointments = filteredAppointments.filter(
                              (a) => a.serviceId === service.id && a.status === "completed",
                            )
                            const totalIncome = serviceAppointments.reduce((sum, a) => sum + a.price, 0)
                            return { name: service.name, value: totalIncome }
                          })
                          .filter((item) => item.value > 0)}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {services.map((service, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `₪${value}`} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>נתוני שירותים</CardTitle>
              <CardDescription>סיכום נתוני שירותים</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-pink-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-pink-800">סה"כ שירותים</h3>
                  <p className="text-2xl font-bold text-pink-600">{services.length}</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-purple-800">שירות פופולרי</h3>
                  <p className="text-2xl font-bold text-purple-600">
                    {servicePopularity.sort((a, b) => b.count - a.count)[0]?.name || "אין נתונים"}
                  </p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-blue-800">זמן טיפול ממוצע</h3>
                  <p className="text-2xl font-bold text-blue-600">
                    {Math.round(services.reduce((sum, s) => sum + s.duration, 0) / services.length)} דקות
                  </p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-green-800">הכנסות מטיפולים</h3>
                  <p className="text-2xl font-bold text-green-600">
                    ₪
                    {filteredTransactions
                      .filter((t) => t.type === "income" && t.category === "service")
                      .reduce((sum, t) => sum + t.amount, 0)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="loyalty" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>התפלגות נקודות נאמנות</CardTitle>
                <CardDescription>התפלגות הלקוחות לפי דרגות נאמנות</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={loyaltyPointsDistribution}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {loyaltyPointsDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>שימוש בקופונים</CardTitle>
                <CardDescription>מספר השימושים בכל קופון</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={couponUsage}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="value" fill="#ec4899" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>סיכום נתוני נאמנות</CardTitle>
              <CardDescription>נתונים מרכזיים על תוכנית הנאמנות</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-pink-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-pink-800">סה"כ נקודות שחולקו</h3>
                  <p className="text-2xl font-bold text-pink-600">
                    {customers.reduce((sum, c) => sum + (c.loyaltyPoints || 0), 0) || 0}
                  </p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-purple-800">מספר הטבות שמומשו</h3>
                  <p className="text-2xl font-bold text-purple-600">
                    {rewardRedemptions.reduce((sum, r) => sum + (r.value || 0), 0) || 0}
                  </p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-blue-800">קופונים שנוצלו</h3>
                  <p className="text-2xl font-bold text-blue-600">
                    {coupons.reduce((sum, c) => sum + (c.usageCount || 0), 0) || 0}
                  </p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-green-800">הטבה פופולרית</h3>
                  <p className="text-2xl font-bold text-green-600">
                    {rewardRedemptions.sort((a, b) => b.value - a.value)[0]?.name || "אין נתונים"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
