"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useStore } from "@/lib/store"
import { useToast } from "@/hooks/use-toast"
import { Upload, FileText, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function CustomerImport({ onClose }) {
  const { toast } = useToast()
  const addCustomer = useStore((state) => state.addCustomer)
  const customers = useStore((state) => state.customers)

  const [file, setFile] = useState(null)
  const [fileName, setFileName] = useState("")
  const [previewData, setPreviewData] = useState([])
  const [importStatus, setImportStatus] = useState(null)
  const fileInputRef = useRef(null)

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0]
    if (!selectedFile) return

    setFile(selectedFile)
    setFileName(selectedFile.name)

    // קריאת הקובץ לתצוגה מקדימה
    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const content = event.target.result

        // בדיקה אם הקובץ הוא CSV
        if (selectedFile.name.endsWith(".csv")) {
          const lines = content.split("\n")
          if (lines.length > 0) {
            const headers = lines[0].split(",")
            const previewRows = []

            // הצגת עד 5 שורות לתצוגה מקדימה
            for (let i = 1; i < Math.min(lines.length, 6); i++) {
              if (lines[i].trim()) {
                const values = lines[i].split(",")
                const row = {}
                headers.forEach((header, index) => {
                  row[header.trim()] = values[index] ? values[index].trim() : ""
                })
                previewRows.push(row)
              }
            }

            setPreviewData(previewRows)
            setImportStatus({ type: "success", message: `נמצאו ${lines.length - 1} רשומות בקובץ` })
          }
        }
        // בדיקה אם הקובץ הוא JSON
        else if (selectedFile.name.endsWith(".json")) {
          const jsonData = JSON.parse(content)
          if (Array.isArray(jsonData)) {
            setPreviewData(jsonData.slice(0, 5))
            setImportStatus({ type: "success", message: `נמצאו ${jsonData.length} רשומות בקובץ` })
          } else {
            setImportStatus({ type: "error", message: "הקובץ אינו מכיל מערך של לקוחות" })
          }
        } else {
          setImportStatus({ type: "error", message: "פורמט קובץ לא נתמך. יש להשתמש ב-CSV או JSON" })
        }
      } catch (error) {
        console.error("Error parsing file:", error)
        setImportStatus({ type: "error", message: "שגיאה בקריאת הקובץ. וודא שהקובץ תקין" })
      }
    }
    reader.readAsText(selectedFile)
  }

  const handleImport = () => {
    if (!file) {
      toast({
        title: "שגיאה",
        description: "יש לבחור קובץ לייבוא",
        variant: "destructive",
      })
      return
    }

    try {
      const reader = new FileReader()
      reader.onload = (event) => {
        try {
          let customersToImport = []

          // טיפול בקובץ CSV
          if (file.name.endsWith(".csv")) {
            const content = event.target.result
            const lines = content.split("\n")
            const headers = lines[0].split(",").map((h) => h.trim())

            // מיפוי כותרות לשדות
            const nameIndex = headers.findIndex((h) => h === "שם" || h.toLowerCase() === "name")
            const phoneIndex = headers.findIndex((h) => h === "טלפון" || h.toLowerCase() === "phone")
            const emailIndex = headers.findIndex((h) => h === "אימייל" || h.toLowerCase() === "email")
            const statusIndex = headers.findIndex((h) => h === "סטטוס" || h.toLowerCase() === "status")
            const loyaltyPointsIndex = headers.findIndex(
              (h) => h === "נקודות נאמנות" || h.toLowerCase() === "loyaltypoints",
            )
            const visitsIndex = headers.findIndex((h) => h === "ביקורים" || h.toLowerCase() === "visits")
            const isRegisteredIndex = headers.findIndex((h) => h === "רשום" || h.toLowerCase() === "isregistered")
            const notesIndex = headers.findIndex((h) => h === "הערות" || h.toLowerCase() === "notes")

            // יצירת אובייקטים של לקוחות
            for (let i = 1; i < lines.length; i++) {
              if (!lines[i].trim()) continue

              const values = lines[i].split(",")

              // וידוא שיש שם וטלפון
              if (nameIndex >= 0 && phoneIndex >= 0 && values[nameIndex] && values[phoneIndex]) {
                const customer = {
                  name: values[nameIndex].trim().replace(/^"|"$/g, ""),
                  phone: values[phoneIndex].trim().replace(/^"|"$/g, ""),
                  email: emailIndex >= 0 && values[emailIndex] ? values[emailIndex].trim().replace(/^"|"$/g, "") : "",
                  status:
                    statusIndex >= 0 && values[statusIndex] ? values[statusIndex].trim().replace(/^"|"$/g, "") : "new",
                  loyaltyPoints:
                    loyaltyPointsIndex >= 0 && values[loyaltyPointsIndex]
                      ? Number.parseInt(values[loyaltyPointsIndex])
                      : 0,
                  visits: visitsIndex >= 0 && values[visitsIndex] ? Number.parseInt(values[visitsIndex]) : 0,
                  isRegistered:
                    isRegisteredIndex >= 0 && values[isRegisteredIndex]
                      ? values[isRegisteredIndex].trim().toLowerCase() === "true" ||
                        values[isRegisteredIndex].trim() === "כן" ||
                        values[isRegisteredIndex].trim() === "1"
                      : false,
                  notes: notesIndex >= 0 && values[notesIndex] ? values[notesIndex].trim().replace(/^"|"$/g, "") : "",
                }
                customersToImport.push(customer)
              }
            }
          }
          // טיפול בקובץ JSON
          else if (file.name.endsWith(".json")) {
            const jsonData = JSON.parse(event.target.result)
            if (Array.isArray(jsonData)) {
              customersToImport = jsonData.filter((customer) => customer.name && customer.phone)
            }
          }

          // בדיקה שיש לקוחות לייבוא
          if (customersToImport.length === 0) {
            toast({
              title: "שגיאה",
              description: "לא נמצאו לקוחות תקינים בקובץ",
              variant: "destructive",
            })
            return
          }

          // בדיקת לקוחות כפולים
          const existingPhones = customers.map((c) => c.phone)
          const newCustomers = customersToImport.filter((c) => !existingPhones.includes(c.phone))
          const duplicates = customersToImport.length - newCustomers.length

          // הוספת הלקוחות החדשים
          newCustomers.forEach((customer) => {
            addCustomer(customer)
          })

          toast({
            title: "ייבוא הושלם",
            description: `יובאו ${newCustomers.length} לקוחות חדשים${duplicates > 0 ? `, ${duplicates} לקוחות כפולים לא יובאו` : ""}`,
          })

          if (onClose) onClose()
        } catch (error) {
          console.error("Error importing customers:", error)
          toast({
            title: "שגיאה בייבוא",
            description: "אירעה שגיאה בעת ייבוא הלקוחות",
            variant: "destructive",
          })
        }
      }
      reader.readAsText(file)
    } catch (error) {
      console.error("Error reading file:", error)
      toast({
        title: "שגיאה בקריאת הקובץ",
        description: "אירעה שגיאה בעת קריאת הקובץ",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <h3 className="text-lg font-medium">ייבוא לקוחות</h3>
        <p className="text-sm text-muted-foreground">העלה קובץ CSV או JSON עם רשימת לקוחות</p>
      </div>

      <div className="space-y-4">
        <div className="grid w-full max-w-sm items-center gap-1.5">
          <Label htmlFor="file">בחר קובץ</Label>
          <div className="flex gap-2">
            <Input
              ref={fileInputRef}
              id="file"
              type="file"
              accept=".csv,.json"
              className="hidden"
              onChange={handleFileChange}
            />
            <Button variant="outline" onClick={() => fileInputRef.current?.click()} className="w-full">
              <Upload className="mr-2 h-4 w-4" />
              בחר קובץ
            </Button>
          </div>
          {fileName && (
            <p className="text-sm text-muted-foreground flex items-center mt-2">
              <FileText className="mr-2 h-4 w-4" />
              {fileName}
            </p>
          )}
        </div>

        {importStatus && (
          <Alert variant={importStatus.type === "error" ? "destructive" : "default"}>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{importStatus.message}</AlertDescription>
          </Alert>
        )}

        {previewData.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium">תצוגה מקדימה</h4>
            <div className="max-h-40 overflow-auto border rounded-md p-2">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    {Object.keys(previewData[0]).map((key) => (
                      <th key={key} className="p-2 text-right">
                        {key}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {previewData.map((row, index) => (
                    <tr key={index} className="border-b">
                      {Object.values(row).map((value, i) => (
                        <td key={i} className="p-2">
                          {value}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={onClose}>
          ביטול
        </Button>
        <Button onClick={handleImport} disabled={!file} className="bg-pink-500 hover:bg-pink-600">
          <Upload className="mr-2 h-4 w-4" />
          ייבוא לקוחות
        </Button>
      </div>
    </div>
  )
}
