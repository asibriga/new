"use client"

import { useState, useEffect } from "react"
import { useStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Search, UserPlus, Edit, Trash, Download, Upload, Phone, Mail, Calendar, Clock } from "lucide-react"
import { format } from "date-fns"
import CustomerExport from "./export"
import CustomerImport from "./import"

export default function CustomersPage() {
  const { toast } = useToast()
  const customers = useStore((state) => state.customers)
  const addCustomer = useStore((state) => state.addCustomer)
  const updateCustomer = useStore((state) => state.updateCustomer)
  const deleteCustomer = useStore((state) => state.deleteCustomer)
  const appointments = useStore((state) => state.appointments)

  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false)
  const [isExportDialogOpen, setIsExportDialogOpen] = useState(false)
  const [selectedCustomer, setSelectedCustomer] = useState(null)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    notes: "",
    status: "new",
    isRegistered: false,
    loyaltyPoints: 0,
  })
  const [isMobile, setIsMobile] = useState(false)
  const [viewMode, setViewMode] = useState("all")

  // Check if mobile
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)

    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  // Filter customers based on search and status
  const filteredCustomers = customers.filter((customer) => {
    // Search filter
    if (
      searchQuery &&
      !customer.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !customer.phone.includes(searchQuery) &&
      !(customer.email && customer.email.toLowerCase().includes(searchQuery.toLowerCase()))
    ) {
      return false
    }

    // Status filter
    if (statusFilter !== "all" && customer.status !== statusFilter) {
      return false
    }

    // View mode filter
    if (viewMode === "new" && customer.status !== "new") {
      return false
    }
    if (viewMode === "active" && customer.status !== "active") {
      return false
    }
    if (viewMode === "needs_followup" && customer.status !== "needs_followup") {
      return false
    }

    return true
  })

  // Handle form submission for adding a new customer
  const handleAddCustomer = () => {
    if (!formData.name || !formData.phone) {
      toast({
        title: "שגיאה",
        description: "יש למלא שם וטלפון",
        variant: "destructive",
      })
      return
    }

    addCustomer(formData)
    setIsAddDialogOpen(false)
    setFormData({
      name: "",
      phone: "",
      email: "",
      notes: "",
      status: "new",
      isRegistered: false,
      loyaltyPoints: 0,
    })

    toast({
      title: "לקוח נוסף",
      description: `${formData.name} נוסף בהצלחה`,
    })
  }

  // Handle form submission for editing a customer
  const handleEditCustomer = () => {
    if (!formData.name || !formData.phone) {
      toast({
        title: "שגיאה",
        description: "יש למלא שם וטלפון",
        variant: "destructive",
      })
      return
    }

    updateCustomer(selectedCustomer.id, formData)
    setIsEditDialogOpen(false)
    setSelectedCustomer(null)

    toast({
      title: "לקוח עודכן",
      description: `${formData.name} עודכן בהצלחה`,
    })
  }

  // Handle customer deletion
  const handleDeleteCustomer = () => {
    if (!selectedCustomer) return

    deleteCustomer(selectedCustomer.id)
    setIsDeleteDialogOpen(false)
    setSelectedCustomer(null)

    toast({
      title: "לקוח נמחק",
      description: `הלקוח נמחק בהצלחה`,
    })
  }

  // Open edit dialog and populate form data
  const handleEditClick = (customer) => {
    setSelectedCustomer(customer)
    setFormData({
      name: customer.name,
      phone: customer.phone,
      email: customer.email || "",
      notes: customer.notes || "",
      status: customer.status,
      isRegistered: customer.isRegistered || false,
      loyaltyPoints: customer.loyaltyPoints || 0,
    })
    setIsEditDialogOpen(true)
  }

  // Open delete dialog
  const handleDeleteClick = (customer) => {
    setSelectedCustomer(customer)
    setIsDeleteDialogOpen(true)
  }

  // Get customer appointments
  const getCustomerAppointments = (customerId) => {
    return appointments.filter((appointment) => appointment.customerId === customerId)
  }

  // Get status badge
  const getStatusBadge = (status) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">פעיל</Badge>
      case "inactive":
        return (
          <Badge variant="outline" className="text-gray-500 border-gray-300">
            לא פעיל
          </Badge>
        )
      case "new":
        return <Badge className="bg-blue-500">חדש</Badge>
      case "needs_followup":
        return (
          <Badge variant="outline" className="text-orange-500 border-orange-500">
            דורש מעקב
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <div className="container mx-auto p-4">
      <div className="flex flex-col space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">כל הלקוחות</h1>
            <p className="text-gray-500">צפייה וניהול של כל הלקוחות במערכת</p>
          </div>
          <div className="flex flex-wrap gap-2 w-full md:w-auto">
            <Button
              onClick={() => setIsAddDialogOpen(true)}
              className="bg-pink-500 hover:bg-pink-600 flex-1 md:flex-initial"
            >
              <UserPlus className="h-4 w-4 ml-2" />
              לקוח חדש
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setIsImportDialogOpen(true)
              }}
              className="flex-1 md:flex-initial"
            >
              <Upload className="h-4 w-4 ml-2" />
              ייבוא
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setIsExportDialogOpen(true)
              }}
              className="flex-1 md:flex-initial"
            >
              <Download className="h-4 w-4 ml-2" />
              ייצוא
            </Button>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="חיפוש לפי שם, טלפון או אימייל"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="סטטוס" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">הכל</SelectItem>
                <SelectItem value="active">פעיל</SelectItem>
                <SelectItem value="inactive">לא פעיל</SelectItem>
                <SelectItem value="new">חדש</SelectItem>
                <SelectItem value="needs_followup">דורש מעקב</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs defaultValue="all" onValueChange={setViewMode}>
          <TabsList className="mb-4">
            <TabsTrigger value="all">הכל</TabsTrigger>
            <TabsTrigger value="new">חדשים</TabsTrigger>
            <TabsTrigger value="active">פעילים</TabsTrigger>
            <TabsTrigger value="needs_followup">דורש מעקב</TabsTrigger>
          </TabsList>

          <TabsContent value={viewMode}>
            {isMobile ? (
              // Mobile view - cards
              <div className="space-y-4">
                {filteredCustomers.length > 0 ? (
                  filteredCustomers.map((customer) => (
                    <Card key={customer.id} className="overflow-hidden">
                      <CardContent className="p-0">
                        <div className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <h3 className="font-medium text-lg">{customer.name}</h3>
                            {getStatusBadge(customer.status)}
                          </div>

                          <div className="space-y-2 mt-3">
                            <div className="flex items-center text-sm text-gray-600">
                              <Phone className="h-4 w-4 mr-1" />
                              <span>{customer.phone}</span>
                            </div>

                            {customer.email && (
                              <div className="flex items-center text-sm text-gray-600">
                                <Mail className="h-4 w-4 mr-1" />
                                <span>{customer.email}</span>
                              </div>
                            )}

                            <div className="flex items-center text-sm text-gray-600">
                              <Calendar className="h-4 w-4 mr-1" />
                              <span>ביקורים: {customer.visits || 0}</span>
                            </div>

                            {customer.lastVisit && (
                              <div className="flex items-center text-sm text-gray-600">
                                <Clock className="h-4 w-4 mr-1" />
                                <span>ביקור אחרון: {format(new Date(customer.lastVisit), "dd/MM/yyyy")}</span>
                              </div>
                            )}
                          </div>

                          <div className="flex justify-end mt-3 gap-2">
                            <Button variant="outline" size="sm" onClick={() => handleEditClick(customer)}>
                              <Edit className="h-4 w-4 mr-1" />
                              עריכה
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-red-500"
                              onClick={() => handleDeleteClick(customer)}
                            >
                              <Trash className="h-4 w-4 mr-1" />
                              מחיקה
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-500">לא נמצאו לקוחות התואמים את החיפוש</div>
                )}
              </div>
            ) : (
              // Desktop view - table
              <div className="rounded-md border overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>שם</TableHead>
                      <TableHead>טלפון</TableHead>
                      <TableHead>אימייל</TableHead>
                      <TableHead>ביקורים</TableHead>
                      <TableHead>סטטוס</TableHead>
                      <TableHead className="text-left">פעולות</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCustomers.length > 0 ? (
                      filteredCustomers.map((customer) => (
                        <TableRow key={customer.id}>
                          <TableCell className="font-medium">{customer.name}</TableCell>
                          <TableCell>{customer.phone}</TableCell>
                          <TableCell>{customer.email || "-"}</TableCell>
                          <TableCell>{customer.visits || 0}</TableCell>
                          <TableCell>{getStatusBadge(customer.status)}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" onClick={() => handleEditClick(customer)}>
                                <Edit className="h-4 w-4 mr-1" />
                                עריכה
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-red-500"
                                onClick={() => handleDeleteClick(customer)}
                              >
                                <Trash className="h-4 w-4 mr-1" />
                                מחיקה
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                          לא נמצאו לקוחות התואמים את החיפוש
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Add Customer Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>הוספת לקוח חדש</DialogTitle>
            <DialogDescription>הוסף לקוח חדש למערכת</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">שם מלא</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="phone">טלפון</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">אימייל</Label>
              <Input
                id="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="status">סטטוס</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="בחר סטטוס" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">פעיל</SelectItem>
                  <SelectItem value="inactive">לא פעיל</SelectItem>
                  <SelectItem value="new">חדש</SelectItem>
                  <SelectItem value="needs_followup">דורש מעקב</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="notes">הערות</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              ביטול
            </Button>
            <Button onClick={handleAddCustomer} className="bg-pink-500 hover:bg-pink-600">
              הוספה
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Customer Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>עריכת לקוח</DialogTitle>
            <DialogDescription>עריכת פרטי הלקוח</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">שם מלא</Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-phone">טלפון</Label>
              <Input
                id="edit-phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-email">אימייל</Label>
              <Input
                id="edit-email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-status">סטטוס</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger id="edit-status">
                  <SelectValue placeholder="בחר סטטוס" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">פעיל</SelectItem>
                  <SelectItem value="inactive">לא פעיל</SelectItem>
                  <SelectItem value="new">חדש</SelectItem>
                  <SelectItem value="needs_followup">דורש מעקב</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-notes">הערות</Label>
              <Textarea
                id="edit-notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-loyalty">נקודות נאמנות</Label>
              <Input
                id="edit-loyalty"
                type="number"
                value={formData.loyaltyPoints}
                onChange={(e) => setFormData({ ...formData, loyaltyPoints: Number.parseInt(e.target.value) || 0 })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              ביטול
            </Button>
            <Button onClick={handleEditCustomer} className="bg-pink-500 hover:bg-pink-600">
              שמירה
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Customer Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>מחיקת לקוח</DialogTitle>
            <DialogDescription>האם אתה בטוח שברצונך למחוק את הלקוח {selectedCustomer?.name}?</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-red-500">פעולה זו אינה ניתנת לביטול.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              ביטול
            </Button>
            <Button variant="destructive" onClick={handleDeleteCustomer}>
              מחיקה
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Import Dialog */}
      <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>ייבוא לקוחות</DialogTitle>
            <DialogDescription>ייבוא לקוחות מקובץ CSV</DialogDescription>
          </DialogHeader>
          <CustomerImport onClose={() => setIsImportDialogOpen(false)} />
        </DialogContent>
      </Dialog>

      {/* Export Dialog */}
      <Dialog open={isExportDialogOpen} onOpenChange={setIsExportDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>ייצוא לקוחות</DialogTitle>
            <DialogDescription>ייצוא לקוחות לקובץ CSV</DialogDescription>
          </DialogHeader>
          <CustomerExport onClose={() => setIsExportDialogOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  )
}
