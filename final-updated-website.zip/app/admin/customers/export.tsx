"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { useStore } from "@/lib/store"
import { useToast } from "@/hooks/use-toast"
import { Download } from "lucide-react"

export default function CustomerExport({ onClose }) {
  const { toast } = useToast()
  const customers = useStore((state) => state.customers)

  const [selectedFields, setSelectedFields] = useState({
    name: true,
    phone: true,
    email: true,
    status: true,
    loyaltyPoints: true,
    visits: true,
    isRegistered: true,
    notes: false,
    lastVisit: false,
  })

  const handleFieldChange = (field) => {
    setSelectedFields({
      ...selectedFields,
      [field]: !selectedFields[field],
    })
  }

  const handleExport = () => {
    try {
      // בדיקה שנבחר לפחות שדה אחד
      if (!Object.values(selectedFields).some((value) => value)) {
        toast({
          title: "שגיאה",
          description: "יש לבחור לפחות שדה אחד לייצוא",
          variant: "destructive",
        })
        return
      }

      // יצירת כותרות לקובץ CSV
      const headers = []
      if (selectedFields.name) headers.push("שם")
      if (selectedFields.phone) headers.push("טלפון")
      if (selectedFields.email) headers.push("אימייל")
      if (selectedFields.status) headers.push("סטטוס")
      if (selectedFields.loyaltyPoints) headers.push("נקודות נאמנות")
      if (selectedFields.visits) headers.push("ביקורים")
      if (selectedFields.isRegistered) headers.push("רשום")
      if (selectedFields.notes) headers.push("הערות")
      if (selectedFields.lastVisit) headers.push("ביקור אחרון")

      // יצירת שורות נתונים
      const rows = customers.map((customer) => {
        const row = []
        if (selectedFields.name) row.push(`"${customer.name?.replace(/"/g, '""') || ""}"`)
        if (selectedFields.phone) row.push(`"${customer.phone || ""}"`)
        if (selectedFields.email) row.push(`"${customer.email || ""}"`)
        if (selectedFields.status) row.push(`"${customer.status || ""}"`)
        if (selectedFields.loyaltyPoints) row.push(customer.loyaltyPoints || 0)
        if (selectedFields.visits) row.push(customer.visits || 0)
        if (selectedFields.isRegistered) row.push(customer.isRegistered ? "כן" : "לא")
        if (selectedFields.notes) row.push(`"${customer.notes?.replace(/"/g, '""') || ""}"`)
        if (selectedFields.lastVisit) row.push(customer.lastVisit || "")
        return row.join(",")
      })

      // יצירת תוכן ה-CSV
      const csvContent = [headers.join(","), ...rows].join("\n")

      // יצירת קובץ להורדה
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.setAttribute("href", url)
      link.setAttribute("download", `customers_export_${new Date().toISOString().split("T")[0]}.csv`)
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toast({
        title: "ייצוא הושלם",
        description: `${customers.length} לקוחות יוצאו בהצלחה`,
      })

      if (onClose) onClose()
    } catch (error) {
      console.error("Export error:", error)
      toast({
        title: "שגיאה בייצוא",
        description: "אירעה שגיאה בעת ייצוא הלקוחות",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <h3 className="text-lg font-medium">בחר שדות לייצוא</h3>
        <p className="text-sm text-muted-foreground">סמן את השדות שברצונך לכלול בקובץ הייצוא</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Checkbox id="name" checked={selectedFields.name} onCheckedChange={() => handleFieldChange("name")} />
          <Label htmlFor="name">שם</Label>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Checkbox id="phone" checked={selectedFields.phone} onCheckedChange={() => handleFieldChange("phone")} />
          <Label htmlFor="phone">טלפון</Label>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Checkbox id="email" checked={selectedFields.email} onCheckedChange={() => handleFieldChange("email")} />
          <Label htmlFor="email">אימייל</Label>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Checkbox id="status" checked={selectedFields.status} onCheckedChange={() => handleFieldChange("status")} />
          <Label htmlFor="status">סטטוס</Label>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Checkbox
            id="loyaltyPoints"
            checked={selectedFields.loyaltyPoints}
            onCheckedChange={() => handleFieldChange("loyaltyPoints")}
          />
          <Label htmlFor="loyaltyPoints">נקודות נאמנות</Label>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Checkbox id="visits" checked={selectedFields.visits} onCheckedChange={() => handleFieldChange("visits")} />
          <Label htmlFor="visits">ביקורים</Label>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Checkbox
            id="isRegistered"
            checked={selectedFields.isRegistered}
            onCheckedChange={() => handleFieldChange("isRegistered")}
          />
          <Label htmlFor="isRegistered">רשום</Label>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Checkbox id="notes" checked={selectedFields.notes} onCheckedChange={() => handleFieldChange("notes")} />
          <Label htmlFor="notes">הערות</Label>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Checkbox
            id="lastVisit"
            checked={selectedFields.lastVisit}
            onCheckedChange={() => handleFieldChange("lastVisit")}
          />
          <Label htmlFor="lastVisit">ביקור אחרון</Label>
        </div>
      </div>

      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={onClose}>
          ביטול
        </Button>
        <Button onClick={handleExport} className="bg-pink-500 hover:bg-pink-600">
          <Download className="mr-2 h-4 w-4" />
          ייצוא {customers.length} לקוחות
        </Button>
      </div>
    </div>
  )
}
