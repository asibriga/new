"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useStore } from "@/lib/store"
import { useToast } from "@/components/ui/use-toast"
import { Upload, AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function ImportCustomersPage() {
  const router = useRouter()
  const customers = useStore((state) => state.customers)
  const addCustomer = useStore((state) => state.addCustomer)
  const updateCustomer = useStore((state) => state.updateCustomer)
  const { toast } = useToast()

  const [importFile, setImportFile] = useState<File | null>(null)
  const [isImporting, setIsImporting] = useState(false)
  const [importStats, setImportStats] = useState({ added: 0, updated: 0 })
  const [error, setError] = useState<string | null>(null)
  const [fileEncoding, setFileEncoding] = useState("utf-8")

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setImportFile(e.target.files[0])
      setError(null) // Clear any previous errors
    }
  }

  const handleImportCustomers = async () => {
    if (!importFile) {
      setError("אנא בחר קובץ לייבוא")
      return
    }

    setIsImporting(true)
    setError(null)

    try {
      // Read file as text with the selected encoding
      const reader = new FileReader()

      reader.onload = async (event) => {
        try {
          const fileContent = event.target?.result as string
          let importedCustomers = []

          // Parse file based on extension
          if (importFile.name.endsWith(".csv")) {
            // Parse CSV
            const rows = fileContent.split("\n")
            if (rows.length < 2) {
              throw new Error("הקובץ ריק או לא בפורמט תקין")
            }

            const headers = rows[0].split(",")

            importedCustomers = rows
              .slice(1)
              .filter((row) => row && row.trim() !== "")
              .map((row) => {
                const values = row.split(",")
                return {
                  name: values[0]?.replace(/^"|"$/g, "") || "",
                  phone: values[1] || "",
                  email: values[2]?.replace(/^"|"$/g, "") || "",
                  notes: values[3]?.replace(/^"|"$/g, "") || "",
                }
              })
          } else if (importFile.name.endsWith(".json")) {
            // Parse JSON
            importedCustomers = JSON.parse(fileContent)
          } else {
            throw new Error("פורמט קובץ לא נתמך. אנא השתמש בקובץ CSV או JSON")
          }

          // Add imported customers
          let addedCount = 0
          let updatedCount = 0

          // Check if importedCustomers is an array and not empty
          if (!Array.isArray(importedCustomers) || importedCustomers.length === 0) {
            throw new Error("לא נמצאו לקוחות תקינים בקובץ הייבוא")
          }

          for (let i = 0; i < importedCustomers.length; i++) {
            const customer = importedCustomers[i]
            if (!customer || !customer.name || !customer.phone) continue

            // Check if customer already exists
            const existingCustomer = customers.find((c) => c && c.phone === customer.phone)

            if (existingCustomer) {
              // Update existing customer
              updateCustomer(existingCustomer.id, {
                name: customer.name,
                email: customer.email,
                notes: customer.notes,
              })
              updatedCount++
            } else {
              // Add new customer
              addCustomer({
                name: customer.name,
                phone: customer.phone,
                email: customer.email,
                notes: customer.notes,
                status: "new",
                createdAt: new Date().toISOString().split("T")[0],
              })
              addedCount++
            }
          }

          setImportStats({ added: addedCount, updated: updatedCount })

          toast({
            title: "הייבוא הושלם בהצלחה",
            description: `נוספו ${addedCount} לקוחות חדשים ועודכנו ${updatedCount} לקוחות קיימים`,
          })

          // Navigate back to customers page after 2 seconds
          setTimeout(() => {
            router.push("/admin/customers")
          }, 2000)
        } catch (error) {
          console.error("Error importing customers:", error)
          setError(error.message || "אירעה שגיאה בייבוא הלקוחות. אנא ודא שהקובץ בפורמט תקין ונסה שנית.")
        } finally {
          setIsImporting(false)
        }
      }

      reader.onerror = () => {
        setError("אירעה שגיאה בקריאת הקובץ")
        setIsImporting(false)
      }

      // Read the file with the selected encoding
      reader.readAsText(importFile, fileEncoding)
    } catch (error) {
      console.error("Error importing customers:", error)
      setError("אירעה שגיאה בייבוא הלקוחות. אנא ודא שהקובץ בפורמט תקין ונסה שנית.")
      setIsImporting(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle>ייבוא לקוחות</CardTitle>
          <CardDescription>העלה קובץ CSV או JSON עם רשימת הלקוחות</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6">
            <div className="grid gap-2">
              <Label>בחר קובץ</Label>
              <Input type="file" accept=".csv,.json" onChange={handleFileChange} className="cursor-pointer" />
              {importFile && (
                <p className="text-sm text-gray-500">
                  נבחר: {importFile.name} ({Math.round(importFile.size / 1024)} KB)
                </p>
              )}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="encoding">קידוד קובץ (אם יש בעיות עם תווים בעברית)</Label>
              <select
                id="encoding"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={fileEncoding}
                onChange={(e) => setFileEncoding(e.target.value)}
              >
                <option value="utf-8">UTF-8 (ברירת מחדל)</option>
                <option value="windows-1255">Windows-1255 (עברית)</option>
                <option value="iso-8859-8">ISO-8859-8 (עברית)</option>
              </select>
            </div>

            <div className="text-sm text-gray-500">
              <p>פורמט קובץ CSV: שם, טלפון, אימייל, הערות</p>
              <p>פורמט קובץ JSON: מערך של אובייקטים עם השדות name, phone, email, notes</p>
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>שגיאה</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {importStats.added > 0 || importStats.updated > 0 ? (
              <div className="bg-green-50 p-4 rounded-md">
                <h3 className="font-medium text-green-800">הייבוא הושלם בהצלחה</h3>
                <p className="text-green-700">
                  נוספו {importStats.added} לקוחות חדשים ועודכנו {importStats.updated} לקוחות קיימים
                </p>
              </div>
            ) : null}

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => router.push("/admin/customers")}>
                ביטול
              </Button>
              <Button
                className="bg-pink-500 hover:bg-pink-600"
                onClick={handleImportCustomers}
                disabled={!importFile || isImporting}
              >
                {isImporting ? (
                  <div className="flex items-center">
                    <svg
                      className="animate-spin -ml-1 mr-3 h-4 w-4 text-white"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    מייבא...
                  </div>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" /> ייבוא
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
