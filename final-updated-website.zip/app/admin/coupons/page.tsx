"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { format, addMonths, subMonths } from "date-fns"
import { Copy, Edit, Plus, Trash2, Ticket } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useStore } from "@/lib/store"
import { he } from "date-fns/locale"
import { ChevronLeft, ChevronRight } from "lucide-react"

// Mock data for coupons
const initialCoupons = []

export default function CouponsPage() {
  const [coupons, setCoupons] = useState(initialCoupons)
  const [activeTab, setActiveTab] = useState("all")
  const [isCreating, setIsCreating] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [editingCouponId, setEditingCouponId] = useState(null)
  const { toast } = useToast()

  // Calendar state
  const [fromMonth, setFromMonth] = useState(new Date())
  const [toMonth, setToMonth] = useState(new Date())

  // New coupon form state
  const [newCoupon, setNewCoupon] = useState({
    code: "",
    discount: 0,
    discountType: "percentage",
    description: "",
    validFrom: format(new Date(), "yyyy-MM-dd"),
    validTo: format(new Date(new Date().setMonth(new Date().getMonth() + 3)), "yyyy-MM-dd"),
    minPurchase: 0,
    maxUses: 0,
    isActive: true,
    applicableServices: ["all"],
    applicableProducts: ["all"],
  })

  // Filter coupons based on active tab
  const filteredCoupons = coupons.filter((coupon) => {
    if (activeTab === "all") return true
    if (activeTab === "active") return coupon.isActive
    if (activeTab === "inactive") return !coupon.isActive
    if (activeTab === "expired") {
      const today = new Date().toISOString().split("T")[0]
      return coupon.validTo < today
    }
    return true
  })

  const handleCreateCoupon = () => {
    if (!newCoupon.code) {
      toast({
        title: "שגיאה",
        description: "קוד קופון הוא שדה חובה",
        variant: "destructive",
      })
      return
    }

    if (newCoupon.discount <= 0) {
      toast({
        title: "שגיאה",
        description: "ערך ההנחה חייב להיות גדול מ-0",
        variant: "destructive",
      })
      return
    }

    // Validate date range
    if (new Date(newCoupon.validFrom) > new Date(newCoupon.validTo)) {
      toast({
        title: "שגיאה",
        description: "תאריך התוקף חייב להיות לאחר תאריך התחילה",
        variant: "destructive",
      })
      return
    }

    const newCouponWithId = {
      ...newCoupon,
      id: Date.now().toString(),
      usedCount: 0,
    }

    // Update the state with the new coupon
    setCoupons([...coupons, newCouponWithId])

    // Also update the store
    const store = useStore.getState()
    const currentCoupons = store.coupons || []

    // Create a simplified version for the store
    const storeCoupon = {
      id: newCouponWithId.id,
      code: newCouponWithId.code,
      discount: newCouponWithId.discount,
      expirationDate: newCouponWithId.validTo,
      isActive: newCouponWithId.isActive,
    }

    // Add to store
    if (store.coupons) {
      useStore.setState({ coupons: [...currentCoupons, storeCoupon] })
    }

    setIsCreating(false)
    setNewCoupon({
      code: "",
      discount: 0,
      discountType: "percentage",
      description: "",
      validFrom: format(new Date(), "yyyy-MM-dd"),
      validTo: format(new Date(new Date().setMonth(new Date().getMonth() + 3)), "yyyy-MM-dd"),
      minPurchase: 0,
      maxUses: 0,
      isActive: true,
      applicableServices: ["all"],
      applicableProducts: ["all"],
    })

    toast({
      title: "הקופון נוצר בהצלחה",
      description: `הקופון ${newCouponWithId.code} נוצר בהצלחה`,
    })
  }

  const handleEditCoupon = () => {
    if (!newCoupon.code) {
      toast({
        title: "שגיאה",
        description: "קוד קופון הוא שדה חובה",
        variant: "destructive",
      })
      return
    }

    if (newCoupon.discount <= 0) {
      toast({
        title: "שגיאה",
        description: "ערך ההנחה חייב להיות גדול מ-0",
        variant: "destructive",
      })
      return
    }

    setCoupons(
      coupons.map((coupon) => (coupon.id === editingCouponId ? { ...newCoupon, id: editingCouponId } : coupon)),
    )
    setIsEditing(false)
    setEditingCouponId(null)
    setNewCoupon({
      code: "",
      discount: 0,
      discountType: "percentage",
      description: "",
      validFrom: format(new Date(), "yyyy-MM-dd"),
      validTo: format(new Date(new Date().setMonth(new Date().getMonth() + 3)), "yyyy-MM-dd"),
      minPurchase: 0,
      maxUses: 0,
      isActive: true,
      applicableServices: ["all"],
      applicableProducts: ["all"],
    })

    toast({
      title: "הקופון עודכן בהצלחה",
      description: `הקופון ${newCoupon.code} עודכן בהצלחה`,
    })
  }

  // Исправление функции handleDeleteCoupon для правильного удаления купонов
  const handleDeleteCoupon = (id) => {
    const coupon = coupons.find((c) => c.id === id)
    setCoupons(coupons.filter((coupon) => coupon.id !== id))

    // Также удалить из хранилища
    if (coupon) {
      const store = useStore.getState()
      const storeCoupons = store.coupons || []

      // Удалить купон из хранилища
      const updatedStoreCoupons = storeCoupons.filter((c) => c.id !== id)

      useStore.setState({ coupons: updatedStoreCoupons })
    }

    toast({
      title: "הקופון נמחק בהצלחה",
      description: "הקופון נמחק בהצלחה מהמערכת",
    })
  }

  // Исправление функции toggleCouponStatus для правильного включения/выключения купонов
  const toggleCouponStatus = (id) => {
    setCoupons(coupons.map((coupon) => (coupon.id === id ? { ...coupon, isActive: !coupon.isActive } : coupon)))

    // Также обновить хранилище
    const coupon = coupons.find((c) => c.id === id)
    if (coupon) {
      const store = useStore.getState()
      const storeCoupons = store.coupons || []

      // Найти и обновить купон в хранилище
      const updatedStoreCoupons = storeCoupons.map((c) => (c.id === id ? { ...c, isActive: !coupon.isActive } : c))

      useStore.setState({ coupons: updatedStoreCoupons })

      toast({
        title: coupon.isActive ? "הקופון הושבת" : "הקופון הופעל",
        description: `הקופון ${coupon.code} ${coupon.isActive ? "הושבת" : "הופעל"} בהצלחה`,
      })
    }
  }

  // В функции useEffect добавить инициализацию купонов из хранилища
  useEffect(() => {
    const storeCoupons = useStore.getState().coupons || []
    // Filter demo coupons
    const filteredCoupons = storeCoupons.filter((coupon) => coupon.code !== "WELCOME10" && coupon.code !== "SUMMER50")

    // Update store without demo coupons
    useStore.setState({ coupons: filteredCoupons })

    // Ensure all coupons have the required properties
    const normalizedCoupons = filteredCoupons.map((coupon) => ({
      id: coupon.id,
      code: coupon.code,
      discount: coupon.discount || 0,
      discountType: coupon.discountType || "percentage",
      description: coupon.description || "",
      validFrom: coupon.validFrom || format(new Date(), "yyyy-MM-dd"),
      validTo:
        coupon.expirationDate ||
        coupon.validTo ||
        format(new Date(new Date().setMonth(new Date().getMonth() + 3)), "yyyy-MM-dd"),
      minPurchase: coupon.minPurchase || 0,
      maxUses: coupon.maxUses || 0,
      isActive: coupon.isActive !== undefined ? coupon.isActive : true,
      applicableServices: coupon.applicableServices || ["all"],
      applicableProducts: coupon.applicableProducts || ["all"],
      usedCount: coupon.usedCount || 0,
    }))

    // Set coupons in local state
    setCoupons(normalizedCoupons)
  }, [])

  const startEditCoupon = (coupon) => {
    setNewCoupon({ ...coupon })
    setEditingCouponId(coupon.id)
    setIsEditing(true)
    setIsCreating(false)

    // Set calendar months
    setFromMonth(new Date(coupon.validFrom))
    setToMonth(new Date(coupon.validTo))
  }

  const copyCouponCode = (code) => {
    navigator.clipboard.writeText(code)
    toast({
      title: "הקוד הועתק",
      description: `הקוד ${code} הועתק ללוח`,
    })
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">ניהול קופונים</h1>
        <Button
          onClick={() => {
            setIsCreating(true)
            setIsEditing(false)
            setFromMonth(new Date())
            setToMonth(new Date(new Date().setMonth(new Date().getMonth() + 3)))
          }}
          className="bg-pink-500 hover:bg-pink-600"
        >
          <Plus className="mr-2 h-4 w-4" /> קופון חדש
        </Button>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="all">כל הקופונים</TabsTrigger>
          <TabsTrigger value="active">פעילים</TabsTrigger>
          <TabsTrigger value="inactive">לא פעילים</TabsTrigger>
          <TabsTrigger value="expired">פג תוקף</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab}>
          {isCreating || isEditing ? (
            <Card>
              <CardHeader>
                <CardTitle>{isEditing ? "עריכת קופון" : "יצירת קופון חדש"}</CardTitle>
                <CardDescription>
                  {isEditing ? "ערוך את פרטי הקופון הקיים" : "צור קופון חדש שלקוחות יוכלו להשתמש בו לקבלת הנחות"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="coupon-code">קוד קופון</Label>
                    <Input
                      id="coupon-code"
                      placeholder="לדוגמה: WELCOME20"
                      value={newCoupon.code}
                      onChange={(e) => setNewCoupon({ ...newCoupon, code: e.target.value.toUpperCase() })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="discount-type">סוג הנחה</Label>
                    <Select
                      value={newCoupon.discountType}
                      onValueChange={(value) => setNewCoupon({ ...newCoupon, discountType: value })}
                    >
                      <SelectTrigger id="discount-type">
                        <SelectValue placeholder="בחר סוג הנחה" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="percentage">אחוזים (%)</SelectItem>
                        <SelectItem value="fixed">סכום קבוע (₪)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="discount-value">ערך הנחה</Label>
                    <Input
                      id="discount-value"
                      type="number"
                      placeholder={newCoupon.discountType === "percentage" ? "לדוגמה: 20" : "לדוגמה: 50"}
                      value={newCoupon.discount}
                      onChange={(e) => setNewCoupon({ ...newCoupon, discount: Number.parseFloat(e.target.value) || 0 })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="min-purchase">רכישה מינימלית (₪)</Label>
                    <Input
                      id="min-purchase"
                      type="number"
                      placeholder="0 = ללא מינימום"
                      value={newCoupon.minPurchase}
                      onChange={(e) =>
                        setNewCoupon({ ...newCoupon, minPurchase: Number.parseFloat(e.target.value) || 0 })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="valid-from">תקף מתאריך</Label>
                    <div className="border rounded-lg p-4">
                      <div className="text-center mb-4">
                        <div className="flex items-center justify-between">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setFromMonth(addMonths(fromMonth, 1))}
                            type="button"
                          >
                            <ChevronLeft className="h-5 w-5" />
                          </Button>
                          <h3 className="text-lg font-medium">{format(fromMonth, "MMMM yyyy", { locale: he })}</h3>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setFromMonth(subMonths(fromMonth, 1))}
                            type="button"
                          >
                            <ChevronRight className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>

                      <div className="calendar-container rtl">
                        {/* Days of week - right to left */}
                        <div className="grid grid-cols-7 gap-1 mb-2 text-center">
                          <div className="text-sm font-medium">א'</div>
                          <div className="text-sm font-medium">ב'</div>
                          <div className="text-sm font-medium">ג'</div>
                          <div className="text-sm font-medium">ד'</div>
                          <div className="text-sm font-medium">ה'</div>
                          <div className="text-sm font-medium">ו'</div>
                          <div className="text-sm font-medium">ש'</div>
                        </div>

                        <Calendar
                          mode="single"
                          selected={new Date(newCoupon.validFrom)}
                          onSelect={(date) =>
                            setNewCoupon({ ...newCoupon, validFrom: format(date || new Date(), "yyyy-MM-dd") })
                          }
                          month={fromMonth}
                          onMonthChange={setFromMonth}
                          initialFocus
                          locale={he}
                          className="rtl"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="valid-to">תקף עד תאריך</Label>
                    <div className="border rounded-lg p-4">
                      <div className="text-center mb-4">
                        <div className="flex items-center justify-between">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setToMonth(addMonths(toMonth, 1))}
                            type="button"
                          >
                            <ChevronLeft className="h-5 w-5" />
                          </Button>
                          <h3 className="text-lg font-medium">{format(toMonth, "MMMM yyyy", { locale: he })}</h3>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setToMonth(subMonths(toMonth, 1))}
                            type="button"
                          >
                            <ChevronRight className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>

                      <div className="calendar-container rtl">
                        {/* Days of week - right to left */}
                        <div className="grid grid-cols-7 gap-1 mb-2 text-center">
                          <div className="text-sm font-medium">א'</div>
                          <div className="text-sm font-medium">ב'</div>
                          <div className="text-sm font-medium">ג'</div>
                          <div className="text-sm font-medium">ד'</div>
                          <div className="text-sm font-medium">ה'</div>
                          <div className="text-sm font-medium">ו'</div>
                          <div className="text-sm font-medium">ש'</div>
                        </div>

                        <Calendar
                          mode="single"
                          selected={new Date(newCoupon.validTo)}
                          onSelect={(date) =>
                            setNewCoupon({ ...newCoupon, validTo: format(date || new Date(), "yyyy-MM-dd") })
                          }
                          month={toMonth}
                          onMonthChange={setToMonth}
                          initialFocus
                          locale={he}
                          className="rtl"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="max-uses">מקסימום שימושים</Label>
                    <Input
                      id="max-uses"
                      type="number"
                      placeholder="0 = ללא הגבלה"
                      value={newCoupon.maxUses}
                      onChange={(e) => setNewCoupon({ ...newCoupon, maxUses: Number.parseInt(e.target.value) || 0 })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="applicable-services">שירותים רלוונטיים</Label>
                    <Select
                      value={newCoupon.applicableServices[0]}
                      onValueChange={(value) => setNewCoupon({ ...newCoupon, applicableServices: [value] })}
                    >
                      <SelectTrigger id="applicable-services">
                        <SelectValue placeholder="בחר שירותים" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">כל השירותים</SelectItem>
                        <SelectItem value="1">מניקור קלאסי</SelectItem>
                        <SelectItem value="2">מניקור ג'ל</SelectItem>
                        <SelectItem value="3">בניית ציפורניים ג'ל</SelectItem>
                        <SelectItem value="4">פדיקור קלאסי</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="applicable-products">מוצרים רלוונטיים</Label>
                    <Select
                      value={newCoupon.applicableProducts[0]}
                      onValueChange={(value) => setNewCoupon({ ...newCoupon, applicableProducts: [value] })}
                    >
                      <SelectTrigger id="applicable-products">
                        <SelectValue placeholder="בחר מוצרים" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">כל המוצרים</SelectItem>
                        <SelectItem value="1">לק ג'ל ורוד פסטל</SelectItem>
                        <SelectItem value="2">לק ג'ל אדום קלאסי</SelectItem>
                        <SelectItem value="3">שמן קוטיקולה</SelectItem>
                        <SelectItem value="4">ערכת מניקור ביתית</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">תיאור הקופון</Label>
                  <Textarea
                    id="description"
                    placeholder="תיאור קצר של הקופון"
                    value={newCoupon.description}
                    onChange={(e) => setNewCoupon({ ...newCoupon, description: e.target.value })}
                  />
                </div>

                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <Switch
                    id="coupon-active"
                    checked={newCoupon.isActive}
                    onCheckedChange={(checked) => setNewCoupon({ ...newCoupon, isActive: checked })}
                  />
                  <Label htmlFor="coupon-active">קופון פעיל</Label>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsCreating(false)
                    setIsEditing(false)
                  }}
                >
                  ביטול
                </Button>
                <Button
                  onClick={isEditing ? handleEditCoupon : handleCreateCoupon}
                  className="bg-pink-500 hover:bg-pink-600"
                >
                  {isEditing ? "עדכון קופון" : "יצירת קופון"}
                </Button>
              </CardFooter>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredCoupons.length > 0 ? (
                filteredCoupons.map((coupon) => (
                  <Card key={coupon.id} className={!coupon.isActive ? "opacity-70" : ""}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center">
                          <Ticket className="h-5 w-5 text-pink-500 mr-2" />
                          <CardTitle className="text-lg">{coupon.code}</CardTitle>
                        </div>
                        <div className="flex space-x-1 rtl:space-x-reverse">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              navigator.clipboard.writeText(coupon.code)
                              toast({
                                title: "הקוד הועתק",
                                description: `הקוד ${coupon.code} הועתק ללוח`,
                              })
                            }}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setNewCoupon({
                                code: coupon.code,
                                discount: coupon.discount,
                                discountType: coupon.discountType,
                                description: coupon.description || "",
                                validFrom: coupon.validFrom,
                                validTo: coupon.validTo,
                                minPurchase: coupon.minPurchase || 0,
                                maxUses: coupon.maxUses || 0,
                                isActive: coupon.isActive !== false,
                                applicableServices: coupon.applicableServices || ["all"],
                                applicableProducts: coupon.applicableProducts || ["all"],
                              })
                              setEditingCouponId(coupon.id)
                              setIsEditing(true)
                              setIsCreating(false)
                              setFromMonth(new Date(coupon.validFrom))
                              setToMonth(new Date(coupon.validTo))
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              if (confirm(`האם אתה בטוח שברצונך למחוק את הקופון ${coupon.code}?`)) {
                                handleDeleteCoupon(coupon.id)
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center mt-1">
                        <Badge
                          variant={coupon.isActive ? "default" : "secondary"}
                          className="bg-pink-100 text-pink-800 hover:bg-pink-200"
                        >
                          {coupon.isActive ? "פעיל" : "לא פעיל"}
                        </Badge>
                        <Badge variant="outline" className="ml-2">
                          {coupon.discountType === "percentage" ? `${coupon.discount}%` : `₪${coupon.discount}`}
                        </Badge>
                      </div>
                      <CardDescription className="mt-2">{coupon.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="text-sm space-y-1">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">תוקף:</span>
                          <span>
                            {coupon.validFrom} - {coupon.validTo}
                          </span>
                        </div>
                        {coupon.minPurchase > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">מינימום רכישה:</span>
                            <span>₪{coupon.minPurchase}</span>
                          </div>
                        )}
                        {coupon.maxUses > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">שימושים:</span>
                            <span>
                              {coupon.usedCount}/{coupon.maxUses}
                            </span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                    <CardFooter>
                      <div className="flex items-center w-full justify-between">
                        <span className="text-sm text-muted-foreground">
                          {coupon.applicableServices && coupon.applicableServices[0] === "all"
                            ? "כל השירותים"
                            : "שירותים נבחרים"}
                        </span>
                        <Switch checked={coupon.isActive} onCheckedChange={() => toggleCouponStatus(coupon.id)} />
                      </div>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <div className="col-span-full text-center py-10 text-muted-foreground">
                  לא נמצאו קופונים בקטגוריה זו
                </div>
              )}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
