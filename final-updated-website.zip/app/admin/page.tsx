"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, DollarSign, Plus, Users, Bell, Check, X } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useStore } from "@/lib/store"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import MonthlyCalendar from "@/components/admin/monthly-calendar"

export default function AdminDashboard() {
  const { toast } = useToast()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("stats")
  const [monthlyIncome, setMonthlyIncome] = useState(0)
  const [monthlyAppointmentsCount, setMonthlyAppointmentsCount] = useState(0)
  const [newCustomersCount, setNewCustomersCount] = useState(0)
  const [averageDuration, setAverageDuration] = useState(0)
  const [todayAppointments, setTodayAppointments] = useState([])
  const [tomorrowAppointments, setTomorrowAppointments] = useState([])
  const [isScheduleWaitlistDialogOpen, setIsScheduleWaitlistDialogOpen] = useState(false)
  const [selectedWaitlistAppointment, setSelectedWaitlistAppointment] = useState(null)
  const [scheduleTime, setScheduleTime] = useState("")
  const [availableTimesForWaitlist, setAvailableTimesForWaitlist] = useState([])

  // Get data from store
  const appointments = useStore((state) => state.appointments)
  const updateAppointment = useStore((state) => state.updateAppointment)
  const pendingAppointments = appointments.filter(
    (appointment) => appointment.status === "pending" && !appointment.isWaitlist,
  )
  const waitlistAppointments = appointments.filter((appointment) => appointment.isWaitlist)
  const notifications = useStore((state) => state.notifications)
  const markNotificationAsRead = useStore((state) => state.markNotificationAsRead)
  // Only show admin notifications, not customer notifications
  const unreadNotifications = notifications.filter(
    (notification) =>
      !notification.isRead &&
      notification.type !== "customer" &&
      !notification.isCustomerNotification &&
      (!notification.userId || notification.userId === "admin"),
  )
  const transactions = useStore((state) => state.transactions)
  const customers = useStore((state) => state.customers)
  const services = useStore((state) => state.services)

  // Group pending appointments by customer, date and time
  const groupedPendingAppointments = (() => {
    const groups = {}

    pendingAppointments.forEach((appointment) => {
      const key = `${appointment.customerPhone}-${appointment.date}-${appointment.time}`
      if (!groups[key]) {
        groups[key] = {
          customerId: appointment.customerId,
          customerName: appointment.customerName,
          customerPhone: appointment.customerPhone,
          customerEmail: appointment.customerEmail,
          date: appointment.date,
          time: appointment.time,
          status: appointment.status,
          isWaitlist: appointment.isWaitlist,
          services: [],
          totalPrice: 0,
          appointmentIds: [],
          notes: appointment.notes || "",
        }
      }

      groups[key].services.push({
        id: appointment.id,
        name: appointment.serviceName,
        price: appointment.price || 0,
        status: appointment.status,
        serviceId: appointment.serviceId,
      })

      groups[key].totalPrice += appointment.price || 0
      groups[key].appointmentIds.push(appointment.id)
    })

    return Object.values(groups)
  })()

  // Group waitlist appointments by customer, date and time
  const groupedWaitlistAppointments = (() => {
    const groups = {}

    waitlistAppointments.forEach((appointment) => {
      const key = `${appointment.customerPhone}-${appointment.date}-${appointment.time || "no-time"}`
      if (!groups[key]) {
        groups[key] = {
          customerId: appointment.customerId,
          customerName: appointment.customerName,
          customerPhone: appointment.customerPhone,
          customerEmail: appointment.customerEmail,
          date: appointment.date,
          time: appointment.time,
          status: appointment.status,
          isWaitlist: appointment.isWaitlist,
          services: [],
          totalPrice: 0,
          appointmentIds: [],
          notes: appointment.notes || "",
        }
      }

      groups[key].services.push({
        id: appointment.id,
        name: appointment.serviceName,
        price: appointment.price || 0,
        status: appointment.status,
        serviceId: appointment.serviceId,
      })

      groups[key].totalPrice += appointment.price || 0
      groups[key].appointmentIds.push(appointment.id)
    })

    return Object.values(groups)
  })()

  const handleApproveAppointment = (appointment) => {
    try {
      // Update all services in this appointment
      appointment.appointmentIds.forEach((id) => {
        updateAppointment(id, { status: "confirmed" })
      })

      toast({
        title: "התור אושר",
        description: `התור של ${appointment.customerName} אושר בהצלחה`,
      })
    } catch (error) {
      console.error("Error approving appointment:", error)
      toast({
        title: "שגיאה באישור התור",
        description: "אירעה שגיאה באישור התור. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  const handleRejectAppointment = (appointment) => {
    try {
      // Cancel all services in this appointment
      appointment.appointmentIds.forEach((id) => {
        updateAppointment(id, { status: "cancelled" })
      })

      toast({
        title: "התור בוטל",
        description: `התור של ${appointment.customerName} בוטל בהצלחה`,
      })
    } catch (error) {
      console.error("Error rejecting appointment:", error)
      toast({
        title: "שגיאה בביטול התור",
        description: "אירעה שגיאה בביטול התור. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  const handleMarkAsRead = (id) => {
    try {
      markNotificationAsRead(id)
    } catch (error) {
      console.error("Error marking notification as read:", error)
      toast({
        title: "שגיאה בסימון ההתראה",
        description: "אירעה שגיאה בסימון ההתראה כנקראה. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  // עדכון הסטטיסטיקות בלוח הבקרה
  useEffect(() => {
    // חישוב הכנסות החודש
    const currentDate = new Date()
    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
    const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)
    const firstDayStr = format(firstDayOfMonth, "yyyy-MM-dd")
    const lastDayStr = format(lastDayOfMonth, "yyyy-MM-dd")

    const monthlyIncomeCalc = transactions
      .filter((t) => {
        return t.type === "income" && t.date >= firstDayStr && t.date <= lastDayStr
      })
      .reduce((sum, t) => sum + t.amount, 0)

    setMonthlyIncome(monthlyIncomeCalc)

    // חישוב תורים החודש
    const monthlyAppointments = appointments.filter((a) => {
      return a.date >= firstDayStr && a.date <= lastDayStr
    })

    setMonthlyAppointmentsCount(monthlyAppointments.length)

    // חישוב לקוחות חדשים החודש
    const newCustomers = customers.filter((c) => {
      if (!c.createdAt) return false
      return c.createdAt >= firstDayStr && c.createdAt <= lastDayStr
    })

    setNewCustomersCount(newCustomers.length)

    // חישוב זמן ממוצע לטיפול
    const completedAppointments = appointments.filter((a) => a.status === "completed")
    if (completedAppointments.length > 0) {
      const totalDuration = completedAppointments.reduce((sum, a) => {
        const service = services.find((s) => s.id === a.serviceId)
        return sum + (service ? service.duration : 0)
      }, 0)

      setAverageDuration(Math.round(totalDuration / completedAppointments.length))
    }

    // תורים להיום
    const today = format(new Date(), "yyyy-MM-dd")
    const todayAppointmentsCalc = appointments.filter((a) => a.date === today)
    setTodayAppointments(todayAppointmentsCalc)

    // תורים למחר
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    const tomorrowStr = format(tomorrow, "yyyy-MM-dd")
    const tomorrowAppointmentsCalc = appointments.filter((a) => a.date === tomorrowStr)
    setTomorrowAppointments(tomorrowAppointmentsCalc)
  }, [appointments, transactions, customers, services])

  const openScheduleWaitlistDialog = (appointment) => {
    setSelectedWaitlistAppointment(appointment)

    // Get available times for the selected date
    const formattedDate = appointment.date

    // Calculate total duration of all services in this appointment
    let totalDuration = 0
    appointment.services.forEach((service) => {
      const serviceObj = services.find((s) => s.id === service.serviceId)
      if (serviceObj) {
        totalDuration += serviceObj.duration
      }
    })

    // Get all possible time slots
    const allTimeSlots = [
      "11:00",
      "11:20",
      "11:40",
      "12:00",
      "12:20",
      "12:40",
      "13:00",
      "13:20",
      "13:40",
      "14:00",
      "14:20",
      "14:40",
      "15:00",
      "15:20",
      "15:40",
      "16:00",
      "16:20",
      "16:40",
      "17:00",
      "17:20",
      "17:40",
    ]

    // Filter time slots based on confirmed appointments
    const confirmedAppointments = appointments.filter(
      (a) =>
        a.date === formattedDate &&
        (a.status === "confirmed" || a.status === "completed" || a.status === "pending") &&
        !a.isWaitlist,
    )

    const availableSlots = allTimeSlots.filter((timeSlot) => {
      // Convert time slot to minutes
      const [hours, minutes] = timeSlot.split(":").map(Number)
      const slotStartMinutes = hours * 60 + minutes
      const slotEndMinutes = slotStartMinutes + totalDuration

      // Check if this slot would go past closing time (18:00 = 1080 minutes)
      if (slotEndMinutes > 1080) {
        return false
      }

      // Check if this slot overlaps with any confirmed appointments
      for (const appointment of confirmedAppointments) {
        // Get the service for this appointment to determine its duration
        const appointmentService = services.find((s) => s.id === appointment.serviceId)
        if (!appointmentService) continue

        // Calculate appointment start and end times in minutes
        const [appHours, appMinutes] = appointment.time.split(":").map(Number)
        const appStartMinutes = appHours * 60 + appMinutes
        const appEndMinutes = appStartMinutes + appointmentService.duration

        // Check for overlap
        if (
          (slotStartMinutes >= appStartMinutes && slotStartMinutes < appEndMinutes) || // Slot starts during an appointment
          (slotEndMinutes > appStartMinutes && slotEndMinutes <= appEndMinutes) || // Slot ends during an appointment
          (slotStartMinutes <= appStartMinutes && slotEndMinutes >= appEndMinutes) // Slot completely contains an appointment
        ) {
          return false
        }
      }

      return true
    })

    setAvailableTimesForWaitlist(availableSlots)
    setIsScheduleWaitlistDialogOpen(true)
  }

  const handleScheduleWaitlistAppointment = () => {
    try {
      if (!selectedWaitlistAppointment || !scheduleTime) {
        toast({
          title: "שגיאה",
          description: "אנא בחר שעה לתור",
          variant: "destructive",
        })
        return
      }

      // Update all services in this appointment with the selected time and change status to confirmed
      selectedWaitlistAppointment.appointmentIds.forEach((id, index) => {
        // For subsequent services, calculate start time based on previous services duration
        let serviceTime = scheduleTime
        if (index > 0) {
          const previousServicesDuration = selectedWaitlistAppointment.services
            .slice(0, index)
            .reduce((total, service) => {
              const serviceObj = services.find((s) => s.id === service.serviceId)
              return total + (serviceObj ? serviceObj.duration : 0)
            }, 0)

          const [hours, minutes] = scheduleTime.split(":").map(Number)
          const startTimeDate = new Date()
          startTimeDate.setHours(hours, minutes, 0, 0)
          const serviceStartTime = new Date(startTimeDate.getTime() + previousServicesDuration * 60000)
          serviceTime = `${serviceStartTime.getHours().toString().padStart(2, "0")}:${serviceStartTime.getMinutes().toString().padStart(2, "0")}`
        }

        updateAppointment(id, {
          time: serviceTime,
          isWaitlist: false,
          status: "confirmed",
        })
      })

      setIsScheduleWaitlistDialogOpen(false)
      setScheduleTime("")

      toast({
        title: "התור נקבע בהצלחה",
        description: `התור נקבע ל${selectedWaitlistAppointment.date} בשעה ${scheduleTime}`,
      })
    } catch (error) {
      console.error("Error scheduling waitlist appointment:", error)
      toast({
        title: "שגיאה בקביעת התור",
        description: "אירעה שגיאה בקביעת התור מרשימת ההמתנה. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  // Calculate end time for an appointment
  const calculateEndTime = (appointment) => {
    if (!appointment || !appointment.time) return "לא צוין"

    try {
      // Calculate total duration for all services in this appointment
      let totalDuration = 0
      appointment.services.forEach((service) => {
        const serviceObj = services.find((s) => s.id === service.serviceId)
        if (serviceObj) {
          totalDuration += serviceObj.duration
        } else {
          // Fallback durations based on service name
          if (service.name.includes("מניקור")) totalDuration += 45
          else if (service.name.includes("פדיקור")) totalDuration += 60
          else if (service.name.includes("בניית ציפורניים")) totalDuration += 90
          else if (service.name.includes("ג'ל")) totalDuration += 60
          else totalDuration += 45
        }
      })

      const [hours, minutes] = appointment.time.split(":").map(Number)
      if (isNaN(hours) || isNaN(minutes)) return "לא צוין"

      const startDate = new Date()
      startDate.setHours(hours, minutes, 0, 0)
      const endDate = new Date(startDate.getTime() + totalDuration * 60000)
      return `${endDate.getHours().toString().padStart(2, "0")}:${endDate.getMinutes().toString().padStart(2, "0")}`
    } catch (error) {
      console.error("Error calculating end time:", error)
      return "לא צוין"
    }
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
        <h1 className="text-2xl font-bold">לוח בקרה</h1>
        <Link href="/admin/appointments/new">
          <Button
            className="bg-pink-500 hover:bg-pink-600 w-full sm:w-auto"
            onClick={() => {
              router.push("/admin/appointments/new")
            }}
          >
            <Plus className="mr-2 h-4 w-4" /> הוספת תור חדש
          </Button>
        </Link>
      </div>

      <div className="mb-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="stats">סטטיסטיקות</TabsTrigger>
            <TabsTrigger value="pending">
              תורים לאישור
              {groupedPendingAppointments.length > 0 && (
                <Badge className="mr-2 bg-pink-500">{groupedPendingAppointments.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="calendar">יומן חודשי</TabsTrigger>
          </TabsList>

          <TabsContent value="stats" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="p-4">
                  <CardTitle className="text-sm font-medium flex items-center">
                    <DollarSign className="h-4 w-4 mr-1 text-muted-foreground" />
                    הכנסות החודש
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold">₪ {monthlyIncome}</div>
                  <p className="text-xs text-muted-foreground">{monthlyIncome === 0 ? "אין נתונים עדיין" : ""}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="p-4">
                  <CardTitle className="text-sm font-medium flex items-center">
                    <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                    תורים החודש
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold">{monthlyAppointmentsCount}</div>
                  <p className="text-xs text-muted-foreground">
                    {monthlyAppointmentsCount === 0 ? "אין נתונים עדיין" : ""}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="p-4">
                  <CardTitle className="text-sm font-medium flex items-center">
                    <Users className="h-4 w-4 mr-1 text-muted-foreground" />
                    לקוחות חדשים
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold">{newCustomersCount}</div>
                  <p className="text-xs text-muted-foreground">{newCustomersCount === 0 ? "אין נתונים עדיין" : ""}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="p-4">
                  <CardTitle className="text-sm font-medium flex items-center">
                    <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
                    זמן ממוצע לטיפול
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold">{averageDuration} דקות</div>
                  <p className="text-xs text-muted-foreground">{averageDuration === 0 ? "אין נתונים עדיין" : ""}</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader className="p-4">
                <CardTitle className="text-sm font-medium">התראות חדשות</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                {unreadNotifications.length > 0 ? (
                  <div className="space-y-3">
                    {unreadNotifications.map((notification) => (
                      <div
                        key={notification.id}
                        className="flex justify-between items-center p-3 bg-pink-50 rounded-md"
                      >
                        <div className="flex items-center">
                          <Bell className="h-4 w-4 text-pink-500 mr-2" />
                          <div>
                            <p className="text-sm">{notification.message}</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(notification.date).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleMarkAsRead(notification.id)}
                          type="button"
                        >
                          סמן כנקרא
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">אין התראות חדשות</div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="p-4">
                <CardTitle className="text-sm font-medium">תורים להיום</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                {todayAppointments.length > 0 ? (
                  <ul className="list-none p-0">
                    {todayAppointments.map((appointment) => (
                      <li key={appointment.id} className="py-2">
                        {appointment.customerName} - {appointment.time} - {appointment.serviceName}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">אין תורים להיום</div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="p-4">
                <CardTitle className="text-sm font-medium">תורים למחר</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                {tomorrowAppointments.length > 0 ? (
                  <ul className="list-none p-0">
                    {tomorrowAppointments.map((appointment) => (
                      <li key={appointment.id} className="py-2">
                        {appointment.customerName} - {appointment.time} - {appointment.serviceName}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">אין תורים למחר</div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pending">
            <Card>
              <CardHeader className="p-4">
                <CardTitle className="text-lg">תורים ממתינים לאישור</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                {groupedPendingAppointments.length > 0 || groupedWaitlistAppointments.length > 0 ? (
                  <div className="space-y-6">
                    {groupedPendingAppointments.length > 0 && (
                      <div>
                        <h3 className="text-lg font-medium mb-4 flex items-center">
                          <Calendar className="h-5 w-5 mr-2 text-pink-500" />
                          תורים ממתינים לאישור
                        </h3>
                        <div className="space-y-4">
                          {groupedPendingAppointments.map((appointment, index) => {
                            // Calculate end time based on all services
                            const endTime = calculateEndTime(appointment)

                            return (
                              <div
                                key={index}
                                className="border rounded-lg p-4 bg-white shadow-sm hover:shadow-md transition-all"
                              >
                                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                                  <div className="flex items-center">
                                    <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center text-pink-600 mr-3">
                                      {appointment.customerName.charAt(0)}
                                    </div>
                                    <div>
                                      <h3 className="font-medium text-lg">{appointment.customerName}</h3>
                                      <div className="flex items-center text-sm text-gray-500">
                                        <Calendar className="h-3.5 w-3.5 mr-1" />
                                        <span>{appointment.date}</span>
                                        <Clock className="h-3.5 w-3.5 mr-1 ml-2" />
                                        <span>
                                          {appointment.time} - {endTime}
                                        </span>
                                      </div>
                                      <div className="text-sm mt-1">
                                        {appointment.services.map((service, idx) => (
                                          <div key={idx} className="text-pink-600">
                                            {service.name}
                                            {idx < appointment.services.length - 1 ? ", " : ""}
                                          </div>
                                        ))}
                                        <div className="font-medium mt-1">סה"כ: ₪{appointment.totalPrice}</div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex gap-2 w-full sm:w-auto">
                                    <Button
                                      className="flex-1 sm:flex-initial bg-green-500 hover:bg-green-600"
                                      onClick={() => handleApproveAppointment(appointment)}
                                      type="button"
                                    >
                                      <Check className="mr-2 h-4 w-4" /> אישור
                                    </Button>
                                    <Button
                                      variant="outline"
                                      className="flex-1 sm:flex-initial text-red-500 border-red-200 hover:bg-red-50"
                                      onClick={() => handleRejectAppointment(appointment)}
                                      type="button"
                                    >
                                      <X className="mr-2 h-4 w-4" /> ביטול
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    )}

                    {groupedWaitlistAppointments.length > 0 && (
                      <div>
                        <h3 className="text-lg font-medium mb-4 flex items-center">
                          <Clock className="h-5 w-5 mr-2 text-pink-500" />
                          רשימת המתנה
                        </h3>
                        <div className="space-y-4">
                          {groupedWaitlistAppointments.map((appointment, index) => (
                            <div
                              key={index}
                              className="border rounded-lg p-4 bg-white shadow-sm hover:shadow-md transition-all"
                            >
                              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                                <div className="flex items-center">
                                  <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center text-pink-600 mr-3">
                                    {appointment.customerName.charAt(0)}
                                  </div>
                                  <div>
                                    <h3 className="font-medium text-lg">{appointment.customerName}</h3>
                                    <div className="flex items-center text-sm text-gray-500">
                                      <Calendar className="h-3.5 w-3.5 mr-1" />
                                      <span>{appointment.date}</span>
                                    </div>
                                    <div className="text-sm mt-1">
                                      {appointment.services.map((service, idx) => (
                                        <div key={idx} className="text-pink-600">
                                          {service.name}
                                          {idx < appointment.services.length - 1 ? ", " : ""}
                                        </div>
                                      ))}
                                      <div className="font-medium mt-1">סה"כ: ₪{appointment.totalPrice}</div>
                                    </div>
                                  </div>
                                </div>
                                <div>
                                  <Button
                                    className="bg-blue-500 hover:bg-blue-600"
                                    onClick={() => openScheduleWaitlistDialog(appointment)}
                                    type="button"
                                  >
                                    קבע תור
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">אין תורים ממתינים לאישור</div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="calendar">
            <Card>
              <CardHeader className="p-4">
                <CardTitle className="text-lg">יומן חודשי</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <MonthlyCalendar />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Schedule Waitlist Dialog */}
      {isScheduleWaitlistDialogOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-lg font-medium mb-4">קביעת תור מרשימת המתנה</h2>
            <p className="mb-4">
              בחר שעה עבור התור של {selectedWaitlistAppointment?.customerName} בתאריך{" "}
              {selectedWaitlistAppointment?.date}:
            </p>

            <div className="mb-4">
              <label htmlFor="scheduleTime" className="block text-sm font-medium text-gray-700">
                בחר שעה:
              </label>
              <select
                id="scheduleTime"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-pink-500 focus:ring-pink-500 sm:text-sm"
                value={scheduleTime}
                onChange={(e) => setScheduleTime(e.target.value)}
              >
                <option value="">בחר שעה</option>
                {availableTimesForWaitlist.map((time) => (
                  <option key={time} value={time}>
                    {time}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setIsScheduleWaitlistDialogOpen(false)} type="button">
                ביטול
              </Button>
              <Button onClick={handleScheduleWaitlistAppointment} type="button">
                קבע תור
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
