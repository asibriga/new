"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { Download, Upload, AlertCircle, Database, FileText, Users, Calendar, ShoppingBag, Settings } from "lucide-react"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"

export default function DataManagementPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("export")
  const [exportData, setExportData] = useState("")
  const [importData, setImportData] = useState("")
  const [isExporting, setIsExporting] = useState(false)
  const [isImporting, setIsImporting] = useState(false)
  const [exportProgress, setExportProgress] = useState(0)
  const [importProgress, setImportProgress] = useState(0)
  const [exportOptions, setExportOptions] = useState({
    customers: true,
    appointments: true,
    services: true,
    products: true,
    orders: true,
    users: true,
    settings: true,
    transactions: true,
    invoices: true,
    logs: true,
    analytics: true,
    loyalty: true,
    coupons: true,
    notifications: true,
  })
  const [importOptions, setImportOptions] = useState({
    customers: true,
    appointments: true,
    services: true,
    products: true,
    orders: true,
    users: true,
    settings: true,
    transactions: true,
    invoices: true,
    logs: true,
    analytics: true,
    loyalty: true,
    coupons: true,
    notifications: true,
  })
  const [exportedFileName, setExportedFileName] = useState("")
  const downloadLinkRef = useRef<HTMLAnchorElement>(null)

  // Use refs to store interval IDs
  const exportIntervalRef = useRef<any>(null)
  const importIntervalRef = useRef<any>(null)

  // Clean up intervals on unmount
  useEffect(() => {
    return () => {
      if (exportIntervalRef.current) clearInterval(exportIntervalRef.current)
      if (importIntervalRef.current) clearInterval(importIntervalRef.current)
    }
  }, [])

  // Get all data from store - use function to get fresh data instead of storing in state
  const getStoreData = () => {
    const state = useStore.getState()
    return {
      customers: state.customers || [],
      appointments: state.appointments || [],
      services: state.services || [],
      products: state.products || [],
      orders: state.orders || [],
      holidays: state.holidays || [],
      closedDays: state.closedDays || [],
      twilioSettings: state.twilioSettings || {},
      transactions: state.transactions || [],
      newsletterSubscribers: state.newsletterSubscribers || [],
      siteContent: state.siteContent || {},
      logs: state.logs || [],
      analytics: state.analytics || {},
      invoices: state.invoices || [],
      appointmentTips: state.appointmentTips || {},
      loggedInCustomerId: state.loggedInCustomerId || "",
      // Add loyalty data
      loyaltySettings: state.loyaltySettings || {},
      loyaltyTiers: state.loyaltyTiers || [],
      loyaltyRewards: state.loyaltyRewards || [],
      // Add coupons
      coupons: state.coupons || [],
      notifications: state.notifications || [],
      cart: state.cart || [],
      // Add customer reward history
      rewardHistory: (state.customers || []).reduce((acc, customer) => {
        if (customer.rewardHistory) {
          acc[customer.id] = customer.rewardHistory
        }
        return acc
      }, {}),
      // Add referral codes
      referralCodes: (state.customers || []).reduce((acc, customer) => {
        if (customer.referralCode) {
          acc[customer.id] = customer.referralCode
        }
        return acc
      }, {}),
    }
  }

  // Handle export
  const handleExport = () => {
    // Clear any existing interval
    if (exportIntervalRef.current) {
      clearInterval(exportIntervalRef.current)
    }

    setIsExporting(true)
    setExportProgress(0)

    // Simulate progress
    exportIntervalRef.current = setInterval(() => {
      setExportProgress((prev) => {
        if (prev >= 95) {
          clearInterval(exportIntervalRef.current)
          return 95
        }
        return prev + 5
      })
    }, 100)

    try {
      // Get fresh data
      const storeData = getStoreData()

      // Filter data based on export options
      const dataToExport: any = {}

      if (exportOptions.customers) {
        dataToExport.customers = storeData.customers
      }

      if (exportOptions.appointments) {
        dataToExport.appointments = storeData.appointments
      }

      if (exportOptions.services) {
        dataToExport.services = storeData.services
      }

      if (exportOptions.products) {
        dataToExport.products = storeData.products
      }

      if (exportOptions.orders) {
        dataToExport.orders = storeData.orders
      }

      if (exportOptions.users) {
        dataToExport.newsletterSubscribers = storeData.newsletterSubscribers
        dataToExport.loggedInCustomerId = storeData.loggedInCustomerId
      }

      if (exportOptions.settings) {
        dataToExport.holidays = storeData.holidays
        dataToExport.closedDays = storeData.closedDays
        dataToExport.twilioSettings = storeData.twilioSettings
        dataToExport.siteContent = storeData.siteContent
        dataToExport.appointmentTips = storeData.appointmentTips
      }

      if (exportOptions.transactions) {
        dataToExport.transactions = storeData.transactions
      }

      if (exportOptions.invoices) {
        dataToExport.invoices = storeData.invoices
      }

      if (exportOptions.logs) {
        dataToExport.logs = storeData.logs
      }

      if (exportOptions.analytics) {
        dataToExport.analytics = storeData.analytics
      }

      if (exportOptions.loyalty) {
        dataToExport.loyaltySettings = storeData.loyaltySettings
        dataToExport.loyaltyTiers = storeData.loyaltyTiers
        dataToExport.loyaltyRewards = storeData.loyaltyRewards
      }

      if (exportOptions.coupons) {
        dataToExport.coupons = storeData.coupons
      }

      if (exportOptions.notifications) {
        dataToExport.notifications = storeData.notifications
      }

      // Convert to JSON
      const jsonData = JSON.stringify(dataToExport, null, 2)
      setExportData(jsonData)

      // Create download link
      const blob = new Blob([jsonData], { type: "application/json" })
      const url = URL.createObjectURL(blob)
      const fileName = `may-beauty-data-${new Date().toISOString().split("T")[0]}.json`
      setExportedFileName(fileName)

      // Create a hidden download link and trigger it programmatically
      if (downloadLinkRef.current) {
        downloadLinkRef.current.href = url
        downloadLinkRef.current.download = fileName

        // Wait for progress to complete
        setTimeout(() => {
          if (downloadLinkRef.current) {
            downloadLinkRef.current.click()
          }
          URL.revokeObjectURL(url)
          setIsExporting(false)
          setExportProgress(100)

          toast({
            title: "ייצוא הושלם בהצלחה",
            description: `הנתונים יוצאו בהצלחה לקובץ ${fileName}`,
          })
        }, 1500)
      } else {
        // Fallback if ref is not available
        const a = document.createElement("a")
        a.href = url
        a.download = fileName
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(url)

        setTimeout(() => {
          setIsExporting(false)
          setExportProgress(100)

          toast({
            title: "ייצוא הושלם בהצלחה",
            description: `הנתונים יוצאו בהצלחה לקובץ ${fileName}`,
          })
        }, 1500)
      }
    } catch (error) {
      console.error("Error exporting data:", error)
      setIsExporting(false)
      clearInterval(exportIntervalRef.current)

      toast({
        title: "שגיאה בייצוא הנתונים",
        description: "אירעה שגיאה בעת ייצוא הנתונים. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  // Handle import
  const handleImport = () => {
    if (!importData) {
      toast({
        title: "שגיאה",
        description: "אנא הזן נתונים לייבוא",
        variant: "destructive",
      })
      return
    }

    // Clear any existing interval
    if (importIntervalRef.current) {
      clearInterval(importIntervalRef.current)
    }

    setIsImporting(true)
    setImportProgress(0)

    // Simulate progress
    importIntervalRef.current = setInterval(() => {
      setImportProgress((prev) => {
        if (prev >= 95) {
          clearInterval(importIntervalRef.current)
          return 95
        }
        return prev + 5
      })
    }, 100)

    try {
      // Parse JSON data
      const parsedData = JSON.parse(importData)

      // Create a single update object to avoid multiple state updates
      const updatedState: any = {}

      // Only include data that should be imported based on options
      if (importOptions.customers && parsedData.customers) {
        updatedState.customers = parsedData.customers
      }

      if (importOptions.appointments && parsedData.appointments) {
        updatedState.appointments = parsedData.appointments
      }

      if (importOptions.services && parsedData.services) {
        updatedState.services = parsedData.services
      }

      if (importOptions.products && parsedData.products) {
        updatedState.products = parsedData.products
      }

      if (importOptions.orders && parsedData.orders) {
        updatedState.orders = parsedData.orders
      }

      if (importOptions.users) {
        if (parsedData.newsletterSubscribers) updatedState.newsletterSubscribers = parsedData.newsletterSubscribers
        if (parsedData.loggedInCustomerId) updatedState.loggedInCustomerId = parsedData.loggedInCustomerId
      }

      if (importOptions.settings) {
        if (parsedData.holidays) updatedState.holidays = parsedData.holidays
        if (parsedData.closedDays) updatedState.closedDays = parsedData.closedDays
        if (parsedData.twilioSettings) updatedState.twilioSettings = parsedData.twilioSettings
        if (parsedData.siteContent) updatedState.siteContent = parsedData.siteContent
        if (parsedData.appointmentTips) updatedState.appointmentTips = parsedData.appointmentTips
      }

      if (importOptions.transactions && parsedData.transactions) {
        updatedState.transactions = parsedData.transactions
      }

      if (importOptions.invoices && parsedData.invoices) {
        updatedState.invoices = parsedData.invoices
      }

      if (importOptions.logs && parsedData.logs) {
        updatedState.logs = parsedData.logs
      }

      if (importOptions.analytics && parsedData.analytics) {
        updatedState.analytics = parsedData.analytics
      }

      if (importOptions.loyalty) {
        if (parsedData.loyaltySettings) updatedState.loyaltySettings = parsedData.loyaltySettings
        if (parsedData.loyaltyTiers) updatedState.loyaltyTiers = parsedData.loyaltyTiers
        if (parsedData.loyaltyRewards) updatedState.loyaltyRewards = parsedData.loyaltyRewards
      }

      if (importOptions.coupons && parsedData.coupons) {
        updatedState.coupons = parsedData.coupons
      }

      if (importOptions.notifications && parsedData.notifications) {
        updatedState.notifications = parsedData.notifications
      }

      // Apply all updates at once to avoid cascading updates
      if (Object.keys(updatedState).length > 0) {
        useStore.setState(updatedState)
      }

      // Wait for progress to complete
      setTimeout(() => {
        setIsImporting(false)
        setImportProgress(100)
        setImportData("")

        toast({
          title: "ייבוא הושלם בהצלחה",
          description: "הנתונים יובאו בהצלחה למערכת",
        })
      }, 2000)
    } catch (error) {
      console.error("Error importing data:", error)
      setIsImporting(false)
      clearInterval(importIntervalRef.current)

      toast({
        title: "שגיאה בייבוא הנתונים",
        description: "אירעה שגיאה בעת ייבוא הנתונים. אנא ודא שהפורמט תקין ונסה שנית.",
        variant: "destructive",
      })
    }
  }

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string
        if (content) {
          setImportData(content)
        }
      } catch (error) {
        console.error("Error reading file:", error)
        toast({
          title: "שגיאה בקריאת הקובץ",
          description: "אירעה שגיאה בעת קריאת הקובץ. אנא ודא שהקובץ תקין ונסה שנית.",
          variant: "destructive",
        })
      }
    }
    reader.readAsText(file)
  }

  // Handle checkbox change without causing re-renders
  const handleExportOptionChange = (option: string, checked: boolean) => {
    setExportOptions((prev) => ({ ...prev, [option]: checked }))
  }

  const handleImportOptionChange = (option: string, checked: boolean) => {
    setImportOptions((prev) => ({ ...prev, [option]: checked }))
  }

  // Export to CSV
  const handleExportCSV = (dataType: string) => {
    try {
      const storeData = getStoreData()
      let dataToExport: any[] = []
      let headers: string[] = []
      let fileName = ""

      switch (dataType) {
        case "customers":
          dataToExport = storeData.customers
          headers = ["id", "name", "phone", "email", "loyaltyPoints", "visits", "createdAt"]
          fileName = "customers.csv"
          break
        case "appointments":
          dataToExport = storeData.appointments
          headers = ["id", "customerId", "customerName", "serviceId", "serviceName", "date", "time", "status", "price"]
          fileName = "appointments.csv"
          break
        case "orders":
          dataToExport = storeData.orders
          headers = ["id", "customerId", "customerName", "date", "total", "status", "paymentMethod"]
          fileName = "orders.csv"
          break
        default:
          throw new Error("Invalid data type")
      }

      // Create CSV content
      let csvContent = headers.join(",") + "\n"

      dataToExport.forEach((item) => {
        const row = headers.map((header) => {
          const value = item[header]
          // Handle special cases like arrays or objects
          if (typeof value === "object" && value !== null) {
            return `"${JSON.stringify(value).replace(/"/g, '""')}"`
          }
          // Handle strings with commas
          if (typeof value === "string" && value.includes(",")) {
            return `"${value.replace(/"/g, '""')}"`
          }
          return value !== undefined && value !== null ? value : ""
        })
        csvContent += row.join(",") + "\n"
      })

      // Create download link
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = fileName
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      toast({
        title: "ייצוא CSV הושלם בהצלחה",
        description: `הנתונים יוצאו בהצלחה לקובץ ${fileName}`,
      })
    } catch (error) {
      console.error("Error exporting CSV:", error)
      toast({
        title: "שגיאה בייצוא CSV",
        description: "אירעה שגיאה בעת ייצוא הנתונים. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">ניהול נתונים</h1>
      </div>

      {/* Hidden download link for export */}
      <a ref={downloadLinkRef} style={{ display: "none" }} />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 gap-2 mb-6">
              <TabsTrigger value="export">ייצוא נתונים</TabsTrigger>
              <TabsTrigger value="import">ייבוא נתונים</TabsTrigger>
            </TabsList>

            <TabsContent value="export">
              <Card>
                <CardHeader>
                  <CardTitle>ייצוא נתונים</CardTitle>
                  <CardDescription>ייצא את נתוני האתר לקובץ JSON לגיבוי או העברה</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>שים לב</AlertTitle>
                      <AlertDescription>
                        ייצוא הנתונים יכלול את כל המידע שנבחר למטה. שמור את הקובץ במקום בטוח.
                      </AlertDescription>
                    </Alert>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                      <div className="space-y-2">
                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.customers}
                            onChange={(e) => handleExportOptionChange("customers", e.target.checked)}
                            className="mr-2"
                          />
                          <Users className="h-4 w-4 mr-2" />
                          <span>לקוחות</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.appointments}
                            onChange={(e) => handleExportOptionChange("appointments", e.target.checked)}
                            className="mr-2"
                          />
                          <Calendar className="h-4 w-4 mr-2" />
                          <span>תורים</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.services}
                            onChange={(e) => handleExportOptionChange("services", e.target.checked)}
                            className="mr-2"
                          />
                          <FileText className="h-4 w-4 mr-2" />
                          <span>שירותים</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.products}
                            onChange={(e) => handleExportOptionChange("products", e.target.checked)}
                            className="mr-2"
                          />
                          <ShoppingBag className="h-4 w-4 mr-2" />
                          <span>מוצרים</span>
                        </Label>
                      </div>

                      <div className="space-y-2">
                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.orders}
                            onChange={(e) => handleExportOptionChange("orders", e.target.checked)}
                            className="mr-2"
                          />
                          <Database className="h-4 w-4 mr-2" />
                          <span>הזמנות</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.settings}
                            onChange={(e) => handleExportOptionChange("settings", e.target.checked)}
                            className="mr-2"
                          />
                          <Settings className="h-4 w-4 mr-2" />
                          <span>הגדרות</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.transactions}
                            onChange={(e) => handleExportOptionChange("transactions", e.target.checked)}
                            className="mr-2"
                          />
                          <Database className="h-4 w-4 mr-2" />
                          <span>עסקאות</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.invoices}
                            onChange={(e) => handleExportOptionChange("invoices", e.target.checked)}
                            className="mr-2"
                          />
                          <FileText className="h-4 w-4 mr-2" />
                          <span>חשבוניות</span>
                        </Label>
                      </div>

                      <div className="space-y-2">
                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.logs}
                            onChange={(e) => handleExportOptionChange("logs", e.target.checked)}
                            className="mr-2"
                          />
                          <FileText className="h-4 w-4 mr-2" />
                          <span>לוגים</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.analytics}
                            onChange={(e) => handleExportOptionChange("analytics", e.target.checked)}
                            className="mr-2"
                          />
                          <Database className="h-4 w-4 mr-2" />
                          <span>אנליטיקס</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.users}
                            onChange={(e) => handleExportOptionChange("users", e.target.checked)}
                            className="mr-2"
                          />
                          <Users className="h-4 w-4 mr-2" />
                          <span>משתמשים</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={exportOptions.loyalty}
                            onChange={(e) => handleExportOptionChange("loyalty", e.target.checked)}
                            className="mr-2"
                          />
                          <Users className="h-4 w-4 mr-2" />
                          <span>נאמנות</span>
                        </Label>
                      </div>
                    </div>

                    <div className="mt-6">
                      <h3 className="text-lg font-medium mb-3">ייצוא מהיר (CSV)</h3>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          variant="outline"
                          onClick={() => handleExportCSV("customers")}
                          className="flex items-center"
                        >
                          <Download className="mr-2 h-4 w-4" />
                          ייצוא לקוחות
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => handleExportCSV("appointments")}
                          className="flex items-center"
                        >
                          <Download className="mr-2 h-4 w-4" />
                          ייצוא תורים
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => handleExportCSV("orders")}
                          className="flex items-center"
                        >
                          <Download className="mr-2 h-4 w-4" />
                          ייצוא הזמנות
                        </Button>
                      </div>
                    </div>

                    {isExporting && (
                      <div className="mt-4">
                        <Label>התקדמות הייצוא</Label>
                        <Progress value={exportProgress} className="mt-2" />
                        {exportProgress === 100 && exportedFileName && (
                          <p className="text-sm text-green-600 mt-2">
                            הייצוא הושלם בהצלחה! הקובץ {exportedFileName} הורד למחשב שלך.
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={() => console.log("TODO: Add functionality")}>ביטול</Button>
                  <Button onClick={handleExport} disabled={isExporting} className="bg-pink-500 hover:bg-pink-600">
                    <Download className="mr-2 h-4 w-4" />
                    {isExporting ? "מייצא..." : "ייצוא נתונים"}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="import">
              <Card>
                <CardHeader>
                  <CardTitle>ייבוא נתונים</CardTitle>
                  <CardDescription>ייבא נתונים מקובץ JSON שיוצא בעבר</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>אזהרה</AlertTitle>
                      <AlertDescription>
                        ייבוא נתונים יחליף את הנתונים הקיימים במערכת. מומלץ לגבות את הנתונים הנוכחיים לפני הייבוא.
                      </AlertDescription>
                    </Alert>

                    <div className="grid grid-cols-1 gap-4 mt-4">
                      <div>
                        <Label htmlFor="import-file">בחר קובץ לייבוא</Label>
                        <Input
                          id="import-file"
                          type="file"
                          accept=".json"
                          onChange={handleFileUpload}
                          className="mt-2"
                        />
                      </div>

                      <div>
                        <Label htmlFor="import-data">או הדבק את תוכן ה-JSON</Label>
                        <Textarea
                          id="import-data"
                          value={importData}
                          onChange={(e) => setImportData(e.target.value)}
                          placeholder='{"customers": [], "appointments": [], ...}'
                          className="mt-2 font-mono text-sm h-32"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                      <div className="space-y-2">
                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.customers}
                            onChange={(e) => handleImportOptionChange("customers", e.target.checked)}
                            className="mr-2"
                          />
                          <Users className="h-4 w-4 mr-2" />
                          <span>לקוחות</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.appointments}
                            onChange={(e) => handleImportOptionChange("appointments", e.target.checked)}
                            className="mr-2"
                          />
                          <Calendar className="h-4 w-4 mr-2" />
                          <span>תורים</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.services}
                            onChange={(e) => handleImportOptionChange("services", e.target.checked)}
                            className="mr-2"
                          />
                          <FileText className="h-4 w-4 mr-2" />
                          <span>שירותים</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.products}
                            onChange={(e) => handleImportOptionChange("products", e.target.checked)}
                            className="mr-2"
                          />
                          <ShoppingBag className="h-4 w-4 mr-2" />
                          <span>מוצרים</span>
                        </Label>
                      </div>

                      <div className="space-y-2">
                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.orders}
                            onChange={(e) => handleImportOptionChange("orders", e.target.checked)}
                            className="mr-2"
                          />
                          <Database className="h-4 w-4 mr-2" />
                          <span>הזמנות</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.settings}
                            onChange={(e) => handleImportOptionChange("settings", e.target.checked)}
                            className="mr-2"
                          />
                          <Settings className="h-4 w-4 mr-2" />
                          <span>הגדרות</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.transactions}
                            onChange={(e) => handleImportOptionChange("transactions", e.target.checked)}
                            className="mr-2"
                          />
                          <Database className="h-4 w-4 mr-2" />
                          <span>עסקאות</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.invoices}
                            onChange={(e) => handleImportOptionChange("invoices", e.target.checked)}
                            className="mr-2"
                          />
                          <FileText className="h-4 w-4 mr-2" />
                          <span>חשבוניות</span>
                        </Label>
                      </div>

                      <div className="space-y-2">
                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.logs}
                            onChange={(e) => handleImportOptionChange("logs", e.target.checked)}
                            className="mr-2"
                          />
                          <FileText className="h-4 w-4 mr-2" />
                          <span>לוגים</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.analytics}
                            onChange={(e) => handleImportOptionChange("analytics", e.target.checked)}
                            className="mr-2"
                          />
                          <Database className="h-4 w-4 mr-2" />
                          <span>אנליטיקס</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.users}
                            onChange={(e) => handleImportOptionChange("users", e.target.checked)}
                            className="mr-2"
                          />
                          <Users className="h-4 w-4 mr-2" />
                          <span>משתמשים</span>
                        </Label>

                        <Label className="flex items-center space-x-2 rtl:space-x-reverse">
                          <input
                            type="checkbox"
                            checked={importOptions.loyalty}
                            onChange={(e) => handleImportOptionChange("loyalty", e.target.checked)}
                            className="mr-2"
                          />
                          <Users className="h-4 w-4 mr-2" />
                          <span>נאמנות</span>
                        </Label>
                      </div>
                    </div>

                    {isImporting && (
                      <div className="mt-4">
                        <Label>התקדמות הייבוא</Label>
                        <Progress value={importProgress} className="mt-2" />
                        {importProgress === 100 && (
                          <p className="text-sm text-green-600 mt-2">הייבוא הושלם בהצלחה! הנתונים נטענו למערכת.</p>
                        )}
                      </div>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={() => console.log("TODO: Add functionality")}>ביטול</Button>
                  <Button
                    onClick={handleImport}
                    disabled={isImporting || !importData}
                    className="bg-pink-500 hover:bg-pink-600"
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    {isImporting ? "מייבא..." : "ייבוא נתונים"}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>מידע על ניהול נתונים</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">ייצוא נתונים</h3>
                <p className="text-sm text-gray-500">
                  ייצוא הנתונים מאפשר לך לשמור גיבוי של כל המידע במערכת. השתמש באפשרות זו לפני עדכון גרסה או כגיבוי
                  תקופתי.
                </p>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">ייבוא נתונים</h3>
                <p className="text-sm text-gray-500">
                  ייבוא נתונים מאפשר לך להחזיר מידע מגיבוי קודם או להעביר מידע בין מערכות. שים לב שייבוא יחליף את
                  הנתונים הקיימים.
                </p>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">תדירות גיבוי מומלצת</h3>
                <ul className="text-sm text-gray-500 space-y-1 list-disc list-inside">
                  <li>גיבוי שבועי של כל הנתונים</li>
                  <li>גיבוי לפני כל עדכון גרסה</li>
                  <li>גיבוי לאחר הוספת נתונים בכמות גדולה</li>
                </ul>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">פורמטים נתמכים</h3>
                <ul className="text-sm text-gray-500 space-y-1 list-disc list-inside">
                  <li>JSON - לגיבוי מלא של כל הנתונים</li>
                  <li>CSV - לייצוא מהיר של נתונים ספציפיים</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
