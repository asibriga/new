"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, Eye, User, Package, CreditCard } from "lucide-react"
import { useStore } from "@/lib/store"
import { useToast } from "@/hooks/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { format } from "date-fns"
import { he } from "date-fns/locale"

export default function OrdersPage() {
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedOrder, setSelectedOrder] = useState(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [filterStatus, setFilterStatus] = useState("all")
  const [isMobile, setIsMobile] = useState(false)

  // Get orders from store
  const orders = useStore((state) => state.orders) || []
  const updateOrder = useStore((state) => state.updateOrder)
  const products = useStore((state) => state.products) || []

  // Check if mobile
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)

    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  // Filter orders based on search term and status
  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customerPhone?.includes(searchTerm) ||
      order.id?.includes(searchTerm)

    const matchesStatus = filterStatus === "all" || order.status === filterStatus

    return matchesSearch && matchesStatus
  })

  const handleViewOrder = (order) => {
    setSelectedOrder(order)
    setIsViewDialogOpen(true)
  }

  const handleUpdateStatus = (id, status) => {
    updateOrder(id, { status })

    toast({
      title: "סטטוס הזמנה עודכן",
      description: `סטטוס ההזמנה עודכן ל${getStatusText(status)}`,
    })

    if (selectedOrder && selectedOrder.id === id) {
      setSelectedOrder({ ...selectedOrder, status })
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="text-orange-500 border-orange-500">
            ממתינה
          </Badge>
        )
      case "paid":
        return <Badge className="bg-blue-500">שולמה</Badge>
      case "completed":
        return <Badge className="bg-green-500">הושלמה</Badge>
      case "cancelled":
        return <Badge variant="destructive">בוטלה</Badge>
      default:
        return null
    }
  }

  const getStatusText = (status) => {
    switch (status) {
      case "pending":
        return "ממתינה"
      case "paid":
        return "שולמה"
      case "completed":
        return "הושלמה"
      case "cancelled":
        return "בוטלה"
      default:
        return status
    }
  }

  const getPaymentMethodText = (method) => {
    switch (method) {
      case "bit":
        return "ביט"
      case "cash":
        return "מזומן"
      case "credit_card":
        return "כרטיס אשראי"
      default:
        return method
    }
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return format(date, "dd/MM/yyyy", { locale: he })
  }

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">ניהול הזמנות</h1>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle>הזמנות</CardTitle>
              <CardDescription>רשימת כל ההזמנות במערכת</CardDescription>
            </div>
            <div className="relative w-full md:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="חיפוש הזמנות..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="grid grid-cols-4 mb-4">
              <TabsTrigger value="all" onClick={() => setFilterStatus("all")}>
                כל ההזמנות
              </TabsTrigger>
              <TabsTrigger value="pending" onClick={() => setFilterStatus("pending")}>
                ממתינות
              </TabsTrigger>
              <TabsTrigger value="paid" onClick={() => setFilterStatus("paid")}>
                שולמו
              </TabsTrigger>
              <TabsTrigger value="completed" onClick={() => setFilterStatus("completed")}>
                הושלמו
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              {isMobile ? (
                <div className="space-y-4">
                  {filteredOrders.length > 0 ? (
                    filteredOrders.map((order) => (
                      <Card key={order.id} className="overflow-hidden border-l-4 border-l-pink-500">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h3 className="font-medium text-lg">#{order.id.slice(-6)}</h3>
                              <p className="text-sm text-gray-500">{formatDate(order.date)}</p>
                            </div>
                            {getStatusBadge(order.status)}
                          </div>

                          <div className="mt-2">
                            <div className="flex items-center mb-1">
                              <User className="h-4 w-4 mr-1 text-gray-400" />
                              <span className="font-medium">{order.customerName}</span>
                            </div>
                            <div className="flex items-center mb-1">
                              <Package className="h-4 w-4 mr-1 text-gray-400" />
                              <span>{order.items?.length || 0} פריטים</span>
                            </div>
                            <div className="flex items-center mb-1">
                              <CreditCard className="h-4 w-4 mr-1 text-gray-400" />
                              <span>{getPaymentMethodText(order.paymentMethod)}</span>
                            </div>
                          </div>

                          <div className="mt-2 text-lg font-bold text-pink-600">₪{order.total}</div>

                          <div className="flex justify-end mt-3 gap-2">
                            <Button variant="outline" size="sm" onClick={() => handleViewOrder(order)}>
                              <Eye className="h-4 w-4 mr-1" />
                              צפייה
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="outline" size="sm" onClick={() => console.log("TODO: Add functionality")}>
                                  עדכון סטטוס
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent>
                                <DropdownMenuItem
                                  onClick={() => {
                                    handleUpdateStatus(order.id, "pending")
                                    toast({
                                      title: "סטטוס הזמנה עודכן",
                                      description: "ההזמנה סומנה כממתינה",
                                    })
                                  }}
                                >
                                  ממתינה
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => {
                                    handleUpdateStatus(order.id, "paid")
                                    toast({
                                      title: "סטטוס הזמנה עודכן",
                                      description: "ההזמנה סומנה כשולמה",
                                    })
                                  }}
                                >
                                  שולמה
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => {
                                    handleUpdateStatus(order.id, "completed")
                                    toast({
                                      title: "סטטוס הזמנה עודכן",
                                      description: "ההזמנה סומנה כהושלמה",
                                    })
                                  }}
                                >
                                  הושלמה
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => {
                                    if (confirm("האם אתה בטוח שברצונך לבטל את ההזמנה?")) {
                                      handleUpdateStatus(order.id, "cancelled")
                                      toast({
                                        title: "סטטוס הזמנה עודכן",
                                        description: "ההזמנה סומנה כבוטלה",
                                      })
                                    }
                                  }}
                                >
                                  בוטלה
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-12">
                      <p className="text-muted-foreground">לא נמצאו הזמנות</p>
                    </div>
                  )}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>מס' הזמנה</TableHead>
                      <TableHead>תאריך</TableHead>
                      <TableHead>לקוח/ה</TableHead>
                      <TableHead>סכום</TableHead>
                      <TableHead>אמצעי תשלום</TableHead>
                      <TableHead>סטטוס</TableHead>
                      <TableHead>פעולות</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredOrders.length > 0 ? (
                      filteredOrders.map((order) => (
                        <TableRow key={order.id}>
                          <TableCell>#{order.id.slice(-6)}</TableCell>
                          <TableCell>{formatDate(order.date)}</TableCell>
                          <TableCell>{order.customerName}</TableCell>
                          <TableCell className="font-bold text-pink-600">₪{order.total}</TableCell>
                          <TableCell>{getPaymentMethodText(order.paymentMethod)}</TableCell>
                          <TableCell>{getStatusBadge(order.status)}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button variant="ghost" size="sm" onClick={() => handleViewOrder(order)}>
                                <Eye className="h-4 w-4 mr-2" />
                                צפייה
                              </Button>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="outline" size="sm" onClick={() => console.log("TODO: Add functionality")}>
                                    עדכון סטטוס
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                  <DropdownMenuItem
                                    onClick={() => {
                                      handleUpdateStatus(order.id, "pending")
                                      toast({
                                        title: "סטטוס הזמנה עודכן",
                                        description: "ההזמנה סומנה כממתינה",
                                      })
                                    }}
                                  >
                                    ממתינה
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    onClick={() => {
                                      handleUpdateStatus(order.id, "paid")
                                      toast({
                                        title: "סטטוס הזמנה עודכן",
                                        description: "ההזמנה סומנה כשולמה",
                                      })
                                    }}
                                  >
                                    שולמה
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    onClick={() => {
                                      handleUpdateStatus(order.id, "completed")
                                      toast({
                                        title: "סטטוס הזמנה עודכן",
                                        description: "ההזמנה סומנה כהושלמה",
                                      })
                                    }}
                                  >
                                    הושלמה
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    onClick={() => {
                                      if (confirm("האם אתה בטוח שברצונך לבטל את ההזמנה?")) {
                                        handleUpdateStatus(order.id, "cancelled")
                                        toast({
                                          title: "סטטוס הזמנה עודכן",
                                          description: "ההזמנה סומנה כבוטלה",
                                        })
                                      }
                                    }}
                                  >
                                    בוטלה
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-12">
                          <p className="text-muted-foreground">לא נמצאו הזמנות</p>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* דיאלוג צפייה בהזמנה */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>פרטי הזמנה #{selectedOrder?.id.slice(-6)}</DialogTitle>
            <DialogDescription>{selectedOrder && `הזמנה מתאריך ${formatDate(selectedOrder.date)}`}</DialogDescription>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h3 className="font-medium">פרטי לקוח</h3>
                  <div className="bg-gray-50 p-3 rounded-md">
                    <p>
                      <span className="font-medium">שם:</span> {selectedOrder.customerName}
                    </p>
                    <p>
                      <span className="font-medium">טלפון:</span> {selectedOrder.customerPhone}
                    </p>
                    {selectedOrder.customerEmail && (
                      <p>
                        <span className="font-medium">אימייל:</span> {selectedOrder.customerEmail}
                      </p>
                    )}
                  </div>
                </div>
                <div className="space-y-2">
                  <h3 className="font-medium">פרטי הזמנה</h3>
                  <div className="bg-gray-50 p-3 rounded-md">
                    <p>
                      <span className="font-medium">סטטוס:</span> {getStatusText(selectedOrder.status)}
                    </p>
                    <p>
                      <span className="font-medium">אמצעי תשלום:</span>{" "}
                      {getPaymentMethodText(selectedOrder.paymentMethod)}
                    </p>
                    <p>
                      <span className="font-medium">סה"כ:</span>{" "}
                      <span className="font-bold text-pink-600">₪{selectedOrder.total}</span>
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium">פריטים בהזמנה</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>מוצר</TableHead>
                      <TableHead>כמות</TableHead>
                      <TableHead>מחיר ליחידה</TableHead>
                      <TableHead>סה"כ</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedOrder.items.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell>{item.productName}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>₪{item.price}</TableCell>
                        <TableCell>₪{item.price * item.quantity}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {selectedOrder.notes && (
                <div className="space-y-2">
                  <h3 className="font-medium">הערות</h3>
                  <div className="bg-gray-50 p-3 rounded-md">
                    <p>{selectedOrder.notes}</p>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <h3 className="font-medium">עדכון סטטוס</h3>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant={selectedOrder.status === "pending" ? "default" : "outline"}
                    onClick={() => handleUpdateStatus(selectedOrder.id, "pending")}
                  >
                    ממתינה
                  </Button>
                  <Button
                    variant={selectedOrder.status === "paid" ? "default" : "outline"}
                    onClick={() => handleUpdateStatus(selectedOrder.id, "paid")}
                  >
                    שולמה
                  </Button>
                  <Button
                    variant={selectedOrder.status === "completed" ? "default" : "outline"}
                    onClick={() => handleUpdateStatus(selectedOrder.id, "completed")}
                  >
                    הושלמה
                  </Button>
                  <Button
                    variant={selectedOrder.status === "cancelled" ? "destructive" : "outline"}
                    onClick={() => handleUpdateStatus(selectedOrder.id, "cancelled")}
                  >
                    בוטלה
                  </Button>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setIsViewDialogOpen(false)}>סגירה</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
