"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { usePathname, useRouter } from "next/navigation"
import AdminMobileNav from "@/components/admin/admin-mobile-nav"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const pathname = usePathname()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Skip auth check for login page
    if (pathname === "/admin/login") {
      setIsLoading(false)
      return
    }

    // Check if user is authenticated
    const auth = localStorage.getItem("adminAuthenticated")
    if (auth !== "true") {
      router.push("/admin/login")
    } else {
      setIsAuthenticated(true)
    }
    setIsLoading(false)
  }, [pathname, router])

  // Show nothing while checking authentication
  if (isLoading) {
    return null
  }

  // For login page, just render the content
  if (pathname === "/admin/login") {
    return children
  }

  // For authenticated pages, render with admin layout
  if (isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <AdminMobileNav />
        <div className="p-4 pb-24 md:p-8">{children}</div>
      </div>
    )
  }

  return null
}
