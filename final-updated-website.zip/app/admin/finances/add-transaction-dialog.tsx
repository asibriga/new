"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { format } from "date-fns"
import { CalendarIcon } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"

export default function AddTransactionDialog({ isOpen, onClose, onAddTransaction }) {
  const { toast } = useToast()
  const [date, setDate] = useState(new Date())
  const [description, setDescription] = useState("")
  const [amount, setAmount] = useState("")
  const [type, setType] = useState("income")
  const [category, setCategory] = useState("")
  const [customCategory, setCustomCategory] = useState("")
  const [status, setStatus] = useState("completed")
  const [errors, setErrors] = useState({})

  // Predefined categories
  const incomeCategories = ["שירותים", "מוצרים", "מתנות", "אחר"]
  const expenseCategories = ["ציוד", "שכירות", "משכורות", "חשבונות", "פרסום", "מלאי", "אחר"]

  const handleSubmit = () => {
    // Validate form
    const newErrors = {}
    if (!description) newErrors.description = "יש להזין תיאור"
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) newErrors.amount = "יש להזין סכום תקין"
    if (!category && !customCategory) newErrors.category = "יש לבחור קטגוריה"

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    // Create transaction object
    const transaction = {
      date: format(date, "yyyy-MM-dd"),
      description,
      amount: Number(amount),
      type,
      category: category === "אחר" ? customCategory : category,
      status: status || "completed",
    }

    // Call parent handler
    onAddTransaction(transaction)

    // Reset form
    setDescription("")
    setAmount("")
    setType("income")
    setCategory("")
    setCustomCategory("")
    setStatus("completed")
    setErrors({})

    // Show success toast
    toast({
      title: "העסקה נוספה בהצלחה",
      description: `נוספה עסקה חדשה: ${description} - ${amount}₪`,
    })
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>הוספת עסקה חדשה</DialogTitle>
          <DialogDescription>הזן את פרטי העסקה החדשה. לחץ על שמירה כשתסיים.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="date">תאריך</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={"outline"}
                  className={cn("w-full justify-start text-right font-normal", !date && "text-muted-foreground")}
                 onClick={() => console.log("TODO: Add functionality")}>
                  <CalendarIcon className="ml-2 h-4 w-4" />
                  {date ? format(date, "dd/MM/yyyy") : "בחר תאריך"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
              </PopoverContent>
            </Popover>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="type">סוג עסקה</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger>
                <SelectValue placeholder="בחר סוג עסקה" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="income">הכנסה</SelectItem>
                <SelectItem value="expense">הוצאה</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="description">תיאור</Label>
            <Input
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className={errors.description ? "border-red-500" : ""}
            />
            {errors.description && <p className="text-red-500 text-sm">{errors.description}</p>}
          </div>
          <div className="grid gap-2">
            <Label htmlFor="amount">סכום (₪)</Label>
            <Input
              id="amount"
              type="number"
              min="0"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className={errors.amount ? "border-red-500" : ""}
            />
            {errors.amount && <p className="text-red-500 text-sm">{errors.amount}</p>}
          </div>
          <div className="grid gap-2">
            <Label htmlFor="category">קטגוריה</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className={errors.category ? "border-red-500" : ""}>
                <SelectValue placeholder="בחר קטגוריה" />
              </SelectTrigger>
              <SelectContent>
                {type === "income"
                  ? incomeCategories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))
                  : expenseCategories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
              </SelectContent>
            </Select>
            {errors.category && <p className="text-red-500 text-sm">{errors.category}</p>}
          </div>
          {category === "אחר" && (
            <div className="grid gap-2">
              <Label htmlFor="customCategory">קטגוריה מותאמת אישית</Label>
              <Input
                id="customCategory"
                value={customCategory}
                onChange={(e) => setCustomCategory(e.target.value)}
                className={errors.category ? "border-red-500" : ""}
              />
            </div>
          )}
          <div className="grid gap-2">
            <Label htmlFor="status">סטטוס</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger>
                <SelectValue placeholder="בחר סטטוס" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="completed">הושלם</SelectItem>
                <SelectItem value="pending">ממתין</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            ביטול
          </Button>
          <Button
            className="bg-pink-500 hover:bg-pink-600"
            onClick={() => {
              // Validate form
              const newErrors = {}
              if (!description) newErrors.description = "יש להזין תיאור"
              if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) newErrors.amount = "יש להזין סכום תקין"
              if (!category && !customCategory) newErrors.category = "יש לבחור קטגוריה"

              if (Object.keys(newErrors).length > 0) {
                setErrors(newErrors)
                return
              }

              // Create transaction object
              const transaction = {
                date: format(date, "yyyy-MM-dd"),
                description,
                amount: Number(amount),
                type,
                category: category === "אחר" ? customCategory : category,
                status: status || "completed",
              }

              // Call parent handler
              onAddTransaction(transaction)

              // Reset form
              setDescription("")
              setAmount("")
              setType("income")
              setCategory("")
              setCustomCategory("")
              setStatus("completed")
              setErrors({})

              // Show success toast
              toast({
                title: "העסקה נוספה בהצלחה",
                description: `נוספה עסקה חדשה: ${description} - ${amount}₪`,
              })

              // סגירת הדיאלוג
              onClose()
            }}
          >
            שמירה
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
