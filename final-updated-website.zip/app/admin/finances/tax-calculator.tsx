"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calculator } from "lucide-react"

export default function TaxCalculator() {
  const [revenue, setRevenue] = useState("")
  const [expenses, setExpenses] = useState("")
  const [taxRate, setTaxRate] = useState("17")
  const [vatRate, setVatRate] = useState("17")
  const [calculationResults, setCalculationResults] = useState(null)

  const calculateTaxes = () => {
    const revenueNum = Number.parseFloat(revenue) || 0
    const expensesNum = Number.parseFloat(expenses) || 0
    const taxRateNum = Number.parseFloat(taxRate) / 100
    const vatRateNum = Number.parseFloat(vatRate) / 100

    // Calculate profit before tax
    const profitBeforeTax = revenueNum - expensesNum

    // Calculate income tax
    const incomeTax = profitBeforeTax > 0 ? profitBeforeTax * taxRateNum : 0

    // Calculate VAT
    const vatOnRevenue = revenueNum * vatRateNum
    const vatOnExpenses = expensesNum * vatRateNum
    const netVat = vatOnRevenue - vatOnExpenses

    // Calculate profit after tax
    const profitAfterTax = profitBeforeTax - incomeTax

    // Calculate effective tax rate
    const effectiveTaxRate = profitBeforeTax > 0 ? (incomeTax / profitBeforeTax) * 100 : 0

    setCalculationResults({
      profitBeforeTax,
      incomeTax,
      vatOnRevenue,
      vatOnExpenses,
      netVat,
      profitAfterTax,
      effectiveTaxRate,
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Calculator className="mr-2 h-5 w-5" />
          מחשבון מס
        </CardTitle>
        <CardDescription>חישוב מס הכנסה ומע"מ</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="space-y-2">
            <Label htmlFor="revenue">הכנסות (₪)</Label>
            <Input
              id="revenue"
              type="number"
              min="0"
              value={revenue}
              onChange={(e) => setRevenue(e.target.value)}
              placeholder="הזן את סך ההכנסות"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="expenses">הוצאות (₪)</Label>
            <Input
              id="expenses"
              type="number"
              min="0"
              value={expenses}
              onChange={(e) => setExpenses(e.target.value)}
              placeholder="הזן את סך ההוצאות"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="taxRate">שיעור מס הכנסה (%)</Label>
            <Select value={taxRate} onValueChange={setTaxRate}>
              <SelectTrigger id="taxRate">
                <SelectValue placeholder="בחר שיעור מס" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10%</SelectItem>
                <SelectItem value="14">14%</SelectItem>
                <SelectItem value="17">17%</SelectItem>
                <SelectItem value="20">20%</SelectItem>
                <SelectItem value="23">23%</SelectItem>
                <SelectItem value="25">25%</SelectItem>
                <SelectItem value="31">31%</SelectItem>
                <SelectItem value="35">35%</SelectItem>
                <SelectItem value="47">47%</SelectItem>
                <SelectItem value="50">50%</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="vatRate">שיעור מע"מ (%)</Label>
            <Select value={vatRate} onValueChange={setVatRate}>
              <SelectTrigger id="vatRate">
                <SelectValue placeholder="בחר שיעור מע״מ" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="17">17%</SelectItem>
                <SelectItem value="0">0% (פטור ממע״מ)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button className="w-full bg-pink-500 hover:bg-pink-600 mb-4" onClick={calculateTaxes}>
          חשב מיסים
        </Button>

        {calculationResults && (
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700">רווח לפני מס</h3>
                <p
                  className={`text-xl font-bold ${calculationResults.profitBeforeTax >= 0 ? "text-green-600" : "text-red-600"}`}
                >
                  ₪
                  {calculationResults.profitBeforeTax.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700">מס הכנסה</h3>
                <p className="text-xl font-bold text-red-600">
                  ₪
                  {calculationResults.incomeTax.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-blue-700">מע"מ על הכנסות</h3>
                <p className="text-xl font-bold text-blue-600">
                  ₪
                  {calculationResults.vatOnRevenue.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-blue-700">מע"מ על הוצאות</h3>
                <p className="text-xl font-bold text-blue-600">
                  ₪
                  {calculationResults.vatOnExpenses.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-blue-700">מע"מ לתשלום</h3>
                <p className="text-xl font-bold text-blue-600">
                  ₪
                  {calculationResults.netVat.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-green-700">רווח אחרי מס</h3>
                <p
                  className={`text-xl font-bold ${calculationResults.profitAfterTax >= 0 ? "text-green-600" : "text-red-600"}`}
                >
                  ₪
                  {calculationResults.profitAfterTax.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-purple-700">שיעור מס אפקטיבי</h3>
                <p className="text-xl font-bold text-purple-600">{calculationResults.effectiveTaxRate.toFixed(2)}%</p>
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-gray-700">סיכום תשלומי מס</h3>
              <p className="text-lg font-bold text-gray-900 mt-2">
                סה"כ לתשלום: ₪
                {(calculationResults.incomeTax + calculationResults.netVat).toLocaleString(undefined, {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}
              </p>
              <div className="grid grid-cols-2 gap-4 mt-2">
                <div>
                  <p className="text-sm text-gray-600">מס הכנסה:</p>
                  <p className="font-medium">
                    ₪
                    {calculationResults.incomeTax.toLocaleString(undefined, {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">מע"מ:</p>
                  <p className="font-medium">
                    ₪
                    {calculationResults.netVat.toLocaleString(undefined, {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
