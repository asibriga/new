"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChart3, Download, FileText, LineChart, PieChart, TrendingUp } from "lucide-react"
import { useStore } from "@/lib/store"
import { format } from "date-fns"

interface FinancialReportsProps {
  dateRange: { from: Date; to: Date }
}

export function FinancialReports({ dateRange }: FinancialReportsProps) {
  const [reportPeriod, setReportPeriod] = useState("monthly")
  const [financialData, setFinancialData] = useState({
    totalIncome: 0,
    totalExpenses: 0,
    netProfit: 0,
    serviceIncome: 0,
    productIncome: 0,
    expensesByCategory: {},
  })

  // Get financial data from store
  const getFinancialSummary = useStore((state) => state.getFinancialSummary)

  // Update financial data when date range changes
  useEffect(() => {
    if (dateRange.from && dateRange.to) {
      const startDate = dateRange.from.toISOString().split("T")[0]
      const endDate = dateRange.to.toISOString().split("T")[0]

      const summary = getFinancialSummary(startDate, endDate)
      setFinancialData(summary)
    }
  }, [dateRange, getFinancialSummary])

  const handleExportReports = () => {
    // In a real implementation, this would generate and download reports
    console.log("Exporting reports for period:", reportPeriod)
    console.log("Date range:", dateRange)
    console.log("Financial data:", financialData)

    // For now, just alert the user
    alert("הדוחות יוצאו בהצלחה")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-xl font-semibold">דוחות פיננסיים</h2>
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <Select value={reportPeriod} onValueChange={setReportPeriod}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="תקופת דיווח" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">יומי</SelectItem>
              <SelectItem value="weekly">שבועי</SelectItem>
              <SelectItem value="monthly">חודשי</SelectItem>
              <SelectItem value="quarterly">רבעוני</SelectItem>
              <SelectItem value="yearly">שנתי</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={handleExportReports}>
            <Download className="h-4 w-4 mr-2" />
            ייצא דוחות
          </Button>
        </div>
      </div>

      <Tabs defaultValue="revenue" dir="rtl">
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="revenue" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            <span className="hidden md:inline">הכנסות</span>
          </TabsTrigger>
          <TabsTrigger value="expenses" className="flex items-center gap-2">
            <LineChart className="h-4 w-4" />
            <span className="hidden md:inline">הוצאות</span>
          </TabsTrigger>
          <TabsTrigger value="profit" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden md:inline">רווחיות</span>
          </TabsTrigger>
          <TabsTrigger value="tax" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            <span className="hidden md:inline">מס</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="revenue" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-semibold">דוח הכנסות {getReportPeriodText(reportPeriod)}</CardTitle>
              <CardDescription>
                {format(dateRange.from, "dd/MM/yyyy")} - {format(dateRange.to, "dd/MM/yyyy")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-green-800">סה"כ הכנסות</h3>
                  <p className="text-2xl font-bold text-green-600">₪{financialData.totalIncome.toLocaleString()}</p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-blue-800">הכנסות משירותים</h3>
                  <p className="text-2xl font-bold text-blue-600">₪{financialData.serviceIncome.toLocaleString()}</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-purple-800">הכנסות ממוצרים</h3>
                  <p className="text-2xl font-bold text-purple-600">₪{financialData.productIncome.toLocaleString()}</p>
                </div>
              </div>

              <div className="h-80">
                {/* Chart component would go here */}
                <div className="h-full w-full flex items-center justify-center bg-muted/20 rounded-md">
                  <div className="text-center">
                    <LineChart className="h-10 w-10 mx-auto text-muted-foreground" />
                    <p className="mt-2 text-sm text-muted-foreground">
                      נתוני הכנסות {getReportPeriodText(reportPeriod)}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">הכנסות לפי קטגוריה</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-60">
                  {/* Chart component would go here */}
                  <div className="h-full w-full flex items-center justify-center bg-muted/20 rounded-md">
                    <div className="text-center">
                      <PieChart className="h-10 w-10 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">התפלגות הכנסות לפי קטגוריה</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">הכנסות לפי שירות</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-60">
                  {/* Chart component would go here */}
                  <div className="h-full w-full flex items-center justify-center bg-muted/20 rounded-md">
                    <div className="text-center">
                      <BarChart3 className="h-10 w-10 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">הכנסות לפי סוג שירות</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="expenses" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-semibold">דוח הוצאות {getReportPeriodText(reportPeriod)}</CardTitle>
              <CardDescription>
                {format(dateRange.from, "dd/MM/yyyy")} - {format(dateRange.to, "dd/MM/yyyy")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-red-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-red-800">סה"כ הוצאות</h3>
                  <p className="text-2xl font-bold text-red-600">₪{financialData.totalExpenses.toLocaleString()}</p>
                </div>
                <div className="bg-orange-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-orange-800">אחוז מסך ההכנסות</h3>
                  <p className="text-2xl font-bold text-orange-600">
                    {financialData.totalIncome > 0
                      ? Math.round((financialData.totalExpenses / financialData.totalIncome) * 100)
                      : 0}
                    %
                  </p>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-yellow-800">קטגוריות הוצאה</h3>
                  <p className="text-2xl font-bold text-yellow-600">
                    {Object.keys(financialData.expensesByCategory).length}
                  </p>
                </div>
              </div>

              <div className="h-80">
                {/* Chart component would go here */}
                <div className="h-full w-full flex items-center justify-center bg-muted/20 rounded-md">
                  <div className="text-center">
                    <LineChart className="h-10 w-10 mx-auto text-muted-foreground" />
                    <p className="mt-2 text-sm text-muted-foreground">
                      נתוני הוצאות {getReportPeriodText(reportPeriod)}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">הוצאות לפי קטגוריה</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-60">
                  {/* Chart component would go here */}
                  <div className="h-full w-full flex items-center justify-center bg-muted/20 rounded-md">
                    <div className="text-center">
                      <PieChart className="h-10 w-10 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">התפלגות הוצאות לפי קטגוריה</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">הוצאות לפי ספק</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-60">
                  {/* Chart component would go here */}
                  <div className="h-full w-full flex items-center justify-center bg-muted/20 rounded-md">
                    <div className="text-center">
                      <BarChart3 className="h-10 w-10 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">הוצאות לפי ספק</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="profit" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-semibold">דוח רווחיות {getReportPeriodText(reportPeriod)}</CardTitle>
              <CardDescription>
                {format(dateRange.from, "dd/MM/yyyy")} - {format(dateRange.to, "dd/MM/yyyy")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-green-800">רווח נקי</h3>
                  <p className="text-2xl font-bold text-green-600">₪{financialData.netProfit.toLocaleString()}</p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-blue-800">שולי רווח</h3>
                  <p className="text-2xl font-bold text-blue-600">
                    {financialData.totalIncome > 0
                      ? Math.round((financialData.netProfit / financialData.totalIncome) * 100)
                      : 0}
                    %
                  </p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-purple-800">יחס הכנסה/הוצאה</h3>
                  <p className="text-2xl font-bold text-purple-600">
                    {financialData.totalExpenses > 0
                      ? (financialData.totalIncome / financialData.totalExpenses).toFixed(2)
                      : "N/A"}
                  </p>
                </div>
              </div>

              <div className="h-80">
                {/* Chart component would go here */}
                <div className="h-full w-full flex items-center justify-center bg-muted/20 rounded-md">
                  <div className="text-center">
                    <LineChart className="h-10 w-10 mx-auto text-muted-foreground" />
                    <p className="mt-2 text-sm text-muted-foreground">
                      נתוני רווחיות {getReportPeriodText(reportPeriod)}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">רווחיות לפי שירות</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-60">
                  {/* Chart component would go here */}
                  <div className="h-full w-full flex items-center justify-center bg-muted/20 rounded-md">
                    <div className="text-center">
                      <BarChart3 className="h-10 w-10 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">רווחיות לפי סוג שירות</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">מגמות רווחיות</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-60">
                  {/* Chart component would go here */}
                  <div className="h-full w-full flex items-center justify-center bg-muted/20 rounded-md">
                    <div className="text-center">
                      <TrendingUp className="h-10 w-10 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">מגמות רווחיות לאורך זמן</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tax" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-semibold">דוח מס {getReportPeriodText(reportPeriod)}</CardTitle>
              <CardDescription>
                {format(dateRange.from, "dd/MM/yyyy")} - {format(dateRange.to, "dd/MM/yyyy")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">סה"כ מע"מ לתשלום</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        ₪{Math.round(financialData.totalIncome * 0.17).toLocaleString()}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">מע"מ עסקאות</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        ₪{Math.round(financialData.totalIncome * 0.17).toLocaleString()}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">מע"מ תשומות</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        ₪{Math.round(financialData.totalExpenses * 0.17).toLocaleString()}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex justify-end">
                  <Button onClick={() => console.log("TODO: Add functionality")}>
                    <FileText className="h-4 w-4 mr-2" />
                    הפק דוח מע"מ
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-semibold">סיכום מס הכנסה</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">הכנסה חייבת</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">₪{financialData.netProfit.toLocaleString()}</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">הוצאות מוכרות</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">₪{financialData.totalExpenses.toLocaleString()}</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">מקדמות ששולמו</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">₪0</div>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex justify-end">
                  <Button onClick={() => console.log("TODO: Add functionality")}>
                    <FileText className="h-4 w-4 mr-2" />
                    הפק דוח מס הכנסה
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function getReportPeriodText(period: string) {
  switch (period) {
    case "daily":
      return "יומי"
    case "weekly":
      return "שבועי"
    case "monthly":
      return "חודשי"
    case "quarterly":
      return "רבעוני"
    case "yearly":
      return "שנתי"
    default:
      return ""
  }
}
