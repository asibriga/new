"use client"

import { useState, useEffect } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Download, Eye, FileText, MoreHorizontal, Printer, Search, Send, Plus } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Invoice } from "./invoice"
import { InvoiceExport } from "./invoice-export"
import { useStore } from "@/lib/store"
import { isWithinInterval, parseISO } from "date-fns"
import { useToast } from "@/hooks/use-toast"

interface InvoiceListProps {
  dateRange: { from: Date; to: Date }
}

export function InvoiceList({ dateRange }: InvoiceListProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null)
  const [viewMode, setViewMode] = useState<"view" | "print" | "export" | "create">("view")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const { toast } = useToast()

  // Get invoices and related data from store
  const invoices = useStore((state) => state.invoices)
  const deleteInvoice = useStore((state) => state.deleteInvoice)
  const addInvoice = useStore((state) => state.addInvoice)
  const appointments = useStore((state) => state.appointments)
  const orders = useStore((state) => state.orders)
  const customers = useStore((state) => state.customers)

  // Check for completed appointments and orders without invoices
  useEffect(() => {
    // Get all invoice-related IDs
    const invoicedAppointmentIds = invoices
      .filter((invoice) => invoice.notes?.includes("appointmentId:"))
      .map((invoice) => {
        const match = invoice.notes.match(/appointmentId:\s*([^,\s]+)/)
        return match ? match[1] : null
      })
      .filter(Boolean)

    const invoicedOrderIds = invoices
      .filter((invoice) => invoice.notes?.includes("orderId:"))
      .map((invoice) => {
        const match = invoice.notes.match(/orderId:\s*([^,\s]+)/)
        return match ? match[1] : null
      })
      .filter(Boolean)

    // Find completed appointments without invoices
    const completedAppointmentsWithoutInvoice = appointments.filter(
      (appointment) => appointment.status === "completed" && !invoicedAppointmentIds.includes(appointment.id),
    )

    // Find completed orders without invoices
    const completedOrdersWithoutInvoice = orders.filter(
      (order) => (order.status === "completed" || order.status === "paid") && !invoicedOrderIds.includes(order.id),
    )

    // Create invoices for completed appointments
    completedAppointmentsWithoutInvoice.forEach((appointment) => {
      const customer = customers.find((c) => c.id === appointment.customerId)

      if (customer) {
        const invoiceItems = [
          {
            description: appointment.serviceName,
            quantity: 1,
            price: appointment.price,
          },
        ]

        const newInvoice = {
          id: `INV-A${appointment.id.slice(-6)}`,
          date: appointment.date,
          dueDate: appointment.date, // Same day for services
          customerName: customer.name,
          customerPhone: customer.phone,
          customerEmail: customer.email,
          items: invoiceItems,
          total: appointment.price,
          status: "paid",
          paymentMethod: "cash", // Default
          notes: `חשבונית עבור תור שהושלם. appointmentId: ${appointment.id}`,
        }

        addInvoice(newInvoice)

        toast({
          title: "חשבונית חדשה נוצרה",
          description: `חשבונית עבור תור של ${customer.name} נוצרה אוטומטית`,
        })
      }
    })

    // Create invoices for completed orders
    completedOrdersWithoutInvoice.forEach((order) => {
      const invoiceItems = order.items.map((item) => ({
        description: item.productName,
        quantity: item.quantity,
        price: item.price,
      }))

      const newInvoice = {
        id: `INV-O${order.id.slice(-6)}`,
        date: order.date,
        dueDate: order.date, // Same day for orders
        customerName: order.customerName,
        customerPhone: order.customerPhone,
        customerEmail: order.customerEmail,
        items: invoiceItems,
        total: order.total,
        status: order.status === "paid" ? "paid" : "pending",
        paymentMethod: order.paymentMethod,
        notes: `חשבונית עבור הזמנה. orderId: ${order.id}`,
      }

      addInvoice(newInvoice)

      toast({
        title: "חשבונית חדשה נוצרה",
        description: `חשבונית עבור הזמנה של ${order.customerName} נוצרה אוטומטית`,
      })
    })
  }, [appointments, orders, invoices, customers, addInvoice, toast])

  // Filter invoices based on search term and date range
  const filteredInvoices = invoices.filter((invoice) => {
    try {
      const invoiceDate = parseISO(invoice.date)
      const matchesDateRange = isWithinInterval(invoiceDate, {
        start: dateRange.from,
        end: dateRange.to,
      })

      const matchesSearch =
        invoice.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        invoice.customerName?.toLowerCase().includes(searchTerm.toLowerCase())

      return matchesDateRange && matchesSearch
    } catch (error) {
      console.error("Error filtering invoice:", error)
      return false
    }
  })

  const handleViewInvoice = (invoice: any) => {
    // בדיקה אם הפונקציות קיימות לפני השימוש בהן
    if (typeof setSelectedInvoice === "function") {
      setSelectedInvoice(invoice)
    }
    if (typeof setViewMode === "function") {
      setViewMode("view")
    }
    if (typeof setIsDialogOpen === "function") {
      setIsDialogOpen(true)
    }

    // אם הפונקציות לא קיימות, הצג הודעה
    if (!setSelectedInvoice || !setViewMode || !setIsDialogOpen) {
      console.log("צפייה בחשבונית:", invoice)
      alert(`צפייה בחשבונית: ${invoice.id}`)
    }
  }

  const handlePrintInvoice = (invoice: any) => {
    setSelectedInvoice(invoice)
    setViewMode("print")
    setIsDialogOpen(true)
  }

  const handleExportInvoice = (invoice: any) => {
    setSelectedInvoice(invoice)
    setViewMode("export")
    setIsDialogOpen(true)
  }

  const handleCreateInvoice = () => {
    setSelectedInvoice(null)
    setViewMode("create")
    setIsDialogOpen(true)
  }

  const handleSendInvoice = (invoice: any) => {
    toast({
      title: "חשבונית נשלחה",
      description: `החשבונית נשלחה בהצלחה ל${invoice.customerName}`,
    })
  }

  const handleDeleteInvoice = (id: string) => {
    try {
      deleteInvoice(id)
      toast({
        title: "החשבונית נמחקה",
        description: "החשבונית נמחקה בהצלחה",
      })
    } catch (error) {
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה בעת מחיקת החשבונית",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-500">שולם</Badge>
      case "pending":
        return <Badge className="bg-yellow-500">ממתין</Badge>
      case "cancelled":
        return <Badge className="bg-red-500">בוטל</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const handleEditInvoice = (invoice: any) => {
    // בדיקה אם הפונקציות קיימות לפני השימוש בהן
    if (typeof setSelectedInvoice === "function") {
      setSelectedInvoice(invoice)
    }
    if (typeof setViewMode === "function") {
      setViewMode("edit")
    }
    if (typeof setIsDialogOpen === "function") {
      setIsDialogOpen(true)
    }

    // אם הפונקציות לא קיימות, הצג הודעה
    if (!setSelectedInvoice || !setViewMode || !setIsDialogOpen) {
      console.log("עריכת חשבונית:", invoice)
      alert(`עריכת חשבונית: ${invoice.id}`)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 p-4">
        <div className="flex items-center gap-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="חפש לפי מספר חשבונית או שם לקוח..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="h-9 w-[250px]"
          />
        </div>
        <Button onClick={handleCreateInvoice} className="bg-pink-500 hover:bg-pink-600">
          <Plus className="h-4 w-4 mr-2" />
          חשבונית חדשה
        </Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>מספר חשבונית</TableHead>
              <TableHead>לקוח</TableHead>
              <TableHead>תאריך</TableHead>
              <TableHead>סכום</TableHead>
              <TableHead>סטטוס</TableHead>
              <TableHead className="text-right">פעולות</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredInvoices.length > 0 ? (
              filteredInvoices.map((invoice) => (
                <TableRow key={invoice.id}>
                  <TableCell className="font-medium">{invoice.id}</TableCell>
                  <TableCell>{invoice.customerName}</TableCell>
                  <TableCell>{new Date(invoice.date).toLocaleDateString("he-IL")}</TableCell>
                  <TableCell>₪{invoice.total.toLocaleString()}</TableCell>
                  <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" onClick={() => console.log("TODO: Add functionality")}>
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">פתח תפריט</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleViewInvoice(invoice)}>
                          <Eye className="h-4 w-4 mr-2" />
                          צפה
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handlePrintInvoice(invoice)}>
                          <Printer className="h-4 w-4 mr-2" />
                          הדפס
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleExportInvoice(invoice)}>
                          <Download className="h-4 w-4 mr-2" />
                          ייצא ל-PDF
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleSendInvoice(invoice)}>
                          <Send className="h-4 w-4 mr-2" />
                          שלח במייל
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteInvoice(invoice.id)}>
                          <FileText className="h-4 w-4 mr-2" />
                          מחק
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-6 text-muted-foreground">
                  <FileText className="h-10 w-10 mx-auto mb-2 text-muted-foreground/60" />
                  <p>לא נמצאו חשבוניות בטווח התאריכים שנבחר</p>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>
              {viewMode === "view" && "צפייה בחשבונית"}
              {viewMode === "print" && "הדפסת חשבונית"}
              {viewMode === "export" && "ייצוא חשבונית ל-PDF"}
              {viewMode === "create" && "יצירת חשבונית חדשה"}
            </DialogTitle>
          </DialogHeader>

          <div className="mt-4">
            {viewMode === "view" && selectedInvoice && <Invoice invoice={selectedInvoice} />}
            {viewMode === "print" && selectedInvoice && <Invoice invoice={selectedInvoice} printMode />}
            {viewMode === "export" && selectedInvoice && <InvoiceExport invoice={selectedInvoice} />}
            {viewMode === "create" && <Invoice invoice={null} />}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
