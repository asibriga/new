"use client"

import { useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { format } from "date-fns"
import { he } from "date-fns/locale"
import { Download } from "lucide-react"
import { useState } from "react"
import { FileText, Loader2 } from "lucide-react"
import { Invoice } from "./invoice"

// No interface needed as we're using an inline type

export function InvoiceExport({ invoice }: { invoice: any }) {
  const router = useRouter()
  const { toast } = useToast()
  const invoiceRef = useRef(null)
  const [isExporting, setIsExporting] = useState(false)
  const [isExported, setIsExported] = useState(false)

  const handlePrint = () => {
    if (!invoiceRef.current) return

    // Save current document content
    const originalContent = document.body.innerHTML

    // Replace with invoice content
    const printContent = invoiceRef.current.innerHTML
    document.body.innerHTML = printContent

    // Print
    window.print()

    // Restore original content
    document.body.innerHTML = originalContent

    toast({
      title: "החשבונית נשלחה להדפסה",
      description: "החשבונית נשלחה למדפסת",
    })
  }

  const handleExportPDF = () => {
    if (!invoice) return

    try {
      // Create a hidden div to generate PDF content
      const printDiv = document.createElement("div")
      printDiv.style.display = "none"
      printDiv.innerHTML = `
      <div style="font-family: Arial, sans-serif; direction: rtl; padding: 20px; max-width: 800px; margin: 0 auto;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
          <div>
            <div style="font-size: 24px; font-weight: bold; color: #d53f8c;">May Beauty</div>
            <p>רחוב הרצל 123, תל אביב</p>
            <p>טלפון: 054-1234567</p>
            <p>אימייל: info@maybeauty.co.il</p>
          </div>
          <div style="text-align: left;">
            <h2>חשבונית מס</h2>
            <p>מספר: ${invoice.id}</p>
            <p>תאריך: ${format(new Date(invoice.date), "dd/MM/yyyy", { locale: he })}</p>
            <p>תאריך לתשלום: ${format(new Date(invoice.dueDate), "dd/MM/yyyy", { locale: he })}</p>
          </div>
        </div>

        <div style="margin-bottom: 20px;">
          <h3>פרטי לקוח:</h3>
          <p>${invoice.customerName}</p>
          <p>${invoice.customerPhone}</p>
          ${invoice.customerEmail ? `<p>${invoice.customerEmail}</p>` : ""}
          ${invoice.customerAddress ? `<p>${invoice.customerAddress}</p>` : ""}
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="border-bottom: 2px solid #eee;">
              <th style="text-align: right; padding: 10px;">תיאור</th>
              <th style="text-align: center; padding: 10px;">כמות</th>
              <th style="text-align: center; padding: 10px;">מחיר</th>
              <th style="text-align: left; padding: 10px;">סה"כ</th>
            </tr>
          </thead>
          <tbody>
            ${invoice.items
              .map(
                (item) => `
              <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 10px;">${item.description}</td>
                <td style="text-align: center; padding: 10px;">${item.quantity}</td>
                <td style="text-align: center; padding: 10px;">₪${item.price.toFixed(2)}</td>
                <td style="text-align: left; padding: 10px;">₪${(item.quantity * item.price).toFixed(2)}</td>
              </tr>
            `,
              )
              .join("")}
          </tbody>
          <tfoot>
            <tr style="font-weight: bold;">
              <td colspan="3" style="text-align: right; padding: 10px;">סה"כ לתשלום:</td>
              <td style="text-align: left; padding: 10px;">₪${invoice.total.toFixed(2)}</td>
            </tr>
          </tfoot>
        </table>

        <div style="margin-bottom: 20px;">
          <h3>פרטי תשלום:</h3>
          <p>
            אמצעי תשלום: 
            ${
              invoice.paymentMethod === "cash"
                ? "מזומן"
                : invoice.paymentMethod === "credit"
                  ? "כרטיס אשראי"
                  : invoice.paymentMethod === "bit"
                    ? "ביט"
                    : "העברה בנקאית"
            }
          </p>
          <p>סטטוס: ${invoice.status === "paid" ? "שולם" : invoice.status === "pending" ? "ממתין לתשלום" : "בוטל"}</p>
        </div>

        ${
          invoice.notes
            ? `
          <div style="margin-bottom: 20px;">
            <h3>הערות:</h3>
            <p>${invoice.notes}</p>
          </div>
        `
            : ""
        }

        <div style="text-align: center; margin-top: 40px; color: #666;">
          <p>תודה על הקנייה!</p>
          <p>May Beauty © ${new Date().getFullYear()}</p>
        </div>
      </div>
    `

      document.body.appendChild(printDiv)

      // Use browser's print functionality to generate PDF
      window.print()

      // Clean up
      document.body.removeChild(printDiv)

      toast({
        title: "החשבונית יוצאה בהצלחה",
        description: "החשבונית נשלחה להדפסה. בחר 'שמור כ-PDF' באפשרויות ההדפסה",
      })
    } catch (error) {
      console.error("Error exporting invoice:", error)
      toast({
        title: "שגיאה בייצוא החשבונית",
        description: "אירעה שגיאה בעת ייצוא החשבונית",
        variant: "destructive",
      })
    }
  }

  const handleExport = () => {
    setIsExporting(true)

    // Simulate PDF generation
    setTimeout(() => {
      setIsExporting(false)
      setIsExported(true)

      // Simulate download
      const link = document.createElement("a")
      link.href = "#"
      link.download = `invoice-${invoice.id}.pdf`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    }, 2000)
  }

  if (!invoice) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">חשבונית לא נמצאה</h1>
          <Button onClick={() => router.push("/admin/finances")}>חזרה לדף הפיננסים</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-6">
          <Invoice invoice={invoice} />
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleExport} disabled={isExporting || isExported} className="w-full sm:w-auto">
          {isExporting ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              מייצא PDF...
            </>
          ) : isExported ? (
            <>
              <FileText className="h-4 w-4 mr-2" />
              PDF יוצא בהצלחה
            </>
          ) : (
            <>
              <Download className="h-4 w-4 mr-2" />
              ייצא ל-PDF
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
