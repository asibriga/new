"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useStore } from "@/lib/store"
import { format } from "date-fns"
import { he } from "date-fns/locale"
import { Printer, Download, Save, Trash } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface InvoiceItem {
  description: string
  quantity: number
  price: number
}

interface InvoiceProps {
  invoice: {
    id: string
    customer: string
    date: string
    amount: number
    status: string
    items: InvoiceItem[]
  } | null
  printMode?: boolean
}

export function Invoice({ invoice, printMode = false }: InvoiceProps) {
  const invoiceRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()
  const [invoiceNumber, setInvoiceNumber] = useState(`INV-${Date.now().toString().slice(-6)}`)
  const [invoiceDate, setInvoiceDate] = useState(format(new Date(), "yyyy-MM-dd"))
  const [dueDate, setDueDate] = useState(format(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), "yyyy-MM-dd"))
  const [customerName, setCustomerName] = useState("")
  const [customerPhone, setCustomerPhone] = useState("")
  const [customerEmail, setCustomerEmail] = useState("")
  const [customerAddress, setCustomerAddress] = useState("")
  const [notes, setNotes] = useState("")
  const [items, setItems] = useState<InvoiceItem[]>([{ description: "", quantity: 1, price: 0 }])
  const [paymentMethod, setPaymentMethod] = useState("cash")
  const [paymentStatus, setPaymentStatus] = useState("paid")
  const [isEditing, setIsEditing] = useState(false)

  // Get data from store
  const customers = useStore((state) => state.customers)
  const appointments = useStore((state) => state.appointments)
  const services = useStore((state) => state.services)
  const addInvoice = useStore((state) => state.addInvoice)
  const updateInvoice = useStore((state) => state.updateInvoice)

  // Initialize form if invoice is provided
  useEffect(() => {
    if (invoice) {
      setInvoiceNumber(invoice.id || invoiceNumber)
      setInvoiceDate(invoice.date || invoiceDate)
      setDueDate(invoice.date || dueDate) // Use invoice date as due date if not provided
      setCustomerName(invoice.customer || customerName)
      setItems(invoice.items || items)
      setPaymentStatus(invoice.status || paymentStatus)

      // Try to find customer details
      const customer = customers.find((c) => c.name === invoice.customer)
      if (customer) {
        setCustomerPhone(customer.phone || "")
        setCustomerEmail(customer.email || "")
      }
    }
  }, [invoice, customers])

  // Calculate total
  const total = items.reduce((sum, item) => sum + item.quantity * item.price, 0)

  const handlePrint = () => {
    if (invoiceRef.current) {
      const printContents = invoiceRef.current.innerHTML
      const originalContents = document.body.innerHTML

      document.body.innerHTML = `
        <html>
          <head>
            <title>הדפסת חשבונית</title>
            <style>
              @media print {
                body {
                  font-family: Arial, sans-serif;
                  direction: rtl;
                }
                table {
                  width: 100%;
                  border-collapse: collapse;
                }
                th, td {
                  border: 1px solid #ddd;
                  padding: 8px;
                  text-align: right;
                }
                th {
                  background-color: #f2f2f2;
                }
                .invoice-header {
                  display: flex;
                  justify-content: space-between;
                  margin-bottom: 20px;
                }
                .invoice-footer {
                  margin-top: 30px;
                  text-align: center;
                }
              }
            </style>
          </head>
          <body>
            ${printContents}
          </body>
        </html>
      `

      window.print()
      document.body.innerHTML = originalContents
    }
  }

  const handleExportPDF = () => {
    const printWindow = window.open("", "_blank")

    if (!printWindow) {
      toast({
        title: "שגיאה",
        description: "לא ניתן לפתוח חלון ייצוא. אנא בדוק את הגדרות החוסם של הדפדפן.",
        variant: "destructive",
      })
      return
    }

    const invoiceContent = invoiceRef.current?.innerHTML || ""

    printWindow.document.write(`
      <!DOCTYPE html>
      <html dir="rtl">
        <head>
          <title>חשבונית - ${invoiceNumber}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { padding: 8px; text-align: right; border-bottom: 1px solid #ddd; }
            .text-pink-600 { color: #db2777; }
            .font-bold { font-weight: bold; }
            .text-xl { font-size: 1.25rem; }
            .text-2xl { font-size: 1.5rem; }
            .mb-2 { margin-bottom: 0.5rem; }
            .mb-8 { margin-bottom: 2rem; }
            .py-2 { padding-top: 0.5rem; padding-bottom: 0.5rem; }
            .text-right { text-align: right; }
            .text-left { text-align: left; }
            .text-center { text-align: center; }
            .text-gray-700 { color: #374151; }
            .text-gray-500 { color: #6b7280; }
            .text-sm { font-size: 0.875rem; }
            .mt-12 { margin-top: 3rem; }
            .border-b { border-bottom: 1px solid #e5e7eb; }
            .border-b-2 { border-bottom: 2px solid #e5e7eb; }
            .border-gray-200 { border-color: #e5e7eb; }
            .border-gray-300 { border-color: #d1d5db; }
            @media print {
              body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
            }
          </style>
        </head>
        <body>
          ${invoiceContent}
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
                document.title = "שמירה כ-PDF";
              }, 500);
            };
          </script>
        </body>
      </html>
    `)

    printWindow.document.close()

    toast({
      title: "החשבונית יוצאה בהצלחה",
      description: "בחר 'שמור כ-PDF' באפשרויות ההדפסה",
    })
  }

  const handleSaveInvoice = () => {
    // וידוא שיש את כל הנתונים הנדרשים
    if (!customerName || !customerPhone || items.some((item) => !item.description || item.quantity <= 0)) {
      toast({
        title: "שגיאה",
        description: "אנא מלא את כל השדות הנדרשים",
        variant: "destructive",
      })
      return
    }

    const invoiceData = {
      id: invoiceNumber,
      date: invoiceDate,
      dueDate: dueDate,
      customerName,
      customerPhone,
      customerEmail,
      customerAddress,
      items,
      total,
      status: paymentStatus,
      paymentMethod,
      notes,
    }

    try {
      if (invoice && invoice.id) {
        // עדכון חשבונית קיימת
        updateInvoice(invoice.id, invoiceData)
        toast({
          title: "החשבונית עודכנה בהצלחה",
          description: "החשבונית עודכנה במערכת",
        })
      } else {
        // יצירת חשבונית חדשה
        addInvoice(invoiceData)
        toast({
          title: "החשבונית נשמרה בהצלחה",
          description: "החשבונית נשמרה במערכת",
        })
      }
    } catch (error) {
      console.error("Save invoice error:", error)
      toast({
        title: "שגיאה בשמירה",
        description: "אירעה שגיאה בעת שמירת החשבונית",
        variant: "destructive",
      })
    }
  }

  const handleAddItem = () => {
    setItems([...items, { description: "", quantity: 1, price: 0 }])
  }

  const handleRemoveItem = (index) => {
    setItems(items.filter((_, i) => i !== index))
  }

  const handleItemChange = (index, field, value) => {
    const newItems = [...items]
    newItems[index] = { ...newItems[index], [field]: value }
    setItems(newItems)
  }

  const handleCustomerSelect = (customerId) => {
    const customer = customers.find((c) => c.id === customerId)
    if (customer) {
      setCustomerName(customer.name)
      setCustomerPhone(customer.phone)
      setCustomerEmail(customer.email || "")

      // Get customer's last appointment
      const customerAppointments = appointments
        .filter((a) => a.customerId === customerId)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

      if (customerAppointments.length > 0) {
        const lastAppointment = customerAppointments[0]
        const service = services.find((s) => s.id === lastAppointment.serviceId)

        if (service) {
          setItems([
            {
              description: service.name,
              quantity: 1,
              price: service.price,
            },
          ])
        }
      }
    }
  }

  // If we're just viewing an existing invoice and not in print mode
  if (invoice && !isEditing && !printMode) {
    return (
      <div>
        <div ref={invoiceRef} className="bg-white p-6 rounded-lg">
          <div className="flex justify-between items-start mb-8">
            <div>
              <h2 className="text-2xl font-bold">חשבונית</h2>
              <p className="text-muted-foreground">מספר: {invoice.id}</p>
              <p className="text-muted-foreground">תאריך: {new Date(invoice.date).toLocaleDateString("he-IL")}</p>
            </div>
            <div className="text-right">
              <h3 className="font-bold text-lg">סטודיו ליופי</h3>
              <p>רחוב הרצל 123, תל אביב</p>
              <p>טלפון: 03-1234567</p>
              <p>מייל: info@beautystudio.co.il</p>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="font-bold mb-2">פרטי לקוח:</h3>
            <p>{invoice.customer}</p>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>תיאור</TableHead>
                <TableHead className="text-center">כמות</TableHead>
                <TableHead className="text-center">מחיר</TableHead>
                <TableHead className="text-right">סה"כ</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoice.items.map((item, index) => (
                <TableRow key={index}>
                  <TableCell>{item.description}</TableCell>
                  <TableCell className="text-center">{item.quantity}</TableCell>
                  <TableCell className="text-center">₪{item.price.toLocaleString()}</TableCell>
                  <TableCell className="text-right">₪{(item.quantity * item.price).toLocaleString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <div className="mt-6 text-right">
            <div className="flex justify-end mb-2">
              <div className="w-1/2 flex justify-between">
                <span className="font-semibold">סכום ביניים:</span>
                <span>₪{invoice.amount.toLocaleString()}</span>
              </div>
            </div>
            <div className="flex justify-end mb-2">
              <div className="w-1/2 flex justify-between">
                <span className="font-semibold">מע"מ (17%):</span>
                <span>₪{(invoice.amount * 0.17).toLocaleString()}</span>
              </div>
            </div>
            <div className="flex justify-end font-bold text-lg">
              <div className="w-1/2 flex justify-between">
                <span>סה"כ לתשלום:</span>
                <span>₪{(invoice.amount * 1.17).toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="mt-12 text-center text-sm text-muted-foreground">
            <p>תודה שבחרת בסטודיו ליופי!</p>
            <p>עוסק מורשה: 123456789</p>
          </div>
        </div>

        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={() => setIsEditing(true)}>
            ערוך
          </Button>
          <Button variant="outline" onClick={handlePrint}>
            <Printer className="h-4 w-4 mr-2" />
            הדפס
          </Button>
          <Button onClick={handleExportPDF}>
            <Download className="h-4 w-4 mr-2" />
            הורד PDF
          </Button>
        </div>
      </div>
    )
  }

  // For editing existing invoice or creating new one
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">{invoice ? "עריכת חשבונית" : "יצירת חשבונית"}</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handlePrint}>
            <Printer className="mr-2 h-4 w-4" /> הדפסה
          </Button>
          <Button variant="outline" onClick={handleExportPDF}>
            <Download className="mr-2 h-4 w-4" /> ייצוא PDF
          </Button>
          <Button
            className="bg-pink-500 hover:bg-pink-600"
            onClick={() => {
              // וידוא שיש את כל הנתונים הנדרשים
              if (!customerName || !items.some((item) => item.description && item.quantity > 0)) {
                toast({
                  title: "שגיאה",
                  description: "אנא מלא את כל השדות הנדרשים",
                  variant: "destructive",
                })
                return
              }

              const invoiceData = {
                id: invoiceNumber,
                date: invoiceDate,
                dueDate: dueDate,
                customerName,
                customerPhone,
                customerEmail,
                customerAddress,
                items,
                total: items.reduce((sum, item) => sum + item.quantity * item.price, 0),
                status: paymentStatus,
                paymentMethod,
                notes,
              }

              try {
                if (invoice && invoice.id) {
                  // עדכון חשבונית קיימת
                  updateInvoice(invoice.id, invoiceData)
                  toast({
                    title: "החשבונית עודכנה בהצלחה",
                    description: "החשבונית עודכנה במערכת",
                  })
                } else {
                  // יצירת חשבונית חדשה
                  addInvoice(invoiceData)
                  toast({
                    title: "החשבונית נשמרה בהצלחה",
                    description: "החשבונית נשמרה במערכת",
                  })
                }

                // סגירת הדיאלוג אחרי שמירה מוצלחת
                // if (typeof onClose === 'function') {
                //   onClose();
                // }
              } catch (error) {
                console.error("Save invoice error:", error)
                toast({
                  title: "שגיאה בשמירה",
                  description: "אירעה שגיאה בעת שמירת החשבונית",
                  variant: "destructive",
                })
              }
            }}
          >
            <Save className="mr-2 h-4 w-4" /> שמירה
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>פרטי חשבונית</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="invoice-number">מספר חשבונית</Label>
                <Input
                  id="invoice-number"
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  readOnly={!!invoice}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="invoice-date">תאריך חשבונית</Label>
                <Input
                  id="invoice-date"
                  type="date"
                  value={invoiceDate}
                  onChange={(e) => setInvoiceDate(e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="due-date">תאריך לתשלום</Label>
                <Input id="due-date" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="payment-status">סטטוס תשלום</Label>
                <Select value={paymentStatus} onValueChange={setPaymentStatus}>
                  <SelectTrigger id="payment-status">
                    <SelectValue placeholder="בחרי סטטוס" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="paid">שולם</SelectItem>
                    <SelectItem value="pending">ממתין לתשלום</SelectItem>
                    <SelectItem value="cancelled">בוטל</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="payment-method">אמצעי תשלום</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger id="payment-method">
                  <SelectValue placeholder="בחרי אמצעי תשלום" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">מזומן</SelectItem>
                  <SelectItem value="credit">כרטיס אשראי</SelectItem>
                  <SelectItem value="bit">ביט</SelectItem>
                  <SelectItem value="transfer">העברה בנקאית</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">הערות</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="הערות לחשבונית"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>פרטי לקוח</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="customer-select">בחירת לקוח קיים</Label>
              <Select onValueChange={handleCustomerSelect}>
                <SelectTrigger id="customer-select">
                  <SelectValue placeholder="בחרי לקוח" />
                </SelectTrigger>
                <SelectContent>
                  {customers.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.name} - {customer.phone}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="customer-name">שם לקוח</Label>
              <Input id="customer-name" value={customerName} onChange={(e) => setCustomerName(e.target.value)} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="customer-phone">טלפון</Label>
                <Input id="customer-phone" value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="customer-email">אימייל</Label>
                <Input
                  id="customer-email"
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="customer-address">כתובת</Label>
              <Input
                id="customer-address"
                value={customerAddress}
                onChange={(e) => setCustomerAddress(e.target.value)}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>פריטים</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {items.map((item, index) => (
              <div key={index} className="grid grid-cols-12 gap-4 items-end">
                <div className="col-span-6 space-y-2">
                  <Label htmlFor={`item-desc-${index}`}>תיאור</Label>
                  <Input
                    id={`item-desc-${index}`}
                    value={item.description}
                    onChange={(e) => handleItemChange(index, "description", e.target.value)}
                  />
                </div>
                <div className="col-span-2 space-y-2">
                  <Label htmlFor={`item-qty-${index}`}>כמות</Label>
                  <Input
                    id={`item-qty-${index}`}
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) => handleItemChange(index, "quantity", Number.parseInt(e.target.value) || 1)}
                  />
                </div>
                <div className="col-span-3 space-y-2">
                  <Label htmlFor={`item-price-${index}`}>מחיר</Label>
                  <Input
                    id={`item-price-${index}`}
                    type="number"
                    min="0"
                    value={item.price}
                    onChange={(e) => handleItemChange(index, "price", Number.parseFloat(e.target.value) || 0)}
                  />
                </div>
                <div className="col-span-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-red-500 hover:text-red-700"
                    onClick={() => handleRemoveItem(index)}
                    disabled={items.length === 1}
                  >
                    <Trash className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}

            <Button variant="outline" onClick={handleAddItem}>
              הוספת פריט
            </Button>

            <div className="flex justify-end pt-4 border-t">
              <div className="text-right">
                <div className="flex justify-between w-64">
                  <span className="font-medium">סה"כ:</span>
                  <span className="font-bold">₪{total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* תצוגה מקדימה של החשבונית */}
      <Card>
        <CardHeader>
          <CardTitle>תצוגה מקדימה</CardTitle>
        </CardHeader>
        <CardContent>
          <div ref={invoiceRef} className="p-6 bg-white">
            <div className="flex justify-between items-start mb-8">
              <div>
                <h1 className="text-2xl font-bold text-pink-600">May Beauty</h1>
                <p>רחוב הרצל 123, תל אביב</p>
                <p>טלפון: 054-1234567</p>
                <p>אימייל: info@maybeauty.co.il</p>
              </div>
              <div className="text-right">
                <h2 className="text-xl font-bold">חשבונית מס</h2>
                <p>מספר: {invoiceNumber}</p>
                <p>תאריך: {format(new Date(invoiceDate), "dd/MM/yyyy", { locale: he })}</p>
                <p>תאריך לתשלום: {format(new Date(dueDate), "dd/MM/yyyy", { locale: he })}</p>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="font-bold mb-2 text-gray-700">פרטי לקוח:</h3>
              <p>{customerName}</p>
              <p>{customerPhone}</p>
              {customerEmail && <p>{customerEmail}</p>}
              {customerAddress && <p>{customerAddress}</p>}
            </div>

            <table className="w-full mb-8">
              <thead>
                <tr className="border-b-2 border-gray-300">
                  <th className="text-right py-2">תיאור</th>
                  <th className="text-center py-2">כמות</th>
                  <th className="text-center py-2">מחיר</th>
                  <th className="text-left py-2">סה"כ</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => (
                  <tr key={index} className="border-b border-gray-200">
                    <td className="py-2">{item.description}</td>
                    <td className="text-center py-2">{item.quantity}</td>
                    <td className="text-center py-2">₪{item.price.toFixed(2)}</td>
                    <td className="text-left py-2">₪{(item.quantity * item.price).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="font-bold">
                  <td colSpan={3} className="text-right py-2">
                    סה"כ לתשלום:
                  </td>
                  <td className="text-left py-2">₪{total.toFixed(2)}</td>
                </tr>
              </tfoot>
            </table>

            <div className="mb-8">
              <h3 className="font-bold mb-2 text-gray-700">פרטי תשלום:</h3>
              <p>
                אמצעי תשלום:{" "}
                {paymentMethod === "cash"
                  ? "מזומן"
                  : paymentMethod === "credit"
                    ? "כרטיס אשראי"
                    : paymentMethod === "bit"
                      ? "ביט"
                      : "העברה בנקאית"}
              </p>
              <p>סטטוס: {paymentStatus === "paid" ? "שולם" : paymentStatus === "pending" ? "ממתין לתשלום" : "בוטל"}</p>
            </div>

            {notes && (
              <div className="mb-8">
                <h3 className="font-bold mb-2 text-gray-700">הערות:</h3>
                <p>{notes}</p>
              </div>
            )}

            <div className="text-center text-sm text-gray-500 mt-12">
              <p>תודה על הקנייה!</p>
              <p>May Beauty © {new Date().getFullYear()}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default function InvoiceGenerator({ invoiceId }: { invoiceId?: string }) {
  return <Invoice invoice={null} />
}
