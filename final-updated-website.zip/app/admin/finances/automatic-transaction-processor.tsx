"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import { useStore } from "@/lib/store"
import { format } from "date-fns"

export default function AutomaticTransactionProcessor() {
  const { toast } = useToast()
  const [isEnabled, setIsEnabled] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [lastProcessed, setLastProcessed] = useState<string | null>(null)

  // Get data from store
  const appointments = useStore((state) => state.appointments)
  const orders = useStore((state) => state.orders)
  const transactions = useStore((state) => state.transactions)
  const addTransaction = useStore((state) => state.addTransaction)

  // Process transactions
  const processTransactions = () => {
    setIsProcessing(true)

    try {
      // Process completed appointments that don't have a corresponding transaction
      let newTransactionsCount = 0

      // Process appointments
      appointments
        .filter(
          (appointment) =>
            appointment.status === "completed" &&
            !transactions.some(
              (t) => t.relatedId === appointment.id && t.type === "income" && t.category === "service",
            ),
        )
        .forEach((appointment) => {
          addTransaction({
            date: appointment.date,
            description: `תשלום עבור ${appointment.serviceName} - ${appointment.customerName}`,
            amount: appointment.price,
            type: "income",
            category: "service",
            relatedId: appointment.id,
            status: "completed",
          })
          newTransactionsCount++
        })

      // Process paid/completed orders
      orders
        .filter(
          (order) =>
            (order.status === "paid" || order.status === "completed") &&
            !transactions.some((t) => t.relatedId === order.id && t.type === "income" && t.category === "product"),
        )
        .forEach((order) => {
          addTransaction({
            date: order.date,
            description: `תשלום עבור הזמנה #${order.id.slice(-6)} - ${order.customerName}`,
            amount: order.total,
            type: "income",
            category: "product",
            relatedId: order.id,
            status: "completed",
          })
          newTransactionsCount++
        })

      // Update last processed time
      setLastProcessed(new Date().toISOString())

      // Show success message
      toast({
        title: "עיבוד הושלם",
        description: `נוספו ${newTransactionsCount} עסקאות חדשות למערכת`,
      })
    } catch (error) {
      console.error("Error processing transactions:", error)
      toast({
        title: "שגיאה בעיבוד",
        description: "אירעה שגיאה בעת עיבוד העסקאות האוטומטי",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  // Toggle automatic processing
  const toggleAutomaticProcessing = (enabled: boolean) => {
    setIsEnabled(enabled)

    if (enabled) {
      toast({
        title: "עיבוד אוטומטי הופעל",
        description: "המערכת תעבד עסקאות באופן אוטומטי",
      })
    } else {
      toast({
        title: "עיבוד אוטומטי הושבת",
        description: "המערכת לא תעבד עסקאות באופן אוטומטי",
      })
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">עיבוד עסקאות אוטומטי</CardTitle>
        <CardDescription>המערכת יכולה לעבד באופן אוטומטי עסקאות מתורים והזמנות שהושלמו</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="automatic-processing">עיבוד אוטומטי</Label>
              <p className="text-sm text-muted-foreground">הפעל עיבוד אוטומטי של עסקאות מתורים והזמנות</p>
            </div>
            <Switch id="automatic-processing" checked={isEnabled} onCheckedChange={toggleAutomaticProcessing} />
          </div>

          <Separator />

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-medium">עיבוד ידני</h3>
                <p className="text-sm text-muted-foreground">עבד עסקאות באופן ידני מתורים והזמנות שהושלמו</p>
              </div>
              <Button
                onClick={() => {
                  setIsProcessing(true)
                  toast({
                    title: "מעבד עסקאות",
                    description: "מעבד עסקאות מתורים והזמנות...",
                  })

                  try {
                    // Process completed appointments that don't have a corresponding transaction
                    let newTransactionsCount = 0

                    // Process appointments
                    appointments
                      .filter(
                        (appointment) =>
                          appointment.status === "completed" &&
                          !transactions.some(
                            (t) => t.relatedId === appointment.id && t.type === "income" && t.category === "service",
                          ),
                      )
                      .forEach((appointment) => {
                        addTransaction({
                          date: appointment.date,
                          description: `תשלום עבור ${appointment.serviceName} - ${appointment.customerName}`,
                          amount: appointment.price,
                          type: "income",
                          category: "service",
                          relatedId: appointment.id,
                          status: "completed",
                        })
                        newTransactionsCount++
                      })

                    // Process paid/completed orders
                    orders
                      .filter(
                        (order) =>
                          (order.status === "paid" || order.status === "completed") &&
                          !transactions.some(
                            (t) => t.relatedId === order.id && t.type === "income" && t.category === "product",
                          ),
                      )
                      .forEach((order) => {
                        addTransaction({
                          date: order.date,
                          description: `תשלום עבור הזמנה #${order.id.slice(-6)} - ${order.customerName}`,
                          amount: order.total,
                          type: "income",
                          category: "product",
                          relatedId: order.id,
                          status: "completed",
                        })
                        newTransactionsCount++
                      })

                    // Update last processed time
                    setLastProcessed(new Date().toISOString())

                    // Show success message
                    toast({
                      title: "עיבוד הושלם",
                      description: `נוספו ${newTransactionsCount} עסקאות חדשות למערכת`,
                    })
                  } catch (error) {
                    console.error("Error processing transactions:", error)
                    toast({
                      title: "שגיאה בעיבוד",
                      description: "אירעה שגיאה בעת עיבוד העסקאות האוטומטי",
                      variant: "destructive",
                    })
                  } finally {
                    setIsProcessing(false)
                  }
                }}
                disabled={isProcessing}
                className="bg-pink-500 hover:bg-pink-600"
              >
                {isProcessing ? "מעבד..." : "עבד עכשיו"}
              </Button>
            </div>

            {lastProcessed && (
              <div className="text-sm text-muted-foreground">
                עיבוד אחרון: {format(new Date(lastProcessed), "dd/MM/yyyy HH:mm:ss")}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
