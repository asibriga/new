"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { ArrowDownUp, Calendar, Check, CreditCard, MoreHorizontal, Search, Trash, X } from "lucide-react"
import { useStore } from "@/lib/store"
import { format, isWithinInterval, parseISO } from "date-fns"
import { useToast } from "@/hooks/use-toast"

interface TransactionsListProps {
  dateRange: { from: Date; to: Date }
  limit?: number
}

export function TransactionsList({ dateRange, limit }: TransactionsListProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")
  const { toast } = useToast()

  // Get transactions from store
  const transactions = useStore((state) => state.transactions)
  const updateTransaction = useStore((state) => state.updateTransaction)
  const deleteTransaction = useStore((state) => state.deleteTransaction)

  // Filter transactions based on search term and date range
  const filteredTransactions = transactions
    .filter((transaction) => {
      // Check if transaction has a valid date
      if (!transaction.date) return false

      try {
        const transactionDate = parseISO(transaction.date)
        const matchesDateRange = isWithinInterval(transactionDate, {
          start: dateRange.from,
          end: dateRange.to,
        })

        const matchesSearch =
          transaction.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          transaction.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          transaction.category?.toLowerCase().includes(searchTerm.toLowerCase())

        return matchesDateRange && matchesSearch
      } catch (error) {
        console.error("Error filtering transaction:", error)
        return false
      }
    })
    .sort((a, b) => {
      try {
        const dateA = new Date(a.date).getTime()
        const dateB = new Date(b.date).getTime()
        return sortDirection === "asc" ? dateA - dateB : dateB - dateA
      } catch (error) {
        return 0
      }
    })

  // Apply limit if provided
  const displayedTransactions = limit ? filteredTransactions.slice(0, limit) : filteredTransactions

  const toggleSortDirection = () => {
    setSortDirection(sortDirection === "asc" ? "desc" : "asc")
  }

  const handleDeleteTransaction = (id: string) => {
    try {
      deleteTransaction(id)
      toast({
        title: "העסקה נמחקה",
        description: "העסקה נמחקה בהצלחה",
      })
    } catch (error) {
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה בעת מחיקת העסקה",
        variant: "destructive",
      })
    }
  }

  const handleUpdateStatus = (id: string, status: string) => {
    try {
      updateTransaction(id, { status })
      toast({
        title: "העסקה עודכנה",
        description: "סטטוס העסקה עודכן בהצלחה",
      })
    } catch (error) {
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה בעת עדכון העסקה",
        variant: "destructive",
      })
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "income":
        return <Badge className="bg-green-500">הכנסה</Badge>
      case "expense":
        return <Badge className="bg-red-500">הוצאה</Badge>
      default:
        return <Badge>{type}</Badge>
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-green-500 flex items-center gap-1">
            <Check className="h-3 w-3" /> הושלם
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-yellow-500 flex items-center gap-1">
            <Calendar className="h-3 w-3" /> ממתין
          </Badge>
        )
      case "failed":
        return (
          <Badge className="bg-red-500 flex items-center gap-1">
            <X className="h-3 w-3" /> נכשל
          </Badge>
        )
      default:
        return <Badge>{status || "הושלם"}</Badge>
    }
  }

  const getPaymentMethodLabel = (method: string) => {
    switch (method) {
      case "credit-card":
      case "credit_card":
        return "כרטיס אשראי"
      case "cash":
        return "מזומן"
      case "bank-transfer":
      case "bank_transfer":
        return "העברה בנקאית"
      case "bit":
        return "ביט"
      default:
        return method || "לא צוין"
    }
  }

  return (
    <div className="space-y-4">
      {!limit && (
        <div className="flex items-center gap-2 p-4">
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="חפש לפי תיאור או מזהה עסקה..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="h-9"
          />
        </div>
      )}

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleSortDirection}
                  className="flex items-center gap-1 p-0 h-auto font-medium"
                >
                  תאריך
                  <ArrowDownUp className="h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead>תיאור</TableHead>
              <TableHead>סכום</TableHead>
              <TableHead>סוג</TableHead>
              <TableHead>קטגוריה</TableHead>
              <TableHead>סטטוס</TableHead>
              {!limit && <TableHead className="text-right">פעולות</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {displayedTransactions.length > 0 ? (
              displayedTransactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell>{transaction.date ? format(new Date(transaction.date), "dd/MM/yyyy") : "N/A"}</TableCell>
                  <TableCell className="max-w-[200px] truncate">{transaction.description}</TableCell>
                  <TableCell className={transaction.type === "income" ? "text-green-600" : "text-red-600"}>
                    {transaction.type === "income" ? "+" : "-"}₪{transaction.amount.toLocaleString()}
                  </TableCell>
                  <TableCell>{getTypeLabel(transaction.type)}</TableCell>
                  <TableCell>{transaction.category}</TableCell>
                  <TableCell>{getStatusLabel(transaction.status)}</TableCell>
                  {!limit && (
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" onClick={() => console.log("TODO: Add functionality")}>
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">פתח תפריט</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => {
                              handleUpdateStatus(transaction.id, "completed")
                              toast({
                                title: "סטטוס עודכן",
                                description: "העסקה סומנה כהושלמה",
                              })
                            }}
                          >
                            <Check className="h-4 w-4 mr-2" />
                            סמן כהושלם
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => {
                              handleUpdateStatus(transaction.id, "pending")
                              toast({
                                title: "סטטוס עודכן",
                                description: "העסקה סומנה כממתינה",
                              })
                            }}
                          >
                            <Calendar className="h-4 w-4 mr-2" />
                            סמן כממתין
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-red-600"
                            onClick={() => {
                              if (confirm("האם אתה בטוח שברצונך למחוק עסקה זו?")) {
                                handleDeleteTransaction(transaction.id)
                                toast({
                                  title: "העסקה נמחקה",
                                  description: "העסקה נמחקה בהצלחה",
                                })
                              }
                            }}
                          >
                            <Trash className="h-4 w-4 mr-2" />
                            מחק
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  )}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={limit ? 6 : 7} className="text-center py-6 text-muted-foreground">
                  <CreditCard className="h-10 w-10 mx-auto mb-2 text-muted-foreground/60" />
                  <p>לא נמצאו עסקאות בטווח התאריכים שנבחר</p>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
