"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { format, parseISO, isWithinInterval } from "date-fns"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, Calendar, Package, User, CreditCard, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

export default function OrderRevenueTracker({ dateRange }) {
  const [searchQuery, setSearchQuery] = useState("")
  const [filteredOrders, setFilteredOrders] = useState([])
  const [totalRevenue, setTotalRevenue] = useState(0)
  const [completedCount, setCompletedCount] = useState(0)
  const [canceledCount, setCanceledCount] = useState(0)
  const { toast } = useToast()

  // Get data from store
  const orders = useStore((state) => state.orders || [])
  const addTransaction = useStore((state) => state.addTransaction)
  const transactions = useStore((state) => state.transactions || [])
  const addInvoice = useStore((state) => state.addInvoice)
  const invoices = useStore((state) => state.invoices || [])

  // Check for completed orders without transactions
  useEffect(() => {
    // Get all order IDs that already have transactions
    const transactionOrderIds = transactions
      .filter((t) => t.relatedId && t.category === "product")
      .map((t) => t.relatedId)

    // Get all order IDs that already have invoices
    const invoicedOrderIds = invoices
      .filter((invoice) => invoice.notes?.includes("orderId:"))
      .map((invoice) => {
        const match = invoice.notes.match(/orderId:\s*([^,\s]+)/)
        return match ? match[1] : null
      })
      .filter(Boolean)

    // Find completed orders without transactions
    const completedOrdersWithoutTransaction = orders.filter(
      (order) => (order.status === "completed" || order.status === "paid") && !transactionOrderIds.includes(order.id),
    )

    // Create transactions for completed orders
    completedOrdersWithoutTransaction.forEach((order) => {
      const newTransaction = {
        date: order.date,
        description: `תשלום עבור הזמנה #${order.id.slice(-6)} - ${order.customerName}`,
        amount: order.total,
        type: "income",
        category: "product",
        relatedId: order.id,
      }

      addTransaction(newTransaction)

      toast({
        title: "עסקה חדשה נוצרה",
        description: `עסקה עבור הזמנה של ${order.customerName} נוצרה אוטומטית`,
      })
    })

    // Find completed orders without invoices
    const completedOrdersWithoutInvoice = orders.filter(
      (order) => (order.status === "completed" || order.status === "paid") && !invoicedOrderIds.includes(order.id),
    )

    // Create invoices for completed orders
    completedOrdersWithoutInvoice.forEach((order) => {
      const invoiceItems = order.items.map((item) => ({
        description: item.productName,
        quantity: item.quantity,
        price: item.price,
      }))

      const newInvoice = {
        id: `INV-O${order.id.slice(-6)}`,
        date: order.date,
        dueDate: order.date, // Same day for orders
        customerName: order.customerName,
        customerPhone: order.customerPhone,
        customerEmail: order.customerEmail,
        items: invoiceItems,
        total: order.total,
        status: order.status === "paid" ? "paid" : "pending",
        paymentMethod: order.paymentMethod,
        notes: `חשבונית עבור הזמנה. orderId: ${order.id}`,
      }

      addInvoice(newInvoice)

      toast({
        title: "חשבונית חדשה נוצרה",
        description: `חשבונית עבור הזמנה של ${order.customerName} נוצרה אוטומטית`,
      })
    })
  }, [orders, transactions, invoices, addTransaction, addInvoice, toast])

  // Filter orders based on date range and search query
  useEffect(() => {
    if (!orders || !dateRange || !dateRange.from || !dateRange.to) return

    try {
      // Filter orders within date range
      const filtered = orders.filter((order) => {
        if (!order.date) return false

        try {
          const orderDate = parseISO(order.date)
          const isInDateRange = isWithinInterval(orderDate, {
            start: dateRange.from,
            end: dateRange.to,
          })

          // Search filter
          const matchesSearch = searchQuery
            ? (order.customerName && order.customerName.toLowerCase().includes(searchQuery.toLowerCase())) ||
              (order.items &&
                order.items.some(
                  (item) => item.productName && item.productName.toLowerCase().includes(searchQuery.toLowerCase()),
                ))
            : true

          return isInDateRange && matchesSearch
        } catch (error) {
          console.error("Error parsing order date:", error, order)
          return false
        }
      })

      // Sort by date
      const sorted = [...filtered].sort((a, b) => {
        if (!a.date || !b.date) return 0

        try {
          return new Date(b.date).getTime() - new Date(a.date).getTime()
        } catch (error) {
          return 0
        }
      })

      setFilteredOrders(sorted)

      // Calculate statistics
      const revenue = filtered
        .filter((o) => o.status === "completed" || o.status === "paid")
        .reduce((sum, o) => sum + (o.total || 0), 0)

      const completed = filtered.filter((o) => o.status === "completed" || o.status === "paid").length
      const canceled = filtered.filter((o) => o.status === "cancelled").length

      setTotalRevenue(revenue)
      setCompletedCount(completed)
      setCanceledCount(canceled)
    } catch (error) {
      console.error("Error filtering orders:", error)
    }
  }, [orders, dateRange, searchQuery])

  // Get status badge
  const getStatusBadge = useCallback((status) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500">הושלם</Badge>
      case "paid":
        return <Badge className="bg-blue-500">שולם</Badge>
      case "pending":
        return (
          <Badge variant="outline" className="text-orange-500 border-orange-500">
            ממתין
          </Badge>
        )
      case "cancelled":
        return <Badge variant="destructive">בוטל</Badge>
      default:
        return null
    }
  }, [])

  // Check if order has a transaction
  const hasTransaction = useCallback(
    (orderId) => {
      return transactions.some((t) => t.relatedId === orderId && t.category === "product")
    },
    [transactions],
  )

  // Check if order has an invoice
  const hasInvoice = useCallback(
    (orderId) => {
      return invoices.some((invoice) => invoice.notes?.includes(`orderId: ${orderId}`))
    },
    [invoices],
  )

  // Create transaction for order
  const createTransaction = useCallback(
    (order) => {
      if (hasTransaction(order.id)) {
        toast({
          title: "עסקה קיימת",
          description: "כבר קיימת עסקה עבור הזמנה זו",
        })
        return
      }

      const newTransaction = {
        date: order.date,
        description: `תשלום עבור הזמנה #${order.id.slice(-6)} - ${order.customerName}`,
        amount: order.total,
        type: "income",
        category: "product",
        relatedId: order.id,
      }

      addTransaction(newTransaction)

      toast({
        title: "עסקה נוצרה",
        description: "העסקה נוצרה בהצלחה",
      })
    },
    [addTransaction, hasTransaction, toast],
  )

  // Create invoice for order
  const createInvoice = useCallback(
    (order) => {
      if (hasInvoice(order.id)) {
        toast({
          title: "חשבונית קיימת",
          description: "כבר קיימת חשבונית עבור הזמנה זו",
        })
        return
      }

      const invoiceItems = order.items.map((item) => ({
        description: item.productName,
        quantity: item.quantity,
        price: item.price,
      }))

      const newInvoice = {
        id: `INV-O${order.id.slice(-6)}`,
        date: order.date,
        dueDate: order.date, // Same day for orders
        customerName: order.customerName,
        customerPhone: order.customerPhone,
        customerEmail: order.customerEmail,
        items: invoiceItems,
        total: order.total,
        status: order.status === "paid" ? "paid" : "pending",
        paymentMethod: order.paymentMethod,
        notes: `חשבונית עבור הזמנה. orderId: ${order.id}`,
      }

      addInvoice(newInvoice)

      toast({
        title: "חשבונית נוצרה",
        description: "החשבונית נוצרה בהצלחה",
      })
    },
    [addInvoice, hasInvoice, toast],
  )

  return (
    <Card>
      <CardHeader>
        <CardTitle>מעקב הכנסות מהזמנות</CardTitle>
        <CardDescription>
          ניתוח הכנסות מהזמנות בתקופה: {dateRange.from ? format(dateRange.from, "dd/MM/yyyy") : ""} -{" "}
          {dateRange.to ? format(dateRange.to, "dd/MM/yyyy") : ""}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="חיפוש לפי שם לקוח או מוצר"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-pink-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-pink-800">סה"כ הכנסות</h3>
            <p className="text-2xl font-bold text-pink-600">₪{totalRevenue.toLocaleString()}</p>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-green-800">הזמנות שהושלמו</h3>
            <p className="text-2xl font-bold text-green-600">{completedCount}</p>
          </div>
          <div className="bg-red-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-red-800">הזמנות שבוטלו</h3>
            <p className="text-2xl font-bold text-red-600">{canceledCount}</p>
          </div>
        </div>

        <div className="rounded-md border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>תאריך</TableHead>
                <TableHead>מס' הזמנה</TableHead>
                <TableHead>לקוח/ה</TableHead>
                <TableHead>פריטים</TableHead>
                <TableHead>סה"כ</TableHead>
                <TableHead>סטטוס</TableHead>
                <TableHead>פעולות</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrders.length > 0 ? (
                filteredOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                        {order.date ? format(parseISO(order.date), "dd/MM/yyyy") : "N/A"}
                      </div>
                    </TableCell>
                    <TableCell>#{order.id ? order.id.slice(-6) : "N/A"}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <User className="h-4 w-4 mr-2 text-gray-400" />
                        {order.customerName || "N/A"}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Package className="h-4 w-4 mr-2 text-gray-400" />
                        {order.items ? `${order.items.length} פריטים` : "0 פריטים"}
                      </div>
                    </TableCell>
                    <TableCell className={order.status === "cancelled" ? "text-gray-400 line-through" : "font-medium"}>
                      ₪{order.total || 0}
                    </TableCell>
                    <TableCell>{getStatusBadge(order.status)}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        {(order.status === "completed" || order.status === "paid") && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => createTransaction(order)}
                              disabled={hasTransaction(order.id)}
                              className="h-8 px-2 text-xs"
                            >
                              <CreditCard className="h-3 w-3 mr-1" />
                              {hasTransaction(order.id) ? "נרשם" : "רשום עסקה"}
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => createInvoice(order)}
                              disabled={hasInvoice(order.id)}
                              className="h-8 px-2 text-xs"
                            >
                              <FileText className="h-3 w-3 mr-1" />
                              {hasInvoice(order.id) ? "חשבונית קיימת" : "צור חשבונית"}
                            </Button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center">
                    לא נמצאו הזמנות בתקופה זו
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
