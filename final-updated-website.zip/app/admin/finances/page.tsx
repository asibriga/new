"use client"

import React, { useEffect, useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DateRangePicker } from "@/components/admin/date-range-picker"
import AddTransactionDialog from "./add-transaction-dialog"
import { TransactionsList } from "./transactions-list"
import { FinancialReports } from "./financial-reports"
import FinancialCalculator from "./financial-calculator"
import TaxCalculator from "./tax-calculator"
import AutomaticTransactionProcessor from "./automatic-transaction-processor"
import AppointmentRevenueTracker from "./appointment-revenue-tracker"
import OrderRevenueTracker from "./order-revenue-tracker"
import { InvoiceList } from "./invoice-list"
import { Button } from "@/components/ui/button"
import { BarChart3, Calculator, CalendarDays, CreditCard, FileText, PieChart, Plus, Receipt } from "lucide-react"
import { useStore } from "@/lib/store"
import { format } from "date-fns"
import { toast } from "@/components/ui/use-toast"

export default function FinancesPage() {
  const [dateRange, setDateRange] = React.useState({
    from: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
    to: new Date(),
  })

  const [isAddTransactionDialogOpen, setIsAddTransactionDialogOpen] = React.useState(false)
  const [financialSummary, setFinancialSummary] = useState({
    totalIncome: 0,
    totalExpenses: 0,
    netProfit: 0,
    serviceIncome: 0,
    productIncome: 0,
  })
  const [completedAppointments, setCompletedAppointments] = useState(0)
  const [reportPeriod, setReportPeriod] = useState("monthly")

  // Get data from store
  const getFinancialSummary = useStore((state) => state.getFinancialSummary)
  const appointments = useStore((state) => state.appointments)
  const addManualTransaction = useStore((state) => state.addManualTransaction)
  const invoices = useStore((state) => state.invoices)

  // Calculate financial summary when date range changes
  useEffect(() => {
    if (dateRange.from && dateRange.to) {
      const startDate = dateRange.from.toISOString().split("T")[0]
      const endDate = dateRange.to.toISOString().split("T")[0]

      const summary = getFinancialSummary(startDate, endDate)
      setFinancialSummary(summary)

      // Count completed appointments
      const completed = appointments.filter(
        (a) => a.status === "completed" && new Date(a.date) >= dateRange.from && new Date(a.date) <= dateRange.to,
      ).length

      setCompletedAppointments(completed)
    }
  }, [dateRange, getFinancialSummary, appointments])

  const handleAddTransaction = (transaction) => {
    addManualTransaction(transaction)
    setIsAddTransactionDialogOpen(false)
  }

  // Calculate percentage change (for demo purposes)
  const calculatePercentChange = (current, previous) => {
    if (previous === 0) return 0
    return ((current - previous) / previous) * 100
  }

  // Simulate previous month data by reducing current by random percentage
  const getPreviousMonthEstimate = (current) => {
    const randomReduction = 0.7 + Math.random() * 0.4 // Between 70% and 110%
    return current * randomReduction
  }

  // Calculate percentage changes for display
  const incomeChange = calculatePercentChange(
    financialSummary.totalIncome,
    getPreviousMonthEstimate(financialSummary.totalIncome),
  )

  const expenseChange = calculatePercentChange(
    financialSummary.totalExpenses,
    getPreviousMonthEstimate(financialSummary.totalExpenses),
  )

  const profitChange = calculatePercentChange(
    financialSummary.netProfit,
    getPreviousMonthEstimate(financialSummary.netProfit),
  )

  const appointmentsChange = calculatePercentChange(
    completedAppointments,
    getPreviousMonthEstimate(completedAppointments),
  )

  return (
    <div className="container mx-auto p-4 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">ניהול פיננסי</h1>
          <p className="text-muted-foreground">נהל את ההכנסות, ההוצאות והדוחות הפיננסיים של העסק שלך</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
          <DateRangePicker dateRange={dateRange} onDateRangeChange={setDateRange} className="w-full sm:w-auto" />
          <Button onClick={() => setIsAddTransactionDialogOpen(true)} className="bg-pink-500 hover:bg-pink-600">
            <Plus className="h-4 w-4 mr-2" />
            עסקה חדשה
          </Button>
        </div>
      </div>

      <AddTransactionDialog
        isOpen={isAddTransactionDialogOpen}
        onClose={() => setIsAddTransactionDialogOpen(false)}
        onAddTransaction={handleAddTransaction}
      />

      <Tabs defaultValue="overview" dir="rtl" className="w-full">
        <TabsList className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-5 mb-4">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <PieChart className="h-4 w-4" />
            <span className="hidden md:inline">סקירה כללית</span>
          </TabsTrigger>
          <TabsTrigger value="transactions" className="flex items-center gap-2">
            <CreditCard className="h-4 w-4" />
            <span className="hidden md:inline">עסקאות</span>
          </TabsTrigger>
          <TabsTrigger value="invoices" className="flex items-center gap-2">
            <Receipt className="h-4 w-4" />
            <span className="hidden md:inline">חשבוניות</span>
          </TabsTrigger>
          <TabsTrigger value="reports" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden md:inline">דוחות</span>
          </TabsTrigger>
          <TabsTrigger value="tools" className="flex items-center gap-2">
            <Calculator className="h-4 w-4" />
            <span className="hidden md:inline">כלים</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">סך הכנסות</CardTitle>
                <CardDescription>
                  <CalendarDays className="h-4 w-4 inline mr-1" />
                  {dateRange.from.toLocaleDateString()} - {dateRange.to.toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₪{financialSummary.totalIncome.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  <span className={incomeChange >= 0 ? "text-green-500" : "text-red-500"}>
                    {incomeChange >= 0 ? "↑" : "↓"}
                    {Math.abs(Math.round(incomeChange))}%
                  </span>{" "}
                  מהחודש הקודם
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">סך הוצאות</CardTitle>
                <CardDescription>
                  <CalendarDays className="h-4 w-4 inline mr-1" />
                  {dateRange.from.toLocaleDateString()} - {dateRange.to.toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₪{financialSummary.totalExpenses.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  <span className={expenseChange <= 0 ? "text-green-500" : "text-red-500"}>
                    {expenseChange >= 0 ? "↑" : "↓"}
                    {Math.abs(Math.round(expenseChange))}%
                  </span>{" "}
                  מהחודש הקודם
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">רווח נקי</CardTitle>
                <CardDescription>
                  <CalendarDays className="h-4 w-4 inline mr-1" />
                  {dateRange.from.toLocaleDateString()} - {dateRange.to.toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₪{financialSummary.netProfit.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  <span className={profitChange >= 0 ? "text-green-500" : "text-red-500"}>
                    {profitChange >= 0 ? "↑" : "↓"}
                    {Math.abs(Math.round(profitChange))}%
                  </span>{" "}
                  מהחודש הקודם
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">תורים שהושלמו</CardTitle>
                <CardDescription>
                  <CalendarDays className="h-4 w-4 inline mr-1" />
                  {dateRange.from.toLocaleDateString()} - {dateRange.to.toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{completedAppointments}</div>
                <p className="text-xs text-muted-foreground">
                  <span className={appointmentsChange >= 0 ? "text-green-500" : "text-red-500"}>
                    {appointmentsChange >= 0 ? "↑" : "↓"}
                    {Math.abs(Math.round(appointmentsChange))}%
                  </span>{" "}
                  מהחודש הקודם
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  הכנסות לפי קטגוריה
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  {/* Chart component would go here */}
                  <div className="h-full w-full flex items-center justify-center bg-muted/20 rounded-md">
                    <div className="text-center">
                      <BarChart3 className="h-10 w-10 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">נתוני הכנסות לפי קטגוריה</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold flex items-center">
                  <PieChart className="h-5 w-5 mr-2" />
                  התפלגות הכנסות
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  {/* Chart component would go here */}
                  <div className="h-full w-full flex items-center justify-center bg-muted/20 rounded-md">
                    <div className="text-center">
                      <PieChart className="h-10 w-10 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">התפלגות הכנסות לפי מקור</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-semibold flex items-center">
                  <CreditCard className="h-5 w-5 mr-2" />
                  עסקאות אחרונות
                </CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8"
                  onClick={() => {
                    toast({
                      title: "הייצוא החל",
                      description: "הנתונים מיוצאים לקובץ CSV",
                    })

                    // יצירת נתונים לייצוא
                    const transactions = []
                    const headers = ["תאריך", "תיאור", "סכום", "סוג", "קטגוריה", "סטטוס"]
                    const csvContent = [
                      headers.join(","),
                      ...transactions.map((t) =>
                        [
                          t.date ? format(new Date(t.date), "dd/MM/yyyy") : "",
                          `"${t.description?.replace(/"/g, '""') || ""}"`,
                          t.amount,
                          t.type === "income" ? "הכנסה" : "הוצאה",
                          t.category || "",
                          t.status || "הושלם",
                        ].join(","),
                      ),
                    ].join("\n")

                    // הורדת הקובץ
                    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
                    const url = URL.createObjectURL(blob)
                    const link = document.createElement("a")
                    link.setAttribute("href", url)
                    link.setAttribute("download", `transactions_${format(new Date(), "yyyy-MM-dd")}.csv`)
                    document.body.appendChild(link)
                    link.click()
                    document.body.removeChild(link)

                    setTimeout(() => {
                      toast({
                        title: "הייצוא הושלם",
                        description: "הנתונים יוצאו בהצלחה",
                      })
                    }, 1000)
                  }}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  ייצא
                </Button>
              </CardHeader>
              <CardContent>
                <TransactionsList limit={5} dateRange={dateRange} />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">עסקאות</h2>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => console.log("TODO: Add functionality")}>
                <FileText className="h-4 w-4 mr-2" />
                ייצא
              </Button>
              <Button size="sm" onClick={() => setIsAddTransactionDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                עסקה חדשה
              </Button>
            </div>
          </div>
          <Card>
            <CardContent className="p-0">
              <TransactionsList dateRange={dateRange} />
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <AppointmentRevenueTracker dateRange={dateRange} />
            <OrderRevenueTracker dateRange={dateRange} />
          </div>

          <AutomaticTransactionProcessor />
        </TabsContent>

        <TabsContent value="invoices" className="space-y-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">חשבוניות</h2>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  toast({
                    title: "ייצוא חשבוניות",
                    description: "מייצא את כל החשבוניות לקובץ CSV",
                  })

                  // יצירת נתונים לייצוא
                  const invoicesToExport = invoices || []
                  const headers = ["מספר חשבונית", "לקוח", "תאריך", "סכום", "סטטוס"]
                  const csvContent = [
                    headers.join(","),
                    ...invoicesToExport.map((inv) =>
                      [
                        inv.id || "",
                        `"${inv.customerName?.replace(/"/g, '""') || ""}"`,
                        inv.date ? format(new Date(inv.date), "dd/MM/yyyy") : "",
                        inv.total || 0,
                        inv.status || "",
                      ].join(","),
                    ),
                  ].join("\n")

                  // הורדת הקובץ
                  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
                  const url = URL.createObjectURL(blob)
                  const link = document.createElement("a")
                  link.setAttribute("href", url)
                  link.setAttribute("download", `invoices_${format(new Date(), "yyyy-MM-dd")}.csv`)
                  document.body.appendChild(link)
                  link.click()
                  document.body.removeChild(link)

                  setTimeout(() => {
                    toast({
                      title: "הייצוא הושלם",
                      description: "החשבוניות יוצאו בהצלחה",
                    })
                  }, 1000)
                }}
              >
                <FileText className="h-4 w-4 mr-2" />
                ייצא הכל
              </Button>
              <Button
                size="sm"
                onClick={() => {
                  toast({
                    title: "יצירת חשבונית",
                    description: "פתיחת דיאלוג ליצירת חשבונית חדשה",
                  })
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                חשבונית חדשה
              </Button>
            </div>
          </div>
          <Card>
            <CardContent className="p-0">
              <InvoiceList dateRange={dateRange} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <FinancialReports dateRange={dateRange} />
          <Button
            onClick={() => {
              toast({
                title: 'הפקת דוח מע"מ',
                description: 'מפיק דוח מע"מ לתקופה הנבחרת',
              })

              // יצירת נתונים לדוח
              const startDate = format(dateRange.from, "dd/MM/yyyy")
              const endDate = format(dateRange.to, "dd/MM/yyyy")
              const vatOnIncome = Math.round(financialSummary.totalIncome * 0.17)
              const vatOnExpenses = Math.round(financialSummary.totalExpenses * 0.17)
              const vatToPay = vatOnIncome - vatOnExpenses

              // יצירת תוכן הדוח
              const reportContent =
                `דוח מע"מ לתקופה ${startDate} - ${endDate}\n\n` +
                `מע"מ עסקאות: ₪${vatOnIncome.toLocaleString()}\n` +
                `מע"מ תשומות: ₪${vatOnExpenses.toLocaleString()}\n` +
                `סה"כ מע"מ לתשלום: ₪${vatToPay.toLocaleString()}\n\n` +
                `הופק בתאריך: ${format(new Date(), "dd/MM/yyyy HH:mm:ss")}`

              // הורדת הקובץ
              const blob = new Blob([reportContent], { type: "text/plain;charset=utf-8;" })
              const url = URL.createObjectURL(blob)
              const link = document.createElement("a")
              link.setAttribute("href", url)
              link.setAttribute("download", `vat_report_${format(new Date(), "yyyy-MM-dd")}.txt`)
              document.body.appendChild(link)
              link.click()
              document.body.removeChild(link)

              setTimeout(() => {
                toast({
                  title: "הדוח הופק בהצלחה",
                  description: 'דוח המע"מ הורד למחשב שלך',
                })
              }, 1000)
            }}
          >
            <FileText className="h-4 w-4 mr-2" />
            הפק דוח מע"מ
          </Button>
          <Button
            onClick={() => {
              toast({
                title: "הפקת דוח מס הכנסה",
                description: "מפיק דוח מס הכנסה לתקופה הנבחרת",
              })

              // יצירת נתונים לדוח
              const startDate = format(dateRange.from, "dd/MM/yyyy")
              const endDate = format(dateRange.to, "dd/MM/yyyy")

              // יצירת תוכן הדוח
              const reportContent =
                `דוח מס הכנסה לתקופה ${startDate} - ${endDate}\n\n` +
                `הכנסה חייבת: ₪${financialSummary.netProfit.toLocaleString()}\n` +
                `הוצאות מוכרות: ₪${financialSummary.totalExpenses.toLocaleString()}\n` +
                `סה"כ הכנסות: ₪${financialSummary.totalIncome.toLocaleString()}\n\n` +
                `הופק בתאריך: ${format(new Date(), "dd/MM/yyyy HH:mm:ss")}`

              // הורדת הקובץ
              const blob = new Blob([reportContent], { type: "text/plain;charset=utf-8;" })
              const url = URL.createObjectURL(blob)
              const link = document.createElement("a")
              link.setAttribute("href", url)
              link.setAttribute("download", `income_tax_report_${format(new Date(), "yyyy-MM-dd")}.txt`)
              document.body.appendChild(link)
              link.click()
              document.body.removeChild(link)

              setTimeout(() => {
                toast({
                  title: "הדוח הופק בהצלחה",
                  description: "דוח מס ההכנסה הורד למחשב שלך",
                })
              }, 1000)
            }}
          >
            <FileText className="h-4 w-4 mr-2" />
            הפק דוח מס הכנסה
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              toast({
                title: "ייצוא דוחות",
                description: `מייצא דוחות ${reportPeriod === "monthly" ? "חודשי" : reportPeriod === "yearly" ? "שנתי" : reportPeriod === "weekly" ? "שבועי" : reportPeriod === "daily" ? "יומי" : "רבעוני"}`,
              })

              // יצירת נתונים לדוח
              const startDate = format(dateRange.from, "dd/MM/yyyy")
              const endDate = format(dateRange.to, "dd/MM/yyyy")

              // יצירת תוכן הדוח
              const reportContent =
                `דוח פיננסי ${reportPeriod === "monthly" ? "חודשי" : reportPeriod === "yearly" ? "שנתי" : reportPeriod === "weekly" ? "שבועי" : reportPeriod === "daily" ? "יומי" : "רבעוני"} לתקופה ${startDate} - ${endDate}\n\n` +
                `סה"כ הכנסות: ₪${financialSummary.totalIncome.toLocaleString()}\n` +
                `סה"כ הוצאות: ₪${financialSummary.totalExpenses.toLocaleString()}\n` +
                `רווח נקי: ₪${financialSummary.netProfit.toLocaleString()}\n` +
                `הכנסות משירותים: ₪${financialSummary.serviceIncome.toLocaleString()}\n` +
                `הכנסות ממוצרים: ₪${financialSummary.productIncome.toLocaleString()}\n\n` +
                `הופק בתאריך: ${format(new Date(), "dd/MM/yyyy HH:mm:ss")}`

              // הורדת הקובץ
              const blob = new Blob([reportContent], { type: "text/plain;charset=utf-8;" })
              const url = URL.createObjectURL(blob)
              const link = document.createElement("a")
              link.setAttribute("href", url)
              link.setAttribute("download", `financial_report_${format(new Date(), "yyyy-MM-dd")}.txt`)
              document.body.appendChild(link)
              link.click()
              document.body.removeChild(link)

              setTimeout(() => {
                toast({
                  title: "הדוחות יוצאו בהצלחה",
                  description: "הדוחות הפיננסיים הורדו למחשב שלך",
                })
              }, 1000)
            }}
          >
            <FileText className="h-4 w-4 mr-2" />
            ייצא דוחות
          </Button>
        </TabsContent>

        <TabsContent value="tools" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FinancialCalculator />
            <TaxCalculator />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
