"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calculator, Percent, DollarSign, Calendar } from "lucide-react"

export default function FinancialCalculator() {
  const [activeTab, setActiveTab] = useState("profit")

  // Profit Margin Calculator
  const [revenue, setRevenue] = useState("")
  const [costs, setCosts] = useState("")
  const [profitMargin, setProfitMargin] = useState<number | null>(null)

  // Break-even Calculator
  const [fixedCosts, setFixedCosts] = useState("")
  const [pricePerUnit, setPricePerUnit] = useState("")
  const [variableCostPerUnit, setVariableCostPerUnit] = useState("")
  const [breakEvenPoint, setBreakEvenPoint] = useState<number | null>(null)

  // ROI Calculator
  const [initialInvestment, setInitialInvestment] = useState("")
  const [finalValue, setFinalValue] = useState("")
  const [investmentPeriod, setInvestmentPeriod] = useState("")
  const [roi, setRoi] = useState<number | null>(null)
  const [annualizedRoi, setAnnualizedRoi] = useState<number | null>(null)

  // Calculate profit margin
  const calculateProfitMargin = () => {
    const revenueNum = Number.parseFloat(revenue)
    const costsNum = Number.parseFloat(costs)

    if (isNaN(revenueNum) || isNaN(costsNum) || revenueNum === 0) {
      setProfitMargin(null)
      return
    }

    const profit = revenueNum - costsNum
    const margin = (profit / revenueNum) * 100
    setProfitMargin(margin)
  }

  // Calculate break-even point
  const calculateBreakEven = () => {
    const fixedCostsNum = Number.parseFloat(fixedCosts)
    const pricePerUnitNum = Number.parseFloat(pricePerUnit)
    const variableCostPerUnitNum = Number.parseFloat(variableCostPerUnit)

    if (
      isNaN(fixedCostsNum) ||
      isNaN(pricePerUnitNum) ||
      isNaN(variableCostPerUnitNum) ||
      pricePerUnitNum <= variableCostPerUnitNum
    ) {
      setBreakEvenPoint(null)
      return
    }

    const contributionMargin = pricePerUnitNum - variableCostPerUnitNum
    const breakEven = fixedCostsNum / contributionMargin
    setBreakEvenPoint(breakEven)
  }

  // Calculate ROI
  const calculateRoi = () => {
    const initialInvestmentNum = Number.parseFloat(initialInvestment)
    const finalValueNum = Number.parseFloat(finalValue)
    const periodNum = Number.parseFloat(investmentPeriod)

    if (isNaN(initialInvestmentNum) || isNaN(finalValueNum) || initialInvestmentNum === 0) {
      setRoi(null)
      setAnnualizedRoi(null)
      return
    }

    const roiValue = ((finalValueNum - initialInvestmentNum) / initialInvestmentNum) * 100
    setRoi(roiValue)

    if (!isNaN(periodNum) && periodNum > 0) {
      const annualizedRoiValue = (Math.pow(finalValueNum / initialInvestmentNum, 1 / periodNum) - 1) * 100
      setAnnualizedRoi(annualizedRoiValue)
    } else {
      setAnnualizedRoi(null)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Calculator className="mr-2 h-5 w-5" />
          מחשבון פיננסי
        </CardTitle>
        <CardDescription>כלים לחישובים פיננסיים שימושיים</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="profit">שולי רווח</TabsTrigger>
            <TabsTrigger value="breakeven">נקודת איזון</TabsTrigger>
            <TabsTrigger value="roi">תשואה על השקעה</TabsTrigger>
          </TabsList>

          <TabsContent value="profit" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="revenue">הכנסות (₪)</Label>
                <Input
                  id="revenue"
                  type="number"
                  min="0"
                  value={revenue}
                  onChange={(e) => setRevenue(e.target.value)}
                  placeholder="הזן את סך ההכנסות"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="costs">עלויות (₪)</Label>
                <Input
                  id="costs"
                  type="number"
                  min="0"
                  value={costs}
                  onChange={(e) => setCosts(e.target.value)}
                  placeholder="הזן את סך העלויות"
                />
              </div>
            </div>

            <Button className="w-full bg-pink-500 hover:bg-pink-600" onClick={calculateProfitMargin}>
              חשב שולי רווח
            </Button>

            {profitMargin !== null && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Percent className="h-5 w-5 text-pink-500 mr-2" />
                    <span className="font-medium">שולי רווח:</span>
                  </div>
                  <span className={`text-xl font-bold ${profitMargin >= 0 ? "text-green-600" : "text-red-600"}`}>
                    {profitMargin.toFixed(2)}%
                  </span>
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  {profitMargin >= 0
                    ? `על כל ₪100 הכנסות, העסק מרוויח ₪${((profitMargin / 100) * 100).toFixed(2)}`
                    : `על כל ₪100 הכנסות, העסק מפסיד ₪${Math.abs((profitMargin / 100) * 100).toFixed(2)}`}
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="breakeven" className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fixedCosts">עלויות קבועות (₪)</Label>
                <Input
                  id="fixedCosts"
                  type="number"
                  min="0"
                  value={fixedCosts}
                  onChange={(e) => setFixedCosts(e.target.value)}
                  placeholder="הזן את סך העלויות הקבועות"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pricePerUnit">מחיר ליחידה (₪)</Label>
                <Input
                  id="pricePerUnit"
                  type="number"
                  min="0"
                  value={pricePerUnit}
                  onChange={(e) => setPricePerUnit(e.target.value)}
                  placeholder="הזן את המחיר ליחידה"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="variableCostPerUnit">עלות משתנה ליחידה (₪)</Label>
                <Input
                  id="variableCostPerUnit"
                  type="number"
                  min="0"
                  value={variableCostPerUnit}
                  onChange={(e) => setVariableCostPerUnit(e.target.value)}
                  placeholder="הזן את העלות המשתנה ליחידה"
                />
              </div>
            </div>

            <Button className="w-full bg-pink-500 hover:bg-pink-600" onClick={calculateBreakEven}>
              חשב נקודת איזון
            </Button>

            {breakEvenPoint !== null && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <DollarSign className="h-5 w-5 text-pink-500 mr-2" />
                    <span className="font-medium">נקודת איזון:</span>
                  </div>
                  <span className="text-xl font-bold text-blue-600">{Math.ceil(breakEvenPoint)} יחידות</span>
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  העסק צריך למכור לפחות {Math.ceil(breakEvenPoint)} יחידות כדי לכסות את כל העלויות
                </p>
                <div className="mt-2">
                  <span className="text-sm font-medium">הכנסות בנקודת האיזון:</span>
                  <span className="text-sm font-bold mr-2">
                    ₪{(Math.ceil(breakEvenPoint) * Number.parseFloat(pricePerUnit)).toLocaleString()}
                  </span>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="roi" className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="initialInvestment">השקעה התחלתית (₪)</Label>
                <Input
                  id="initialInvestment"
                  type="number"
                  min="0"
                  value={initialInvestment}
                  onChange={(e) => setInitialInvestment(e.target.value)}
                  placeholder="הזן את סכום ההשקעה ההתחלתי"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="finalValue">ערך סופי (₪)</Label>
                <Input
                  id="finalValue"
                  type="number"
                  min="0"
                  value={finalValue}
                  onChange={(e) => setFinalValue(e.target.value)}
                  placeholder="הזן את הערך הסופי של ההשקעה"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="investmentPeriod">תקופת השקעה (שנים)</Label>
                <Input
                  id="investmentPeriod"
                  type="number"
                  min="0"
                  step="0.1"
                  value={investmentPeriod}
                  onChange={(e) => setInvestmentPeriod(e.target.value)}
                  placeholder="הזן את תקופת ההשקעה בשנים"
                />
              </div>
            </div>

            <Button className="w-full bg-pink-500 hover:bg-pink-600" onClick={calculateRoi}>
              חשב תשואה על השקעה
            </Button>

            {roi !== null && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Percent className="h-5 w-5 text-pink-500 mr-2" />
                    <span className="font-medium">תשואה כוללת:</span>
                  </div>
                  <span className={`text-xl font-bold ${roi >= 0 ? "text-green-600" : "text-red-600"}`}>
                    {roi.toFixed(2)}%
                  </span>
                </div>

                {annualizedRoi !== null && (
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center">
                      <Calendar className="h-5 w-5 text-pink-500 mr-2" />
                      <span className="font-medium">תשואה שנתית ממוצעת:</span>
                    </div>
                    <span className={`text-xl font-bold ${annualizedRoi >= 0 ? "text-green-600" : "text-red-600"}`}>
                      {annualizedRoi.toFixed(2)}%
                    </span>
                  </div>
                )}

                <p className="text-sm text-gray-500 mt-2">
                  {roi >= 0
                    ? `ההשקעה הניבה רווח של ₪${(Number.parseFloat(finalValue) - Number.parseFloat(initialInvestment)).toLocaleString()}`
                    : `ההשקעה הניבה הפסד של ₪${Math.abs(Number.parseFloat(finalValue) - Number.parseFloat(initialInvestment)).toLocaleString()}`}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
