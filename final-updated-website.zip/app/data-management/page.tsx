"use client"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"

const getStoreData = () => {
  // Mock data for demonstration purposes
  return {
    customers: [
      { id: 1, name: "John Doe" },
      { id: 2, name: "Jane Smith" },
    ],
    appointments: [{ id: 101, customerId: 1, date: "2024-01-01" }],
    services: [{ id: 201, name: "Haircut" }],
    products: [{ id: 301, name: "Shampoo" }],
    orders: [{ id: 401, customerId: 1, productId: 301 }],
    newsletterSubscribers: ["john@example.com", "jane@example.com"],
    loggedInCustomerId: 1,
    holidays: ["2024-12-25"],
    closedDays: [0, 6],
    twilioSettings: { accountSid: "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" },
    siteContent: { homePageTitle: "Welcome to May Beauty" },
    appointmentTips: ["Book in advance", "Arrive 15 minutes early"],
    loyaltySettings: { enabled: true },
    loyaltyTiers: [{ id: 1, name: "Bronze" }],
    loyaltyRewards: [{ id: 1, tierId: 1, description: "10% off" }],
    coupons: [{ id: 1, code: "SUMMER20", discount: 20 }],
    transactions: [{ id: 1, customerId: 1, amount: 50 }],
    invoices: [{ id: 1, customerId: 1, amount: 50 }],
    logs: [{ id: 1, message: "User logged in" }],
    analytics: [{ date: "2024-01-01", pageViews: 100 }],
  }
}

const DataManagementPage = () => {
  const [exportOptions, setExportOptions] = useState({
    customers: true,
    appointments: true,
    services: true,
    products: true,
    orders: true,
    users: true,
    settings: true,
    transactions: true,
    invoices: true,
    logs: true,
    analytics: true,
  })
  const [isExporting, setIsExporting] = useState(false)
  const [exportProgress, setExportProgress] = useState(0)
  const [exportData, setExportData] = useState("")
  const exportIntervalRef = useRef(null)
  const { toast } = useToast()

  const handleOptionChange = (option) => {
    setExportOptions((prev) => ({
      ...prev,
      [option]: !prev[option],
    }))
  }

  // Fix the handleExport function
  const handleExport = () => {
    // Clear any existing interval
    if (exportIntervalRef.current) {
      clearInterval(exportIntervalRef.current)
    }

    setIsExporting(true)
    setExportProgress(0)

    // Simulate progress
    exportIntervalRef.current = setInterval(() => {
      setExportProgress((prev) => {
        if (prev >= 100) {
          clearInterval(exportIntervalRef.current)
          return 100
        }
        return prev + 5
      })
    }, 50)

    try {
      // Get fresh data
      const storeData = getStoreData()

      // Filter data based on export options
      const dataToExport = {}

      if (exportOptions.customers) {
        dataToExport.customers = storeData.customers
      }

      if (exportOptions.appointments) {
        dataToExport.appointments = storeData.appointments
      }

      if (exportOptions.services) {
        dataToExport.services = storeData.services
      }

      if (exportOptions.products) {
        dataToExport.products = storeData.products
      }

      if (exportOptions.orders) {
        dataToExport.orders = storeData.orders
      }

      if (exportOptions.users) {
        dataToExport.newsletterSubscribers = storeData.newsletterSubscribers
        dataToExport.loggedInCustomerId = storeData.loggedInCustomerId
      }

      if (exportOptions.settings) {
        dataToExport.holidays = storeData.holidays
        dataToExport.closedDays = storeData.closedDays
        dataToExport.twilioSettings = storeData.twilioSettings
        dataToExport.siteContent = storeData.siteContent
        dataToExport.appointmentTips = storeData.appointmentTips
        // Add loyalty settings
        dataToExport.loyaltySettings = storeData.loyaltySettings
        dataToExport.loyaltyTiers = storeData.loyaltyTiers
        dataToExport.loyaltyRewards = storeData.loyaltyRewards
        // Add coupons
        dataToExport.coupons = storeData.coupons
      }

      if (exportOptions.transactions) {
        dataToExport.transactions = storeData.transactions
      }

      if (exportOptions.invoices) {
        dataToExport.invoices = storeData.invoices
      }

      if (exportOptions.logs) {
        dataToExport.logs = storeData.logs
      }

      if (exportOptions.analytics) {
        dataToExport.analytics = storeData.analytics
      }

      // Convert to JSON
      const jsonData = JSON.stringify(dataToExport, null, 2)
      setExportData(jsonData)

      // Create download link
      const blob = new Blob([jsonData], { type: "application/json" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `may-beauty-data-${new Date().toISOString().split("T")[0]}.json`

      // Wait for progress to reach a certain point to ensure better UX
      setTimeout(() => {
        a.click()
        URL.revokeObjectURL(url)

        // Complete the progress bar after file download starts
        setTimeout(() => {
          setExportProgress(100)
          setIsExporting(false)

          toast({
            title: "ייצוא הושלם בהצלחה",
            description: "הנתונים יוצאו בהצלחה וההורדה החלה",
          })
        }, 500)
      }, 800)
    } catch (error) {
      console.error("Error exporting data:", error)
      setIsExporting(false)
      clearInterval(exportIntervalRef.current)

      toast({
        title: "שגיאה בייצוא הנתונים",
        description: "אירעה שגיאה בעת ייצוא הנתונים. אנא נסה שנית.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>ניהול נתונים</CardTitle>
          <CardDescription>ייצוא וייבוא נתונים של האפליקציה.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="customers" className="text-right">
                לקוחות
              </Label>
              <Switch
                id="customers"
                checked={exportOptions.customers}
                onCheckedChange={() => handleOptionChange("customers")}
              />
            </div>
            <div>
              <Label htmlFor="appointments" className="text-right">
                תורים
              </Label>
              <Switch
                id="appointments"
                checked={exportOptions.appointments}
                onCheckedChange={() => handleOptionChange("appointments")}
              />
            </div>
            <div>
              <Label htmlFor="services" className="text-right">
                שירותים
              </Label>
              <Switch
                id="services"
                checked={exportOptions.services}
                onCheckedChange={() => handleOptionChange("services")}
              />
            </div>
            <div>
              <Label htmlFor="products" className="text-right">
                מוצרים
              </Label>
              <Switch
                id="products"
                checked={exportOptions.products}
                onCheckedChange={() => handleOptionChange("products")}
              />
            </div>
            <div>
              <Label htmlFor="orders" className="text-right">
                הזמנות
              </Label>
              <Switch id="orders" checked={exportOptions.orders} onCheckedChange={() => handleOptionChange("orders")} />
            </div>
            <div>
              <Label htmlFor="users" className="text-right">
                משתמשים
              </Label>
              <Switch id="users" checked={exportOptions.users} onCheckedChange={() => handleOptionChange("users")} />
            </div>
            <div>
              <Label htmlFor="settings" className="text-right">
                הגדרות
              </Label>
              <Switch
                id="settings"
                checked={exportOptions.settings}
                onCheckedChange={() => handleOptionChange("settings")}
              />
            </div>
            <div>
              <Label htmlFor="transactions" className="text-right">
                עסקאות
              </Label>
              <Switch
                id="transactions"
                checked={exportOptions.transactions}
                onCheckedChange={() => handleOptionChange("transactions")}
              />
            </div>
            <div>
              <Label htmlFor="invoices" className="text-right">
                חשבוניות
              </Label>
              <Switch
                id="invoices"
                checked={exportOptions.invoices}
                onCheckedChange={() => handleOptionChange("invoices")}
              />
            </div>
            <div>
              <Label htmlFor="logs" className="text-right">
                לוגים
              </Label>
              <Switch id="logs" checked={exportOptions.logs} onCheckedChange={() => handleOptionChange("logs")} />
            </div>
            <div>
              <Label htmlFor="analytics" className="text-right">
                אנליטיקס
              </Label>
              <Switch
                id="analytics"
                checked={exportOptions.analytics}
                onCheckedChange={() => handleOptionChange("analytics")}
              />
            </div>
          </div>

          <Button onClick={handleExport} disabled={isExporting}>
            {isExporting ? "מייצא..." : "ייצוא נתונים"}
          </Button>

          {isExporting && <Progress value={exportProgress} className="mt-4" />}
        </CardContent>
      </Card>
    </div>
  )
}

export default DataManagementPage
