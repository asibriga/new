"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import Image from "next/image"
import { Calendar } from "lucide-react"
import { useStore } from "@/lib/store"

export default function ServicesPage() {
  // Get services from store
  const services = useStore((state) => state.services)
  const [activeCategory, setActiveCategory] = useState("manicure")

  // Define service categories
  const serviceCategories = [
    {
      id: "manicure",
      name: "מניקור",
      description: "טיפולי מניקור מקצועיים",
    },
    {
      id: "pedicure",
      name: "פדיקור",
      description: "טיפולי פדיקור מפנקים",
    },
    {
      id: "gel-nails",
      name: "בניית ציפורניים",
      description: "בניית ציפורניים בג'ל ואקריליק",
    },
    {
      id: "nail-art",
      name: "עיצוב ציפורניים",
      description: "עיצובים מיוחדים וציורי ציפורניים",
    },
  ]

  // Map services to categories
  const categorizedServices = {
    manicure: services.filter((s) => s.name.includes("מניקור") || s.description.includes("מניקור")),
    pedicure: services.filter((s) => s.name.includes("פדיקור") || s.description.includes("פדיקור")),
    "gel-nails": services.filter(
      (s) =>
        s.name.includes("בניית") ||
        s.name.includes("ג'ל") ||
        s.description.includes("בניית") ||
        s.description.includes("ג'ל"),
    ),
    "nail-art": services.filter((s) => s.name.includes("עיצוב") || s.description.includes("עיצוב")),
  }

  // Add any uncategorized services to a default category
  services.forEach((service) => {
    let isInCategory = false
    for (const category in categorizedServices) {
      if (categorizedServices[category].some((s) => s.id === service.id)) {
        isInCategory = true
        break
      }
    }

    if (!isInCategory) {
      categorizedServices["manicure"].push(service)
    }
  })

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">השירותים שלנו</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          ב-May Beauty אנו מציעים מגוון רחב של טיפולי ציפורניים וטיפולי יופי ברמה הגבוהה ביותר
        </p>
      </div>

      <Tabs defaultValue="manicure" value={activeCategory} onValueChange={setActiveCategory} className="mb-12">
        <TabsList className="flex flex-wrap justify-center mb-8">
          {serviceCategories.map((category) => (
            <TabsTrigger key={category.id} value={category.id} className="px-6">
              {category.name}
            </TabsTrigger>
          ))}
        </TabsList>

        {serviceCategories.map((category) => (
          <TabsContent key={category.id} value={category.id}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {categorizedServices[category.id].map((service) => (
                <Card key={service.id} className="overflow-hidden">
                  <div className="aspect-video relative">
                    <Image
                      src={service.image || "/placeholder.svg?height=200&width=300"}
                      alt={service.name}
                      fill
                      className="object-cover"
                      unoptimized={service.image?.startsWith("blob:")}
                    />
                  </div>
                  <CardHeader>
                    <CardTitle>{service.name}</CardTitle>
                    <CardDescription>{service.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-bold text-pink-500">₪{service.price}</span>
                      <span className="text-sm text-gray-500">{service.duration} דקות</span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href={`/booking?service=${service.id}`} className="w-full">
                      <Button className="w-full bg-pink-500 hover:bg-pink-600" onClick={() => console.log("TODO: Add functionality")}>
                        <Calendar className="mr-2 h-4 w-4" /> הזמנת תור
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
