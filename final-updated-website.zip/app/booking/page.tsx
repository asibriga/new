"use client"

import { useState, useEffect, useCallback } from "react"
import { format, addMinutes } from "date-fns"
import { he } from "date-fns/locale"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { CheckCircle, ChevronLeft, ChevronRight, Clock } from "lucide-react"
import { useStore } from "@/lib/store"
import { isIsraeliHoliday } from "@/lib/israeli-holidays"
import { useRouter } from "next/navigation"
import CouponCodeInput from "@/components/coupon-code-input"

export default function BookingPage() {
  const { toast } = useToast()
  const [step, setStep] = useState(1)
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [selectedTime, setSelectedTime] = useState<string | null>(null)
  const [selectedServices, setSelectedServices] = useState<string[]>([])
  const [customerName, setCustomerName] = useState("")
  const [customerPhone, setCustomerPhone] = useState("")
  const [notes, setNotes] = useState("")
  const [isWaitlist, setIsWaitlist] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [availableTimes, setAvailableTimes] = useState<string[]>([])
  const [totalDuration, setTotalDuration] = useState(0)
  const [totalPrice, setTotalPrice] = useState(0)
  const [endTime, setEndTime] = useState<string | null>(null)

  const router = useRouter()
  const loggedInCustomerId = useStore((state) => state.loggedInCustomerId)

  const [couponDiscount, setCouponDiscount] = useState(0)
  const [couponType, setCouponType] = useState<"percentage" | "fixed">("fixed")
  const [appliedCouponCode, setAppliedCouponCode] = useState("")

  // Function to check if a time slot is within closed hours
  const isWithinClosedHours = useCallback((date: string, time: string) => {
    const closedHours = useStore.getState().closedHours || []
    const closedHoursForDate = closedHours.filter((ch) => ch.date === date)

    if (closedHoursForDate.length === 0) return false

    // Convert time to minutes for easier comparison
    const [hours, minutes] = time.split(":").map(Number)
    const timeInMinutes = hours * 60 + minutes

    // Check if time falls within any closed hours period
    return closedHoursForDate.some((ch) => {
      const [startHours, startMinutes] = ch.startTime.split(":").map(Number)
      const [endHours, endMinutes] = ch.endTime.split(":").map(Number)

      const startTimeInMinutes = startHours * 60 + startMinutes
      const endTimeInMinutes = endHours * 60 + endMinutes

      return timeInMinutes >= startTimeInMinutes && timeInMinutes < endTimeInMinutes
    })
  }, [])

  // Check if user is logged in
  useEffect(() => {
    // Check if there's a rebooking request in session storage
    const rebookAppointment = sessionStorage.getItem("rebookAppointment")
    if (rebookAppointment && loggedInCustomerId) {
      try {
        const rebookData = JSON.parse(rebookAppointment)
        setSelectedServices([rebookData.serviceId])

        // Clear the rebook data
        sessionStorage.removeItem("rebookAppointment")

        toast({
          title: "פרטי התור שוחזרו",
          description: `בחרת לקבוע תור חדש ל${rebookData.serviceName}`,
        })

        // Set step to date/time selection
        setStep(2)
      } catch (error) {
        console.error("Error restoring rebooking data:", error)
        sessionStorage.removeItem("rebookAppointment")
      }
    }
    // Check if there's a pending booking in session storage
    const pendingBooking = sessionStorage.getItem("pendingBooking")

    if (pendingBooking && loggedInCustomerId) {
      // User has logged in and has a pending booking
      try {
        const bookingData = JSON.parse(pendingBooking)
        setCustomerName(bookingData.customerName || "")
        setCustomerPhone(bookingData.customerPhone || "")
        if (bookingData.selectedDate) {
          setSelectedDate(new Date(bookingData.selectedDate))
        }
        setSelectedTime(bookingData.selectedTime || null)
        setSelectedServices(bookingData.selectedServices || [])
        setNotes(bookingData.notes || "")
        setIsWaitlist(bookingData.isWaitlist || false)

        // Clear the pending booking
        sessionStorage.removeItem("pendingBooking")

        // Set step to the appropriate step based on what data is available
        if (bookingData.selectedServices?.length > 0) {
          if (bookingData.selectedDate && (bookingData.selectedTime || bookingData.isWaitlist)) {
            setStep(3) // Go to personal details step
          } else {
            setStep(2) // Go to date/time selection
          }
        }

        toast({
          title: "פרטי ההזמנה שוחזרו",
          description: "ניתן להמשיך בתהליך קביעת התור",
        })
      } catch (error) {
        console.error("Error restoring booking data:", error)
        sessionStorage.removeItem("pendingBooking")
      }
    } else if (!loggedInCustomerId) {
      // User is not logged in, redirect to login page
      toast({
        title: "נדרשת התחברות",
        description: "יש להתחבר או להירשם לפני קביעת תור",
        variant: "destructive",
      })
      router.push("/client/login?redirect=booking")
    }
  }, [loggedInCustomerId, toast, router])

  // Auto-fill customer details when logged in
  useEffect(() => {
    if (loggedInCustomerId) {
      const customers = useStore.getState().customers
      const loggedInCustomer = customers.find((c) => c.id === loggedInCustomerId)

      if (loggedInCustomer) {
        setCustomerName(loggedInCustomer.name || "")
        setCustomerPhone(loggedInCustomer.phone || "")
      }
    }
  }, [loggedInCustomerId])

  // Get data from store
  const services = useStore((state) => state.services)
  const holidays = useStore((state) => state.holidays || [])
  const closedDays = useStore((state) => state.closedDays || [])
  const addAppointment = useStore((state) => state.addAppointment)
  const getAvailableTimeSlots = useStore((state) => state.getAvailableTimeSlots)
  const appointmentTips = useStore(
    (state) =>
      state.appointmentTips || {
        title: "טיפים חשובים לקראת התור שלך",
        content: [
          "נא להגיע 10 דקות לפני התור שנקבע",
          "במקרה של איחור, התור עלול להתקצר או להתבטל",
          "אנא הודיעי מראש על ביטול (לפחות 24 שעות מראש)",
          "אנו מקבלים תשלום במזומן, העברה בנקאית או ביט",
        ],
      },
  )
  const appointments = useStore((state) => state.appointments)

  // Calculate total duration and price when services change
  useEffect(() => {
    let duration = 0
    let price = 0

    selectedServices.forEach((serviceId) => {
      const service = services.find((s) => s.id === serviceId)
      if (service) {
        duration += service.duration
        price += service.price
      }
    })

    setTotalDuration(duration)
    setTotalPrice(price)

    // Calculate end time if a start time is selected
    if (selectedTime) {
      const [hours, minutes] = selectedTime.split(":").map(Number)
      const startTimeDate = new Date()
      startTimeDate.setHours(hours, minutes, 0, 0)
      const endTimeDate = addMinutes(startTimeDate, duration)
      setEndTime(
        `${endTimeDate.getHours().toString().padStart(2, "0")}:${endTimeDate.getMinutes().toString().padStart(2, "0")}`,
      )
    }
  }, [selectedServices, selectedTime, services])

  // Update the useEffect for available times to exclude pending appointments
  useEffect(() => {
    if (selectedDate && selectedServices.length > 0) {
      // Get the first service for initial time slots
      const primaryServiceId = selectedServices[0]
      const formattedDate = format(selectedDate, "yyyy-MM-dd")

      // Get all time slots for the primary service
      const timeSlots = getAvailableTimeSlots(formattedDate, primaryServiceId)
        .filter((slot) => slot.isAvailable)
        .map((slot) => slot.time)

      // Filter out slots that would cause overlap with other services
      const validTimeSlots = timeSlots.filter((time) => {
        // Check if this time works for all selected services
        const hasOverlap = selectedServices.some((serviceId) => {
          const service = services.find((s) => s.id === serviceId)
          if (!service) return false

          return checkAppointmentOverlap(time, service.duration, formattedDate, appointments)
        })

        // Also filter out times that fall within closed hours
        const isClosedHour = isWithinClosedHours(formattedDate, time)

        return !hasOverlap && !isClosedHour
      })

      setAvailableTimes(validTimeSlots)
    } else {
      setAvailableTimes([])
    }
  }, [selectedDate, selectedServices, services, appointments, getAvailableTimeSlots, isWithinClosedHours])

  const handleServiceToggle = (serviceId: string) => {
    setSelectedServices((prev) => {
      if (prev.includes(serviceId)) {
        return prev.filter((id) => id !== serviceId)
      } else {
        return [...prev, serviceId]
      }
    })
  }

  const handleApplyCoupon = (discount: number, type: "percentage" | "fixed", code: string) => {
    setCouponDiscount(discount)
    setCouponType(type)
    setAppliedCouponCode(code)
  }

  const handleRemoveCoupon = () => {
    setCouponDiscount(0)
    setCouponType("fixed")
    setAppliedCouponCode("")
  }

  const calculateFinalPrice = () => {
    if (couponDiscount <= 0) return totalPrice

    if (couponType === "percentage") {
      return totalPrice - totalPrice * (couponDiscount / 100)
    } else {
      return Math.max(0, totalPrice - couponDiscount)
    }
  }

  // Update the handleSubmit function to create a single appointment with multiple services
  const handleSubmit = () => {
    if (
      !customerName ||
      !customerPhone ||
      !selectedDate ||
      (!selectedTime && !isWaitlist) ||
      selectedServices.length === 0
    ) {
      toast({
        title: "שגיאה",
        description: "אנא מלא את כל השדות הנדרשים",
        variant: "destructive",
      })
      return
    }

    // Check if user is logged in
    const loggedInCustomerId = useStore.getState().loggedInCustomerId
    if (!loggedInCustomerId) {
      toast({
        title: "נדרשת התחברות",
        description: "יש להתחבר או להירשם לפני קביעת תור",
        variant: "destructive",
      })

      // Save booking data to session storage for after login
      const bookingData = {
        customerName,
        customerPhone,
        selectedDate: selectedDate?.toISOString(),
        selectedTime,
        selectedServices,
        notes,
        isWaitlist,
      }
      sessionStorage.setItem("pendingBooking", JSON.stringify(bookingData))

      // Redirect to login page
      router.push("/client/login?redirect=booking")
      return
    }

    // Format date
    const formattedDate = format(selectedDate, "yyyy-MM-dd")

    // Get all selected service details
    const servicesDetails = selectedServices.map((serviceId) => {
      const service = services.find((s) => s.id === serviceId)
      return {
        id: serviceId,
        name: service?.name || "",
        price: service?.price || 0,
        duration: service?.duration || 0,
      }
    })

    // Calculate total price
    const totalPrice = servicesDetails.reduce((sum, service) => sum + service.price, 0)

    // Create a single appointment with all services
    const serviceNames = servicesDetails.map((s) => s.name).join(", ")

    // Create appointment with combined services
    addAppointment({
      customerId: loggedInCustomerId,
      customerName,
      customerPhone,
      customerEmail: "",
      serviceId: selectedServices[0], // Use first service ID as primary
      serviceName: serviceNames, // Combined service names
      date: formattedDate,
      time: selectedTime || "",
      notes: JSON.stringify({
        multipleServices: true,
        services: servicesDetails,
        totalDuration: totalDuration,
        endTime: endTime,
      }),
      price: totalPrice,
      status: isWaitlist ? "pending" : "pending",
      isWaitlist,
    })

    toast({
      title: isWaitlist && !selectedTime ? "נרשמת לרשימת המתנה" : "התור נקבע בהצלחה",
      description:
        isWaitlist && !selectedTime
          ? `נרשמת לרשימת המתנה לתאריך ${format(selectedDate, "dd/MM/yyyy", { locale: he })}`
          : `תור חדש נקבע: ${customerName} - ${format(selectedDate, "dd/MM/yyyy", { locale: he })} ${selectedTime}`,
    })

    setIsSubmitted(true)
  }

  const isDateDisabled = (date: Date) => {
    if (!date) return true
    const formattedDate = format(date, "yyyy-MM-dd")
    const isHoliday = holidays.some((h) => h.date === formattedDate) || isIsraeliHoliday(date)
    const isClosed = closedDays.some((d) => d.date === formattedDate)
    const isWeekend = date.getDay() === 6 // Saturday
    const isPastDate = date < new Date(new Date().setHours(0, 0, 0, 0))

    return isHoliday || isClosed || isWeekend || isPastDate
  }

  const getDateClassName = (date: Date) => {
    if (!date) return ""
    const formattedDate = format(date, "yyyy-MM-dd")
    const isHoliday = holidays.find((h) => h.date === formattedDate)
    const isClosed = closedDays.find((d) => d.date === formattedDate)
    const isIsraelHoliday = isIsraeliHoliday(date)

    if (isHoliday || isIsraelHoliday) return "bg-red-100 text-red-800 relative holiday"
    if (isClosed) return "bg-orange-100 text-orange-800 relative closed-day"
    if (date.getDay() === 6) return "bg-gray-100 text-gray-400" // Saturday
    return ""
  }

  const checkAppointmentOverlap = (time: string, duration: number, date: string, appointments: any[]) => {
    const [hours, minutes] = time.split(":").map(Number)
    const startTimeMinutes = hours * 60 + minutes
    const endTimeMinutes = startTimeMinutes + duration

    const bookedAppointments = appointments.filter(
      (a) =>
        a.date === date &&
        (a.status === "confirmed" || a.status === "completed" || a.status === "pending") &&
        !a.isWaitlist,
    )

    for (const appointment of bookedAppointments) {
      let appointmentDuration = 0

      try {
        if (appointment.notes && appointment.notes.includes("multipleServices")) {
          const notesData = JSON.parse(appointment.notes)
          appointmentDuration = notesData.totalDuration || 0
        } else {
          const appointmentService = services.find((s) => s.id === appointment.serviceId)
          appointmentDuration = appointmentService ? appointmentService.duration : 60
        }
      } catch (error) {
        console.error("Error parsing appointment notes:", error)
        const appointmentService = services.find((s) => s.id === appointment.serviceId)
        appointmentDuration = appointmentService ? appointmentService.duration : 60
      }

      const [appHours, appMinutes] = appointment.time.split(":").map(Number)
      const appStartTimeMinutes = appHours * 60 + appMinutes
      const appEndTimeMinutes = appStartTimeMinutes + appointmentDuration

      if (
        (startTimeMinutes >= appStartTimeMinutes && startTimeMinutes < appEndTimeMinutes) ||
        (endTimeMinutes > appStartTimeMinutes && endTimeMinutes <= appEndTimeMinutes) ||
        (startTimeMinutes <= appStartTimeMinutes && endTimeMinutes >= appEndTimeMinutes)
      ) {
        return true
      }
    }

    return false
  }

  if (isSubmitted) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-md">
        <Card className="overflow-hidden">
          <CardHeader className="text-center bg-pink-50 pb-6">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
              <CheckCircle className="h-10 w-10 text-green-600" />
            </div>
            <CardTitle className="text-2xl">
              {isWaitlist ? "נרשמת לרשימת המתנה בהצלחה!" : "התור נקבע בהצלחה!"}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="mb-6">
              <p className="mb-4 text-center">
                {isWaitlist
                  ? "תודה שנרשמת לרשימת ההמתנה. נעדכן אותך במידה ויתפנה מקום."
                  : "תודה שקבעת תור אצלנו. נשלח לך תזכורת יום לפני התור."}
              </p>

              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <div className="mb-2">
                  <span className="font-semibold">שם:</span> {customerName}
                </div>
                <div className="mb-2">
                  <span className="font-semibold">טלפון:</span> {customerPhone}
                </div>
                <div className="mb-2">
                  <span className="font-semibold">תאריך:</span> {format(selectedDate!, "dd/MM/yyyy", { locale: he })}
                </div>
                {!isWaitlist && (
                  <>
                    <div className="mb-2">
                      <span className="font-semibold">שעה:</span> {selectedTime} - {endTime}
                    </div>
                    <div className="mb-2">
                      <span className="font-semibold">משך הטיפול:</span> {totalDuration} דקות
                    </div>
                  </>
                )}
                <div className="mb-2">
                  <span className="font-semibold">שירותים:</span>
                  <ul className="list-disc list-inside mr-4 mt-1">
                    {selectedServices.map((serviceId) => {
                      const service = services.find((s) => s.id === serviceId)
                      return service ? (
                        <li key={serviceId}>
                          {service.name} ({service.duration} דקות) - ₪{service.price}
                        </li>
                      ) : null
                    })}
                  </ul>
                </div>
                <div>
                  <span className="font-semibold">סה"כ לתשלום:</span> ₪{totalPrice}
                </div>
              </div>

              {!isWaitlist && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-800 mb-2">{appointmentTips.title}</h4>
                  <ul className="text-blue-700 text-sm space-y-1">
                    {appointmentTips.content.map((tip, index) => (
                      <li key={index} className="flex items-start">
                        <span className="ml-2 mt-1">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <Button className="w-full bg-pink-500 hover:bg-pink-600" onClick={() => (window.location.href = "/")}>
              חזרה לדף הבית
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-pink-500 mb-2">קביעת תור</h1>
        <p className="text-gray-600">בחרי את השירותים הרצויים, תאריך ושעה</p>
      </div>

      <div className="flex justify-center mb-6">
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? "bg-pink-500 text-white" : "bg-gray-200"}`}
          >
            3
          </div>
          <div className={`w-16 h-1 ${step >= 2 ? "bg-pink-500" : "bg-gray-200"}`}></div>
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? "bg-pink-500 text-white" : "bg-gray-200"}`}
          >
            2
          </div>
          <div className={`w-16 h-1 ${step >= 1 ? "bg-pink-500" : "bg-gray-200"}`}></div>
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? "bg-pink-500 text-white" : "bg-gray-200"}`}
          >
            1
          </div>
        </div>
      </div>

      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">בחירת שירותים</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {services.map((service) => (
                <div
                  key={service.id}
                  className={`border rounded-lg p-4 cursor-pointer transition-all ${
                    selectedServices.includes(service.id) ? "border-pink-500 bg-pink-50" : "hover:border-pink-200"
                  }`}
                  onClick={() => handleServiceToggle(service.id)}
                >
                  <div className="flex justify-between items-center">
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-medium">{service.name}</h3>
                        <Checkbox
                          checked={selectedServices.includes(service.id)}
                          onCheckedChange={() => handleServiceToggle(service.id)}
                          className="h-5 w-5 border-pink-500 data-[state=checked]:bg-pink-500"
                        />
                      </div>
                      <p className="text-gray-600 mt-1">{service.description}</p>
                      <div className="flex items-center mt-2 space-x-3 rtl:space-x-reverse">
                        <div className="bg-pink-100 text-pink-800 px-3 py-1 rounded-full text-sm">₪{service.price}</div>
                        <div className="flex items-center text-gray-500 text-sm">
                          <Clock className="h-3 w-3 ml-1" />
                          {service.duration} דקות
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {selectedServices.length > 0 && (
                <div className="mt-6 bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">סה"כ זמן:</p>
                      <p className="text-gray-600">{totalDuration} דקות</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">סה"כ לתשלום:</p>
                      <p className="text-xl font-bold text-pink-500">₪{totalPrice}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-8 flex justify-between">
              <Button variant="outline" onClick={() => (window.location.href = "/")}>
                ביטול
              </Button>
              <Button
                className="bg-pink-500 hover:bg-pink-600"
                onClick={() => setStep(2)}
                disabled={selectedServices.length === 0}
              >
                המשך לבחירת תאריך
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {step === 2 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">בחירת תאריך ושעה</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-medium mb-3">תאריך</h3>
                {/* Calendar component */}
                <div className="border rounded-lg p-4">
                  <div className="text-center mb-4">
                    <div className="flex items-center justify-between">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (selectedDate) {
                            const nextMonth = new Date(selectedDate)
                            nextMonth.setMonth(nextMonth.getMonth() + 1)
                            setSelectedDate(nextMonth)
                          }
                        }}
                      >
                        <ChevronLeft className="h-5 w-5" />
                      </Button>
                      <h3 className="text-lg font-medium">
                        {selectedDate ? format(selectedDate, "MMMM yyyy", { locale: he }) : ""}
                      </h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (selectedDate) {
                            const prevMonth = new Date(selectedDate)
                            prevMonth.setMonth(prevMonth.getMonth() - 1)
                            setSelectedDate(prevMonth)
                          }
                        }}
                      >
                        <ChevronRight className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>

                  <div className="calendar-container rtl">
                    {/* Days of week - right to left */}
                    <div className="grid grid-cols-7 gap-1 mb-2 text-center">
                      <div className="text-sm font-medium">א'</div>
                      <div className="text-sm font-medium">ב'</div>
                      <div className="text-sm font-medium">ג'</div>
                      <div className="text-sm font-medium">ד'</div>
                      <div className="text-sm font-medium">ה'</div>
                      <div className="text-sm font-medium">ו'</div>
                      <div className="text-sm font-medium">ש'</div>
                    </div>

                    {/* Calendar grid */}
                    <div className="grid grid-cols-7 gap-1">
                      {(() => {
                        if (!selectedDate) return null

                        const year = selectedDate.getFullYear()
                        const month = selectedDate.getMonth()

                        // First day of month
                        const firstDay = new Date(year, month, 1)

                        // Last day of month
                        const lastDay = new Date(year, month + 1, 0)

                        // Get day of week for first day (0 = Sunday, 6 = Saturday)
                        const firstDayOfWeek = firstDay.getDay() // 0 for Sunday, 1 for Monday, etc.
                        const emptyCellsAtStart = firstDayOfWeek // For RTL Hebrew calendar, Sunday is rightmost

                        // Array to hold all calendar cells
                        const days = []

                        // Add empty cells for days before first day of month
                        for (let i = 0; i < emptyCellsAtStart; i++) {
                          days.push(<div key={`empty-start-${i}`} className="h-10"></div>)
                        }

                        // Add days of month
                        for (let i = 1; i <= lastDay.getDate(); i++) {
                          const date = new Date(year, month, i)
                          const isToday = new Date().toDateString() === date.toDateString()
                          const isSelected = selectedDate.getDate() === i
                          const isDisabled = isDateDisabled(date)
                          const customClass = getDateClassName(date)

                          days.push(
                            <Button
                              key={`day-${i}`}
                              variant="ghost"
                              className={`h-10 w-full rounded-md flex items-center justify-center p-0 ${
                                isSelected ? "bg-pink-500 text-white hover:bg-pink-600" : ""
                              } ${isToday && !isSelected ? "bg-pink-100 text-pink-900" : ""} 
                              ${isDisabled ? "opacity-50 cursor-not-allowed" : ""}
                              ${customClass}`}
                              disabled={isDisabled}
                              onClick={() => setSelectedDate(date)}
                            >
                              {i}
                            </Button>,
                          )
                        }

                        // Calculate total cells needed (7 days * up to 6 rows)
                        const totalCells = 7 * Math.ceil((emptyCellsAtStart + lastDay.getDate()) / 7)

                        // Add empty cells at the end to complete the grid
                        const emptyCellsAtEnd = totalCells - days.length
                        for (let i = 0; i < emptyCellsAtEnd; i++) {
                          days.push(<div key={`empty-end-${i}`} className="h-10"></div>)
                        }

                        return days
                      })()}
                    </div>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-red-100 ml-1 rounded-sm"></div>
                      <span className="text-xs">חג</span>
                    </div>
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-orange-100 ml-1 rounded-sm"></div>
                      <span className="text-xs">יום סגור</span>
                    </div>
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-pink-100 ml-1 rounded-sm"></div>
                      <span className="text-xs">היום</span>
                    </div>
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-pink-500 ml-1 rounded-sm"></div>
                      <span className="text-xs">נבחר</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-3">שעה</h3>
                <div className="border rounded-lg p-4">
                  {availableTimes.length > 0 ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-2">
                        {availableTimes.map((time) => (
                          <Button
                            key={time}
                            variant={selectedTime === time ? "default" : "outline"}
                            className={selectedTime === time ? "bg-pink-500 hover:bg-pink-600" : ""}
                            onClick={() => setSelectedTime(time)}
                          >
                            {time}
                          </Button>
                        ))}
                      </div>

                      <div className="flex items-center mt-4 p-3 bg-yellow-50 rounded-md border border-yellow-200">
                        <Checkbox
                          id="waitlist-option"
                          checked={isWaitlist}
                          onCheckedChange={(checked) => setIsWaitlist(checked === true)}
                          className="h-4 w-4 border-yellow-500 data-[state=checked]:bg-yellow-500"
                        />
                        <label htmlFor="waitlist-option" className="mr-2 text-sm cursor-pointer">
                          הרשם גם לרשימת המתנה במקרה של ביטול
                        </label>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500 mb-4">אין שעות זמינות בתאריך זה</p>
                      <div className="bg-yellow-50 p-4 rounded-md border border-yellow-200 max-w-md mx-auto">
                        <h3 className="font-medium text-yellow-800 mb-2">רשימת המתנה</h3>
                        <p className="text-sm text-yellow-700 mb-3">
                          אין תורים פנויים בתאריך זה, אך באפשרותך להירשם לרשימת המתנה ונעדכן אותך במקרה של ביטול.
                        </p>
                        <div className="flex items-center">
                          <Checkbox
                            id="waitlist"
                            checked={isWaitlist}
                            onCheckedChange={(checked) => setIsWaitlist(checked === true)}
                            className="h-4 w-4 border-yellow-500 data-[state=checked]:bg-yellow-500"
                          />
                          <label htmlFor="waitlist" className="mr-2 text-sm cursor-pointer font-medium">
                            הרשם לרשימת המתנה
                          </label>
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedTime && (
                    <div className="mt-4 bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm">
                        <span className="font-medium">זמן התחלה:</span> {selectedTime}
                      </p>
                      <p className="text-sm">
                        <span className="font-medium">זמן סיום משוער:</span> {endTime}
                      </p>
                      <p className="text-sm">
                        <span className="font-medium">משך הטיפול:</span> {totalDuration} דקות
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-8 flex justify-between">
              <Button variant="outline" onClick={() => setStep(1)}>
                חזרה
              </Button>
              <Button
                className="bg-pink-500 hover:bg-pink-600"
                onClick={() => setStep(3)}
                disabled={!selectedDate || (!selectedTime && !isWaitlist)}
              >
                המשך להזנת פרטים
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {step === 3 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">פרטים אישיים</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium mb-1">
                  שם מלא
                </label>
                <Input
                  id="name"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="הכנס שם מלא"
                  className="w-full"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium mb-1">
                  מספר טלפון
                </label>
                <Input
                  id="phone"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="הכנס מספר טלפון"
                  className="w-full"
                  type="tel"
                  inputMode="numeric"
                  pattern="[0-9]*"
                />
              </div>

              <div>
                <label htmlFor="notes" className="block text-sm font-medium mb-1">
                  הערות (אופציונלי)
                </label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="הערות נוספות לגבי התור"
                  className="w-full resize-none"
                />
              </div>

              <div className="space-y-4">
                <CouponCodeInput onApply={handleApplyCoupon} onRemove={handleRemoveCoupon} />
              </div>

              <div className="mt-6 bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium mb-3">סיכום הזמנה</h3>

                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span>שירותים:</span>
                    <span>{selectedServices.length} שירותים</span>
                  </div>
                  <div className="flex justify-between">
                    <span>תאריך:</span>
                    <span>{format(selectedDate!, "dd/MM/yyyy", { locale: he })}</span>
                  </div>
                  {selectedTime && (
                    <div className="flex justify-between">
                      <span>שעה:</span>
                      <span>
                        {selectedTime} - {endTime}
                      </span>
                    </div>
                  )}
                  {isWaitlist && (
                    <div className="flex justify-between text-orange-600">
                      <span>סטטוס:</span>
                      <span>רשימת המתנה</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>משך טיפול:</span>
                    <span>{totalDuration} דקות</span>
                  </div>
                  <div className="flex justify-between">
                    <span>מחיר:</span>
                    <span>₪{totalPrice}</span>
                  </div>

                  {couponDiscount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>הנחת קופון:</span>
                      <span>{couponType === "percentage" ? `${couponDiscount}%` : `₪${couponDiscount}`}</span>
                    </div>
                  )}

                  <div className="flex justify-between font-bold">
                    <span>סה"כ לתשלום:</span>
                    <span className="text-pink-500">₪{calculateFinalPrice()}</span>
                  </div>
                </div>

                <div className="text-sm text-gray-500">* התשלום יתבצע במקום בסיום הטיפול</div>
              </div>
            </div>

            <div className="mt-8 flex justify-between">
              <Button variant="outline" onClick={() => setStep(2)}>
                חזרה
              </Button>
              <Button className="bg-pink-500 hover:bg-pink-600" onClick={handleSubmit}>
                {isWaitlist ? "הרשם לרשימת המתנה" : "קבע תור"}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
