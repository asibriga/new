"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle2 } from "lucide-react"

// Define form schema
const formSchema = z.object({
  phone: z
    .string()
    .min(10, { message: "מספר טלפון חייב להכיל לפחות 10 ספרות" })
    .regex(/^[0-9]+$/, { message: "מספר טלפון חייב להכיל ספרות בלבד" }),
})

export default function ForgotPasswordPage() {
  const router = useRouter()
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<boolean>(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const customers = useStore((state) => state.customers)
  const updateCustomer = useStore((state) => state.updateCustomer)
  const addNotification = useStore((state) => state.addNotification)

  // Initialize form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      phone: "",
    },
  })

  // Generate a random password
  const generateTemporaryPassword = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    let password = ""
    for (let i = 0; i < 8; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return password
  }

  // Handle form submission
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      setIsSubmitting(true)
      setError(null)
      setSuccess(false)

      // Find customer by phone number
      const customer = customers.find((c) => c.phone === values.phone && c.isRegistered)

      if (!customer) {
        setError("לא נמצא משתמש רשום עם מספר הטלפון הזה")
        setIsSubmitting(false)
        return
      }

      // Generate temporary password
      const tempPassword = generateTemporaryPassword()

      // Update customer password
      updateCustomer(customer.id, {
        password: tempPassword,
      })

      // Add notification about password reset
      addNotification({
        type: "system",
        message: `הסיסמה שלך אופסה. הסיסמה החדשה שלך היא: ${tempPassword}`,
        userId: customer.id,
      })

      // Show success message
      setSuccess(true)
      setIsSubmitting(false)

      // In a real app, you would send an SMS with the temporary password
      console.log(`Temporary password for ${customer.name}: ${tempPassword}`)
    } catch (err) {
      console.error("Password reset error:", err)
      setError("אירעה שגיאה באיפוס הסיסמה. אנא נסי שנית.")
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto py-10 px-4 max-w-md">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">שכחתי סיסמה</CardTitle>
          <CardDescription>הזיני את מספר הטלפון שלך כדי לאפס את הסיסמה</CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success ? (
            <div className="bg-green-50 p-6 rounded-lg text-center">
              <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-green-800 mb-2">הסיסמה אופסה בהצלחה!</h3>
              <p className="text-green-700 mb-4">
                סיסמה זמנית נשלחה אליך. אנא בדקי את ההתראות במערכת או את הודעות ה-SMS שלך.
              </p>
              <Button className="bg-green-500 hover:bg-green-600 w-full" onClick={() => router.push("/client/login")}>
                חזרה לדף ההתחברות
              </Button>
            </div>
          ) : (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>מספר טלפון</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="הכניסי את מספר הטלפון שלך"
                          {...field}
                          type="tel"
                          inputMode="numeric"
                          pattern="[0-9]*"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? "מאפס סיסמה..." : "אפס סיסמה"}
                </Button>
              </form>
            </Form>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <div className="text-sm text-gray-500">
            נזכרת בסיסמה?{" "}
            <Link href="/client/login" className="text-pink-600 hover:underline">
              התחברי כאן
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
