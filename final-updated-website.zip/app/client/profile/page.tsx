"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import { useStore } from "@/lib/store"
import { useRouter } from "next/navigation"
import { ArrowLeft, Save, Upload, X } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function ProfilePage() {
  const { toast } = useToast()
  const router = useRouter()
  const loggedInCustomerId = useStore((state) => state.loggedInCustomerId)
  const customers = useStore((state) => state.customers)
  const updateCustomer = useStore((state) => state.updateCustomer)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    birthdate: "",
    isSubscribedToNewsletter: false,
    image: "",
  })

  const [isLoading, setIsLoading] = useState(false)
  const [previewImage, setPreviewImage] = useState<string | null>(null)

  // Redirect if not logged in
  useEffect(() => {
    if (!loggedInCustomerId) {
      router.push("/client/login")
    } else {
      // Load customer data
      const customer = customers.find((c) => c.id === loggedInCustomerId)
      if (customer) {
        setFormData({
          name: customer.name || "",
          phone: customer.phone || "",
          email: customer.email || "",
          address: customer.address || "",
          birthdate: customer.birthdate || "",
          isSubscribedToNewsletter: customer.isSubscribedToNewsletter || false,
          image: customer.image || "",
        })

        if (customer.image) {
          setPreviewImage(customer.image)
        }
      }
    }
  }, [loggedInCustomerId, customers, router])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (checked) => {
    setFormData((prev) => ({ ...prev, isSubscribedToNewsletter: checked }))
  }

  const handleImageUpload = (e) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "שגיאה",
        description: "גודל הקובץ חייב להיות קטן מ-5MB",
        variant: "destructive",
      })
      return
    }

    // Check file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "שגיאה",
        description: "הקובץ חייב להיות תמונה",
        variant: "destructive",
      })
      return
    }

    // Create a preview
    const reader = new FileReader()
    reader.onload = (e) => {
      const result = e.target?.result as string
      setPreviewImage(result)
      setFormData((prev) => ({ ...prev, image: result }))
    }
    reader.readAsDataURL(file)
  }

  const handleRemoveImage = () => {
    setPreviewImage(null)
    setFormData((prev) => ({ ...prev, image: "" }))
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      if (!formData.name || !formData.phone) {
        toast({
          title: "שגיאה",
          description: "שם וטלפון הם שדות חובה",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }

      // Update customer
      updateCustomer(loggedInCustomerId, {
        name: formData.name,
        phone: formData.phone,
        email: formData.email,
        address: formData.address,
        birthdate: formData.birthdate,
        isSubscribedToNewsletter: formData.isSubscribedToNewsletter,
        image: formData.image,
      })

      toast({
        title: "הפרטים עודכנו בהצלחה",
        description: "הפרטים האישיים שלך עודכנו במערכת",
      })

      // Redirect back to dashboard
      setTimeout(() => {
        router.push("/client/dashboard")
      }, 1000)
    } catch (error) {
      console.error("Error updating profile:", error)
      toast({
        title: "שגיאה בעדכון הפרטים",
        description: "אירעה שגיאה בעת עדכון הפרטים. אנא נסי שוב.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (!loggedInCustomerId) {
    return null
  }

  return (
    <div className="container mx-auto py-8 max-w-md">
      <Button variant="ghost" className="mb-4" onClick={() => router.push("/client/dashboard")}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        חזרה לדף הבית
      </Button>

      <Card>
        <CardHeader>
          <CardTitle>עריכת פרטים אישיים</CardTitle>
          <CardDescription>עדכני את הפרטים האישיים שלך</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex flex-col items-center mb-6">
              <div className="relative">
                <Avatar className="h-24 w-24 border-4 border-pink-200 mb-2">
                  <AvatarImage
                    src={previewImage || "/placeholder.svg?height=100&width=100"}
                    alt={formData.name}
                    unoptimized={previewImage?.startsWith?.("blob:") ? "true" : undefined}
                  />
                  <AvatarFallback className="bg-pink-100 text-pink-800 text-xl">
                    {formData.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                {previewImage && (
                  <Button
                    type="button"
                    variant="destructive"
                    size="icon"
                    className="absolute -top-2 -right-2 h-6 w-6 rounded-full"
                    onClick={handleRemoveImage}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
              <div className="flex items-center mt-2">
                <input
                  type="file"
                  id="profile-image"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageUpload}
                  ref={fileInputRef}
                />
                <Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                  <Upload className="h-4 w-4 mr-2" />
                  העלאת תמונה
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">שם מלא *</Label>
              <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">טלפון *</Label>
              <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">אימייל</Label>
              <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">כתובת</Label>
              <Textarea
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="הכניסי את כתובתך המלאה"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="birthdate">תאריך לידה</Label>
              <Input
                id="birthdate"
                name="birthdate"
                type="date"
                value={formData.birthdate || ""}
                onChange={handleChange}
                placeholder="הכניסי את תאריך הלידה שלך לקבלת הטבת יום הולדת"
              />
              <p className="text-xs text-gray-500">הכניסי את תאריך הלידה שלך כדי לקבל הטבה מיוחדת ביום ההולדת שלך</p>
            </div>

            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Switch
                id="newsletter"
                checked={formData.isSubscribedToNewsletter}
                onCheckedChange={handleSwitchChange}
              />
              <Label htmlFor="newsletter">אני מעוניינת לקבל עדכונים ומבצעים</Label>
            </div>
          </form>
        </CardContent>
        <CardFooter>
          <Button className="w-full bg-pink-500 hover:bg-pink-600" onClick={handleSubmit} disabled={isLoading}>
            {isLoading ? (
              "מעדכן..."
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                שמירת שינויים
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
