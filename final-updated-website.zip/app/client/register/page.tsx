"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Check, X } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

// Define form schema
const formSchema = z
  .object({
    name: z.string().min(2, { message: "שם חייב להכיל לפחות 2 תווים" }),
    phone: z
      .string()
      .min(10, { message: "מספר טלפון חייב להכיל לפחות 10 ספרות" })
      .regex(/^[0-9]+$/, { message: "מספר טלפון חייב להכיל ספרות בלבד" }),
    email: z.string().email({ message: "כתובת אימייל לא תקינה" }).optional().or(z.literal("")),
    password: z.string().min(6, { message: "סיסמה חייבת להכיל לפחות 6 תווים" }),
    confirmPassword: z.string(),
    referralCode: z.string().optional(),
    termsAccepted: z.boolean().refine((val) => val === true, {
      message: "יש לאשר את תנאי השימוש",
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "הסיסמאות אינן תואמות",
    path: ["confirmPassword"],
  })

export default function RegisterPage() {
  const router = useRouter()
  const [error, setError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isReferralValid, setIsReferralValid] = useState<boolean | null>(null)
  const [isTermsDialogOpen, setIsTermsDialogOpen] = useState(false)
  const [isPrivacyDialogOpen, setIsPrivacyDialogOpen] = useState(false)

  const addCustomer = useStore((state) => state.addCustomer)
  const setLoggedInCustomer = useStore((state) => state.setLoggedInCustomer)
  const customers = useStore((state) => state.customers)
  const updateCustomer = useStore((state) => state.updateCustomer)
  const addNotification = useStore((state) => state.addNotification)
  const verifyReferralCode = useStore((state) => state.verifyReferralCode)

  // Initialize form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      password: "",
      confirmPassword: "",
      referralCode: "",
      termsAccepted: false,
    },
  })

  // Check referral code validity when it changes
  const referralCode = form.watch("referralCode")

  // Fix the referral code validation
  const checkReferralCode = () => {
    if (!referralCode || referralCode.trim() === "") {
      setIsReferralValid(null)
      return
    }

    // Call the store function directly and handle the result
    try {
      const trimmedCode = referralCode.trim()
      console.log("Checking referral code:", trimmedCode)
      const isValid = verifyReferralCode(trimmedCode)
      console.log("Referral code validation result:", isValid)
      setIsReferralValid(isValid)

      if (!isValid) {
        // Show error message if code is invalid
        toast({
          title: "קוד הפניה לא תקין",
          description: "קוד ההפניה שהזנת אינו תקף או שניסית להשתמש בקוד שלך",
          variant: "destructive",
        })
      } else {
        // Show success message if code is valid
        toast({
          title: "קוד הפניה תקין",
          description: "קוד ההפניה אומת בהצלחה",
        })
      }
    } catch (error) {
      console.error("Error validating referral code:", error)
      setIsReferralValid(false)
      toast({
        title: "שגיאה",
        description: "אירעה שגיאה בבדיקת קוד ההפניה",
        variant: "destructive",
      })
    }
  }

  // Fix the form submission function
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      setIsSubmitting(true)
      setError(null)

      // Check if phone number already exists
      const existingCustomer = customers.find((c) => c.phone === values.phone)
      if (existingCustomer) {
        setError("מספר הטלפון כבר רשום במערכת")
        setIsSubmitting(false)
        return
      }

      // Validate referral code if provided
      let referrerId = null
      if (values.referralCode && values.referralCode.trim() !== "") {
        const trimmedCode = values.referralCode.trim()
        const isValid = verifyReferralCode(trimmedCode)

        if (!isValid) {
          setError("קוד ההפניה אינו תקין או שניסית להשתמש בקוד שלך")
          setIsSubmitting(false)
          return
        }

        // Find the customer with this referral code
        const referrer = customers.find((c) => c.referralCode === trimmedCode)
        if (referrer) {
          referrerId = referrer.id
        }
      }

      // Add customer to store
      const customerId = addCustomer({
        name: values.name,
        phone: values.phone,
        email: values.email || undefined,
        password: values.password,
        isRegistered: true,
        status: "active",
        visits: 0,
        referredBy: referrerId,
        loyaltyPoints: referrerId ? 50 : 0, // Bonus points for using referral code
        createdAt: new Date().toISOString().split("T")[0], // Add creation date
      })

      // Add welcome notification
      addNotification({
        type: "system",
        message: "ברוכה הבאה ל-May Beauty! תודה שנרשמת למערכת שלנו.",
        userId: customerId,
      })

      // Set logged in customer
      setLoggedInCustomer(customerId)

      // Redirect to dashboard
      console.log("Registration successful, redirecting to dashboard...")
      router.push("/client/dashboard")
    } catch (err) {
      console.error("Registration error:", err)
      setError("אירעה שגיאה בתהליך ההרשמה. אנא נסי שנית.")
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto py-10 px-4 max-w-md">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">הרשמה</CardTitle>
          <CardDescription>צרי חשבון חדש כדי לקבוע תורים ולעקוב אחרי ההזמנות שלך</CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>שם מלא</FormLabel>
                    <FormControl>
                      <Input placeholder="הכניסי את שמך המלא" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>מספר טלפון</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="הכניסי את מספר הטלפון שלך"
                        {...field}
                        type="tel"
                        inputMode="numeric"
                        pattern="[0-9]*"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>אימייל (אופציונלי)</FormLabel>
                    <FormControl>
                      <Input placeholder="הכניסי את כתובת האימייל שלך" {...field} type="email" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>סיסמה</FormLabel>
                    <FormControl>
                      <Input placeholder="בחרי סיסמה" {...field} type="password" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>אימות סיסמה</FormLabel>
                    <FormControl>
                      <Input placeholder="הכניסי את הסיסמה שוב" {...field} type="password" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="referralCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>קוד הפניה (אופציונלי)</FormLabel>
                    <div className="flex space-x-2 rtl:space-x-reverse">
                      <FormControl>
                        <Input placeholder="הכניסי קוד הפניה אם יש לך" {...field} />
                      </FormControl>
                      <Button type="button" variant="outline" onClick={checkReferralCode} className="shrink-0">
                        בדיקה
                      </Button>
                    </div>
                    {isReferralValid !== null && (
                      <div className="mt-2 text-sm flex items-center">
                        {isReferralValid ? (
                          <>
                            <Check className="h-4 w-4 text-green-500 mr-1" />
                            <span className="text-green-600">קוד הפניה תקין</span>
                          </>
                        ) : (
                          <>
                            <X className="h-4 w-4 text-red-500 mr-1" />
                            <span className="text-red-600">קוד הפניה אינו תקין</span>
                          </>
                        )}
                      </div>
                    )}
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="termsAccepted"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rtl:space-x-reverse">
                    <FormControl>
                      <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>
                        אני מסכימ/ה ל
                        <button
                          type="button"
                          onClick={() => setIsTermsDialogOpen(true)}
                          className="text-pink-600 hover:underline mx-1"
                        >
                          תנאי השימוש
                        </button>
                        ול
                        <button
                          type="button"
                          onClick={() => setIsPrivacyDialogOpen(true)}
                          className="text-pink-600 hover:underline mx-1"
                        >
                          מדיניות הפרטיות
                        </button>
                      </FormLabel>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />

              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "מבצע רישום..." : "הרשמה"}
              </Button>
            </form>
          </Form>
        </CardContent>
        <CardFooter className="flex justify-center">
          <div className="text-sm text-gray-500">
            כבר יש לך חשבון?{" "}
            <Link href="/client/login" className="text-pink-600 hover:underline">
              התחברי כאן
            </Link>
          </div>
        </CardFooter>
      </Card>

      {/* Terms of Service Dialog */}
      <Dialog open={isTermsDialogOpen} onOpenChange={setIsTermsDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>תנאי שימוש</DialogTitle>
            <DialogDescription>אנא קראי בעיון את תנאי השימוש הבאים</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 text-sm">
            <h3 className="text-lg font-bold">1. כללי</h3>
            <p>
              ברוכים הבאים לאתר May Beauty. השימוש באתר ובשירותים המוצעים בו כפוף לתנאי השימוש המפורטים להלן. המשך
              השימוש באתר מהווה הסכמה מצדך לתנאים אלה.
            </p>

            <h3 className="text-lg font-bold">2. הרשמה וחשבון משתמש</h3>
            <p>
              על מנת להשתמש בחלק מהשירותים באתר, עליך להירשם ולפתוח חשבון משתמש. בעת ההרשמה, עליך למסור פרטים מדויקים
              ומלאים. אתה אחראי לשמירה על סודיות פרטי החשבון שלך ולכל הפעילויות המתבצעות תחת חשבונך.
            </p>

            <h3 className="text-lg font-bold">3. קביעת תורים וביטולים</h3>
            <p>
              האתר מאפשר קביעת תורים לטיפולים. ביטול תור יש לבצע לפחות 24 שעות מראש. ביטול מאוחר יותר עלול לגרור חיוב
              בדמי ביטול.
            </p>

            <h3 className="text-lg font-bold">4. רכישות ותשלומים</h3>
            <p>
              המחירים המוצגים באתר הם בשקלים חדשים וכוללים מע"מ. אנו שומרים לעצמנו את הזכות לשנות מחירים בכל עת ללא
              הודעה מוקדמת.
            </p>

            <h3 className="text-lg font-bold">5. מדיניות החזרים</h3>
            <p>
              החזרים יינתנו בהתאם לחוק הגנת הצרכן. מוצרים שנפתחו או נעשה בהם שימוש אינם ניתנים להחזרה אלא אם נמצא בהם
              פגם.
            </p>

            <h3 className="text-lg font-bold">6. תוכן המשתמש</h3>
            <p>
              בפרסום תוכן באתר (כגון תגובות או ביקורות), אתה מעניק לנו רישיון בלתי חוזר להשתמש בתוכן זה. אתה מתחייב שלא
              לפרסם תוכן פוגעני, מאיים, גזעני או בלתי חוקי.
            </p>

            <h3 className="text-lg font-bold">7. קניין רוחני</h3>
            <p>
              כל התכנים באתר, לרבות טקסטים, תמונות, לוגו וסימנים מסחריים, הם קניינה הרוחני של May Beauty או של צדדים
              שלישיים שהעניקו לנו רישיון להשתמש בהם.
            </p>

            <h3 className="text-lg font-bold">8. הגבלת אחריות</h3>
            <p>
              השימוש באתר הוא על אחריותך בלבד. האתר מסופק "כפי שהוא" (AS IS) ואיננו מתחייבים שהשירות יהיה ללא הפרעות או
              שגיאות.
            </p>

            <h3 className="text-lg font-bold">9. שינויים בתנאי השימוש</h3>
            <p>אנו שומרים לעצמנו את הזכות לשנות את תנאי השימוש בכל עת. שינויים אלה ייכנסו לתוקף מיד עם פרסומם באתר.</p>

            <h3 className="text-lg font-bold">10. דין וסמכות שיפוט</h3>
            <p>
              על תנאי שימוש אלה יחולו דיני מדינת ישראל. סמכות השיפוט הבלעדית בכל עניין הנוגע לתנאים אלה תהיה נתונה לבתי
              המשפט המוסמכים בתל אביב.
            </p>
          </div>
          <div className="flex justify-end">
            <Button onClick={() => setIsTermsDialogOpen(false)}>סגירה</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Privacy Policy Dialog */}
      <Dialog open={isPrivacyDialogOpen} onOpenChange={setIsPrivacyDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>מדיניות פרטיות</DialogTitle>
            <DialogDescription>אנא קראי בעיון את מדיניות הפרטיות הבאה</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 text-sm">
            <h3 className="text-lg font-bold">1. איסוף מידע</h3>
            <p>
              אנו אוספים מידע אישי כגון שם, כתובת דואר אלקטרוני, מספר טלפון וכתובת למשלוח כאשר אתה נרשם לאתר, מבצע רכישה
              או קובע תור.
            </p>

            <h3 className="text-lg font-bold">2. שימוש במידע</h3>
            <p>אנו משתמשים במידע שנאסף כדי:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>לספק, לתחזק ולשפר את השירותים שלנו</li>
              <li>לעבד הזמנות ותשלומים</li>
              <li>לשלוח הודעות בנוגע לחשבונך או לשירותים שלנו</li>
              <li>לשלוח חומרים שיווקיים ופרסומיים (אם הסכמת לכך)</li>
            </ul>
          </div>
          <div className="flex justify-end">
            <Button onClick={() => setIsPrivacyDialogOpen(false)}>סגירה</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
