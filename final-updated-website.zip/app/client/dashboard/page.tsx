"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useStore } from "@/lib/store"
import {
  CalendarIcon,
  Clock,
  FileText,
  User,
  LogOut,
  Gift,
  Bell,
  CheckCircle2,
  Sparkles,
  Award,
  ShoppingBag,
  Ticket,
  Copy,
  X,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { format } from "date-fns"
import { he } from "date-fns/locale"
import { Progress } from "@/components/ui/progress"
import ReferralCodeWidget from "@/components/referral-code-widget"
import LoyaltyPointsWidget from "@/components/loyalty-points-widget"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Calendar } from "@/components/ui/calendar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ClientDashboard() {
  const router = useRouter()
  const { toast } = useToast()

  // Store data
  const loggedInCustomerId = useStore((state) => state.loggedInCustomerId)
  const getLoggedInCustomer = useStore((state) => state.getLoggedInCustomer)
  const logoutCustomer = useStore((state) => state.logoutCustomer)
  const appointments = useStore((state) => state.appointments)
  const orders = useStore((state) => state.orders)
  const services = useStore((state) => state.services)
  const loyaltyTiers = useStore((state) => state.loyaltyTiers || [])
  const loyaltyRewards = useStore((state) => state.loyaltyRewards || [])
  const redeemReward = useStore((state) => state.redeemReward)
  const updateCustomer = useStore((state) => state.updateCustomer)
  const addCoupon = useStore((state) => state.addCoupon)
  const coupons = useStore((state) => state.coupons || [])
  const notifications = useStore((state) => state.notifications || [])
  const addNotification = useStore((state) => state.addNotification)
  const markNotificationAsRead = useStore((state) => state.markNotificationAsRead)
  const clearNotifications = useStore((state) => state.clearNotifications)
  const getAvailableTimeSlots = useStore((state) => state.getAvailableTimeSlots)
  const updateAppointment = useStore((state) => state.updateAppointment)
  const cancelAppointment = useStore((state) => state.cancelAppointment)

  // UI state
  const [unreadNotifications, setUnreadNotifications] = useState(0)
  const [activeTab, setActiveTab] = useState("overview")
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false)
  const [showRewardsDialog, setShowRewardsDialog] = useState(false)
  const [selectedReward, setSelectedReward] = useState(null)
  const [rewardCouponCode, setRewardCouponCode] = useState("")
  const [showCouponDialog, setShowCouponDialog] = useState(false)
  const [isClientLoggedIn, setIsClientLoggedIn] = useState(false)
  const [customerData, setCustomerData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)

  // Appointment and order details states
  const [selectedAppointment, setSelectedAppointment] = useState(null)
  const [isAppointmentDetailsOpen, setIsAppointmentDetailsOpen] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState(null)
  const [isOrderDetailsOpen, setIsOrderDetailsOpen] = useState(false)

  // Change appointment states
  const [isChangeAppointmentDialogOpen, setIsChangeAppointmentDialogOpen] = useState(false)
  const [appointmentToChange, setAppointmentToChange] = useState(null)
  const [newAppointmentDate, setNewAppointmentDate] = useState(null)
  const [newAppointmentTime, setNewAppointmentTime] = useState("")
  const [availableTimes, setAvailableTimes] = useState([])

  // Initialize customer data
  useEffect(() => {
    if (loggedInCustomerId) {
      setIsClientLoggedIn(true)
      const customer = getLoggedInCustomer()
      setCustomerData(customer)
    } else {
      setIsClientLoggedIn(false)
      router.push("/client/login")
    }
    setIsLoading(false)
  }, [loggedInCustomerId, getLoggedInCustomer, router])

  // Count unread notifications
  const countUnreadNotifications = useCallback(() => {
    if (loggedInCustomerId) {
      const userNotifications = notifications.filter((n) => n.userId === loggedInCustomerId)
      const unreadCount = userNotifications.filter((n) => !n.isRead).length
      setUnreadNotifications(unreadCount)
    }
  }, [notifications, loggedInCustomerId])

  useEffect(() => {
    countUnreadNotifications()
  }, [countUnreadNotifications])

  // Load available times when date changes
  const loadAvailableTimes = useCallback(
    (date, serviceId) => {
      if (!date || !serviceId) return

      const formattedDate = format(date, "yyyy-MM-dd")
      const timeSlots = getAvailableTimeSlots(formattedDate, serviceId)
      setAvailableTimes(timeSlots.map((slot) => slot.time))
    },
    [getAvailableTimeSlots],
  )

  // Handle viewing appointment details
  const handleViewAppointmentDetails = useCallback((appointment) => {
    setSelectedAppointment(appointment)
    setIsAppointmentDetailsOpen(true)
  }, [])

  // Handle viewing order details
  const handleViewOrderDetails = useCallback((order) => {
    setSelectedOrder(order)
    setIsOrderDetailsOpen(true)
  }, [])

  // Handle logout
  const handleLogout = useCallback(() => {
    logoutCustomer()
    router.push("/")
  }, [logoutCustomer, router])

  // Calculate appointment end time
  const calculateEndTime = useCallback((startTime, notes) => {
    try {
      if (!startTime) return "לא זמין"

      // Extract total duration from notes if available
      let totalDurationMinutes = 0

      try {
        if (notes) {
          const parsedNotes = JSON.parse(notes)
          if (parsedNotes.totalDuration) {
            totalDurationMinutes = Number.parseInt(parsedNotes.totalDuration)
          } else if (parsedNotes.services && Array.isArray(parsedNotes.services)) {
            // Sum up durations of all services
            totalDurationMinutes = parsedNotes.services.reduce((total, service) => {
              return total + (service.duration || 0)
            }, 0)
          }
        }
      } catch (e) {
        console.error("Error parsing appointment notes:", e)
        return "לא זמין"
      }

      // If we couldn't extract a duration, use a default
      if (totalDurationMinutes <= 0) {
        totalDurationMinutes = 60 // Default duration
      }

      const [hours, minutes] = startTime.split(":").map(Number)
      if (isNaN(hours) || isNaN(minutes)) return "לא זמין"

      const startDate = new Date()
      startDate.setHours(hours, minutes, 0, 0)

      const endDate = new Date(startDate.getTime() + totalDurationMinutes * 60000)
      const endHours = endDate.getHours().toString().padStart(2, "0")
      const endMinutes = endDate.getMinutes().toString().padStart(2, "0")

      return `${endHours}:${endMinutes}`
    } catch (error) {
      console.error("Error calculating end time:", error)
      return "לא זמין"
    }
  }, [])

  // Mark notification as read
  const handleMarkAsRead = useCallback(
    (id) => {
      markNotificationAsRead(id)
    },
    [markNotificationAsRead],
  )

  // Mark all notifications as read
  const markAllAsRead = useCallback(() => {
    const customerNotifications = notifications.filter((notification) => notification.userId === loggedInCustomerId)
    customerNotifications.forEach((notification) => {
      if (!notification.isRead) {
        markNotificationAsRead(notification.id)
      }
    })
  }, [notifications, loggedInCustomerId, markNotificationAsRead])

  // Get notification icon based on type
  const getNotificationIcon = useCallback((type) => {
    switch (type) {
      case "gift":
        return <Gift className="h-5 w-5 text-pink-500" />
      case "points":
        return <Sparkles className="h-5 w-5 text-amber-500" />
      case "redeem":
        return <CheckCircle2 className="h-5 w-5 text-green-500" />
      case "appointment":
        return <CalendarIcon className="h-5 w-5 text-blue-500" />
      case "coupon":
        return <Ticket className="h-5 w-5 text-purple-500" />
      default:
        return <Bell className="h-5 w-5 text-gray-500" />
    }
  }, [])

  // Copy coupon code to clipboard
  const copyToClipboard = useCallback(
    (text) => {
      navigator.clipboard.writeText(text).then(
        () => {
          toast({
            title: "הועתק ללוח",
            description: "קוד הקופון הועתק ללוח בהצלחה",
          })
        },
        (err) => {
          console.error("Could not copy text: ", err)
        },
      )
    },
    [toast],
  )

  // Generate a random coupon code
  const generateCouponCode = useCallback(() => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    let code = "REWARD"
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return code
  }, [])

  // Handle redeeming a reward
  const handleRedeemReward = useCallback(
    (rewardId) => {
      if (!loggedInCustomerId) return

      // Find the reward
      const reward = loyaltyRewards.find((r) => r.id === rewardId)
      if (!reward) {
        toast({
          title: "שגיאה",
          description: "ההטבה לא נמצאה",
          variant: "destructive",
        })
        return
      }

      setSelectedReward(reward)
      setShowRewardsDialog(true)
    },
    [loggedInCustomerId, loyaltyRewards, toast],
  )

  const confirmRedeemReward = useCallback(() => {
    if (!selectedReward || !loggedInCustomerId) return

    // Use the redeemReward function from the store
    const success = redeemReward(loggedInCustomerId, selectedReward.id)

    if (success) {
      // Generate a coupon code for the reward
      const couponCode = generateCouponCode()
      setRewardCouponCode(couponCode)

      // Add the coupon to the system
      let couponValue = 0
      let couponType = "fixed"

      if (selectedReward.type === "discount") {
        couponValue = selectedReward.value || 50
        couponType = "fixed"
      } else if (selectedReward.type === "percentDiscount") {
        couponValue = selectedReward.value || 10
        couponType = "percentage"
      } else {
        // For free services or products, set a high fixed value
        couponValue = 1000
        couponType = "fixed"
      }

      addCoupon({
        code: couponCode,
        discount: couponValue,
        type: couponType,
        isActive: true,
        maxUses: 1,
        usedCount: 0,
        expirationDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // 30 days from now
        description: `קוד קופון עבור ${selectedReward.name}`,
      })

      // Add notification about the redeemed reward
      addNotification({
        type: "redeem",
        message: `מימשת את ההטבה: ${selectedReward.name}. קוד הקופון שלך: ${couponCode}`,
        userId: loggedInCustomerId,
      })

      toast({
        title: "ההטבה מומשה בהצלחה",
        description: `מימשת את ההטבה ${selectedReward.name} בהצלחה`,
      })

      setShowRewardsDialog(false)
      setShowCouponDialog(true)
    } else {
      toast({
        title: "שגיאה במימוש ההטבה",
        description: "אירעה שגיאה בעת מימוש ההטבה. אנא נסי שנית.",
        variant: "destructive",
      })
    }
  }, [selectedReward, loggedInCustomerId, redeemReward, generateCouponCode, addCoupon, addNotification, toast])

  // Function to check if more than 24 hours until appointment
  const isMoreThan24HoursAway = useCallback((date, time) => {
    const appointmentDateTime = new Date(`${date}T${time}`)
    const now = new Date()
    const diffInHours = (appointmentDateTime.getTime() - now.getTime()) / (1000 * 60 * 60)
    return diffInHours > 24
  }, [])

  // Function to handle appointment cancellation
  const handleCancelAppointment = useCallback(
    (appointment) => {
      // Show confirmation dialog
      if (confirm("האם את בטוחה שברצונך לבטל את התור?")) {
        // Call the store function to cancel the appointment
        cancelAppointment(appointment.id)

        toast({
          title: "התור בוטל בהצלחה",
          description: "התור שלך בוטל בהצלחה",
        })

        // Add notification
        addNotification({
          type: "appointment",
          message: `התור שלך ל${appointment.serviceName} בתאריך ${format(new Date(appointment.date), "dd/MM/yyyy")} בשעה ${appointment.time} בוטל בהצלחה`,
          userId: loggedInCustomerId,
        })
      }
    },
    [cancelAppointment, toast, addNotification, loggedInCustomerId],
  )

  // Function to handle changing appointment
  const handleChangeAppointment = useCallback(
    (appointment) => {
      setAppointmentToChange(appointment)
      setNewAppointmentDate(new Date(appointment.date))
      setIsChangeAppointmentDialogOpen(true)

      // Load available times for the selected date
      const formattedDate = format(new Date(appointment.date), "yyyy-MM-dd")
      loadAvailableTimes(new Date(appointment.date), appointment.serviceId)
    },
    [loadAvailableTimes],
  )

  const handleDateChange = useCallback(
    (date) => {
      setNewAppointmentDate(date)
      if (date && appointmentToChange) {
        loadAvailableTimes(date, appointmentToChange.serviceId)
      }
    },
    [appointmentToChange, loadAvailableTimes],
  )

  const confirmAppointmentChange = useCallback(() => {
    if (!newAppointmentDate || !newAppointmentTime || !appointmentToChange) {
      toast({
        title: "שגיאה",
        description: "יש לבחור תאריך ושעה חדשים",
        variant: "destructive",
      })
      return
    }

    const formattedDate = format(newAppointmentDate, "yyyy-MM-dd")

    // Update appointment
    updateAppointment(appointmentToChange.id, {
      date: formattedDate,
      time: newAppointmentTime,
    })

    toast({
      title: "התור עודכן בהצלחה",
      description: "התור שלך עודכן בהצלחה",
    })

    // Add notification
    addNotification({
      type: "appointment",
      message: `התור שלך ל${appointmentToChange.serviceName} עודכן לתאריך ${format(newAppointmentDate, "dd/MM/yyyy")} בשעה ${newAppointmentTime}`,
      userId: loggedInCustomerId,
    })

    setIsChangeAppointmentDialogOpen(false)
  }, [
    newAppointmentDate,
    newAppointmentTime,
    appointmentToChange,
    toast,
    updateAppointment,
    addNotification,
    loggedInCustomerId,
  ])

  // Derived data
  const customerAppointments = loggedInCustomerId
    ? appointments.filter((appointment) => appointment.customerId === loggedInCustomerId)
    : []

  const customerOrders = loggedInCustomerId ? orders.filter((order) => order.customerId === loggedInCustomerId) : []

  const customerNotifications = loggedInCustomerId
    ? notifications.filter((notification) => notification.userId === loggedInCustomerId)
    : []

  const customerCoupons = loggedInCustomerId
    ? coupons.filter((coupon) => {
        return customerNotifications.some(
          (notification) => notification.message && notification.message.includes(coupon.code),
        )
      })
    : []

  // Find customer's loyalty tier
  const customerTier = (customerData &&
    loyaltyTiers?.find(
      (tier) =>
        customerData.loyaltyPoints >= tier.pointsRequired &&
        customerData.loyaltyPoints <= (tier.maxPoints || Number.POSITIVE_INFINITY),
    )) || { name: "רגיל", color: "gray" }

  // Calculate points to next tier
  const nextTier = (() => {
    if (!loyaltyTiers || loyaltyTiers.length === 0 || !customerData) return null

    // Sort tiers by points required
    const sortedTiers = [...loyaltyTiers].sort((a, b) => a.pointsRequired - b.pointsRequired)

    // Find current tier index
    const currentTierIndex = sortedTiers.findIndex(
      (tier) =>
        tier.pointsRequired <= customerData.loyaltyPoints &&
        (tier.maxPoints === undefined || customerData.loyaltyPoints <= tier.maxPoints),
    )

    // If there's a next tier, return it
    if (currentTierIndex < sortedTiers.length - 1) {
      return sortedTiers[currentTierIndex + 1]
    }

    return null
  })()

  const pointsToNextTier = nextTier && customerData ? nextTier.pointsRequired - customerData.loyaltyPoints : 0

  // If loading, show loading state
  if (isLoading) {
    return (
      <div className="container mx-auto py-10 px-4">
        <div className="flex justify-center items-center h-40">
          <div className="animate-pulse flex flex-col items-center">
            <div className="h-12 w-48 bg-gray-200 rounded mb-4"></div>
            <div className="h-8 w-32 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    )
  }

  // If not logged in, show redirect message
  if (!isClientLoggedIn) {
    return (
      <div className="container mx-auto py-10 px-4">
        <div className="flex justify-center items-center h-40">
          <div className="text-center">
            <h2 className="text-xl font-semibold mb-2">יש להתחבר כדי לצפות בדף זה</h2>
            <p className="mb-4">מעבירים אותך לדף ההתחברות...</p>
            <Button onClick={() => router.push("/client/login")}>לדף ההתחברות</Button>
          </div>
        </div>
      </div>
    )
  }

  // הוספת קוד להצגת קופונים פעילים בלבד בדף הלקוח
  // מיקום: בחלק שמציג את הקופונים הפעילים, הוסף את הקוד הבא

  const customer = getLoggedInCustomer()

  const activeCoupons = customerCoupons.filter((coupon) => coupon.isActive)

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <div className="flex flex-col md:flex-row justify-between items-start gap-6 mb-8">
        <div className="w-full md:w-1/3">
          <Card className="shadow-lg border-pink-100 bg-gradient-to-br from-white to-pink-50">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-2xl font-bold text-pink-800">פרופיל</CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    className="rounded-full bg-white hover:bg-pink-100 border-pink-200"
                    onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                  >
                    <Bell className="h-5 w-5 text-pink-600" />
                    {unreadNotifications > 0 && (
                      <span className="absolute -top-1 -right-1 bg-pink-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        {unreadNotifications}
                      </span>
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="rounded-full bg-white hover:bg-pink-100 border-pink-200"
                    onClick={() => router.push("/client/profile")}
                  >
                    <User className="h-5 w-5 text-pink-600" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="rounded-full bg-white hover:bg-pink-100 border-pink-200"
                    onClick={handleLogout}
                  >
                    <LogOut className="h-5 w-5 text-pink-600" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center text-center">
                <Avatar className="h-24 w-24 border-4 border-pink-200 mb-4">
                  <AvatarImage
                    src={customerData?.image || "/placeholder.svg?height=100&width=100"}
                    alt={customerData?.name}
                  />
                  <AvatarFallback className="bg-pink-100 text-pink-800 text-xl">
                    {customerData?.name
                      ? customerData.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")
                      : ""}
                  </AvatarFallback>
                </Avatar>
                <h2 className="text-2xl font-bold text-pink-800 mb-1">{customerData?.name}</h2>
                <p className="text-gray-600 mb-3">{customerData?.email || customerData?.phone}</p>
                <Badge className="bg-gradient-to-r from-pink-500 to-rose-400 hover:from-pink-600 hover:to-rose-500 text-white px-4 py-1 text-sm rounded-full">
                  <Award className="h-4 w-4 mr-1" /> רמה: {customerTier.name}
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Loyalty Points Widget */}
          <div className="mt-6">
            <LoyaltyPointsWidget
              points={customerData?.loyaltyPoints || 0}
              tier={customerTier.name}
              nextTier={nextTier ? nextTier.name : "רמה מקסימלית"}
              pointsToNextTier={pointsToNextTier}
            />
          </div>

          {/* Referral Code Widget */}
          <div className="mt-6">
            <ReferralCodeWidget
              customerId={customerData?.id}
              referralCode={customerData?.referralCode}
              referrals={customerData?.referrals || 0}
            />
          </div>
        </div>

        <div className="w-full md:w-2/3">
          <Tabs defaultValue="appointments" className="w-full">
            <TabsList className="grid grid-cols-5 mb-6 bg-pink-50">
              <TabsTrigger
                value="appointments"
                className="data-[state=active]:bg-pink-500 data-[state=active]:text-white"
              >
                <CalendarIcon className="h-4 w-4 mr-2" />
                תורים
              </TabsTrigger>
              <TabsTrigger value="orders" className="data-[state=active]:bg-pink-500 data-[state=active]:text-white">
                <ShoppingBag className="h-4 w-4 mr-2" />
                הזמנות
              </TabsTrigger>
              <TabsTrigger value="rewards" className="data-[state=active]:bg-pink-500 data-[state=active]:text-white">
                <Gift className="h-4 w-4 mr-2" />
                הטבות
              </TabsTrigger>
              <TabsTrigger value="coupons" className="data-[state=active]:bg-pink-500 data-[state=active]:text-white">
                <Ticket className="h-4 w-4 mr-2" />
                קופונים
              </TabsTrigger>
              <TabsTrigger value="profile" className="data-[state=active]:bg-pink-500 data-[state=active]:text-white">
                <User className="h-4 w-4 mr-2" />
                פרופיל
              </TabsTrigger>
            </TabsList>

            <TabsContent value="appointments">
              <Card className="border-pink-100 shadow-md">
                <CardHeader className="bg-gradient-to-r from-pink-50 to-rose-50 pb-2">
                  <CardTitle className="text-xl text-pink-800">התורים שלי</CardTitle>
                  <CardDescription>צפייה וניהול התורים הקרובים שלך</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  {customerAppointments.length > 0 ? (
                    <div className="divide-y divide-pink-100">
                      {customerAppointments
                        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                        .map((appointment) => (
                          <div key={appointment.id} className="p-4 hover:bg-pink-50 transition-colors">
                            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                              <div>
                                <h3 className="font-medium text-lg text-pink-800">{appointment.serviceName}</h3>
                                <p className="text-gray-600">
                                  {format(new Date(appointment.date), "EEEE, d בMMMM yyyy", { locale: he })}
                                </p>
                                <div className="flex items-center text-sm text-muted-foreground mt-1">
                                  <Clock className="h-4 w-4 ml-1" />
                                  <span>
                                    {appointment.time} - {calculateEndTime(appointment.time, appointment.notes)}
                                  </span>
                                </div>
                              </div>
                              <div className="flex flex-col md:flex-row items-start md:items-center gap-2 w-full md:w-auto">
                                <Badge
                                  className={`${
                                    appointment.status === "confirmed"
                                      ? "bg-green-100 text-green-800 hover:bg-green-200"
                                      : appointment.status === "cancelled"
                                        ? "bg-red-100 text-red-800 hover:bg-red-200"
                                        : "bg-amber-100 text-amber-800 hover:bg-amber-200"
                                  } mb-2 md:mb-0 md:ml-2`}
                                >
                                  {appointment.status === "confirmed"
                                    ? "מאושר"
                                    : appointment.status === "completed"
                                      ? "הושלם"
                                      : appointment.status === "cancelled"
                                        ? "בוטל"
                                        : "ממתין לאישור"}
                                </Badge>
                                <div className="flex flex-wrap gap-2 w-full md:w-auto">
                                  {/* Only show these buttons if appointment is not cancelled and is more than 24 hours away */}
                                  {appointment.status !== "cancelled" &&
                                    isMoreThan24HoursAway(appointment.date, appointment.time) && (
                                      <>
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          className="text-blue-600 hover:text-blue-800 hover:bg-blue-100 flex-1 md:flex-initial"
                                          onClick={() => handleChangeAppointment(appointment)}
                                        >
                                          <Clock className="h-4 w-4 ml-1" />
                                          שינוי
                                        </Button>
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          className="text-red-600 hover:text-red-800 hover:bg-red-100 flex-1 md:flex-initial"
                                          onClick={() => handleCancelAppointment(appointment)}
                                        >
                                          <X className="h-4 w-4 ml-1" />
                                          ביטול
                                        </Button>
                                      </>
                                    )}
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-pink-600 hover:text-pink-800 hover:bg-pink-100 flex-1 md:flex-initial"
                                    onClick={() => handleViewAppointmentDetails(appointment)}
                                  >
                                    <FileText className="h-4 w-4 ml-1" />
                                    פרטים
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div className="p-8 text-center">
                      <p className="text-gray-500">אין לך תורים קרובים</p>
                      <Button
                        className="mt-4 bg-pink-500 hover:bg-pink-600 text-white"
                        onClick={() => router.push("/booking")}
                      >
                        קביעת תור חדש
                      </Button>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="bg-pink-50 justify-end p-3">
                  <Button
                    variant="outline"
                    className="border-pink-300 text-pink-600 hover:bg-pink-100"
                    onClick={() => router.push("/booking")}
                  >
                    קביעת תור חדש
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="orders">
              <Card className="border-pink-100 shadow-md">
                <CardHeader className="bg-gradient-to-r from-pink-50 to-rose-50 pb-2">
                  <CardTitle className="text-xl text-pink-800">ההזמנות שלי</CardTitle>
                  <CardDescription>היסטוריית הרכישות שלך</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  {customerOrders.length > 0 ? (
                    <div className="divide-y divide-pink-100">
                      {customerOrders
                        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                        .map((order) => (
                          <div key={order.id} className="p-4 hover:bg-pink-50 transition-colors">
                            <div className="flex justify-between items-center">
                              <div>
                                <h3 className="font-medium text-lg text-pink-800">הזמנה #{order.id.slice(-4)}</h3>
                                <p className="text-gray-600">
                                  {format(new Date(order.date), "d בMMMM yyyy", { locale: he })}
                                </p>
                                <div className="flex items-center text-sm text-muted-foreground mt-1">
                                  <FileText className="h-4 w-4 mr-1" />
                                  <span>{order.items.length} פריטים</span>
                                </div>
                              </div>
                              <div className="flex items-center">
                                <p className="font-medium text-pink-800 ml-4">₪{order.total}</p>
                                <Badge
                                  className={`${
                                    order.status === "completed"
                                      ? "bg-green-100 text-green-800 hover:bg-green-200"
                                      : order.status === "cancelled"
                                        ? "bg-red-100 text-red-800 hover:bg-red-200"
                                        : order.status === "paid"
                                          ? "bg-blue-100 text-blue-800 hover:bg-blue-200"
                                          : "bg-amber-100 text-amber-800 hover:bg-amber-200"
                                  }`}
                                >
                                  {order.status === "completed"
                                    ? "הושלם"
                                    : order.status === "cancelled"
                                      ? "בוטל"
                                      : order.status === "paid"
                                        ? "שולם"
                                        : "בטיפול"}
                                </Badge>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="ml-2 text-pink-600 hover:text-pink-800 hover:bg-pink-100"
                                  onClick={() => handleViewOrderDetails(order)}
                                >
                                  פרטים
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div className="p-8 text-center">
                      <p className="text-gray-500">אין לך הזמנות קודמות</p>
                      <Button
                        className="mt-4 bg-pink-500 hover:bg-pink-600 text-white"
                        onClick={() => router.push("/shop")}
                      >
                        לחנות
                      </Button>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="bg-pink-50 justify-end p-3">
                  <Button
                    variant="outline"
                    className="border-pink-300 text-pink-600 hover:bg-pink-100"
                    onClick={() => router.push("/shop")}
                  >
                    המשך לקנות
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="rewards">
              <Card className="border-pink-100 shadow-md">
                <CardHeader className="bg-gradient-to-r from-pink-50 to-rose-50 pb-2">
                  <CardTitle className="text-xl text-pink-800">ההטבות שלי</CardTitle>
                  <CardDescription>הטבות ומבצעים זמינים למימוש</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  {loyaltyRewards && loyaltyRewards.length > 0 ? (
                    <div className="divide-y divide-pink-100">
                      {loyaltyRewards
                        .filter((reward) => customerData && customerData.loyaltyPoints >= reward.pointsCost)
                        .map((reward) => (
                          <div key={reward.id} className="p-4 hover:bg-pink-50 transition-colors">
                            <div className="flex justify-between items-center">
                              <div>
                                <h3 className="font-medium text-lg text-pink-800">{reward.name}</h3>
                                <p className="text-gray-600">{reward.description}</p>
                              </div>
                              <div className="flex items-center">
                                <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200 ml-4">
                                  {reward.pointsCost} נקודות
                                </Badge>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="border-pink-300 text-pink-600 hover:bg-pink-100"
                                  onClick={() => handleRedeemReward(reward.id)}
                                >
                                  מימוש
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div className="p-8 text-center">
                      <p className="text-gray-500">אין לך הטבות זמינות כרגע</p>
                      <p className="text-gray-500 mt-2">צברי נקודות נוספות כדי לקבל הטבות</p>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="bg-pink-50 justify-between p-3">
                  <div className="text-sm text-gray-600">יש לך {customerData?.loyaltyPoints || 0} נקודות זמינות</div>
                  <Button variant="outline" className="border-pink-300 text-pink-600 hover:bg-pink-100" onClick={() => console.log("TODO: Add functionality")}>
                    לכל ההטבות
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="coupons">
              <Card className="border-pink-100 shadow-md">
                <CardHeader className="bg-gradient-to-r from-pink-50 to-rose-50 pb-2">
                  <CardTitle className="text-xl text-pink-800">הקופונים שלי</CardTitle>
                  <CardDescription>קופונים זמינים לשימוש</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  {/* בחלק שמציג את הקופונים, הוסף בדיקה שהקופון פעיל ולא נוצל */}
                  {activeCoupons.length > 0 ? (
                    activeCoupons.map((coupon) => {
                      // בדוק אם זה קופון הטבה ואם כן, בדוק אם הוא כבר נוצל
                      if (coupon.isReward && coupon.redemptionId) {
                        const redemption = customer?.rewardHistory?.find((r) => r.id === coupon.redemptionId)
                        if (redemption?.isUsed) {
                          return null // אל תציג קופונים שכבר נוצלו
                        }
                      }

                      return (
                        <div key={coupon.id} className="p-4 hover:bg-pink-50 transition-colors">
                          <div className="flex justify-between items-center">
                            <div>
                              <h3 className="font-medium text-lg text-pink-800">
                                {coupon.type === "percentage" ? `${coupon.discount}% הנחה` : `₪${coupon.discount} הנחה`}
                              </h3>
                              <p className="text-gray-600">{coupon.description || "קוד קופון"}</p>
                              {coupon.expirationDate && (
                                <p className="text-xs text-gray-500">
                                  בתוקף עד: {format(new Date(coupon.expirationDate), "dd/MM/yyyy")}
                                </p>
                              )}
                            </div>
                            <div className="flex items-center">
                              <div className="bg-gray-100 px-3 py-1 rounded-md font-mono text-sm mr-2">
                                {coupon.code}
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-pink-600 hover:text-pink-800 hover:bg-pink-100"
                                onClick={() => copyToClipboard(coupon.code)}
                              >
                                <Copy className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      )
                    })
                  ) : (
                    <div className="p-8 text-center">
                      <p className="text-gray-500">אין לך קופונים זמינים כרגע</p>
                      <p className="text-gray-500 mt-2">ממשי הטבות או השתמשי בקוד הפניה כדי לקבל קופונים</p>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="bg-pink-50 justify-end p-3">
                  <Button
                    variant="outline"
                    className="border-pink-300 text-pink-600 hover:bg-pink-100"
                    onClick={() => setActiveTab("rewards")}
                  >
                    למימוש הטבות
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="profile">
              <Card className="border-pink-100 shadow-md">
                <CardHeader className="bg-gradient-to-r from-pink-50 to-rose-50 pb-2">
                  <CardTitle className="text-xl text-pink-800">פרטים אישיים</CardTitle>
                  <CardDescription>צפייה ועריכת הפרטים האישיים שלך</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-white p-4 rounded-lg border border-pink-100 shadow-sm">
                        <h3 className="text-sm font-medium text-pink-700 mb-2">שם מלא</h3>
                        <p className="text-lg">{customerData?.name}</p>
                      </div>
                      <div className="bg-white p-4 rounded-lg border border-pink-100 shadow-sm">
                        <h3 className="text-sm font-medium text-pink-700 mb-2">טלפון</h3>
                        <p className="text-lg">{customerData?.phone}</p>
                      </div>
                      <div className="bg-white p-4 rounded-lg border border-pink-100 shadow-sm">
                        <h3 className="text-sm font-medium text-pink-700 mb-2">אימייל</h3>
                        <p className="text-lg">{customerData?.email || "לא הוזן"}</p>
                      </div>
                      <div className="bg-white p-4 rounded-lg border border-pink-100 shadow-sm">
                        <h3 className="text-sm font-medium text-pink-700 mb-2">מספר ביקורים</h3>
                        <p className="text-lg">{customerData?.visits || 0}</p>
                      </div>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-pink-100 shadow-sm">
                      <h3 className="text-sm font-medium text-pink-700 mb-2">רמת נאמנות</h3>
                      <div className="flex items-center">
                        <Badge className="bg-pink-100 text-pink-800 mr-2">{customerTier.name}</Badge>
                        <span className="text-sm">{customerData?.loyaltyPoints || 0} נקודות</span>
                      </div>
                      <div className="mt-2">
                        <Progress
                          value={(customerData?.loyaltyPoints / (nextTier?.pointsRequired || 1000)) * 100}
                          className="h-2 bg-gray-200"
                          indicatorClassName="bg-pink-500"
                        />
                        <div className="flex justify-between text-xs mt-1">
                          <span>{customerTier.pointsRequired || 0}</span>
                          <span>{nextTier?.pointsRequired || "רמה מקסימלית"}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="bg-pink-50 py-4 flex justify-center">
                  <Button className="bg-pink-500 hover:bg-pink-600" asChild onClick={() => console.log("TODO: Add functionality")}>
                    <Link href="/client/profile">עריכת פרופיל</Link>
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Notifications Panel */}
      {isNotificationsOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-30 z-50 flex justify-end">
          <div className="bg-white w-full max-w-md h-full overflow-auto shadow-xl animate-slide-in-right">
            <div className="p-4 bg-gradient-to-r from-pink-100 to-rose-100 sticky top-0 z-10">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-pink-800">התראות</h2>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-pink-600 hover:bg-pink-100 border-pink-200"
                    onClick={markAllAsRead}
                  >
                    סמן הכל כנקרא
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-pink-600 hover:bg-pink-100 border-pink-200"
                    onClick={() => setIsNotificationsOpen(false)}
                  >
                    סגירה
                  </Button>
                </div>
              </div>
            </div>
            <div className="divide-y divide-pink-100">
              {customerNotifications.length > 0 ? (
                customerNotifications
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-pink-50 transition-colors ${!notification.isRead ? "bg-pink-50" : ""}`}
                      onClick={() => handleMarkAsRead(notification.id)}
                    >
                      <div className="flex justify-between">
                        <div className="flex items-center">
                          {getNotificationIcon(notification.type)}
                          <h3 className="font-medium text-pink-800 mr-2">
                            {notification.type === "appointment"
                              ? "עדכון תור"
                              : notification.type === "redeem"
                                ? "מימוש הטבה"
                                : notification.type === "points"
                                  ? "נקודות נאמנות"
                                  : notification.type === "coupon"
                                    ? "קופון חדש"
                                    : "התראה"}
                          </h3>
                        </div>
                        <span className="text-sm text-gray-500">
                          {format(new Date(notification.date), "dd/MM/yyyy HH:mm")}
                        </span>
                      </div>
                      <p className="mt-1 text-gray-600">{notification.message}</p>
                      {!notification.isRead && <Badge className="mt-2 bg-pink-100 text-pink-800">חדש</Badge>}
                    </div>
                  ))
              ) : (
                <div className="p-8 text-center">
                  <p className="text-gray-500">אין התראות חדשות</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Reward Redemption Dialog */}
      <Dialog open={showRewardsDialog} onOpenChange={setShowRewardsDialog}>
        <DialogContent className="bg-white rounded-lg border-pink-200 shadow-lg max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl text-pink-800">מימוש הטבה</DialogTitle>
            <DialogDescription>האם את בטוחה שברצונך לממש את ההטבה הזו?</DialogDescription>
          </DialogHeader>

          {selectedReward && (
            <div className="bg-pink-50 p-4 rounded-lg my-4">
              <h3 className="font-medium text-lg text-pink-800">{selectedReward.name}</h3>
              <div className="flex justify-between mt-2">
                <p className="text-gray-600">{selectedReward.description}</p>
                <Badge className="bg-purple-100 text-purple-800">{selectedReward.pointsCost}</Badge>
              </div>
            </div>
          )}

          <DialogFooter className="flex justify-between">
            <Button
              variant="outline"
              className="border-pink-300 text-pink-600 hover:bg-pink-100"
              onClick={() => setShowRewardsDialog(false)}
            >
              ביטול
            </Button>
            <Button className="bg-pink-500 hover:bg-pink-600 text-white" onClick={confirmRedeemReward}>
              מימוש הטבה
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Coupon Code Dialog */}
      <Dialog open={showCouponDialog} onOpenChange={setShowCouponDialog}>
        <DialogContent className="bg-white rounded-lg border-pink-200 shadow-lg max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl text-pink-800">ההטבה מומשה בהצלחה!</DialogTitle>
            <DialogDescription>קוד הקופון שלך מוכן לשימוש</DialogDescription>
          </DialogHeader>

          <div className="bg-pink-50 p-6 rounded-lg my-4 text-center">
            <Ticket className="h-12 w-12 text-pink-500 mx-auto mb-4" />
            <h3 className="font-medium text-lg text-pink-800 mb-2">קוד הקופון שלך:</h3>
            <div className="bg-white p-3 rounded-md border-2 border-pink-300 text-2xl font-bold text-pink-700 tracking-wider">
              {rewardCouponCode}
            </div>
            <p className="mt-4 text-sm text-gray-600">
              שמרי את הקוד הזה. תוכלי להשתמש בו בקנייה הבאה שלך או בתור הבא.
              <br />
              הקוד תקף ל-30 יום ולשימוש חד פעמי.
            </p>
          </div>

          <DialogFooter>
            <Button
              className="bg-pink-500 hover:bg-pink-600 text-white w-full"
              onClick={() => setShowCouponDialog(false)}
            >
              הבנתי
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Appointment Details Dialog */}
      <Dialog open={isAppointmentDetailsOpen} onOpenChange={setIsAppointmentDetailsOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>פרטי התור</DialogTitle>
            <DialogDescription>
              {selectedAppointment && format(new Date(selectedAppointment.date), "EEEE, d בMMMM yyyy", { locale: he })}
            </DialogDescription>
          </DialogHeader>
          {selectedAppointment && (
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-md">
                <h3 className="font-medium mb-2">פרטי השירות</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="font-medium">שירות:</span>
                    <span>{selectedAppointment.serviceName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">שעה:</span>
                    <span>
                      {selectedAppointment.time} -{" "}
                      {calculateEndTime(selectedAppointment.time, selectedAppointment.notes)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">סטטוס:</span>
                    <span>
                      {selectedAppointment.status === "confirmed"
                        ? "מאושר"
                        : selectedAppointment.status === "completed"
                          ? "הושלם"
                          : selectedAppointment.status === "cancelled"
                            ? "בוטל"
                            : "ממתין לאישור"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">מחיר:</span>
                    <span className="font-bold text-pink-600">₪{selectedAppointment.price}</span>
                  </div>
                </div>
              </div>

              {selectedAppointment.notes && (
                <div className="bg-gray-50 p-4 rounded-md">
                  <h3 className="font-medium mb-2">הערות</h3>
                  <p>
                    {
                      // Try to parse notes as JSON and display only relevant information
                      (() => {
                        try {
                          if (selectedAppointment.notes.includes("{")) {
                            const parsedNotes = JSON.parse(selectedAppointment.notes)
                            if (parsedNotes.services) {
                              return `שירותים: ${parsedNotes.services.map((s) => s.name).join(", ")}`
                            }
                            return parsedNotes.message || selectedAppointment.notes
                          }
                          return selectedAppointment.notes
                        } catch (e) {
                          return selectedAppointment.notes
                        }
                      })()
                    }
                  </p>
                </div>
              )}

              <div className="flex justify-end">
                <Button variant="outline" onClick={() => setIsAppointmentDetailsOpen(false)}>
                  סגירה
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Order Details Dialog */}
      <Dialog open={isOrderDetailsOpen} onOpenChange={setIsOrderDetailsOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>פרטי ההזמנה</DialogTitle>
            <DialogDescription>
              {selectedOrder &&
                `הזמנה #${selectedOrder.id.slice(-4)} - ${format(new Date(selectedOrder.date), "d בMMMM yyyy", { locale: he })}`}
            </DialogDescription>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-md">
                <h3 className="font-medium mb-2">פרטי ההזמנה</h3>
                <p>
                  <span className="font-medium">סטטוס:</span>{" "}
                  {selectedOrder.status === "completed"
                    ? "הושלם"
                    : selectedOrder.status === "cancelled"
                      ? "בוטל"
                      : selectedOrder.status === "paid"
                        ? "שולם"
                        : "בטיפול"}
                </p>
                <p>
                  <span className="font-medium">סה"כ:</span> ₪{selectedOrder.total}
                </p>
                <p>
                  <span className="font-medium">אמצעי תשלום:</span>{" "}
                  {selectedOrder.paymentMethod === "bit"
                    ? "ביט"
                    : selectedOrder.paymentMethod === "cash"
                      ? "מזומן"
                      : selectedOrder.paymentMethod === "credit_card"
                        ? "כרטיס אשראי"
                        : selectedOrder.paymentMethod}
                </p>
              </div>

              <div className="bg-gray-50 p-4 rounded-md">
                <h3 className="font-medium mb-2">פריטים</h3>
                <div className="space-y-2">
                  {selectedOrder.items.map((item, index) => (
                    <div key={index} className="flex justify-between">
                      <span>
                        {item.productName} x{item.quantity}
                      </span>
                      <span>₪{item.price * item.quantity}</span>
                    </div>
                  ))}
                  <div className="border-t pt-2 mt-2 font-medium flex justify-between">
                    <span>סה"כ:</span>
                    <span>₪{selectedOrder.total}</span>
                  </div>
                </div>
              </div>

              {selectedOrder.notes && (
                <div className="bg-gray-50 p-4 rounded-md">
                  <h3 className="font-medium mb-2">הערות</h3>
                  <p>{selectedOrder.notes}</p>
                </div>
              )}

              <div className="flex justify-end">
                <Button variant="outline" onClick={() => setIsOrderDetailsOpen(false)}>
                  סגירה
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Change Appointment Dialog */}
      <Dialog open={isChangeAppointmentDialogOpen} onOpenChange={setIsChangeAppointmentDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>שינוי תור</DialogTitle>
            <DialogDescription>בחרי תאריך ושעה חדשים לתור שלך</DialogDescription>
          </DialogHeader>
          {appointmentToChange && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>תאריך חדש</Label>
                <div className="border rounded-lg p-4">
                  <div className="text-center mb-4">
                    <div className="flex items-center justify-between">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (newAppointmentDate) {
                            const nextMonth = new Date(newAppointmentDate)
                            nextMonth.setMonth(nextMonth.getMonth() + 1)
                            setNewAppointmentDate(nextMonth)
                          }
                        }}
                        type="button"
                      >
                        <ChevronLeft className="h-5 w-5" />
                      </Button>
                      <h3 className="text-lg font-medium">
                        {newAppointmentDate ? format(newAppointmentDate, "MMMM yyyy", { locale: he }) : ""}
                      </h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (newAppointmentDate) {
                            const prevMonth = new Date(newAppointmentDate)
                            prevMonth.setMonth(prevMonth.getMonth() - 1)
                            setNewAppointmentDate(prevMonth)
                          }
                        }}
                        type="button"
                      >
                        <ChevronRight className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>

                  <div className="calendar-container rtl" dir="rtl">
                    {/* Days of week - right to left */}
                    <div className="grid grid-cols-7 gap-1 mb-2 text-center">
                      <div className="text-sm font-medium">א'</div>
                      <div className="text-sm font-medium">ב'</div>
                      <div className="text-sm font-medium">ג'</div>
                      <div className="text-sm font-medium">ד'</div>
                      <div className="text-sm font-medium">ה'</div>
                      <div className="text-sm font-medium">ו'</div>
                      <div className="text-sm font-medium">ש'</div>
                    </div>

                    <Calendar
                      mode="single"
                      selected={newAppointmentDate}
                      onSelect={handleDateChange}
                      disabled={(date) => {
                        // Disable dates in the past
                        return date < new Date(new Date().setHours(0, 0, 0, 0))
                      }}
                      locale={he}
                      className="rtl"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label>שעה חדשה</Label>
                {availableTimes.length > 0 ? (
                  <Select value={newAppointmentTime} onValueChange={setNewAppointmentTime}>
                    <SelectTrigger>
                      <SelectValue placeholder="בחרי שעה" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableTimes.map((time) => (
                        <SelectItem key={time} value={time}>
                          {time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <p className="text-red-500">אין שעות פנויות בתאריך זה</p>
                )}
              </div>

              <div className="flex justify-end space-x-2 rtl:space-x-reverse">
                <Button variant="outline" onClick={() => setIsChangeAppointmentDialogOpen(false)}>
                  ביטול
                </Button>
                <Button onClick={confirmAppointmentChange} disabled={!newAppointmentDate || !newAppointmentTime}>
                  עדכון תור
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
