"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { useStore } from "@/lib/store"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { AlertCircle, Lock, Phone } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function LoginPage() {
  const { toast } = useToast()
  const router = useRouter()
  const customers = useStore((state) => state.customers)
  const setLoggedInCustomer = useStore((state) => state.setLoggedInCustomer)
  const updateCustomer = useStore((state) => state.updateCustomer)
  const addNotification = useStore((state) => state.addNotification)

  const [activeTab, setActiveTab] = useState("client")
  const [isResetPasswordOpen, setIsResetPasswordOpen] = useState(false)
  const [isTermsOpen, setIsTermsOpen] = useState(false)
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false)
  const [resetEmail, setResetEmail] = useState("")
  const [resetPhone, setResetPhone] = useState("")
  const [resetSuccess, setResetSuccess] = useState(false)
  const [resetError, setResetError] = useState("")

  const [formData, setFormData] = useState({
    phone: "",
    password: "",
    adminPassword: "",
  })

  const [errors, setErrors] = useState({
    phone: "",
    password: "",
    adminPassword: "",
    general: "",
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Clear error when typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }))
    }
    if (errors.general) {
      setErrors((prev) => ({ ...prev, general: "" }))
    }
  }

  const handleClientSubmit = (e) => {
    e.preventDefault()
    console.log("Client login attempt")

    // Validate form
    let isValid = true
    const newErrors = { ...errors }

    if (!formData.phone.trim()) {
      newErrors.phone = "מספר טלפון הוא שדה חובה"
      isValid = false
    } else {
      // Validate phone number format (Israeli format)
      const phoneRegex = /^0(5[0-9]|[23489])[0-9]{7}$/
      if (!phoneRegex.test(formData.phone)) {
        newErrors.phone = "מספר טלפון לא תקין"
        isValid = false
      }
    }

    if (!formData.password) {
      newErrors.password = "סיסמה היא שדה חובה"
      isValid = false
    }

    if (!isValid) {
      setErrors(newErrors)
      return
    }

    try {
      // Find customer by phone
      const customer = customers.find(
        (c) => c.phone === formData.phone && c.isRegistered && c.password === formData.password,
      )

      // With this improved version that logs more details for debugging:
      console.log("Attempting login with phone:", formData.phone)
      const matchingCustomer = customers.find((c) => c.phone === formData.phone)
      console.log("Found customer:", matchingCustomer ? "Yes" : "No", matchingCustomer)
      console.log("Is registered:", matchingCustomer?.isRegistered)
      console.log("Password match:", matchingCustomer?.password === formData.password)

      const foundCustomer = customers.find(
        (c) => c.phone === formData.phone && c.isRegistered === true && c.password === formData.password,
      )

      if (foundCustomer) {
        // Login successful
        console.log("Customer found, logging in:", foundCustomer.name)
        setLoggedInCustomer(foundCustomer.id)

        // Add login notification
        addNotification({
          type: "system",
          message: "התחברת בהצלחה למערכת. ברוכה הבאה!",
          userId: foundCustomer.id,
        })

        toast({
          title: "התחברת בהצלחה",
          description: `ברוכה הבאה, ${foundCustomer.name}!`,
        })

        // Redirect to dashboard with a slight delay to allow state to update
        setTimeout(() => {
          console.log("Redirecting to dashboard...")
          router.push("/client/dashboard")
        }, 500)
      } else {
        console.log("Customer not found or credentials incorrect")
        // Login failed
        setErrors({
          ...newErrors,
          general: "מספר טלפון או סיסמה שגויים",
        })
      }
    } catch (error) {
      console.error("Login error:", error)
      setErrors({
        ...newErrors,
        general: "שגיאת מערכת, אנא נסי שוב מאוחר יותר",
      })
    }
  }

  const handleAdminSubmit = (e) => {
    e.preventDefault()
    console.log("Admin login attempt")

    // Validate form
    if (!formData.adminPassword) {
      setErrors((prev) => ({ ...prev, adminPassword: "סיסמה היא שדה חובה" }))
      return
    }

    // Simple admin password check (in a real app, this would be more secure)
    if (formData.adminPassword === "admin123") {
      console.log("Admin login successful")
      toast({
        title: "התחברת בהצלחה",
        description: "מאי המלכה :) ברוכה הבאה למערכת הניהול",
      })

      // Redirect to admin page with a slight delay
      setTimeout(() => {
        console.log("Redirecting to admin...")
        router.push("/admin")
      }, 500)
    } else {
      console.log("Admin password incorrect")
      setErrors((prev) => ({ ...prev, adminPassword: "סיסמה שגויה" }))
    }
  }

  const handleResetPassword = (e) => {
    e.preventDefault()
    setResetError("")
    setResetSuccess(false)

    if (!resetPhone) {
      setResetError("אנא הזיני מספר טלפון")
      return
    }

    // Find customer by phone
    const customer = customers.find((c) => c.phone === resetPhone && c.isRegistered)

    if (!customer) {
      setResetError("לא נמצא משתמש עם מספר הטלפון הזה")
      return
    }

    // Generate a temporary password
    const tempPassword = Math.random().toString(36).slice(-8)

    // Update customer with new password
    updateCustomer(customer.id, {
      password: tempPassword,
      passwordReset: true,
    })

    // Add notification about password reset
    addNotification({
      type: "system",
      message: "הסיסמה שלך אופסה. אנא שני את הסיסמה הזמנית בהקדם.",
      userId: customer.id,
    })

    // In a real app, this would send the temp password via SMS or email
    console.log(`Temporary password for ${customer.name}: ${tempPassword}`)

    setResetSuccess(true)
    toast({
      title: "איפוס סיסמה בוצע בהצלחה",
      description: "סיסמה זמנית נשלחה למספר הטלפון שלך",
    })

    // In a real app, we would close the dialog after a delay
    setTimeout(() => {
      setIsResetPasswordOpen(false)
      setResetPhone("")
      setResetSuccess(false)
    }, 3000)
  }

  return (
    <div className="container mx-auto py-10 px-4">
      <div className="max-w-md mx-auto">
        <Card className="border-pink-100 shadow-md">
          <CardHeader className="text-center bg-gradient-to-r from-pink-50 to-pink-100">
            <CardTitle className="text-2xl text-pink-700">התחברות למערכת</CardTitle>
            <CardDescription>התחברי כדי לצפות בתורים או לנהל את המערכת</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mb-6">
              <TabsList className="grid grid-cols-2 w-full">
                <TabsTrigger value="client">לקוחות</TabsTrigger>
                <TabsTrigger value="admin">מנהל</TabsTrigger>
              </TabsList>
            </Tabs>

            {activeTab === "client" ? (
              <form onSubmit={handleClientSubmit} className="space-y-4">
                {errors.general && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{errors.general}</AlertDescription>
                  </Alert>
                )}

                <div className="space-y-2">
                  <Label htmlFor="phone" className="flex items-center">
                    <Phone className="h-4 w-4 mr-1" />
                    מספר טלפון
                  </Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="הכניסי את מספר הטלפון שלך"
                    className={errors.phone ? "border-red-300" : ""}
                    type="tel"
                    inputMode="numeric"
                    pattern="[0-9]*"
                  />
                  {errors.phone && <p className="text-sm text-red-500">{errors.phone}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="flex items-center">
                    <Lock className="h-4 w-4 mr-1" />
                    סיסמה
                  </Label>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="הכניסי את הסיסמה שלך"
                    className={errors.password ? "border-red-300" : ""}
                  />
                  {errors.password && <p className="text-sm text-red-500">{errors.password}</p>}
                </div>

                <div className="text-right">
                  <Button
                    type="button"
                    variant="link"
                    className="p-0 h-auto text-pink-600"
                    onClick={() => setIsResetPasswordOpen(true)}
                  >
                    שכחת את הסיסמה?
                  </Button>
                </div>

                <Button type="submit" className="w-full bg-pink-500 hover:bg-pink-600">
                  התחברות
                </Button>
              </form>
            ) : (
              <form onSubmit={handleAdminSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="adminPassword" className="flex items-center">
                    <Lock className="h-4 w-4 mr-1" />
                    סיסמת מנהל
                  </Label>
                  <Input
                    id="adminPassword"
                    name="adminPassword"
                    type="password"
                    value={formData.adminPassword}
                    onChange={handleChange}
                    placeholder="הכניסי את סיסמת המנהל"
                    className={errors.adminPassword ? "border-red-300" : ""}
                  />
                  {errors.adminPassword && <p className="text-sm text-red-500">{errors.adminPassword}</p>}
                </div>

                <Button type="submit" className="w-full bg-pink-500 hover:bg-pink-600">
                  התחברות כמנהל
                </Button>
              </form>
            )}
          </CardContent>
          <CardFooter className="flex flex-col space-y-2 bg-gray-50 rounded-b-lg">
            {activeTab === "client" && (
              <>
                <p className="text-sm text-gray-500">
                  אין לך חשבון עדיין?{" "}
                  <Link href="/client/register" className="text-pink-500 hover:underline">
                    הירשמי כאן
                  </Link>
                </p>
                <div className="text-xs text-gray-400 flex justify-center space-x-4 rtl:space-x-reverse mt-2">
                  <Button
                    variant="link"
                    className="p-0 h-auto text-gray-400 text-xs"
                    onClick={() => setIsTermsOpen(true)}
                  >
                    תנאי שימוש
                  </Button>
                  <span>|</span>
                  <Button
                    variant="link"
                    className="p-0 h-auto text-gray-400 text-xs"
                    onClick={() => setIsPrivacyOpen(true)}
                  >
                    מדיניות פרטיות
                  </Button>
                </div>
              </>
            )}
          </CardFooter>
        </Card>
      </div>

      {/* Reset Password Dialog */}
      <Dialog open={isResetPasswordOpen} onOpenChange={setIsResetPasswordOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>איפוס סיסמה</DialogTitle>
            <DialogDescription>הזיני את מספר הטלפון שלך ואנו נשלח לך הוראות לאיפוס הסיסמה.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleResetPassword}>
            <div className="grid gap-4 py-4">
              {resetError && (
                <Alert variant="destructive">
                  <AlertDescription>{resetError}</AlertDescription>
                </Alert>
              )}

              {resetSuccess && (
                <Alert className="bg-green-50 border-green-200 text-green-800">
                  <AlertDescription>סיסמה זמנית נשלחה למספר הטלפון שלך. אנא בדקי את ההודעות שלך.</AlertDescription>
                </Alert>
              )}

              <div className="grid gap-2">
                <Label htmlFor="resetPhone">מספר טלפון</Label>
                <Input
                  id="resetPhone"
                  type="tel"
                  value={resetPhone}
                  onChange={(e) => setResetPhone(e.target.value)}
                  placeholder="הכניסי את מספר הטלפון שלך"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsResetPasswordOpen(false)}>
                ביטול
              </Button>
              <Button type="submit" className="bg-pink-500 hover:bg-pink-600">
                שליחה
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Terms of Use Dialog */}
      <Dialog open={isTermsOpen} onOpenChange={setIsTermsOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>תנאי שימוש</DialogTitle>
          </DialogHeader>
          <div className="max-h-[60vh] overflow-y-auto pr-6">
            <h3 className="text-lg font-medium mb-2">1. כללי</h3>
            <p className="mb-4">
              ברוכים הבאים לאתר May Beauty. השימוש באתר ובשירותים המוצעים בו כפוף לתנאי השימוש המפורטים להלן. השימוש
              באתר מהווה הסכמה מצדך לתנאים אלה.
            </p>

            <h3 className="text-lg font-medium mb-2">2. הרשמה וחשבון משתמש</h3>
            <p className="mb-4">
              על מנת להשתמש בחלק מהשירותים באתר, עליך להירשם ולפתוח חשבון משתמש. בעת ההרשמה, עליך למסור פרטים מדויקים
              ומלאים. אתה אחראי לשמור על סודיות פרטי החשבון שלך ולכל פעילות שתתבצע תחת חשבונך.
            </p>

            <h3 className="text-lg font-medium mb-2">3. קביעת תורים וביטולים</h3>
            <p className="mb-4">
              האתר מאפשר קביעת תורים לטיפולים. ביטול תור יש לבצע לפחות 24 שעות מראש. ביטול מאוחר יותר עלול לגרור חיוב
              בדמי ביטול.
            </p>

            <h3 className="text-lg font-medium mb-2">4. תוכנית נאמנות</h3>
            <p className="mb-4">
              תוכנית הנאמנות כפופה לתנאים נפרדים המפורטים באתר. הנקודות אינן ניתנות להמרה למזומן ותקפות למשך שנה מיום
              צבירתן.
            </p>

            <h3 className="text-lg font-medium mb-2">5. שינויים בתנאי השימוש</h3>
            <p className="mb-4">
              אנו שומרים לעצמנו את הזכות לשנות את תנאי השימוש בכל עת. שינויים אלה ייכנסו לתוקף מיד עם פרסומם באתר.
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsTermsOpen(false)}>סגירה</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Privacy Policy Dialog */}
      <Dialog open={isPrivacyOpen} onOpenChange={setIsPrivacyOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>מדיניות פרטיות</DialogTitle>
          </DialogHeader>
          <div className="max-h-[60vh] overflow-y-auto pr-6">
            <h3 className="text-lg font-medium mb-2">1. איסוף מידע</h3>
            <p className="mb-4">
              אנו אוספים מידע אישי כגון שם, מספר טלפון וכתובת אימייל בעת ההרשמה לאתר או קביעת תור. בנוסף, אנו אוספים
              מידע על השימוש שלך באתר באמצעות קובצי Cookie.
            </p>

            <h3 className="text-lg font-medium mb-2">2. שימוש במידע</h3>
            <p className="mb-4">
              המידע שנאסף משמש אותנו לצורך מתן השירותים, שיפור חווית המשתמש, ושליחת עדכונים ומבצעים (בכפוף להסכמתך).
            </p>

            <h3 className="text-lg font-medium mb-2">3. שיתוף מידע</h3>
            <p className="mb-4">
              אנו לא משתפים את המידע האישי שלך עם צדדים שלישיים, למעט במקרים הבאים: א. כאשר נדרש לצורך מתן השירות (כגון
              מערכת תשלומים). ב. כאשר נדרש על פי חוק.
            </p>

            <h3 className="text-lg font-medium mb-2">4. אבטחת מידע</h3>
            <p className="mb-4">
              אנו נוקטים באמצעי אבטחה סבירים כדי להגן על המידע האישי שלך מפני גישה, שימוש או חשיפה בלתי מורשים.
            </p>

            <h3 className="text-lg font-medium mb-2">5. זכויותיך</h3>
            <p className="mb-4">
              יש לך זכות לעיין במידע האישי שלך, לתקן אותו, ולבקש את מחיקתו. לפניות בנושא, אנא צרו קשר באמצעות פרטי הקשר
              המופיעים באתר.
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsPrivacyOpen(false)}>סגירה</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
