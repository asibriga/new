"use client"

import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { useEffect, useState } from "react"

export default function GalleryPage() {
  const siteContent = useStore((state) => state.siteContent)
  const [galleryImages, setGalleryImages] = useState([])
  const [activeCategory, setActiveCategory] = useState("all")

  // Update gallery images when store changes
  useEffect(() => {
    setGalleryImages(
      siteContent.images.gallery.map((src, id) => ({
        id,
        category: "all",
        src,
        alt: `תמונת גלריה ${id + 1}`,
      })),
    )
  }, [siteContent.images.gallery])

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">הגלריה שלנו</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">צפי בעבודות האחרונות שלנו והתרשמי מהסגנון והאיכות</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {galleryImages.length > 0 ? (
          galleryImages.map((image) => <GalleryItem key={image.id} image={image} />)
        ) : (
          <div className="col-span-full text-center py-12 text-muted-foreground">אין תמונות בגלריה כרגע</div>
        )}
      </div>
    </div>
  )
}

function GalleryItem({ image }: { image: any }) {
  return (
    <Card className="overflow-hidden group cursor-pointer">
      <CardContent className="p-0">
        <div className="aspect-square relative overflow-hidden">
          <Image
            src={image.src || "/placeholder.svg"}
            alt={image.alt}
            fill
            className="object-cover transition-transform group-hover:scale-105"
            unoptimized={image.src?.startsWith("blob:")}
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
        </div>
      </CardContent>
    </Card>
  )
}
