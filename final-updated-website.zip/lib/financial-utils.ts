/**
 * Utility functions for financial calculations
 */

/**
 * Calculate profit margin
 * @param revenue Total revenue
 * @param costs Total costs
 * @returns Profit margin as a percentage
 */
export function calculateProfitMargin(revenue: number, costs: number): number {
  if (revenue === 0) return 0
  return ((revenue - costs) / revenue) * 100
}

/**
 * Calculate break-even point
 * @param fixedCosts Total fixed costs
 * @param pricePerUnit Price per unit
 * @param variableCostPerUnit Variable cost per unit
 * @returns Break-even point in units
 */
export function calculateBreakEvenPoint(fixedCosts: number, pricePerUnit: number, variableCostPerUnit: number): number {
  if (pricePerUnit <= variableCostPerUnit) return Number.POSITIVE_INFINITY
  return fixedCosts / (pricePerUnit - variableCostPerUnit)
}

/**
 * Calculate Return on Investment (ROI)
 * @param initialInvestment Initial investment amount
 * @param finalValue Final value of the investment
 * @returns ROI as a percentage
 */
export function calculateROI(initialInvestment: number, finalValue: number): number {
  if (initialInvestment === 0) return 0
  return ((finalValue - initialInvestment) / initialInvestment) * 100
}

/**
 * Calculate annualized ROI
 * @param initialInvestment Initial investment amount
 * @param finalValue Final value of the investment
 * @param years Number of years
 * @returns Annualized ROI as a percentage
 */
export function calculateAnnualizedROI(initialInvestment: number, finalValue: number, years: number): number {
  if (initialInvestment === 0 || years <= 0) return 0
  return (Math.pow(finalValue / initialInvestment, 1 / years) - 1) * 100
}

/**
 * Calculate income tax
 * @param profit Profit before tax
 * @param taxRate Tax rate as a percentage
 * @returns Income tax amount
 */
export function calculateIncomeTax(profit: number, taxRate: number): number {
  if (profit <= 0) return 0
  return profit * (taxRate / 100)
}

/**
 * Calculate VAT
 * @param amount Amount before VAT
 * @param vatRate VAT rate as a percentage
 * @returns VAT amount
 */
export function calculateVAT(amount: number, vatRate: number): number {
  return amount * (vatRate / 100)
}

/**
 * Calculate net profit after tax
 * @param revenue Total revenue
 * @param costs Total costs
 * @param taxRate Tax rate as a percentage
 * @returns Net profit after tax
 */
export function calculateNetProfitAfterTax(revenue: number, costs: number, taxRate: number): number {
  const profitBeforeTax = revenue - costs
  const incomeTax = calculateIncomeTax(profitBeforeTax, taxRate)
  return profitBeforeTax - incomeTax
}

/**
 * Calculate effective tax rate
 * @param profit Profit before tax
 * @param taxPaid Total tax paid
 * @returns Effective tax rate as a percentage
 */
export function calculateEffectiveTaxRate(profit: number, taxPaid: number): number {
  if (profit <= 0) return 0
  return (taxPaid / profit) * 100
}

/**
 * Format currency for display
 * @param amount Amount to format
 * @returns Formatted currency string
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("he-IL", {
    style: "currency",
    currency: "ILS",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)
}

/**
 * Calculate compound interest
 * @param principal Initial principal
 * @param rate Annual interest rate as a percentage
 * @param time Time in years
 * @param n Number of times interest is compounded per year
 * @returns Final amount after compound interest
 */
export function calculateCompoundInterest(principal: number, rate: number, time: number, n = 1): number {
  return principal * Math.pow(1 + rate / 100 / n, n * time)
}

/**
 * Calculate depreciation using straight-line method
 * @param cost Initial cost of the asset
 * @param salvageValue Salvage value at the end of useful life
 * @param usefulLife Useful life in years
 * @returns Annual depreciation amount
 */
export function calculateStraightLineDepreciation(cost: number, salvageValue: number, usefulLife: number): number {
  return (cost - salvageValue) / usefulLife
}

/**
 * Calculate monthly payment for a loan
 * @param principal Loan principal
 * @param annualInterestRate Annual interest rate as a percentage
 * @param years Loan term in years
 * @returns Monthly payment amount
 */
export function calculateMonthlyPayment(principal: number, annualInterestRate: number, years: number): number {
  const monthlyRate = annualInterestRate / 100 / 12
  const numberOfPayments = years * 12

  if (monthlyRate === 0) return principal / numberOfPayments

  return (
    (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) /
    (Math.pow(1 + monthlyRate, numberOfPayments) - 1)
  )
}

/**
 * Calculate the present value of future cash flows
 * @param cashFlows Array of future cash flows
 * @param discountRate Discount rate as a percentage
 * @returns Present value
 */
export function calculatePresentValue(cashFlows: number[], discountRate: number): number {
  const rate = discountRate / 100

  return cashFlows.reduce((pv, cashFlow, index) => {
    return pv + cashFlow / Math.pow(1 + rate, index + 1)
  }, 0)
}

/**
 * Calculate the internal rate of return (IRR)
 * @param cashFlows Array of cash flows (first is initial investment as negative)
 * @param guess Initial guess for IRR
 * @param maxIterations Maximum number of iterations
 * @param precision Precision for convergence
 * @returns IRR as a percentage
 */
export function calculateIRR(cashFlows: number[], guess = 0.1, maxIterations = 100, precision = 0.00001): number {
  let rate = guess

  for (let i = 0; i < maxIterations; i++) {
    const npv = cashFlows.reduce((sum, cashFlow, index) => {
      return sum + cashFlow / Math.pow(1 + rate, index)
    }, 0)

    if (Math.abs(npv) < precision) {
      return rate * 100
    }

    const derivativeNpv = cashFlows.reduce((sum, cashFlow, index) => {
      return sum - (index * cashFlow) / Math.pow(1 + rate, index + 1)
    }, 0)

    rate = rate - npv / derivativeNpv
  }

  return rate * 100
}
