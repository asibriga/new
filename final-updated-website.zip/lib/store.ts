import { create } from "zustand"
import { persist, createJSONStorage, type StateStorage } from "zustand/middleware"

// Define types
export type Service = {
  id: string
  name: string
  description: string
  duration: number
  price: number
  image?: string
}

export type Appointment = {
  id: string
  customerId: string
  customerName: string
  customerPhone: string
  customerEmail?: string
  serviceId: string
  serviceName: string
  date: string
  time: string
  notes?: string
  status: "pending" | "confirmed" | "cancelled" | "completed"
  price: number
  isWaitlist?: boolean
  pointsAwarded?: boolean // Track if points were awarded for this appointment
}

export type Customer = {
  id: string
  name: string
  phone: string
  email?: string
  notes?: string
  visits: number
  lastVisit?: string
  status: "active" | "inactive" | "new" | "needs_followup"
  isSubscribedToNewsletter?: boolean
  isRegistered?: boolean
  password?: string
  referralCode?: string
  loyaltyPoints?: number
  rewardHistory?: RewardRedemption[]
  referrals?: number
  referredBy?: string
  createdAt?: string
  hasLoggedIn?: boolean // Track if customer has logged in for the first time
  pendingReferralBonus?: {
    fromCustomerId: string
    points: number
  } // Track pending referral bonus
}

export type TimeSlot = {
  time: string
  isAvailable: boolean
}

export type D7Settings = {
  accountSid: string
  authToken: string
  phoneNumber: string
  isEnabled: boolean
  templates?: {
    [key: string]: string
  }
}

export type Product = {
  id: string
  name: string
  description: string
  category: string
  price: number
  stock: number
  status: "active" | "inactive" | "out_of_stock"
  image?: string
}

export type CartItem = {
  productId: string
  quantity: number
}

export type Order = {
  id: string
  customerId: string
  customerName: string
  customerPhone: string
  customerEmail?: string
  items: {
    productId: string
    productName: string
    quantity: number
    price: number
  }[]
  total: number
  status: "pending" | "paid" | "completed" | "cancelled"
  paymentMethod: "bit" | "cash" | "credit_card"
  pickupMethod: "pickup" | "delivery"
  date: string
  notes?: string
  couponCode?: string
  couponDiscount?: number
  couponType?: "percentage" | "fixed"
  pointsAwarded?: boolean // Track if points were awarded for this order
}

export type Transaction = {
  id: string
  date: string
  description: string
  amount: number
  type: "income" | "expense"
  category: string
  relatedId?: string // appointment ID or order ID
}

export type NewsletterSubscriber = {
  id: string
  name: string
  phone: string
  date: string
  isActive: boolean
}

export type SiteContent = {
  heroTitle: string
  heroSubtitle: string
  aboutText: string
  contactText: string
  footerText: string
  images: {
    hero: string
    about: string
    services: string[]
    gallery: string[]
  }
  heroVideo?: string // Added for hero video background
}

// הוספת טיפים לאחר קביעת תור
export type AppointmentTips = {
  title: string
  content: string[]
}

export type LoyaltyTier = {
  id: string
  name: string
  pointsRequired: number
  benefits: string[]
  maxPoints?: number
  color?: string
}

export type LoyaltyReward = {
  id: string
  name: string
  description: string
  pointsCost: number
}

export type RewardRedemption = {
  id: string
  rewardId: string
  rewardName: string
  pointsCost: number
  date: string
  couponCode?: string // Track the coupon code generated for this redemption
  isUsed?: boolean // Track if the reward has been used
}

export type LoyaltySettings = {
  pointsPerPurchase: number
  pointsMultiplier: number
  referralPoints: number
}

export type Coupon = {
  id: string
  code: string
  discount: number
  type?: "percentage" | "fixed"
  startDate?: string
  endDate?: string
  expirationDate?: string
  isActive: boolean
  isReferral?: boolean
  minPurchase?: number
  maxUses?: number
  usedCount?: number
  isReward?: boolean // Flag for reward coupons
  customerId?: string // For tracking which customer this coupon belongs to
  redemptionId?: string // Link to the reward redemption
}

// Add the Log type definition
export type Log = {
  id: string
  timestamp: string
  type: "system" | "user" | "appointment" | "order" | "error"
  message: string
  user?: string
  details?: any // Additional details for the log
}

export type Notification = {
  id: string
  type: "newsletter" | "appointment" | "order" | "system" | "contact" | "reward" | "points" | "coupon"
  message: string
  date: string
  isRead: boolean
  userId?: string
  isCustomerNotification?: boolean
}

export type EmailTemplate = {
  id: string
  name: string
  subject: string
  body: string
  type: "newsletter" | "invoice" | "appointment" | "welcome" | "other"
}

export type SocialShare = {
  id: string
  customerId: string
  customerName: string
  platform: "facebook" | "instagram" | "tiktok" | "whatsapp"
  content: string
  date: string
  pointsAwarded: boolean
}

export type ClosedHours = {
  id: string
  date: string
  startTime: string
  endTime: string
  reason: string
}

export type Invoice = {
  id: string
  date: string
  dueDate: string
  customerName: string
  customerPhone: string
  customerEmail?: string
  customerAddress?: string
  items: {
    description: string
    quantity: number
    price: number
  }[]
  total: number
  status: "paid" | "pending" | "cancelled"
  paymentMethod: string
  notes?: string
}

// Define store
type StoreState = {
  services: Service[]
  appointments: Appointment[]
  customers: Customer[]
  d7Settings: D7Settings
  products: Product[]
  cart: CartItem[]
  orders: Order[]
  transactions: Transaction[]
  newsletterSubscribers: NewsletterSubscriber[]
  siteContent: SiteContent
  notifications: Notification[]
  analytics: {
    pageViews: Record<string, number>
    referrers: Record<string, number>
    uniqueVisitors: number
  }

  // הוספת טיפים לאחר קביעת תור
  appointmentTips: AppointmentTips
  holidays: { id?: string; date: string; name: string }[]
  closedDays: {
    id?: string
    date: string
    reason: string
    specificHours?: boolean
    startTime?: string
    endTime?: string
  }[]
  closedHours: ClosedHours[]
  loyaltyTiers: LoyaltyTier[]
  loyaltyRewards: LoyaltyReward[]
  loyaltySettings: LoyaltySettings
  coupons: Coupon[]
  emailTemplates: EmailTemplate[]
  socialShares: SocialShare[]
  invoices: Invoice[]

  // Authentication state
  loggedInCustomerId: string | null
  loggedInAdminId: string | null

  logs: Log[]

  // Actions
  addService: (service: Omit<Service, "id">) => void
  updateService: (id: string, service: Partial<Service>) => void
  deleteService: (id: string) => void

  addAppointment: (appointment: Omit<Appointment, "id" | "status">) => string
  updateAppointment: (id: string, appointment: Partial<Appointment>) => void
  deleteAppointment: (id: string) => void
  cancelAppointment: (id: string) => void // New function to properly cancel appointments
  calculateAppointmentTotal: (appointmentId: string) => number // New function to calculate total price

  addCustomer: (customer: Partial<Customer>) => string
  updateCustomer: (id: string, customer: Partial<Customer>) => void
  deleteCustomer: (id: string) => void

  // Authentication actions
  setLoggedInCustomer: (customerId: string | null) => void
  getLoggedInCustomer: () => Customer | null
  loginCustomer: (phone: string, password: string) => string | null
  logoutCustomer: () => void
  loginAdmin: (password: string) => boolean
  logoutAdmin: () => void

  updateD7Settings: (settings: Partial<D7Settings>) => void
  sendSms: (to: string, templateName: string, variables: Record<string, string>) => Promise<boolean>

  addProduct: (product: Omit<Product, "id">) => void
  updateProduct: (id: string, product: Partial<Product>) => void
  deleteProduct: (id: string) => void

  addToCart: (productId: string, quantity: number) => void
  updateCartItem: (productId: string, quantity: number) => void
  removeFromCart: (productId: string) => void
  clearCart: () => void

  createOrder: (order: Omit<Order, "id">) => string
  updateOrder: (id: string, order: Partial<Order>) => void
  cancelOrder: (id: string) => void // New function to properly cancel orders

  addTransaction: (transaction: Omit<Transaction, "id">) => void
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void
  deleteTransaction: (id: string) => void

  subscribeToNewsletter: (phone: string, name: string) => void
  unsubscribeFromNewsletter: (id: string) => void

  updateSiteContent: (content: Partial<SiteContent>) => void
  addGalleryImage: (image: string) => void
  removeGalleryImage: (imageUrl: string) => void
  resetFinancialData: () => void

  markNotificationAsRead: (id: string) => void
  clearNotifications: () => void
  addNotification: (notification: { type: string; message: string; userId?: string }) => void
  updateNotification: (id: string, notification: Partial<Notification>) => void

  getAvailableTimeSlots: (date: string, serviceId: string) => TimeSlot[]
  isTimeSlotAvailable: (date: string, time: string) => boolean

  getFinancialSummary: (
    startDate: string,
    endDate: string,
  ) => {
    totalIncome: number
    totalExpenses: number
    netProfit: number
    serviceIncome: number
    productIncome: number
    expensesByCategory: Record<string, number>
  }
  addManualTransaction: (transaction: Partial<Transaction>) => void

  addClosedDay: (date: string, reason: string, specificHours?: boolean, startTime?: string, endTime?: string) => void
  removeClosedDay: (date: string) => void
  addClosedHours: (date: string, startTime: string, endTime: string, reason: string) => string
  removeClosedHours: (id: string) => void
  updateAppointmentTips: (tips: Partial<AppointmentTips>) => void

  // Loyalty and coupon actions
  addLoyaltyTier: (tier: Omit<LoyaltyTier, "id">) => string
  updateLoyaltyTier: (id: string, tier: Partial<LoyaltyTier>) => void
  deleteLoyaltyTier: (id: string) => void
  addLoyaltyReward: (reward: Omit<LoyaltyReward, "id">) => string
  updateLoyaltyReward: (id: string, reward: Partial<LoyaltyReward>) => void
  deleteLoyaltyReward: (id: string) => void
  validateCoupon: (code: string) => { valid: boolean; value: number; type: string; isReferral?: boolean }
  applyCoupon: (code: string, orderId?: string) => boolean
  addCoupon: (coupon: Omit<Coupon, "id">) => string
  updateCoupon: (id: string, coupon: Partial<Coupon>) => void
  deleteCoupon: (id: string) => void
  verifyCouponUsed: (code: string) => void // New function to mark coupon as used

  // Reward redemption
  redeemReward: (customerId: string, rewardId: string) => boolean
  addRewardToHistory: (customerId: string, redemption: Omit<RewardRedemption, "id">) => void
  getCustomerRewardHistory: (customerId: string) => RewardRedemption[]
  getCustomerActiveCoupons: (customerId: string) => Coupon[] // New function to get active coupons

  // Analytics actions
  addPageView: (page: string) => void
  addReferrer: (source: string) => void
  addVisitor: () => void

  // Add log actions
  addLog: (log: Omit<Log, "id" | "timestamp">) => void
  clearLogs: () => void
  addSystemLog: (log: { action: string; details: string; userId?: string; userType?: string }) => void

  generateReferralCode: (customerId: string) => string
  verifyReferralCode: (code: string) => boolean // New function to verify referral code
  processReferralBonus: (customerId: string) => void // New function to process pending referral bonus

  // Email templates
  addEmailTemplate: (template: Omit<EmailTemplate, "id">) => string
  updateEmailTemplate: (id: string, template: Partial<EmailTemplate>) => void
  deleteEmailTemplate: (id: string) => void

  // Social sharing
  addSocialShare: (share: Omit<SocialShare, "id" | "date">) => string
  awardPointsForSocialShare: (shareId: string) => void

  // Product recommendations
  getRecommendedProducts: (customerId: string, limit?: number) => Product[]

  // Invoice management
  addInvoice: (invoice: Omit<Invoice, "id">) => string
  updateInvoice: (id: string, invoice: Partial<Invoice>) => void
  deleteInvoice: (id: string) => void
  getInvoiceById: (id: string) => Invoice | undefined
}

// Create a custom storage that handles migration errors
const createCustomStorage = (): StateStorage => {
  const storage = typeof window !== "undefined" ? window.localStorage : null

  return {
    getItem: (name) => {
      try {
        const value = storage?.getItem(name) || null
        return value
      } catch (error) {
        console.error("Error getting item from storage", error)
        return null
      }
    },
    setItem: (name, value) => {
      try {
        // Check if we're likely to exceed the quota
        if (storage && value && value.length > 3000000) {
          // ~3MB threshold
          // Try to remove old data first
          try {
            // Clear any old versions of the store
            for (let i = 0; i < storage.length; i++) {
              const key = storage.key(i)
              if (key && key.startsWith("may-beauty-storage") && key !== name) {
                storage.removeItem(key)
              }
            }
          } catch (e) {
            console.warn("Error cleaning up old storage:", e)
          }

          // Try to store with reduced data if needed
          try {
            const data = JSON.parse(value)
            // Create a smaller version with only essential data
            const essentialData = {
              customers: data.state.customers || [],
              services: data.state.services || [],
              loggedInCustomerId: data.state.loggedInCustomerId,
              loggedInAdminId: data.state.loggedInAdminId,
            }

            storage.setItem(
              name,
              JSON.stringify({
                ...data,
                state: essentialData,
              }),
            )
            console.warn("Stored reduced data due to quota limitations")
            return
          } catch (e) {
            console.error("Error storing reduced data:", e)
          }
        } else {
          // Normal storage attempt
          storage?.setItem(name, value)
        }
      } catch (error) {
        console.error("Error setting item in storage", error)
        // Try to store a minimal version
        try {
          if (storage) {
            const data = JSON.parse(value)
            // Store only authentication state as a fallback
            const minimalData = {
              loggedInCustomerId: data.state?.loggedInCustomerId,
              loggedInAdminId: data.state?.loggedInAdminId,
            }

            storage.setItem(
              name + "-minimal",
              JSON.stringify({
                version: data.version,
                state: minimalData,
              }),
            )
            console.warn("Stored minimal data due to quota error")
          }
        } catch (e) {
          console.error("Failed to store even minimal data:", e)
        }
      }
    },
    removeItem: (name) => {
      try {
        storage?.removeItem(name)
        // Also try to remove any minimal version
        storage?.removeItem(name + "-minimal")
      } catch (error) {
        console.error("Error removing item from storage", error)
      }
    },
  }
}

// Initial site content
const initialSiteContent: SiteContent = {
  heroTitle: "May Beauty",
  heroSubtitle: "עיצוב ציפורניים מקצועי ואיכותי בסטנדרטים הגבוהים ביותר",
  aboutText:
    "May Beauty נוסד בשנת 2018 מתוך אהבה גדולה לאמנות הציפורניים וטיפוח היופי. הסטודיו שלנו מציע מגוון רחב של טיפולי ציפורניים וטיפולי יופי ברמה הגבוהה ביותר.",
  contactText: "יש לך שאלות? אנחנו כאן בשבילך. צרי איתנו קשר ונחזור אלייך בהקדם.",
  footerText: "© 2025 May Beauty. כל הזכויות שמורות.",
  images: {
    hero: "/images/hero-bg.jpg",
    about: "/placeholder.svg?height=400&width=600",
    services: [
      "/placeholder.svg?height=200&width=300",
      "/placeholder.svg?height=200&width=300",
      "/placeholder.svg?height=200&width=300",
    ],
    gallery: [
      "/placeholder.svg?height=300&width=300",
      "/placeholder.svg?height=300&width=300",
      "/placeholder.svg?height=300&width=300",
      "/placeholder.svg?height=300&width=300",
      "/placeholder.svg?height=300&width=300",
      "/placeholder.svg?height=300&width=300",
    ],
  },
  heroVideo: "/videos/hero-background.mp4", // Default hero video
}

// Initial email templates
const initialEmailTemplates: EmailTemplate[] = [
  {
    id: "welcome-template",
    name: "הודעת ברוכים הבאים",
    subject: "ברוכה הבאה ל-May Beauty!",
    body: `<p>שלום {customerName},</p>
<p>ברוכה הבאה ל-May Beauty! אנו שמחים שבחרת להצטרף אלינו.</p>
<p>בתור לקוחה חדשה, את זכאית להנחה של 10% על הטיפול הראשון שלך.</p>
<p>לקביעת תור, פשוט התקשרי אלינו או השתמשי במערכת קביעת התורים באתר שלנו.</p>
<p>בברכה,<br>צוות May Beauty</p>`,
    type: "welcome",
  },
  {
    id: "appointment-confirmation",
    name: "אישור תור",
    subject: "אישור התור שלך ב-May Beauty",
    body: `<p>שלום {customerName},</p>
<p>אנו מאשרים את התור שלך ב-May Beauty:</p>
<p>תאריך: {appointmentDate}<br>שעה: {appointmentTime}<br>שירות: {serviceName}</p>
<p>אם ברצונך לשנות או לבטל את התור, אנא צרי קשר לפחות 24 שעות מראש.</p>
<p>מצפים לראותך!<br>צוות May Beauty</p>`,
    type: "appointment",
  },
  {
    id: "invoice-template",
    name: "חשבונית",
    subject: "החשבונית שלך מ-May Beauty",
    body: `<p>שלום {customerName},</p>
<p>מצורפת החשבונית עבור השירותים שקיבלת ב-May Beauty:</p>
<p>מספר חשבונית: {invoiceNumber}<br>תאריך: {invoiceDate}<br>סכום: {invoiceAmount} ₪</p>
<p>תודה על האמון!<br>צוות May Beauty</p>`,
    type: "invoice",
  },
  {
    id: "newsletter-template",
    name: "ניוזלטר חודשי",
    subject: "חדשות ומבצעים מ-May Beauty",
    body: `<p>שלום {customerName},</p>
<p>אנו שמחים לשתף איתך את החדשות והמבצעים האחרונים שלנו:</p>
<p>{newsletterContent}</p>
<p>להסרה מרשימת התפוצה, לחצי <a href="{unsubscribeLink}">כאן</a>.</p>
<p>בברכה,<br>צוות May Beauty</p>`,
    type: "newsletter",
  },
]

// Create store with persistence
export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      // Initial state
      customers: [],
      services: [
        {
          id: "1",
          name: "מניקור קלאסי",
          description: "טיפול מניקור מקצועי לציפורניים טבעיות",
          duration: 45,
          price: 120,
          image: "/images/service-1.jpg",
        },
        {
          id: "2",
          name: "מניקור ג'ל",
          description: "מניקור עם לק ג'ל עמיד במיוחד",
          duration: 60,
          price: 150,
          image: "/images/service-2.jpg",
        },
        {
          id: "3",
          name: "בניית ציפורניים ג'ל",
          description: "בניית ציפורניים מקצועית בג'ל עם חומרים איכותיים",
          duration: 90,
          price: 250,
          image: "/images/service-3.jpg",
        },
        {
          id: "4",
          name: "פדיקור קלאסי",
          description: "טיפול פדיקור מקצועי לכפות הרגליים",
          duration: 60,
          price: 150,
          image: "/images/service-4.jpg",
        },
      ],
      appointments: [],
      products: [
        {
          id: "1",
          name: "לק ג'ל ורוד פסטל",
          description: "לק ג'ל איכותי בגוון ורוד פסטל, עמיד עד 3 שבועות",
          category: "polish",
          price: 65,
          stock: 15,
          status: "active",
          image: "/images/product-1.jpg",
        },
        {
          id: "2",
          name: "לק ג'ל אדום קלאסי",
          description: "לק ג'ל איכותי בגוון אדום קלאסי, עמיד עד 3 שבועות",
          category: "polish",
          price: 65,
          stock: 10,
          status: "active",
          image: "/images/product-2.jpg",
        },
      ],
      cart: [],
      orders: [],
      transactions: [],
      newsletterSubscribers: [],
      siteContent: initialSiteContent,
      notifications: [],
      analytics: {
        pageViews: {},
        referrers: {},
        uniqueVisitors: 0,
      },
      // הוספה לערכים ההתחלתיים
      appointmentTips: {
        title: "טיפים חשובים לקראת התור שלך",
        content: [
          "נא להגיע 10 דקות לפני התור שנקבע",
          "במקרה של איחור, התור עלול להתקצר או להתבטל",
          "אנא הודיעי מראש על ביטול (לפחות 24 שעות מראש)",
          "הגיעי עם ציפורניים נקיות ללא לק",
          "אנו מקבלים תשלום במזומן, העברה בנקאית או ביט",
        ],
      },
      holidays: [
        { id: "h1", date: "2025-04-15", name: "פסח" },
        { id: "h2", date: "2025-04-21", name: "שביעי של פסח" },
        { id: "h3", date: "2025-05-04", name: "יום העצמאות" },
        { id: "h4", date: "2025-05-24", name: "שבועות" },
        { id: "h5", date: "2025-09-25", name: "ראש השנה" },
        { id: "h6", date: "2025-10-04", name: "יום כיפור" },
        { id: "h7", date: "2025-10-09", name: "סוכות" },
        { id: "h8", date: "2025-10-16", name: "שמחת תורה" },
      ],
      closedDays: [],
      closedHours: [],
      loyaltyTiers: [
        {
          id: "lt1",
          name: "חבר",
          pointsRequired: 0,
          maxPoints: 99,
          benefits: ["צבירת נקודות על כל רכישה", "הטבת יום הולדת"],
          color: "gray",
        },
        {
          id: "lt2",
          name: "כסף",
          pointsRequired: 100,
          maxPoints: 299,
          benefits: ["צבירת נקודות על כל רכישה", "הטבת יום הולדת", "10% הנחה על מוצרים"],
          color: "silver",
        },
        {
          id: "lt3",
          name: "זהב",
          pointsRequired: 300,
          maxPoints: 999,
          benefits: ["צבירת נקודות על כל רכישה", "הטבת יום הולדת", "15% הנחה על מוצרים", "תור מועדף"],
          color: "gold",
        },
      ],
      loyaltyRewards: [
        {
          id: "lr1",
          name: "הנחה של 50 ש״ח",
          description: "הנחה של 50 ש״ח על הטיפול הבא",
          pointsCost: 100,
        },
        {
          id: "lr2",
          name: "טיפול חינם",
          description: "טיפול פנים בסיסי חינם",
          pointsCost: 300,
        },
      ],
      loyaltySettings: {
        pointsPerPurchase: 1,
        pointsMultiplier: 1,
        referralPoints: 50,
      },
      coupons: [
        {
          id: "c1",
          code: "WELCOME10",
          discount: 10,
          type: "percentage",
          isActive: true,
          expirationDate: "2025-12-31",
        },
        {
          id: "c2",
          code: "SUMMER50",
          discount: 50,
          type: "fixed",
          isActive: true,
          expirationDate: "2025-08-31",
        },
      ],
      emailTemplates: initialEmailTemplates,
      socialShares: [],
      invoices: [],
      d7Settings: {
        accountSid: "",
        authToken: "",
        phoneNumber: "",
        isEnabled: false,
        templates: {
          appointmentConfirmation:
            "שלום {name}, התור שלך ל{service} ב-May Beauty נקבע לתאריך {date} בשעה {time}. להתראות!",
          appointmentReminder: "שלום {name}, תזכורת: התור שלך ל{service} ב-May Beauty מחר בשעה {time}. להתראות!",
          appointmentCancellation:
            "שלום {name}, התור שלך ל{service} בתאריך {date} בשעה {time} בוטל. לקביעת תור חדש צרי קשר.",
          waitlistConfirmation: "שלום {name}, תודה שנכנסת לרשימת ההמתנה לתאריך {date}. במידה ויתפנה מקום תעודכני.",
          orderConfirmation:
            "שלום {name}, הזמנתך מ-May Beauty התקבלה בהצלחה! מספר הזמנה: {order_id}. סכום לתשלום: {total}₪. ניצור איתך קשר בהקדם לתיאום איסוף.",
          orderShipped: "שלום {name}, הזמנתך מס' {order_id} נשלחה ותגיע אליך בקרוב. תודה שקנית ב-May Beauty!",
          orderReady: "שלום {name}, הזמנתך מס' {order_id} מוכנה לאיסוף. ניתן לאסוף אותה בשעות הפעילות שלנו.",
          birthdayWish:
            "שלום {name}, צוות May Beauty מאחל לך יום הולדת שמח! קיבלת קופון הנחה של 10% לרגל יום הולדתך: {coupon_code}",
          loyaltyPointsUpdate: 'שלום {name}, צברת {points} נקודות נאמנות חדשות! סה"כ יש לך כעת {total_points} נקודות.',
          loyaltyTierUpgrade:
            "שלום {name}, ברכות! עלית לרמת {tier_name} במועדון הלקוחות שלנו. כעת תוכלי ליהנות מהטבות נוספות!",
          couponIssued:
            "שלום {name}, הונפק לך קופון חדש: {coupon_code}. הקופון מקנה {discount} הנחה ותקף עד {expiry_date}.",
          passwordReset: "שלום {name}, הסיסמה שלך אופסה בהצלחה. הסיסמה החדשה שלך היא: {password}. אנא שני אותה בהקדם.",
          specialPromotion:
            "שלום {name}, מבצע מיוחד ללקוחות May Beauty! {promotion_details}. המבצע בתוקף עד {expiry_date}.",
        },
      },

      // Authentication state
      loggedInCustomerId: null,
      loggedInAdminId: null,

      logs: [],

      // Service actions
      addService: (service) =>
        set((state) => ({
          services: [...state.services, { ...service, id: Date.now().toString() }],
        })),

      updateService: (id, updatedService) =>
        set((state) => ({
          services: state.services.map((service) => (service.id === id ? { ...service, ...updatedService } : service)),
        })),

      deleteService: (id) =>
        set((state) => ({
          services: state.services.filter((service) => service.id !== id),
        })),

      // Calculate appointment total price
      calculateAppointmentTotal: (appointmentId) => {
        const state = get()
        const appointment = state.appointments.find((a) => a.id === appointmentId)
        if (!appointment) return 0

        try {
          // Check if this is a multi-service appointment
          if (appointment.notes && appointment.notes.includes("multipleServices")) {
            const notesData = JSON.parse(appointment.notes)
            if (notesData.services && Array.isArray(notesData.services)) {
              // Sum up prices of all services
              return notesData.services.reduce((total, service) => {
                return total + (service.price || 0)
              }, 0)
            }
          }

          // If not multi-service or parsing failed, return the appointment price
          return appointment.price || 0
        } catch (error) {
          console.error("Error calculating appointment total:", error)
          return appointment.price || 0
        }
      },

      // Appointment actions
      addAppointment: (appointment) => {
        const id = Date.now().toString()

        set((state) => {
          let totalPrice = 0

          // Check if this is a multi-service appointment
          if (appointment.notes && appointment.notes.includes("multipleServices")) {
            try {
              const notesData = JSON.parse(appointment.notes)
              if (notesData.services && Array.isArray(notesData.services)) {
                // Sum up prices of all services
                totalPrice = notesData.services.reduce((total, service) => {
                  return total + (service.price || 0)
                }, 0)
              }
            } catch (error) {
              console.error("Error parsing appointment notes:", error)
              // Fallback to single service price
              const service = state.services.find((s) => s.id === appointment.serviceId)
              totalPrice = service ? service.price : 0
            }
          } else {
            // Single service appointment
            const service = state.services.find((s) => s.id === appointment.serviceId)
            totalPrice = service ? service.price : 0
          }

          const newAppointment = {
            ...appointment,
            id,
            status: "pending" as const,
            price: totalPrice,
            pointsAwarded: false,
          }

          // Add log for appointment creation
          const logEntry = {
            type: "appointment" as const,
            message: `תור חדש נקבע: ${appointment.customerName} - ${appointment.serviceName} בתאריך ${appointment.date}`,
            user: "system",
            details: { appointmentId: id, customerId: appointment.customerId },
          }

          return {
            appointments: [...state.appointments, newAppointment],
            logs: [
              ...state.logs,
              {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                ...logEntry,
              },
            ],
          }
        })

        return id
      },

      updateAppointment: (id, appointment) =>
        set((state) => {
          const currentAppointment = state.appointments.find((a) => a.id === id)
          if (!currentAppointment) return state

          // Calculate the total price if this is a multi-service appointment
          let updatedPrice = currentAppointment.price
          if (appointment.notes && appointment.notes.includes("multipleServices")) {
            try {
              const notesData = JSON.parse(appointment.notes)
              if (notesData.services && Array.isArray(notesData.services)) {
                updatedPrice = notesData.services.reduce((total, service) => {
                  return total + (service.price || 0)
                }, 0)
              }
            } catch (error) {
              console.error("Error parsing updated appointment notes:", error)
            }
          }

          // Check if status is changing to completed and points haven't been awarded yet
          if (
            (appointment.status === "completed" || appointment.status === "confirmed") &&
            currentAppointment.status !== "completed" &&
            currentAppointment.status !== "confirmed" &&
            !currentAppointment.pointsAwarded
          ) {
            // Find the customer
            const customerId = currentAppointment.customerId
            const customer = state.customers.find((c) => c.id === customerId)

            if (customer) {
              // Calculate points to add (1 point per 10 shekels)
              const totalPrice = updatedPrice || currentAppointment.price
              const pointsToAdd = Math.floor(totalPrice / 10)

              // Update customer with points
              const updatedCustomers = state.customers.map((c) =>
                c.id === customerId
                  ? {
                      ...c,
                      loyaltyPoints: (c.loyaltyPoints || 0) + pointsToAdd,
                    }
                  : c,
              )

              // Add notification about points
              const newNotification = {
                id: Date.now().toString(),
                type: "points",
                message: `קיבלת ${pointsToAdd} נקודות נאמנות עבור התור שלך`,
                date: new Date().toISOString(),
                isRead: false,
                userId: customerId,
                isCustomerNotification: true,
              }

              // Add transaction for completed appointment
              const updatedTransactions = [...state.transactions]
              if (appointment.status === "completed" && currentAppointment.status !== "completed") {
                updatedTransactions.push({
                  id: `tr-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                  date: new Date().toISOString().split("T")[0],
                  description: `תשלום עבור ${currentAppointment.serviceName} - ${currentAppointment.customerName}`,
                  amount: totalPrice,
                  type: "income",
                  category: "service",
                  relatedId: currentAppointment.id,
                })
              }

              // Add log for appointment completion
              const logEntry = {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "appointment" as const,
                message: `תור הושלם: ${currentAppointment.customerName} - ${currentAppointment.serviceName} בתאריך ${currentAppointment.date}`,
                user: "system",
                details: { appointmentId: id, customerId, pointsAwarded: pointsToAdd },
              }

              // Update appointment with pointsAwarded flag and updated price
              return {
                appointments: state.appointments.map((a) =>
                  a.id === id
                    ? {
                        ...a,
                        ...appointment,
                        price: updatedPrice,
                        pointsAwarded: true,
                      }
                    : a,
                ),
                customers: updatedCustomers,
                notifications: [...state.notifications, newNotification],
                transactions: updatedTransactions,
                logs: [...state.logs, logEntry],
              }
            }
          }

          // If status is changing to cancelled and points were awarded, remove the points
          if (appointment.status === "cancelled" && currentAppointment.pointsAwarded) {
            // Find the customer
            const customerId = currentAppointment.customerId
            const customer = state.customers.find((c) => c.id === customerId)

            if (customer) {
              // Calculate points to remove (1 point per 10 shekels)
              const pointsToRemove = Math.floor(currentAppointment.price / 10)

              // Update customer with reduced points
              const updatedCustomers = state.customers.map((c) =>
                c.id === customerId
                  ? {
                      ...c,
                      loyaltyPoints: Math.max(0, (c.loyaltyPoints || 0) - pointsToRemove),
                    }
                  : c,
              )

              // Add notification about points removal
              const newNotification = {
                id: Date.now().toString(),
                type: "points",
                message: `${pointsToRemove} נקודות נאמנות הוסרו בעקבות ביטול התור`,
                date: new Date().toISOString(),
                isRead: false,
                userId: customerId,
                isCustomerNotification: true,
              }

              // Add log for appointment cancellation
              const logEntry = {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "appointment" as const,
                message: `תור בוטל: ${currentAppointment.customerName} - ${currentAppointment.serviceName} בתאריך ${currentAppointment.date}`,
                user: "system",
                details: { appointmentId: id, customerId, pointsRemoved: pointsToRemove },
              }

              // Update appointment with pointsAwarded flag set to false
              return {
                appointments: state.appointments.map((a) =>
                  a.id === id
                    ? {
                        ...a,
                        ...appointment,
                        price: updatedPrice,
                        pointsAwarded: false,
                      }
                    : a,
                ),
                customers: updatedCustomers,
                notifications: [...state.notifications, newNotification],
                logs: [...state.logs, logEntry],
              }
            }
          }

          // Add log for appointment update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "appointment" as const,
            message: `תור עודכן: ${currentAppointment.customerName} - ${currentAppointment.serviceName} בתאריך ${currentAppointment.date}`,
            user: "system",
            details: { appointmentId: id, customerId: currentAppointment.customerId, changes: appointment },
          }

          // Default case - just update the appointment with the updated price
          return {
            appointments: state.appointments.map((a) =>
              a.id === id
                ? {
                    ...a,
                    ...appointment,
                    price: updatedPrice,
                  }
                : a,
            ),
            logs: [...state.logs, logEntry],
          }
        }),

      deleteAppointment: (id) =>
        set((state) => {
          const appointment = state.appointments.find((a) => a.id === id)

          // Add log for appointment deletion
          const logEntry = appointment
            ? {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "appointment" as const,
                message: `תור נמחק: ${appointment.customerName} - ${appointment.serviceName} בתאריך ${appointment.date}`,
                user: "system",
                details: { appointmentId: id, customerId: appointment.customerId },
              }
            : {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "appointment" as const,
                message: `תור נמחק: מזהה ${id}`,
                user: "system",
                details: { appointmentId: id },
              }

          return {
            appointments: state.appointments.filter((appointment) => appointment.id !== id),
            logs: [...state.logs, logEntry],
          }
        }),

      // New function to properly cancel appointments
      cancelAppointment: (id) =>
        set((state) => {
          const appointment = state.appointments.find((a) => a.id === id)
          if (!appointment) return state

          // If points were awarded, remove them
          if (appointment.pointsAwarded) {
            const customerId = appointment.customerId
            const customer = state.customers.find((c) => c.id === customerId)

            if (customer) {
              // Calculate points to remove
              const pointsToRemove = Math.floor(appointment.price / 10)

              // Update customer with reduced points
              const updatedCustomers = state.customers.map((c) =>
                c.id === customerId
                  ? {
                      ...c,
                      loyaltyPoints: Math.max(0, (c.loyaltyPoints || 0) - pointsToRemove),
                    }
                  : c,
              )

              // Add notification about points removal
              const newNotification = {
                id: Date.now().toString(),
                type: "points",
                message: `${pointsToRemove} נקודות נאמנות הוסרו בעקבות ביטול התור`,
                date: new Date().toISOString(),
                isRead: false,
                userId: customerId,
              }

              // Add log for appointment cancellation
              const logEntry = {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "appointment" as const,
                message: `תור בוטל: ${appointment.customerName} - ${appointment.serviceName} בתאריך ${appointment.date}`,
                user: "system",
                details: { appointmentId: id, customerId, pointsRemoved: pointsToRemove },
              }

              // Update appointment status to cancelled and pointsAwarded to false
              return {
                appointments: state.appointments.map((a) =>
                  a.id === id
                    ? {
                        ...a,
                        status: "cancelled",
                        pointsAwarded: false,
                      }
                    : a,
                ),
                customers: updatedCustomers,
                notifications: [...state.notifications, newNotification],
                logs: [...state.logs, logEntry],
              }
            }
          }

          // Add log for appointment cancellation
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "appointment" as const,
            message: `תור בוטל: ${appointment.customerName} - ${appointment.serviceName} בתאריך ${appointment.date}`,
            user: "system",
            details: { appointmentId: id, customerId: appointment.customerId },
          }

          // If no points were awarded, just update the status
          return {
            appointments: state.appointments.map((a) =>
              a.id === id
                ? {
                    ...a,
                    status: "cancelled",
                  }
                : a,
            ),
            logs: [...state.logs, logEntry],
          }
        }),

      // Customer actions
      addCustomer: (customer) => {
        const id = customer.id || Date.now().toString()
        const createdAt = customer.createdAt || new Date().toISOString().split("T")[0]

        set((state) => {
          // Add log for customer creation
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "user" as const,
            message: `לקוח חדש נוסף: ${customer.name || "ללא שם"}`,
            user: "system",
            details: { customerId: id },
          }

          return {
            customers: [
              ...state.customers,
              {
                id,
                name: customer.name || "",
                phone: customer.phone || "",
                visits: customer.visits || 0,
                status: customer.status || "new",
                isRegistered: customer.isRegistered || false,
                loyaltyPoints: customer.loyaltyPoints || 0,
                rewardHistory: customer.rewardHistory || [],
                createdAt,
                hasLoggedIn: false,
                ...customer,
              },
            ],
            logs: [...state.logs, logEntry],
          }
        })

        return id
      },

      updateCustomer: (id, updatedCustomer) =>
        set((state) => {
          const currentCustomer = state.customers.find((c) => c.id === id)

          // Add log for customer update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "user" as const,
            message: `לקוח עודכן: ${currentCustomer?.name || id}`,
            user: "system",
            details: { customerId: id, changes: updatedCustomer },
          }

          return {
            customers: state.customers.map((customer) =>
              customer.id === id ? { ...customer, ...updatedCustomer } : customer,
            ),
            logs: [...state.logs, logEntry],
          }
        }),

      deleteCustomer: (id) =>
        set((state) => {
          const customer = state.customers.find((c) => c.id === id)

          // Add log for customer deletion
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "user" as const,
            message: `לקוח נמחק: ${customer?.name || id}`,
            user: "system",
            details: { customerId: id },
          }

          return {
            customers: state.customers.filter((customer) => customer.id !== id),
            logs: [...state.logs, logEntry],
          }
        }),

      // Authentication actions
      setLoggedInCustomer: (customerId) => {
        console.log("Setting logged in customer:", customerId)

        set((state) => {
          // If a customer is logging in, check if they have a pending referral bonus
          if (customerId) {
            const customer = state.customers.find((c) => c.id === customerId)

            // If this is their first login and they have a pending referral bonus
            if (customer && !customer.hasLoggedIn && customer.pendingReferralBonus) {
              // Process the referral bonus
              const { fromCustomerId, points } = customer.pendingReferralBonus
              const referrer = state.customers.find((c) => c.id === fromCustomerId)

              if (referrer) {
                // Add log for referral bonus
                const logEntry = {
                  id: Date.now().toString(),
                  timestamp: new Date().toISOString(),
                  type: "user" as const,
                  message: `בונוס הפניה הוענק: ${referrer.name} קיבל ${points} נקודות עבור הפניית ${customer.name}`,
                  user: "system",
                  details: { referrerId: fromCustomerId, newCustomerId: customerId, points },
                }

                // Update the referrer with points and referral count
                const updatedCustomers = state.customers.map((c) => {
                  if (c.id === fromCustomerId) {
                    return {
                      ...c,
                      loyaltyPoints: (c.loyaltyPoints || 0) + points,
                      referrals: (c.referrals || 0) + 1,
                    }
                  } else if (c.id === customerId) {
                    // Mark the customer as logged in and clear the pending bonus
                    return {
                      ...c,
                      hasLoggedIn: true,
                      pendingReferralBonus: undefined,
                    }
                  }
                  return c
                })

                // Add notification for the referrer
                const newNotification = {
                  id: Date.now().toString(),
                  type: "points",
                  message: `קיבלת ${points} נקודות נאמנות עבור הפניית ${customer.name}!`,
                  date: new Date().toISOString(),
                  isRead: false,
                  userId: fromCustomerId,
                  isCustomerNotification: true,
                }

                return {
                  loggedInCustomerId: customerId,
                  customers: updatedCustomers,
                  notifications: [...state.notifications, newNotification],
                  logs: [...state.logs, logEntry],
                }
              }
            }

            // If this is their first login but no pending bonus
            if (customer && !customer.hasLoggedIn) {
              return {
                loggedInCustomerId: customerId,
                customers: state.customers.map((c) => (c.id === customerId ? { ...c, hasLoggedIn: true } : c)),
              }
            }
          }

          // Default case - just set the logged in customer
          return { loggedInCustomerId: customerId }
        })
      },

      getLoggedInCustomer: () => {
        const customerId = get().loggedInCustomerId
        if (!customerId) return null
        return get().customers.find((c) => c.id === customerId) || null
      },

      loginCustomer: (phone, password) => {
        const customer = get().customers.find((c) => c.phone === phone && c.password === password && c.isRegistered)

        if (customer) {
          // Add log for customer login
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "user" as const,
            message: `לקוח התחבר: ${customer.name}`,
            user: customer.name,
            details: { customerId: customer.id },
          }

          set((state) => ({
            loggedInCustomerId: customer.id,
            logs: [...state.logs, logEntry],
          }))

          // Process any pending referral bonus
          get().processReferralBonus(customer.id)

          return customer.id
        }

        return null
      },

      logoutCustomer: () => {
        const customerId = get().loggedInCustomerId
        const customer = customerId ? get().customers.find((c) => c.id === customerId) : null

        // Add log for customer logout
        if (customer) {
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "user" as const,
            message: `לקוח התנתק: ${customer.name}`,
            user: customer.name,
            details: { customerId },
          }

          set((state) => ({
            loggedInCustomerId: null,
            logs: [...state.logs, logEntry],
          }))
        } else {
          set({ loggedInCustomerId: null })
        }
      },

      loginAdmin: (password) => {
        if (password === "admin123") {
          // Add log for admin login
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "user" as const,
            message: "מנהל התחבר למערכת",
            user: "admin",
            details: { userType: "admin" },
          }

          set((state) => ({
            loggedInAdminId: "admin",
            logs: [...state.logs, logEntry],
          }))

          return true
        }
        return false
      },

      logoutAdmin: () => {
        // Add log for admin logout
        const logEntry = {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          type: "user" as const,
          message: "מנהל התנתק מהמערכת",
          user: "admin",
          details: { userType: "admin" },
        }

        set((state) => ({
          loggedInAdminId: null,
          logs: [...state.logs, logEntry],
        }))
      },

      // D7 settings
      updateD7Settings: (settings) =>
        set((state) => ({
          d7Settings: { ...state.d7Settings, ...settings },
        })),

      // Send SMS using D7
      sendSms: async (to, templateName, variables) => {
        const state = get()
        const { d7Settings } = state

        if (
          !d7Settings ||
          !d7Settings.isEnabled ||
          !d7Settings.accountSid ||
          !d7Settings.authToken ||
          !d7Settings.phoneNumber
        ) {
          console.error("D7 settings not configured")
          return false
        }

        // Get the template
        const templates = d7Settings.templates || {}
        const template = templates[templateName]

        if (!template) {
          console.error(`Template ${templateName} not found`)
          return false
        }

        // Replace variables in the template
        let message = template
        Object.entries(variables).forEach(([key, value]) => {
          message = message.replace(new RegExp(`{${key}}`, "g"), value)
        })

        try {
          // In a real implementation, this would call the D7 API
          // For now, we'll just log the message
          console.log(`Sending SMS to ${to}: ${message}`)

          // Add log for SMS sent
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `SMS נשלח: ${templateName} אל ${to}`,
            user: "system",
            details: { to, templateName, variables },
          }

          set((state) => ({
            logs: [...state.logs, logEntry],
          }))

          return true
        } catch (error) {
          console.error("Error sending SMS:", error)
          return false
        }
      },

      // Product actions
      addProduct: (product) =>
        set((state) => ({
          products: [...state.products, { ...product, id: Date.now().toString() }],
        })),

      updateProduct: (id, updatedProduct) =>
        set((state) => ({
          products: state.products.map((product) => (product.id === id ? { ...product, ...updatedProduct } : product)),
        })),

      deleteProduct: (id) =>
        set((state) => ({
          products: state.products.filter((product) => product.id !== id),
        })),

      // Cart actions
      addToCart: (productId, quantity) =>
        set((state) => {
          const existingItem = state.cart.find((item) => item.productId === productId)

          if (existingItem) {
            return {
              cart: state.cart.map((item) =>
                item.productId === productId ? { ...item, quantity: item.quantity + quantity } : item,
              ),
            }
          } else {
            return {
              cart: [...state.cart, { productId, quantity }],
            }
          }
        }),

      updateCartItem: (productId, quantity) =>
        set((state) => ({
          cart: state.cart.map((item) => (item.productId === productId ? { ...item, quantity } : item)),
        })),

      removeFromCart: (productId) =>
        set((state) => ({
          cart: state.cart.filter((item) => item.productId !== productId),
        })),

      clearCart: () => set({ cart: [] }),

      // Order actions
      createOrder: (order) => {
        const orderId = Date.now().toString()

        set((state) => {
          // Add log for order creation
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "order" as const,
            message: `הזמנה חדשה: ${order.customerName} - סה"כ ${order.total}₪`,
            user: "system",
            details: { orderId, customerId: order.customerId, total: order.total },
          }

          return {
            orders: [...state.orders, { ...order, id: orderId, pointsAwarded: false }],
            cart: [], // Clear cart after order
            logs: [...state.logs, logEntry],
          }
        })

        return orderId
      },

      // עדכון פונקציית updateOrder
      updateOrder: (id, updatedOrder) =>
        set((state) => {
          const currentOrder = state.orders.find((o) => o.id === id)
          if (!currentOrder) return state

          // Check if status is changing to paid/completed and points haven't been awarded yet
          if (
            (updatedOrder.status === "paid" || updatedOrder.status === "completed") &&
            currentOrder.status !== "paid" &&
            currentOrder.status !== "completed" &&
            !currentOrder.pointsAwarded
          ) {
            // Find the customer
            const customerId = currentOrder.customerId
            const customer = state.customers.find((c) => c.id === customerId)

            if (customer) {
              // Calculate points to add (1 point per 10 shekels)
              const pointsToAdd = Math.floor(currentOrder.total / 10)

              // Update customer with points
              const updatedCustomers = state.customers.map((c) =>
                c.id === customerId
                  ? {
                      ...c,
                      loyaltyPoints: (c.loyaltyPoints || 0) + pointsToAdd,
                    }
                  : c,
              )

              // Add notification about points
              const newNotification = {
                id: Date.now().toString(),
                type: "points",
                message: `קיבלת ${pointsToAdd} נקודות נאמנות עבור ההזמנה שלך`,
                date: new Date().toISOString(),
                isRead: false,
                userId: customerId,
                isCustomerNotification: true,
              }

              // Add transaction for completed order
              const updatedTransactions = [...state.transactions]
              if (
                (updatedOrder.status === "paid" || updatedOrder.status === "completed") &&
                currentOrder.status !== "paid" &&
                currentOrder.status !== "completed"
              ) {
                updatedTransactions.push({
                  id: `tr-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                  date: new Date().toISOString().split("T")[0],
                  description: `תשלום עבור הזמנה #${currentOrder.id.slice(-6)} - ${currentOrder.customerName}`,
                  amount: currentOrder.total,
                  type: "income",
                  category: "product",
                  relatedId: currentOrder.id,
                })
              }

              // Add log for order completion
              const logEntry = {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "order" as const,
                message: `הזמנה הושלמה: ${currentOrder.customerName} - סה"כ ${currentOrder.total}₪`,
                user: "system",
                details: { orderId: id, customerId, pointsAwarded: pointsToAdd },
              }

              // Update order with pointsAwarded flag
              return {
                orders: state.orders.map((o) =>
                  o.id === id
                    ? {
                        ...o,
                        ...updatedOrder,
                        pointsAwarded: true,
                      }
                    : o,
                ),
                customers: updatedCustomers,
                notifications: [...state.notifications, newNotification],
                transactions: updatedTransactions,
                logs: [...state.logs, logEntry],
              }
            }
          }

          // If status is changing to cancelled and points were awarded, remove the points
          if (updatedOrder.status === "cancelled" && currentOrder.pointsAwarded) {
            // Find the customer
            const customerId = currentOrder.customerId
            const customer = state.customers.find((c) => c.id === customerId)

            if (customer) {
              // Calculate points to remove (1 point per 10 shekels)
              const pointsToRemove = Math.floor(currentOrder.total / 10)

              // Update customer with reduced points
              const updatedCustomers = state.customers.map((c) =>
                c.id === customerId
                  ? {
                      ...c,
                      loyaltyPoints: Math.max(0, (c.loyaltyPoints || 0) - pointsToRemove),
                    }
                  : c,
              )

              // Add notification about points removal
              const newNotification = {
                id: Date.now().toString(),
                type: "points",
                message: `${pointsToRemove} נקודות נאמנות הוסרו בעקבות ביטול ההזמנה`,
                date: new Date().toISOString(),
                isRead: false,
                userId: customerId,
                isCustomerNotification: true,
              }

              // Add log for order cancellation
              const logEntry = {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "order" as const,
                message: `הזמנה בוטלה: ${currentOrder.customerName} - סה"כ ${currentOrder.total}₪`,
                user: "system",
                details: { orderId: id, customerId, pointsRemoved: pointsToRemove },
              }

              // Update order with pointsAwarded flag set to false
              return {
                orders: state.orders.map((o) =>
                  o.id === id
                    ? {
                        ...o,
                        ...updatedOrder,
                        pointsAwarded: false,
                      }
                    : o,
                ),
                customers: updatedCustomers,
                notifications: [...state.notifications, newNotification],
                logs: [...state.logs, logEntry],
              }
            }
          }

          // Add log for order update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "order" as const,
            message: `הזמנה עודכנה: ${currentOrder.customerName} - סה"כ ${currentOrder.total}₪`,
            user: "system",
            details: { orderId: id, customerId: currentOrder.customerId, changes: updatedOrder },
          }

          // Default case - just update the order
          return {
            orders: state.orders.map((o) => (o.id === id ? { ...o, ...updatedOrder } : o)),
            logs: [...state.logs, logEntry],
          }
        }),

      // New function to properly cancel orders
      cancelOrder: (id) =>
        set((state) => {
          const order = state.orders.find((o) => o.id === id)
          if (!order) return state

          // If points were awarded, remove them
          if (order.pointsAwarded) {
            const customerId = order.customerId
            const customer = state.customers.find((c) => c.id === customerId)

            if (customer) {
              // Calculate points to remove
              const pointsToRemove = Math.floor(order.total / 10)

              // Update customer with reduced points
              const updatedCustomers = state.customers.map((c) =>
                c.id === customerId
                  ? {
                      ...c,
                      loyaltyPoints: Math.max(0, (c.loyaltyPoints || 0) - pointsToRemove),
                    }
                  : c,
              )

              // Add notification about points removal
              const newNotification = {
                id: Date.now().toString(),
                type: "points",
                message: `${pointsToRemove} נקודות נאמנות הוסרו בעקבות ביטול ההזמנה`,
                date: new Date().toISOString(),
                isRead: false,
                userId: customerId,
              }

              // Add log for order cancellation
              const logEntry = {
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                type: "order" as const,
                message: `הזמנה בוטלה: ${order.customerName} - סה"כ ${order.total}₪`,
                user: "system",
                details: { orderId: id, customerId, pointsRemoved: pointsToRemove },
              }

              // Update order status to cancelled and pointsAwarded to false
              return {
                orders: state.orders.map((o) =>
                  o.id === id
                    ? {
                        ...o,
                        status: "cancelled",
                        pointsAwarded: false,
                      }
                    : o,
                ),
                customers: updatedCustomers,
                notifications: [...state.notifications, newNotification],
                logs: [...state.logs, logEntry],
              }
            }
          }

          // Add log for order cancellation
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "order" as const,
            message: `הזמנה בוטלה: ${order.customerName} - סה"כ ${order.total}₪`,
            user: "system",
            details: { orderId: id, customerId: order.customerId },
          }

          // If no points were awarded, just update the status
          return {
            orders: state.orders.map((o) =>
              o.id === id
                ? {
                    ...o,
                    status: "cancelled",
                  }
                : o,
            ),
            logs: [...state.logs, logEntry],
          }
        }),

      // Transaction actions
      addTransaction: (transaction) =>
        set((state) => {
          // Add log for transaction creation
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `עסקה חדשה: ${transaction.description} - ${transaction.amount}₪`,
            user: "system",
            details: { transaction },
          }

          return {
            transactions: [...state.transactions, { ...transaction, id: Date.now().toString() }],
            logs: [...state.logs, logEntry],
          }
        }),

      updateTransaction: (id, updatedTransaction) =>
        set((state) => {
          const transaction = state.transactions.find((t) => t.id === id)

          // Add log for transaction update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `עסקה עודכנה: ${transaction?.description || id}`,
            user: "system",
            details: { transactionId: id, changes: updatedTransaction },
          }

          return {
            transactions: state.transactions.map((transaction) =>
              transaction.id === id ? { ...transaction, ...updatedTransaction } : transaction,
            ),
            logs: [...state.logs, logEntry],
          }
        }),

      deleteTransaction: (id) =>
        set((state) => {
          const transaction = state.transactions.find((t) => t.id === id)

          // Add log for transaction deletion
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `עסקה נמחקה: ${transaction?.description || id}`,
            user: "system",
            details: { transactionId: id },
          }

          return {
            transactions: state.transactions.filter((transaction) => transaction.id !== id),
            logs: [...state.logs, logEntry],
          }
        }),

      addManualTransaction: (transaction) =>
        set((state) => {
          const newTransaction = {
            ...transaction,
            id: Date.now().toString(),
            date: transaction.date || new Date().toISOString().split("T")[0],
          }

          // Add log for manual transaction
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `עסקה ידנית נוספה: ${transaction.description || "ללא תיאור"} - ${transaction.amount}₪`,
            user: "system",
            details: { transaction: newTransaction },
          }

          return {
            transactions: [...state.transactions, newTransaction],
            logs: [...state.logs, logEntry],
          }
        }),

      // Newsletter actions
      subscribeToNewsletter: (phone, name) =>
        set((state) => {
          const newSubscriber = {
            id: Date.now().toString(),
            phone,
            name,
            date: new Date().toISOString(),
            isActive: true,
          }

          // Add log for newsletter subscription
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `הרשמה לניוזלטר: ${name} (${phone})`,
            user: "system",
            details: { subscriber: newSubscriber },
          }

          return {
            newsletterSubscribers: [...state.newsletterSubscribers, newSubscriber],
            logs: [...state.logs, logEntry],
          }
        }),

      unsubscribeFromNewsletter: (id) =>
        set((state) => {
          const subscriber = state.newsletterSubscribers.find((s) => s.id === id)

          // Add log for newsletter unsubscription
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `ביטול הרשמה לניוזלטר: ${subscriber?.name || id}`,
            user: "system",
            details: { subscriberId: id },
          }

          return {
            newsletterSubscribers: state.newsletterSubscribers.map((sub) =>
              sub.id === id ? { ...sub, isActive: false } : sub,
            ),
            logs: [...state.logs, logEntry],
          }
        }),

      // Site content actions
      updateSiteContent: (content) =>
        set((state) => {
          // Add log for site content update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: "תוכן האתר עודכן",
            user: "system",
            details: { changes: content },
          }

          return {
            siteContent: {
              ...state.siteContent,
              ...content,
              images: {
                ...state.siteContent.images,
                ...content.images,
              },
            },
            logs: [...state.logs, logEntry],
          }
        }),

      addGalleryImage: (image) =>
        set((state) => {
          // Add log for gallery image addition
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: "תמונה חדשה נוספה לגלריה",
            user: "system",
            details: { image },
          }

          return {
            siteContent: {
              ...state.siteContent,
              images: {
                ...state.siteContent.images,
                gallery: [...state.siteContent.images.gallery, image],
              },
            },
            logs: [...state.logs, logEntry],
          }
        }),

      removeGalleryImage: (imageUrl) =>
        set((state) => {
          // Add log for gallery image removal
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: "תמונה הוסרה מהגלריה",
            user: "system",
            details: { imageUrl },
          }

          return {
            siteContent: {
              ...state.siteContent,
              images: {
                ...state.siteContent.images,
                gallery: state.siteContent.images.gallery.filter((img) => img !== imageUrl),
              },
            },
            logs: [...state.logs, logEntry],
          }
        }),

      // עדכון פונקציית resetFinancialData
      resetFinancialData: () =>
        set((state) => {
          // Add log for financial data reset
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: "נתונים פיננסיים אופסו",
            user: "system",
          }

          return {
            transactions: [],
            logs: [...state.logs, logEntry],
          }
        }),

      // Notification actions
      markNotificationAsRead: (id) =>
        set((state) => ({
          notifications: state.notifications.map((notification) =>
            notification.id === id ? { ...notification, isRead: true } : notification,
          ),
        })),

      clearNotifications: () =>
        set((state) => {
          // Add log for notifications clear
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: "כל ההתראות נמחקו",
            user: "system",
          }

          return {
            notifications: [],
            logs: [...state.logs, logEntry],
          }
        }),

      // תיקון מערכת ההתראות - הפרדה בין התראות מנהל ולקוח
      // עדכון פונקציית addNotification
      addNotification: (notification) => {
        // Create a unique ID for the notification
        const notificationId = Date.now().toString()

        // Determine if this is a customer-specific notification
        const isCustomerNotification =
          notification.type === "points" ||
          notification.type === "reward" ||
          notification.type === "coupon" ||
          (notification.userId !== undefined && notification.userId !== "admin")

        // Set the correct notification type
        const notificationType = notification.type || "system"

        // Add log for notification creation
        const logEntry = {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          type: "system" as const,
          message: `התראה חדשה: ${notification.message}`,
          user: "system",
          details: { notification, userId: notification.userId },
        }

        set((state) => ({
          notifications: [
            ...state.notifications,
            {
              id: notificationId,
              type: notificationType,
              message: notification.message,
              date: new Date().toISOString(),
              isRead: false,
              userId: notification.userId || null,
              isCustomerNotification: isCustomerNotification,
            },
          ],
          logs: [...state.logs, logEntry],
        }))

        return notificationId
      },

      updateNotification: (id, notification) =>
        set((state) => ({
          notifications: state.notifications.map((n) => (n.id === id ? { ...n, ...notification } : n)),
        })),

      // Time slot utilities
      getAvailableTimeSlots: (date, serviceId) => {
        const state = get()
        const service = state.services.find((s) => s.id === serviceId)
        if (!service) return []

        // Get all possible time slots
        const allTimeSlots = [
          "11:00",
          "11:20",
          "11:40",
          "12:00",
          "12:20",
          "12:40",
          "13:00",
          "13:20",
          "13:40",
          "14:00",
          "14:20",
          "14:40",
          "15:00",
          "15:20",
          "15:40",
          "16:00",
          "16:20",
          "16:40",
          "17:00",
          "17:20",
          "17:40",
        ]

        // Check for closed hours
        const closedHoursForDate = state.closedHours.filter((ch) => ch.date === date)

        // Filter out time slots that fall within closed hours
        const availableSlots = allTimeSlots.filter((timeSlot) => {
          // Convert time slot to minutes
          const [hours, minutes] = timeSlot.split(":").map(Number)
          const slotMinutes = hours * 60 + minutes

          // Check if this slot is within any closed hours
          for (const closedHour of closedHoursForDate) {
            const [startHours, startMinutes] = closedHour.startTime.split(":").map(Number)
            const [endHours, endMinutes] = closedHour.endTime.split(":").map(Number)

            const closedStartMinutes = startHours * 60 + startMinutes
            const closedEndMinutes = endHours * 60 + endMinutes

            if (slotMinutes >= closedStartMinutes && slotMinutes < closedEndMinutes) {
              return false
            }
          }

          // Check if this slot is already booked
          const bookedAppointments = state.appointments.filter(
            (a) => a.date === date && a.time === timeSlot && a.status !== "cancelled",
          )

          return bookedAppointments.length === 0
        })

        return availableSlots.map((time) => ({
          time,
          isAvailable: true,
        }))
      },

      isTimeSlotAvailable: (date, time) => {
        const state = get()

        // Check if this time is within closed hours
        const closedHoursForDate = state.closedHours.filter((ch) => ch.date === date)

        // Convert time to minutes
        const [hours, minutes] = time.split(":").map(Number)
        const timeMinutes = hours * 60 + minutes

        // Check if this time is within any closed hours
        for (const closedHour of closedHoursForDate) {
          const [startHours, startMinutes] = closedHour.startTime.split(":").map(Number)
          const [endHours, endMinutes] = closedHour.endTime.split(":").map(Number)

          const closedStartMinutes = startHours * 60 + startMinutes
          const closedEndMinutes = endHours * 60 + endMinutes

          if (timeMinutes >= closedStartMinutes && timeMinutes < closedEndMinutes) {
            return false
          }
        }

        // Check if there's already an appointment at this time
        const bookedAppointments = state.appointments.filter(
          (a) => a.date === date && a.time === time && a.status !== "cancelled",
        )

        return bookedAppointments.length === 0
      },

      // Financial summary
      getFinancialSummary: (startDate, endDate) => {
        const state = get()

        // Filter transactions within date range
        const filteredTransactions = state.transactions.filter((transaction) => {
          return transaction.date >= startDate && transaction.date <= endDate
        })

        // Calculate totals
        const totalIncome = filteredTransactions
          .filter((t) => t.type === "income")
          .reduce((sum, t) => sum + t.amount, 0)

        const totalExpenses = filteredTransactions
          .filter((t) => t.type === "expense")
          .reduce((sum, t) => sum + t.amount, 0)

        const netProfit = totalIncome - totalExpenses

        // Calculate income by category
        const serviceIncome = filteredTransactions
          .filter((t) => t.type === "income" && t.category === "service")
          .reduce((sum, t) => sum + t.amount, 0)

        const productIncome = filteredTransactions
          .filter((t) => t.type === "income" && t.category === "product")
          .reduce((sum, t) => sum + t.amount, 0)

        // Calculate expenses by category
        const expensesByCategory: Record<string, number> = {}

        filteredTransactions
          .filter((t) => t.type === "expense")
          .forEach((t) => {
            if (!expensesByCategory[t.category]) {
              expensesByCategory[t.category] = 0
            }
            expensesByCategory[t.category] += t.amount
          })

        return {
          totalIncome,
          totalExpenses,
          netProfit,
          serviceIncome,
          productIncome,
          expensesByCategory,
        }
      },

      // פונקציות לניהול ימים סגורים
      addClosedDay: (date, reason, specificHours = false, startTime, endTime) =>
        set((state) => {
          // Add log for closed day addition
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `יום סגור נוסף: ${date} - ${reason}`,
            user: "system",
            details: { date, reason, specificHours, startTime, endTime },
          }

          return {
            closedDays: [
              ...state.closedDays,
              {
                id: `closed-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                date,
                reason,
                specificHours,
                startTime,
                endTime,
              },
            ],
            logs: [...state.logs, logEntry],
          }
        }),

      removeClosedDay: (date) =>
        set((state) => {
          // Add log for closed day removal
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `יום סגור הוסר: ${date}`,
            user: "system",
            details: { date },
          }

          return {
            closedDays: state.closedDays.filter((day) => day.date !== date),
            logs: [...state.logs, logEntry],
          }
        }),

      // Add closed hours
      addClosedHours: (date, startTime: string, endTime: string, reason: string) => {
        const id = `closed-hours-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

        set((state) => {
          // Make sure closedHours exists
          const currentClosedHours = state.closedHours || []

          // Add log for closed hours addition
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `שעות סגורות נוספו: ${date} ${startTime}-${endTime} - ${reason}`,
            user: "system",
            details: { date, startTime, endTime, reason },
          }

          return {
            closedHours: [
              ...currentClosedHours,
              {
                id,
                date,
                startTime,
                endTime,
                reason: reason || `סגור בין ${startTime} ל-${endTime}`,
              },
            ],
            logs: [...state.logs, logEntry],
          }
        })

        return id
      },

      // Remove closed hours
      removeClosedHours: (id) =>
        set((state) => {
          const closedHour = state.closedHours.find((ch) => ch.id === id)

          // Add log for closed hours removal
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `שעות סגורות הוסרו: ${closedHour?.date || id}`,
            user: "system",
            details: { closedHourId: id },
          }

          return {
            closedHours: state.closedHours.filter((hours) => hours.id !== id),
            logs: [...state.logs, logEntry],
          }
        }),

      updateAppointmentTips: (tips) =>
        set((state) => {
          // Add log for appointment tips update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: "טיפים לתור עודכנו",
            user: "system",
            details: { tips },
          }

          return {
            appointmentTips: { ...state.appointmentTips, ...tips },
            logs: [...state.logs, logEntry],
          }
        }),

      // Loyalty and coupon actions
      addLoyaltyTier: (tier) => {
        const id = Date.now().toString()

        set((state) => {
          // Add log for loyalty tier addition
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `דרגת נאמנות חדשה נוספה: ${tier.name}`,
            user: "system",
            details: { tier: { ...tier, id } },
          }

          return {
            loyaltyTiers: [...state.loyaltyTiers, { id, ...tier }],
            logs: [...state.logs, logEntry],
          }
        })

        return id
      },

      updateLoyaltyTier: (id, tier) => {
        set((state) => {
          const currentTier = state.loyaltyTiers.find((t) => t.id === id)

          // Add log for loyalty tier update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `דרגת נאמנות עודכנה: ${currentTier?.name || id}`,
            user: "system",
            details: { tierId: id, changes: tier },
          }

          return {
            loyaltyTiers: state.loyaltyTiers.map((t) => (t.id === id ? { ...t, ...tier } : t)),
            logs: [...state.logs, logEntry],
          }
        })
      },

      deleteLoyaltyTier: (id) => {
        set((state) => {
          const tier = state.loyaltyTiers.find((t) => t.id === id)

          // Add log for loyalty tier deletion
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `דרגת נאמנות נמחקה: ${tier?.name || id}`,
            user: "system",
            details: { tierId: id },
          }

          return {
            loyaltyTiers: state.loyaltyTiers.filter((t) => t.id !== id),
            logs: [...state.logs, logEntry],
          }
        })
      },

      addLoyaltyReward: (reward) => {
        const id = Date.now().toString()

        set((state) => {
          // Add log for loyalty reward addition
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `הטבת נאמנות חדשה נוספה: ${reward.name}`,
            user: "system",
            details: { reward: { ...reward, id } },
          }

          return {
            loyaltyRewards: [...state.loyaltyRewards, { id, ...reward }],
            logs: [...state.logs, logEntry],
          }
        })

        return id
      },

      updateLoyaltyReward: (id, reward) => {
        set((state) => {
          const currentReward = state.loyaltyRewards.find((r) => r.id === id)

          // Add log for loyalty reward update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `הטבת נאמנות עודכנה: ${currentReward?.name || id}`,
            user: "system",
            details: { rewardId: id, changes: reward },
          }

          return {
            loyaltyRewards: state.loyaltyRewards.map((r) => (r.id === id ? { ...r, ...reward } : r)),
            logs: [...state.logs, logEntry],
          }
        })
      },

      deleteLoyaltyReward: (id) => {
        set((state) => {
          const reward = state.loyaltyRewards.find((r) => r.id === id)

          // Add log for loyalty reward deletion
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `הטבת נאמנות נמחקה: ${reward?.name || id}`,
            user: "system",
            details: { rewardId: id },
          }

          return {
            loyaltyRewards: state.loyaltyRewards.filter((r) => r.id !== id),
            logs: [...state.logs, logEntry],
          }
        })
      },

      // תיקון פונקציית validateCoupon
      validateCoupon: (code) => {
        const state = get()
        const coupon = state.coupons.find((c) => c.code.toLowerCase() === code.toLowerCase())

        if (!coupon) {
          return { valid: false, value: 0, type: "percentage", message: "קוד קופון לא קיים" }
        }

        if (!coupon.isActive) {
          return { valid: false, value: 0, type: "percentage", message: "קוד קופון לא פעיל" }
        }

        // Check expiration date
        if (coupon.expirationDate) {
          const today = new Date().toISOString().split("T")[0]
          if (coupon.expirationDate < today) {
            return { valid: false, value: 0, type: "percentage", message: "קוד קופון פג תוקף" }
          }
        }

        // Check max uses
        if (coupon.maxUses && coupon.usedCount && coupon.usedCount >= coupon.maxUses) {
          return { valid: false, value: 0, type: "percentage", message: "קוד קופון הגיע למקסימום שימושים" }
        }

        // Check if it's a reward coupon that belongs to a specific customer
        if (coupon.isReward && coupon.customerId) {
          const loggedInCustomerId = state.loggedInCustomerId
          if (coupon.customerId !== loggedInCustomerId) {
            return { valid: false, value: 0, type: "percentage", message: "קוד קופון לא שייך ללקוח זה" }
          }
        }

        // Add log for coupon validation
        const logEntry = {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          type: "system" as const,
          message: `קופון אומת: ${code}`,
          user: "system",
          details: { couponCode: code, customerId: state.loggedInCustomerId },
        }

        set((state) => ({
          logs: [...state.logs, logEntry],
        }))

        return {
          valid: true,
          value: coupon.discount,
          type: coupon.type || "percentage",
          isReferral: coupon.isReferral,
          message: "קוד קופון תקף",
        }
      },

      // תיקון פונקציית applyCoupon
      applyCoupon: (code, orderId) => {
        const state = get()
        const result = state.validateCoupon(code)

        if (result.valid) {
          // Update coupon usage count
          set((state) => {
            const coupon = state.coupons.find((c) => c.code.toLowerCase() === code.toLowerCase())

            if (!coupon) return state

            // Add log for coupon application
            const logEntry = {
              id: Date.now().toString(),
              timestamp: new Date().toISOString(),
              type: "system" as const,
              message: `קופון הופעל: ${code}`,
              user: "system",
              details: { couponCode: code, customerId: state.loggedInCustomerId, orderId },
            }

            // If this is a reward coupon or has maxUses of 1, mark it as inactive after use
            if (coupon.isReward || coupon.maxUses === 1) {
              // Add notification about coupon usage
              const newNotification = {
                id: Date.now().toString(),
                type: "coupon",
                message: `ניצלת קוד קופון "${coupon.code}" על סך ${coupon.type === "percentage" ? `${coupon.discount}%` : `${coupon.discount} ₪`}`,
                date: new Date().toISOString(),
                isRead: false,
                userId: coupon.customerId || state.loggedInCustomerId,
                isCustomerNotification: true,
              }

              // If this is a reward coupon, mark the redemption as used
              let updatedRewardHistory = [...state.customers]
              if (coupon.redemptionId && coupon.customerId) {
                const customer = state.customers.find((c) => c.id === coupon.customerId)
                if (customer && customer.rewardHistory) {
                  updatedRewardHistory = state.customers.map((c) => {
                    if (c.id === coupon.customerId) {
                      return {
                        ...c,
                        rewardHistory: (c.rewardHistory || []).map((r) =>
                          r.id === coupon.redemptionId ? { ...r, isUsed: true } : r,
                        ),
                      }
                    }
                    return c
                  })
                }
              }

              return {
                coupons: state.coupons.map((c) =>
                  c.code.toLowerCase() === code.toLowerCase()
                    ? {
                        ...c,
                        isActive: false,
                        usedCount: (c.usedCount || 0) + 1,
                      }
                    : c,
                ),
                notifications: [...state.notifications, newNotification],
                customers: updatedRewardHistory,
                logs: [...state.logs, logEntry],
              }
            } else {
              // Otherwise just increment the used count
              const updatedUsedCount = (coupon.usedCount || 0) + 1
              const reachedMaxUses = coupon.maxUses && updatedUsedCount >= coupon.maxUses

              return {
                coupons: state.coupons.map((c) =>
                  c.code.toLowerCase() === code.toLowerCase()
                    ? {
                        ...c,
                        usedCount: updatedUsedCount,
                        isActive: reachedMaxUses ? false : c.isActive,
                      }
                    : c,
                ),
                logs: [...state.logs, logEntry],
              }
            }
          })

          return true
        }

        return false
      },

      // Fix the redeemReward function to properly handle reward redemption
      redeemReward: (customerId, rewardId) => {
        const state = get()
        const customer = state.customers.find((c) => c.id === customerId)
        const reward = state.loyaltyRewards.find((r) => r.id === rewardId)

        if (!customer || !reward) return false

        // Check if customer has enough points
        if ((customer.loyaltyPoints || 0) < reward.pointsCost) return false

        // Generate a coupon code for the reward
        const couponCode = `REWARD${Date.now().toString().slice(-6)}`
        const redemptionId = Date.now().toString()

        // Deduct points and add to history
        set((state) => {
          // Add log for reward redemption
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `הטבה מומשה: ${customer.name} מימש את ${reward.name}`,
            user: "system",
            details: { customerId, rewardId, pointsCost: reward.pointsCost, couponCode },
          }

          const updatedCustomers = state.customers.map((c) =>
            c.id === customerId
              ? {
                  ...c,
                  loyaltyPoints: (c.loyaltyPoints || 0) - reward.pointsCost,
                  rewardHistory: [
                    ...(c.rewardHistory || []),
                    {
                      id: redemptionId,
                      rewardId,
                      rewardName: reward.name,
                      pointsCost: reward.pointsCost,
                      date: new Date().toISOString(),
                      couponCode,
                      isUsed: false,
                    },
                  ],
                }
              : c,
          )

          // Add notification
          const updatedNotifications = [
            ...state.notifications,
            {
              id: Date.now().toString(),
              type: "reward",
              message: `מימשת את ההטבה "${reward.name}" בעלות של ${reward.pointsCost} נקודות. קוד הקופון שלך: ${couponCode}`,
              userId: customerId,
              date: new Date().toISOString(),
              isRead: false,
              isCustomerNotification: true,
            },
          ]

          // Create a coupon for this reward
          const newCoupon = {
            id: Date.now().toString(),
            code: couponCode,
            discount: 50, // Default value, can be adjusted based on reward type
            type: "fixed",
            isActive: true,
            isReward: true,
            customerId: customerId, // Associate with this customer
            redemptionId: redemptionId, // Link to the redemption record
            maxUses: 1, // One-time use
            usedCount: 0,
            expirationDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // 30 days
          }

          return {
            customers: updatedCustomers,
            notifications: updatedNotifications,
            coupons: [...state.coupons, newCoupon],
            logs: [...state.logs, logEntry],
          }
        })

        return true
      },

      // Get customer's active coupons
      getCustomerActiveCoupons: (customerId) => {
        const state = get()

        // Get all coupons that are:
        // 1. Active
        // 2. Either belong to this customer or are general coupons
        // 3. Not expired
        // 4. For reward coupons, check if they're not used yet
        const activeCoupons = state.coupons.filter((coupon) => {
          // Basic checks
          const isActive = coupon.isActive
          const belongsToCustomer = coupon.customerId === customerId || !coupon.customerId
          const notExpired = !coupon.expirationDate || coupon.expirationDate >= new Date().toISOString().split("T")[0]

          // For reward coupons, check if they're used
          if (coupon.isReward && coupon.redemptionId && coupon.customerId === customerId) {
            const customer = state.customers.find((c) => c.id === customerId)
            if (customer && customer.rewardHistory) {
              const redemption = customer.rewardHistory.find((r) => r.id === coupon.redemptionId)
              if (redemption && redemption.isUsed) {
                return false // Don't show used reward coupons
              }
            }
          }

          return isActive && belongsToCustomer && notExpired
        })

        return activeCoupons
      },

      // Fix the verifyReferralCode function to properly handle referral codes
      verifyReferralCode: (code) => {
        if (!code || code.trim() === "") {
          console.log("Referral code is empty")
          return false
        }

        const state = get()
        const trimmedCode = code.trim()
        console.log("Verifying referral code:", trimmedCode)

        // Check if the code belongs to the currently logged in customer
        const loggedInCustomerId = state.loggedInCustomerId
        if (loggedInCustomerId) {
          const loggedInCustomer = state.customers.find((c) => c.id === loggedInCustomerId)
          if (loggedInCustomer && loggedInCustomer.referralCode === trimmedCode) {
            console.log("Self-referral attempt detected")

            // Add log for self-referral attempt
            const logEntry = {
              id: Date.now().toString(),
              timestamp: new Date().toISOString(),
              type: "system" as const,
              message: `ניסיון הפניה עצמית: ${loggedInCustomer.name} ניסה להשתמש בקוד ההפניה שלו`,
              user: "system",
              details: { customerId: loggedInCustomerId, referralCode: trimmedCode },
            }

            set((state) => ({
              logs: [...state.logs, logEntry],
            }))

            return false // Prevent self-referral
          }
        }

        const customers = state.customers
        const matchingCustomer = customers.find((c) => c && c.referralCode === trimmedCode)

        console.log("Found matching customer:", matchingCustomer ? matchingCustomer.name : "No")

        if (matchingCustomer) {
          // Don't award points immediately - store the pending bonus
          // Points will be awarded when the new customer logs in for the first time
          if (loggedInCustomerId) {
            const referralPoints = state.loyaltySettings.referralPoints || 50

            // Add log for valid referral code
            const logEntry = {
              id: Date.now().toString(),
              timestamp: new Date().toISOString(),
              type: "system" as const,
              message: `קוד הפניה תקף: ${trimmedCode} (${matchingCustomer.name})`,
              user: "system",
              details: {
                referrerId: matchingCustomer.id,
                newCustomerId: loggedInCustomerId,
                referralCode: trimmedCode,
              },
            }

            set((state) => {
              // Store the pending referral bonus in the new customer's record
              const updatedCustomers = state.customers.map((c) => {
                if (c.id === loggedInCustomerId) {
                  return {
                    ...c,
                    referredBy: matchingCustomer.id,
                    pendingReferralBonus: {
                      fromCustomerId: matchingCustomer.id,
                      points: referralPoints,
                    },
                  }
                }
                return c
              })

              return {
                customers: updatedCustomers,
                logs: [...state.logs, logEntry],
              }
            })
          }

          return true
        }

        return false
      },

      // תיקון פונקציית processReferralBonus כדי לוודא שהבונוס מוענק רק בהתחברות ראשונה
      processReferralBonus: (customerId) => {
        const state = get()
        const customer = state.customers.find((c) => c.id === customerId)

        if (!customer || !customer.pendingReferralBonus) {
          console.log("No pending bonus found for customer:", customerId)
          return // No pending bonus
        }

        if (customer.hasLoggedIn) {
          console.log("Customer already logged in before, not processing bonus:", customerId)
          return // Already logged in before
        }

        const { fromCustomerId, points } = customer.pendingReferralBonus
        const referrer = state.customers.find((c) => c.id === fromCustomerId)

        if (!referrer) {
          console.log("Referrer not found:", fromCustomerId)
          return // Referrer not found
        }

        console.log("Processing referral bonus:", {
          referrer: referrer.name,
          newCustomer: customer.name,
          points: points,
        })

        // Add log for referral bonus processing
        const logEntry = {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          type: "system" as const,
          message: `בונוס הפניה הוענק: ${referrer.name} קיבל ${points} נקודות עבור הפניית ${customer.name}`,
          user: "system",
          details: { referrerId: fromCustomerId, newCustomerId: customerId, points },
        }

        // Update the referrer with points and referral count
        set((state) => {
          const updatedCustomers = state.customers.map((c) => {
            if (c.id === fromCustomerId) {
              return {
                ...c,
                loyaltyPoints: (c.loyaltyPoints || 0) + points,
                referrals: (c.referrals || 0) + 1,
              }
            } else if (c.id === customerId) {
              // Mark the customer as logged in and clear the pending bonus
              return {
                ...c,
                hasLoggedIn: true,
                pendingReferralBonus: undefined,
              }
            }
            return c
          })

          // Add notification for the referrer
          const newNotification = {
            id: Date.now().toString(),
            type: "points",
            message: `קיבלת ${points} נקודות נאמנות עבור הפניית ${customer.name}!`,
            date: new Date().toISOString(),
            isRead: false,
            userId: fromCustomerId,
            isCustomerNotification: true,
          }

          // Add notification for the new customer
          const newCustomerNotification = {
            id: Date.now().toString() + "-1",
            type: "points",
            message: `קיבלת ${customer.loyaltyPoints || 0} נקודות נאמנות כבונוס על הרשמה עם קוד הפניה!`,
            date: new Date().toISOString(),
            isRead: false,
            userId: customerId,
            isCustomerNotification: true,
          }

          return {
            customers: updatedCustomers,
            notifications: [...state.notifications, newNotification, newCustomerNotification],
            logs: [...state.logs, logEntry],
          }
        })
      },

      // Generate referral code
      generateReferralCode: (customerId) => {
        const state = get()
        const customer = state.customers.find((c) => c.id === customerId)

        if (!customer) {
          return ""
        }

        // Generate a unique referral code
        const code = `MAY${customerId.substring(0, 4)}${Math.floor(Math.random() * 1000)
          .toString()
          .padStart(3, "0")}`

        // Add log for referral code generation
        const logEntry = {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          type: "system" as const,
          message: `קוד הפניה נוצר: ${customer.name} - ${code}`,
          user: "system",
          details: { customerId, referralCode: code },
        }

        // Update the customer with the new code
        set((state) => ({
          customers: state.customers.map((c) => (c.id === customerId ? { ...c, referralCode: code } : c)),
          logs: [...state.logs, logEntry],
        }))

        return code
      },

      // Add coupon
      addCoupon: (coupon) => {
        const id = Date.now().toString()

        set((state) => {
          // Add log for coupon addition
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `קופון חדש נוצר: ${coupon.code}`,
            user: "system",
            details: { coupon: { ...coupon, id } },
          }

          return {
            coupons: [...state.coupons, { ...coupon, id }],
            logs: [...state.logs, logEntry],
          }
        })

        return id
      },

      // Update coupon
      updateCoupon: (id, coupon) => {
        set((state) => {
          const currentCoupon = state.coupons.find((c) => c.id === id)

          // Add log for coupon update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `קופון עודכן: ${currentCoupon?.code || id}`,
            user: "system",
            details: { couponId: id, changes: coupon },
          }

          return {
            coupons: state.coupons.map((c) => (c.id === id ? { ...c, ...coupon } : c)),
            logs: [...state.logs, logEntry],
          }
        })
      },

      // Delete coupon
      deleteCoupon: (id) => {
        set((state) => {
          const coupon = state.coupons.find((c) => c.id === id)

          // Add log for coupon deletion
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `קופון נמחק: ${coupon?.code || id}`,
            user: "system",
            details: { couponId: id },
          }

          return {
            coupons: state.coupons.filter((c) => c.id !== id),
            logs: [...state.logs, logEntry],
          }
        })
      },

      // Verify if coupon has been used
      verifyCouponUsed: (code) => {
        set((state) => {
          const coupon = state.coupons.find((c) => c.code === code)

          if (coupon && coupon.isActive) {
            // Add log for coupon verification
            const logEntry = {
              id: Date.now().toString(),
              timestamp: new Date().toISOString(),
              type: "system" as const,
              message: `קופון נבדק: ${code}`,
              user: "system",
              details: { couponCode: code, isActive: coupon.isActive, usedCount: coupon.usedCount },
            }

            return {
              logs: [...state.logs, logEntry],
            }
          }

          return state
        })
      },

      // Analytics actions
      addPageView: (page) => {
        set((state) => {
          const pageViews = { ...state.analytics.pageViews }
          pageViews[page] = (pageViews[page] || 0) + 1

          // Add log for page view
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `צפייה בדף: ${page}`,
            user: state.loggedInCustomerId || "anonymous",
            details: { page, userId: state.loggedInCustomerId },
          }

          return {
            analytics: {
              ...state.analytics,
              pageViews,
            },
            logs: [...state.logs, logEntry],
          }
        })
      },

      addReferrer: (source) => {
        set((state) => {
          const referrers = { ...state.analytics.referrers }
          referrers[source] = (referrers[source] || 0) + 1

          // Add log for referrer
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `מקור הפניה: ${source}`,
            user: "system",
            details: { source },
          }

          return {
            analytics: {
              ...state.analytics,
              referrers,
            },
            logs: [...state.logs, logEntry],
          }
        })
      },

      addVisitor: () => {
        set((state) => {
          // Add log for new visitor
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: "מבקר חדש באתר",
            user: "system",
          }

          return {
            analytics: {
              ...state.analytics,
              uniqueVisitors: state.analytics.uniqueVisitors + 1,
            },
            logs: [...state.logs, logEntry],
          }
        })
      },

      // Add log actions
      addLog: (log) => {
        const newLog = {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          ...log,
        }

        set((state) => ({
          logs: [...state.logs, newLog],
        }))
      },

      clearLogs: () =>
        set((state) => {
          // Add meta-log for log clearing
          const metaLog = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: "כל הלוגים נמחקו",
            user: "system",
          }

          return {
            logs: [metaLog],
          }
        }),

      addSystemLog: (log) => {
        const newLog = {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          type: "system",
          message: `${log.action}: ${log.details}`,
          user: log.userType || log.userId || "system",
          details: { action: log.action, details: log.details, userId: log.userId, userType: log.userType },
        }

        set((state) => ({
          logs: [...state.logs, newLog],
        }))
      },

      // Email templates
      addEmailTemplate: (template) => {
        const id = Date.now().toString()

        set((state) => {
          // Add log for email template addition
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `תבנית אימייל חדשה נוצרה: ${template.name}`,
            user: "system",
            details: { template: { ...template, id } },
          }

          return {
            emailTemplates: [...state.emailTemplates, { id, ...template }],
            logs: [...state.logs, logEntry],
          }
        })

        return id
      },

      updateEmailTemplate: (id, template) => {
        set((state) => {
          const currentTemplate = state.emailTemplates.find((t) => t.id === id)

          // Add log for email template update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `תבנית אימייל עודכנה: ${currentTemplate?.name || id}`,
            user: "system",
            details: { templateId: id, changes: template },
          }

          return {
            emailTemplates: state.emailTemplates.map((t) => (t.id === id ? { ...t, ...template } : t)),
            logs: [...state.logs, logEntry],
          }
        })
      },

      deleteEmailTemplate: (id) => {
        set((state) => {
          const template = state.emailTemplates.find((t) => t.id === id)

          // Add log for email template deletion
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `תבנית אימייל נמחקה: ${template?.name || id}`,
            user: "system",
            details: { templateId: id },
          }

          return {
            emailTemplates: state.emailTemplates.filter((t) => t.id !== id),
            logs: [...state.logs, logEntry],
          }
        })
      },

      // Social sharing
      addSocialShare: (share) => {
        const id = Date.now().toString()

        set((state) => {
          // Add log for social share
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `שיתוף ברשת חברתית: ${share.customerName} שיתף ב-${share.platform}`,
            user: "system",
            details: { share: { ...share, id, date: new Date().toISOString() } },
          }

          return {
            socialShares: [
              ...state.socialShares,
              {
                ...share,
                id,
                date: new Date().toISOString(),
                pointsAwarded: false,
              },
            ],
            logs: [...state.logs, logEntry],
          }
        })

        return id
      },

      awardPointsForSocialShare: (shareId) => {
        set((state) => {
          const share = state.socialShares.find((s) => s.id === shareId)
          if (!share || share.pointsAwarded) return state

          const customer = state.customers.find((c) => c.id === share.customerId)
          if (!customer) return state

          // Award points (default 20 points per share)
          const pointsToAdd = 20

          // Add log for social share points
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `נקודות עבור שיתוף: ${customer.name} קיבל ${pointsToAdd} נקודות עבור שיתוף ב-${share.platform}`,
            user: "system",
            details: { shareId, customerId: share.customerId, points: pointsToAdd },
          }

          // Update customer with points
          const updatedCustomers = state.customers.map((c) =>
            c.id === share.customerId
              ? {
                  ...c,
                  loyaltyPoints: (c.loyaltyPoints || 0) + pointsToAdd,
                }
              : c,
          )

          // Add notification
          const newNotification = {
            id: Date.now().toString(),
            type: "points",
            message: `קיבלת ${pointsToAdd} נקודות נאמנות עבור שיתוף ב${share.platform}`,
            date: new Date().toISOString(),
            isRead: false,
            userId: share.customerId,
          }

          // Update share with pointsAwarded flag
          const updatedShares = state.socialShares.map((s) =>
            s.id === shareId
              ? {
                  ...s,
                  pointsAwarded: true,
                }
              : s,
          )

          return {
            customers: updatedCustomers,
            socialShares: updatedShares,
            notifications: [...state.notifications, newNotification],
            logs: [...state.logs, logEntry],
          }
        })
      },

      // Product recommendations
      getRecommendedProducts: (customerId, limit = 5) => {
        const state = get()
        const customer = state.customers.find((c) => c.id === customerId)
        if (!customer) return []

        // Get customer's past orders
        const customerOrders = state.orders.filter((o) => o.customerId === customerId)

        // If no past orders, return popular products
        if (customerOrders.length === 0) {
          // Return active products sorted by stock (lower stock = more popular)
          return state.products
            .filter((p) => p.status === "active")
            .sort((a, b) => a.stock - b.stock)
            .slice(0, limit)
        }

        // Get all products the customer has purchased
        const purchasedProductIds = new Set()
        customerOrders.forEach((order) => {
          order.items.forEach((item) => {
            purchasedProductIds.add(item.productId)
          })
        })

        // Get categories of purchased products
        const purchasedCategories = new Set()
        state.products
          .filter((p) => purchasedProductIds.has(p.id))
          .forEach((p) => {
            purchasedCategories.add(p.category)
          })

        // Recommend products from the same categories that the customer hasn't purchased
        const recommendations = state.products
          .filter((p) => p.status === "active" && purchasedCategories.has(p.category) && !purchasedProductIds.has(p.id))
          .slice(0, limit)

        // If we don't have enough recommendations, add popular products
        if (recommendations.length < limit) {
          const popularProducts = state.products
            .filter(
              (p) =>
                p.status === "active" && !purchasedProductIds.has(p.id) && !recommendations.some((r) => r.id === p.id),
            )
            .sort((a, b) => a.stock - b.stock)
            .slice(0, limit - recommendations.length)

          return [...recommendations, ...popularProducts]
        }

        return recommendations
      },

      // Invoice management
      addInvoice: (invoice) => {
        const id = invoice.id || Date.now().toString()

        set((state) => {
          // Add log for invoice creation
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `חשבונית חדשה: ${invoice.customerName} - סה"כ ${invoice.total}₪`,
            user: "system",
            details: { invoice: { ...invoice, id } },
          }

          return {
            invoices: [...state.invoices, { ...invoice, id }],
            logs: [...state.logs, logEntry],
          }
        })

        return id
      },

      updateInvoice: (id, invoice) => {
        set((state) => {
          const currentInvoice = state.invoices.find((i) => i.id === id)

          // Add log for invoice update
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `חשבונית עודכנה: ${currentInvoice?.customerName || id}`,
            user: "system",
            details: { invoiceId: id, changes: invoice },
          }

          return {
            invoices: state.invoices.map((i) => (i.id === id ? { ...i, ...invoice } : i)),
            logs: [...state.logs, logEntry],
          }
        })
      },

      deleteInvoice: (id) => {
        set((state) => {
          const invoice = state.invoices.find((i) => i.id === id)

          // Add log for invoice deletion
          const logEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            type: "system" as const,
            message: `חשבונית נמחקה: ${invoice?.customerName || id}`,
            user: "system",
            details: { invoiceId: id },
          }

          return {
            invoices: state.invoices.filter((i) => i.id !== id),
            logs: [...state.logs, logEntry],
          }
        })
      },

      getInvoiceById: (id) => {
        const state = get()
        return state.invoices.find((i) => i.id === id)
      },
    }),
    {
      name: "may-beauty-storage",
      version: 0, // Reset version to 0 to start fresh
      storage: createJSONStorage(() => createCustomStorage()),
      // Remove the migrate function for now to start fresh
      partialize: (state) => {
        // Only persist essential data, exclude large collections that grow over time
        const {
          analytics, // Exclude analytics from persistence
          logs, // Exclude logs from persistence
          notifications, // Exclude notifications from persistence
          ...persistedState
        } = state

        // Only include a limited subset of analytics data
        return {
          ...persistedState,
          // Include only essential analytics data with limited size
          analytics: {
            uniqueVisitors: analytics.uniqueVisitors,
            // Only include top 20 most viewed pages
            pageViews: Object.entries(analytics.pageViews || {})
              .sort(([, a], [, b]) => Number(b) - Number(a))
              .slice(0, 20)
              .reduce((obj, [key, value]) => ({ ...obj, [key]: value }), {}),
            // Only include top 10 referrers
            referrers: Object.entries(analytics.referrers || {})
              .sort(([, a], [, b]) => Number(b) - Number(a))
              .slice(0, 10)
              .reduce((obj, [key, value]) => ({ ...obj, [key]: value }), {}),
          },
          // Include only the 50 most recent notifications
          notifications: (state.notifications || []).slice(-50),
          // Include only the 50 most recent logs
          logs: (state.logs || []).slice(-50),
        }
      },
    },
  ),
)

// Add a function to clear the store if needed
export const clearStore = () => {
  if (typeof window !== "undefined") {
    window.localStorage.removeItem("may-beauty-storage")
    window.location.reload()
  }
}
