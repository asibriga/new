import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Check if an appointment overlaps with existing appointments
export function checkAppointmentOverlap(
  startTime: string,
  duration: number,
  date: string,
  appointments: any[],
  excludeId?: string,
) {
  // Convert start time to minutes since midnight
  const [startHour, startMinute] = startTime.split(":").map(Number)
  const startMinutes = startHour * 60 + startMinute

  // Calculate end time in minutes
  const endMinutes = startMinutes + duration

  // Filter appointments for the same date and not cancelled
  const appointmentsOnDate = appointments.filter(
    (appointment) =>
      appointment.date === date &&
      appointment.status !== "cancelled" &&
      !appointment.isWaitlist &&
      appointment.id !== excludeId,
  )

  // Check for overlap with each appointment
  for (const appointment of appointmentsOnDate) {
    // Get appointment start time
    const [appStartHour, appStartMinute] = appointment.time.split(":").map(Number)
    const appStartMinutes = appStartHour * 60 + appStartMinute

    // Get appointment duration
    let appDuration = 0

    // Try to get duration from notes
    if (appointment.notes) {
      try {
        const notesData = JSON.parse(appointment.notes)
        if (notesData.totalDuration) {
          appDuration = notesData.totalDuration
        }
      } catch (e) {
        console.error("Error parsing appointment notes:", e)
      }
    }

    // If no duration in notes, try to get from service
    if (!appDuration) {
      // Find the service to get its duration
      const service = appointment.serviceId
        ? window.store?.getState().services.find((s) => s.id === appointment.serviceId)
        : null

      appDuration = service ? service.duration : 60 // Default to 60 minutes if service not found
    }

    // Calculate appointment end time
    const appEndMinutes = appStartMinutes + appDuration

    // Check for overlap
    // Overlap occurs if:
    // 1. New appointment starts during existing appointment
    // 2. New appointment ends during existing appointment
    // 3. New appointment completely contains existing appointment
    if (
      (startMinutes >= appStartMinutes && startMinutes < appEndMinutes) ||
      (endMinutes > appStartMinutes && endMinutes <= appEndMinutes) ||
      (startMinutes <= appStartMinutes && endMinutes >= appEndMinutes)
    ) {
      return true
    }
  }

  return false
}

// Calculate end time for an appointment
export function calculateEndTime(startTime: string, duration: number) {
  const [hours, minutes] = startTime.split(":").map(Number)
  const startDate = new Date()
  startDate.setHours(hours, minutes, 0, 0)
  const endDate = new Date(startDate.getTime() + duration * 60000)
  return `${endDate.getHours().toString().padStart(2, "0")}:${endDate.getMinutes().toString().padStart(2, "0")}`
}
